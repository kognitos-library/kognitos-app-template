import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { I18nProvider, useI18n, useTranslation } from './context';
import { defaultTranslations } from './translations';

// ============================================================================
// TEST COMPONENT
// ============================================================================

function TestComponent() {
  const { t, locale, translations } = useI18n();
  return (
    <div>
      <span data-testid="locale">{locale}</span>
      <span data-testid="simple-key">{t('chat.emptyStateTitle')}</span>
      <span data-testid="nested-key">{t('chat.input.placeholder')}</span>
      <span data-testid="translations-check">
        {translations.chat.emptyStateTitle}
      </span>
    </div>
  );
}

function TestComponentWithParams() {
  const { t } = useI18n();
  return (
    <div>
      <span data-testid="interpolated">
        {t('chat.thinking.completedWithDuration', { duration: '5s' })}
      </span>
      <span data-testid="file-type">
        {t('chat.attachment.ariaLabelFileType', { type: 'pdf' })}
      </span>
    </div>
  );
}

function TestComponentUseTranslation() {
  const title = useTranslation('chat.emptyStateTitle');
  const withParams = useTranslation('chat.thinking.completedWithDuration', {
    duration: '10s',
  });
  return (
    <div>
      <span data-testid="title">{title}</span>
      <span data-testid="with-params">{withParams}</span>
    </div>
  );
}

// ============================================================================
// TESTS
// ============================================================================

describe('I18n Context', () => {
  describe('useI18n without Provider', () => {
    it('should return default English translations when used outside provider', () => {
      render(<TestComponent />);

      expect(screen.getByTestId('locale')).toHaveTextContent('en');
      expect(screen.getByTestId('simple-key')).toHaveTextContent(
        'No messages yet',
      );
      expect(screen.getByTestId('nested-key')).toHaveTextContent('Type here');
    });

    it('should support interpolation without provider', () => {
      render(<TestComponentWithParams />);

      expect(screen.getByTestId('interpolated')).toHaveTextContent(
        'Neurosymbolized for 5s',
      );
      expect(screen.getByTestId('file-type')).toHaveTextContent(
        'pdf file type',
      );
    });
  });

  describe('I18nProvider', () => {
    it('should provide default translations', () => {
      render(
        <I18nProvider>
          <TestComponent />
        </I18nProvider>,
      );

      expect(screen.getByTestId('locale')).toHaveTextContent('en');
      expect(screen.getByTestId('simple-key')).toHaveTextContent(
        'No messages yet',
      );
      expect(screen.getByTestId('translations-check')).toHaveTextContent(
        'No messages yet',
      );
    });

    it('should allow setting a custom locale', () => {
      render(
        <I18nProvider locale="es">
          <TestComponent />
        </I18nProvider>,
      );

      expect(screen.getByTestId('locale')).toHaveTextContent('es');
    });

    it('should allow partial translation overrides', () => {
      const customTranslations = {
        chat: {
          emptyStateTitle: 'Sin mensajes todavía',
        },
      };

      render(
        <I18nProvider locale="es" translations={customTranslations}>
          <TestComponent />
        </I18nProvider>,
      );

      // Overridden value
      expect(screen.getByTestId('simple-key')).toHaveTextContent(
        'Sin mensajes todavía',
      );
      // Non-overridden value should fall back to English
      expect(screen.getByTestId('nested-key')).toHaveTextContent('Type here');
    });

    it('should deeply merge nested translations', () => {
      const customTranslations = {
        chat: {
          input: {
            placeholder: 'Escribe aquí',
          },
        },
      };

      render(
        <I18nProvider translations={customTranslations}>
          <TestComponent />
        </I18nProvider>,
      );

      expect(screen.getByTestId('nested-key')).toHaveTextContent(
        'Escribe aquí',
      );
      // Other chat translations should remain unchanged
      expect(screen.getByTestId('simple-key')).toHaveTextContent(
        'No messages yet',
      );
    });

    it('should support interpolation with custom translations', () => {
      const customTranslations = {
        chat: {
          thinking: {
            completedWithDuration: 'Neurosymbolized en {duration}',
          },
        },
      };

      render(
        <I18nProvider translations={customTranslations}>
          <TestComponentWithParams />
        </I18nProvider>,
      );

      expect(screen.getByTestId('interpolated')).toHaveTextContent(
        'Neurosymbolized en 5s',
      );
    });
  });

  describe('useTranslation hook', () => {
    it('should return a single translation value', () => {
      render(
        <I18nProvider>
          <TestComponentUseTranslation />
        </I18nProvider>,
      );

      expect(screen.getByTestId('title')).toHaveTextContent('No messages yet');
    });

    it('should support interpolation', () => {
      render(
        <I18nProvider>
          <TestComponentUseTranslation />
        </I18nProvider>,
      );

      expect(screen.getByTestId('with-params')).toHaveTextContent(
        'Neurosymbolized for 10s',
      );
    });
  });

  describe('Translation function (t)', () => {
    it('should return the key if translation is missing', () => {
      const consoleWarnSpy = vi
        .spyOn(console, 'warn')
        .mockImplementation(() => {});

      function TestMissingKey() {
        const { t } = useI18n();
        return <span data-testid="missing">{t('nonexistent.key')}</span>;
      }

      render(
        <I18nProvider>
          <TestMissingKey />
        </I18nProvider>,
      );

      expect(screen.getByTestId('missing')).toHaveTextContent(
        'nonexistent.key',
      );
      expect(consoleWarnSpy).toHaveBeenCalledWith(
        '[Lattice i18n] Missing translation for key: "nonexistent.key"',
      );

      consoleWarnSpy.mockRestore();
    });

    it('should handle multiple interpolation params', () => {
      // The ariaLabel has {direction} and {timestamp} placeholders
      function TestMultipleParams() {
        const { t } = useI18n();
        return (
          <span data-testid="multi">
            {t('chat.message.ariaLabel', {
              direction: 'Incoming',
              timestamp: ' at 10:30 AM',
            })}
          </span>
        );
      }

      render(
        <I18nProvider>
          <TestMultipleParams />
        </I18nProvider>,
      );

      expect(screen.getByTestId('multi')).toHaveTextContent(
        'Incoming message at 10:30 AM',
      );
    });

    it('should preserve unmatched placeholders', () => {
      function TestUnmatchedPlaceholder() {
        const { t } = useI18n();
        return (
          <span data-testid="unmatched">
            {t('chat.thinking.completedWithDuration', {})}
          </span>
        );
      }

      render(
        <I18nProvider>
          <TestUnmatchedPlaceholder />
        </I18nProvider>,
      );

      // Should preserve {duration} since no value was provided
      expect(screen.getByTestId('unmatched')).toHaveTextContent(
        'Neurosymbolized for {duration}',
      );
    });

    it('should convert numeric params to strings', () => {
      function TestNumericParam() {
        const { t } = useI18n();
        return (
          <span data-testid="numeric">
            {t('chat.thinking.completedWithDuration', { duration: 5 })}
          </span>
        );
      }

      render(
        <I18nProvider>
          <TestNumericParam />
        </I18nProvider>,
      );

      expect(screen.getByTestId('numeric')).toHaveTextContent(
        'Neurosymbolized for 5',
      );
    });
  });

  describe('defaultTranslations', () => {
    it('should have all required chat translations', () => {
      expect(defaultTranslations.chat.emptyStateTitle).toBe('No messages yet');
      expect(defaultTranslations.chat.emptyStateDescription).toContain(
        'Your Agent is ready',
      );
      expect(defaultTranslations.chat.ariaLabelConversation).toBe(
        'Chat conversation',
      );
      expect(defaultTranslations.chat.input.placeholder).toBe('Type here');
      expect(defaultTranslations.chat.input.ariaLabelAddAttachment).toBe(
        'Add attachment',
      );
      expect(defaultTranslations.chat.input.ariaLabelStop).toBe('Stop');
      expect(defaultTranslations.chat.input.ariaLabelSendMessage).toBe(
        'Send message',
      );
    });

    it('should have all required command translations', () => {
      expect(defaultTranslations.command.dialogTitle).toBe('Command palette');
      expect(defaultTranslations.command.dialogDescription).toBe(
        'Search for a command to run...',
      );
    });

    it('should have all required pagination translations', () => {
      expect(defaultTranslations.pagination.previous).toBe('Previous');
      expect(defaultTranslations.pagination.next).toBe('Next');
      expect(defaultTranslations.pagination.morePages).toBe('More pages');
      expect(defaultTranslations.pagination.ariaLabelPrevious).toBe(
        'Go to previous page',
      );
      expect(defaultTranslations.pagination.ariaLabelNext).toBe(
        'Go to next page',
      );
    });

    it('should have all required date picker translations', () => {
      expect(defaultTranslations.datePicker.placeholder).toBe('Pick a date');
      expect(defaultTranslations.datePicker.placeholderRange).toBe(
        'Pick a date range',
      );
      expect(defaultTranslations.datePicker.placeholderInput).toBe(
        'Select date',
      );
    });

    it('should have all required combobox translations', () => {
      expect(defaultTranslations.combobox.placeholder).toBe('Select option...');
      expect(defaultTranslations.combobox.placeholderMulti).toBe(
        'Select options...',
      );
      expect(defaultTranslations.combobox.searchPlaceholder).toBe('Search...');
      expect(defaultTranslations.combobox.emptyMessage).toBe(
        'No option found.',
      );
      expect(defaultTranslations.combobox.emptyMessageMulti).toBe(
        'No options found.',
      );
    });
  });
});
