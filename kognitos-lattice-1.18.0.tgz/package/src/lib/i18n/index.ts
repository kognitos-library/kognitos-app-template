/**
 * Internationalization (i18n) support for the Lattice design system
 *
 * This module provides localization capabilities for all user-facing strings
 * in the design system components.
 *
 * @example
 * ```tsx
 * import { I18nProvider, useI18n } from '@kognitos/lattice';
 *
 * // Wrap your app with the provider
 * function App() {
 *   return (
 *     <I18nProvider locale="en" translations={customTranslations}>
 *       <MyApp />
 *     </I18nProvider>
 *   );
 * }
 *
 * // Use translations in components
 * function MyComponent() {
 *   const { t } = useI18n();
 *   return <p>{t('chat.emptyStateTitle')}</p>;
 * }
 * ```
 */

export { I18nProvider, useI18n, useTranslation } from './context';
export type { II18nContextValue, II18nProviderProps } from './context';
export type { ITranslations, PartialTranslations } from './types';
export { defaultTranslations } from './translations';
