import * as React from 'react';
import type { ITranslations, PartialTranslations } from './types';
import { defaultTranslations } from './translations';

// ============================================================================
// TYPES
// ============================================================================

export interface II18nContextValue {
  /**
   * Current locale identifier (e.g., 'en', 'es', 'fr')
   */
  locale: string;

  /**
   * Complete translations object with all strings
   */
  translations: ITranslations;

  /**
   * Translation function that supports interpolation
   * @param key - Dot-notation key path (e.g., 'chat.emptyStateTitle')
   * @param params - Optional parameters for interpolation
   */
  t: (key: string, params?: Record<string, string | number>) => string;
}

export interface II18nProviderProps {
  /**
   * Child components that will have access to translations
   */
  children: React.ReactNode;

  /**
   * Current locale identifier
   * @default 'en'
   */
  locale?: string;

  /**
   * Custom translations to override defaults
   * Can be a partial object - missing keys will use default English translations
   */
  translations?: PartialTranslations;
}

// ============================================================================
// UTILITIES
// ============================================================================

/**
 * Deep merge two objects, with source overriding target
 */
function deepMerge<T extends object>(target: T, source: Partial<T>): T {
  const result = { ...target };

  for (const key in source) {
    const sourceValue = source[key];
    const targetValue = target[key];

    if (
      sourceValue !== undefined &&
      typeof sourceValue === 'object' &&
      sourceValue !== null &&
      !Array.isArray(sourceValue) &&
      typeof targetValue === 'object' &&
      targetValue !== null &&
      !Array.isArray(targetValue)
    ) {
      // Recursively merge nested objects
      (result as Record<string, unknown>)[key] = deepMerge(
        targetValue as object,
        sourceValue as Partial<typeof targetValue>,
      );
    } else if (sourceValue !== undefined) {
      // Override with source value
      (result as Record<string, unknown>)[key] = sourceValue;
    }
  }

  return result;
}

/**
 * Get a nested value from an object using dot notation
 * @param obj - The object to traverse
 * @param path - Dot-notation path (e.g., 'chat.input.placeholder')
 */
function getNestedValue(obj: object, path: string): string | undefined {
  const keys = path.split('.');
  let current: unknown = obj;

  for (const key of keys) {
    if (
      current === null ||
      current === undefined ||
      typeof current !== 'object'
    ) {
      return undefined;
    }
    current = (current as Record<string, unknown>)[key];
  }

  return typeof current === 'string' ? current : undefined;
}

/**
 * Interpolate parameters into a string template
 * @param template - String with {key} placeholders
 * @param params - Key-value pairs for interpolation
 */
function interpolate(
  template: string,
  params?: Record<string, string | number>,
): string {
  if (!params) return template;

  return template.replace(/\{(\w+)\}/g, (_, key) => {
    const value = params[key];
    return value !== undefined ? String(value) : `{${key}}`;
  });
}

// ============================================================================
// CONTEXT
// ============================================================================

const I18nContext = React.createContext<II18nContextValue | null>(null);

// ============================================================================
// PROVIDER
// ============================================================================

/**
 * I18n Provider for the Lattice design system
 *
 * Provides translations to all child components. Wrap your application with this
 * provider to enable localization support.
 *
 * @example
 * ```tsx
 * // Using default English translations
 * <I18nProvider>
 *   <App />
 * </I18nProvider>
 *
 * // With custom translations
 * const spanishTranslations = {
 *   chat: {
 *     emptyStateTitle: 'Sin mensajes todavía',
 *     emptyStateDescription: 'Tu agente está listo para ayudar...',
 *   },
 * };
 *
 * <I18nProvider locale="es" translations={spanishTranslations}>
 *   <App />
 * </I18nProvider>
 * ```
 */
export function I18nProvider({
  children,
  locale = 'en',
  translations: customTranslations,
}: II18nProviderProps) {
  // Merge custom translations with defaults
  const translations = React.useMemo<ITranslations>(() => {
    if (!customTranslations) {
      return defaultTranslations;
    }
    return deepMerge(
      defaultTranslations,
      customTranslations as Partial<ITranslations>,
    );
  }, [customTranslations]);

  // Translation function with interpolation support
  const t = React.useCallback(
    (key: string, params?: Record<string, string | number>): string => {
      const value = getNestedValue(translations, key);
      if (value === undefined) {
        console.warn(`[Lattice i18n] Missing translation for key: "${key}"`);
        return key;
      }
      return interpolate(value, params);
    },
    [translations],
  );

  const contextValue = React.useMemo<II18nContextValue>(
    () => ({
      locale,
      translations,
      t,
    }),
    [locale, translations, t],
  );

  return <I18nContext value={contextValue}>{children}</I18nContext>;
}

// ============================================================================
// HOOKS
// ============================================================================

/**
 * Hook to access i18n context
 *
 * Returns the translation function and current locale.
 * Falls back to default translations if used outside of I18nProvider.
 *
 * @example
 * ```tsx
 * function MyComponent() {
 *   const { t, locale } = useI18n();
 *
 *   return (
 *     <div>
 *       <p>Current locale: {locale}</p>
 *       <p>{t('chat.emptyStateTitle')}</p>
 *       <p>{t('chat.thinking.completedWithDuration', { duration: '5s' })}</p>
 *     </div>
 *   );
 * }
 * ```
 */
export function useI18n(): II18nContextValue {
  const context = React.use(I18nContext);

  // Provide fallback for components used outside of I18nProvider
  if (!context) {
    return {
      locale: 'en',
      translations: defaultTranslations,
      t: (key: string, params?: Record<string, string | number>) => {
        const value = getNestedValue(defaultTranslations, key);
        if (value === undefined) {
          return key;
        }
        return interpolate(value, params);
      },
    };
  }

  return context;
}

/**
 * Hook to get a specific translation directly
 *
 * Convenience hook for getting a single translation value.
 *
 * @example
 * ```tsx
 * function ChatEmptyState() {
 *   const title = useTranslation('chat.emptyStateTitle');
 *   const description = useTranslation('chat.emptyStateDescription');
 *
 *   return (
 *     <EmptyState title={title} description={description} />
 *   );
 * }
 * ```
 */
export function useTranslation(
  key: string,
  params?: Record<string, string | number>,
): string {
  const { t } = useI18n();
  return t(key, params);
}
