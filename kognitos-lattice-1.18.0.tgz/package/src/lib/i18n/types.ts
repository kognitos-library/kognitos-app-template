/**
 * Translation keys for the Lattice design system
 *
 * All user-facing strings that can be localized are defined here.
 * Components use these keys to look up translations from the current locale.
 */
export interface ITranslations {
  // ============================================================================
  // CHAT COMPONENTS
  // ============================================================================
  chat: {
    /** Empty state title when there are no messages */
    emptyStateTitle: string;
    /** Empty state description when there are no messages */
    emptyStateDescription: string;
    /** Aria label for the chat conversation region */
    ariaLabelConversation: string;

    // Chat Input
    input: {
      /** Default placeholder for the chat input */
      placeholder: string;
      /** Aria label for the add attachment button */
      ariaLabelAddAttachment: string;
      /** Aria label for the stop button */
      ariaLabelStop: string;
      /** Aria label for the send message button */
      ariaLabelSendMessage: string;
    };

    // Chat Message
    message: {
      /** Label for incoming messages */
      incoming: string;
      /** Label for outgoing messages */
      outgoing: string;
      /** Aria label template for messages. Use {direction} and {timestamp} placeholders */
      ariaLabel: string;
      /** Default avatar alt text */
      avatarAltDefault: string;
    };

    // Chat Message Attachment
    attachment: {
      /** Aria label template for file type. Use {type} placeholder */
      ariaLabelFileType: string;
      /** Aria label for remove attachment button */
      ariaLabelRemove: string;
    };

    // Chat Status
    status: {
      /** Default status text (loading state) */
      defaultText: string;
    };

    // Chat Thinking Message
    thinking: {
      /** Default thinking title */
      title: string;
      /** Completed thinking without duration */
      completed: string;
      /** Completed thinking with duration. Use {duration} placeholder */
      completedWithDuration: string;
      /** Aria label for collapse thinking button */
      ariaLabelCollapse: string;
      /** Aria label for expand thinking button */
      ariaLabelExpand: string;
    };
  };

  // ============================================================================
  // PRIMITIVES
  // ============================================================================

  // Command
  command: {
    /** Default dialog title */
    dialogTitle: string;
    /** Default dialog description */
    dialogDescription: string;
  };

  // Pagination
  pagination: {
    /** Aria label for go to previous page */
    ariaLabelPrevious: string;
    /** Previous page button text */
    previous: string;
    /** Aria label for go to next page */
    ariaLabelNext: string;
    /** Next page button text */
    next: string;
    /** Screen reader text for ellipsis (more pages) */
    morePages: string;
  };

  // Date Picker
  datePicker: {
    /** Default placeholder for single date picker */
    placeholder: string;
    /** Default placeholder for date range picker */
    placeholderRange: string;
    /** Default placeholder for date input picker */
    placeholderInput: string;
  };

  // Combobox
  combobox: {
    /** Default placeholder for single select */
    placeholder: string;
    /** Default placeholder for multi select */
    placeholderMulti: string;
    /** Default search input placeholder */
    searchPlaceholder: string;
    /** Default empty message for single select */
    emptyMessage: string;
    /** Default empty message for multi select */
    emptyMessageMulti: string;
  };

  // Flow Chart
  flowChart: {
    /** Error title when the flow chart cannot be loaded */
    errorTitle: string;
    /** Error description when the flow chart cannot be loaded */
    errorDescription: string;
    /** Error action label when the flow chart cannot be loaded */
    errorActionLabel: string;
  };
}

/**
 * Deep partial type for translations
 * Allows consumers to provide only the translations they want to override
 */
export type PartialTranslations = DeepPartial<ITranslations>;

/**
 * Helper type for deep partial objects
 */
type DeepPartial<T> = {
  [P in keyof T]?: T[P] extends object ? DeepPartial<T[P]> : T[P];
};
