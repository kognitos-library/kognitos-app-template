import type { ITranslations } from './types';

/**
 * Default English translations for the Lattice design system
 *
 * These translations serve as the fallback when no custom translations are provided.
 * Consumers can override any of these values through the I18nProvider.
 */
export const defaultTranslations: ITranslations = {
  // ============================================================================
  // CHAT COMPONENTS
  // ============================================================================
  chat: {
    emptyStateTitle: 'No messages yet',
    emptyStateDescription:
      'Your Agent is ready to assist — type anything to begin.',
    ariaLabelConversation: 'Chat conversation',

    input: {
      placeholder: 'Type here',
      ariaLabelAddAttachment: 'Add attachment',
      ariaLabelStop: 'Stop',
      ariaLabelSendMessage: 'Send message',
    },

    message: {
      incoming: 'Incoming',
      outgoing: 'Outgoing',
      ariaLabel: '{direction} message{timestamp}',
      avatarAltDefault: 'user',
    },

    attachment: {
      ariaLabelFileType: '{type} file type',
      ariaLabelRemove: 'Remove attachment',
    },

    status: {
      defaultText: 'Neurosymbolizing...',
    },

    thinking: {
      title: 'Neurosymbolizing...',
      completed: 'Neurosymbolized',
      completedWithDuration: 'Neurosymbolized for {duration}',
      ariaLabelCollapse: 'Collapse thinking',
      ariaLabelExpand: 'Expand thinking',
    },
  },

  // ============================================================================
  // PRIMITIVES
  // ============================================================================

  command: {
    dialogTitle: 'Command palette',
    dialogDescription: 'Search for a command to run...',
  },

  pagination: {
    ariaLabelPrevious: 'Go to previous page',
    previous: 'Previous',
    ariaLabelNext: 'Go to next page',
    next: 'Next',
    morePages: 'More pages',
  },

  datePicker: {
    placeholder: 'Pick a date',
    placeholderRange: 'Pick a date range',
    placeholderInput: 'Select date',
  },

  combobox: {
    placeholder: 'Select option...',
    placeholderMulti: 'Select options...',
    searchPlaceholder: 'Search...',
    emptyMessage: 'No option found.',
    emptyMessageMulti: 'No options found.',
  },

  flowChart: {
    errorTitle: "Couldn't load the diagram",
    errorDescription:
      'There was an issue displaying this workflow. Please try refreshing the page or try again later.',
    errorActionLabel: 'Refresh',
  },
};
