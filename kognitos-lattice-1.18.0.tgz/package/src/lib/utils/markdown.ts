/**
 * Validates that a URL is safe for use in markdown links.
 * Allows HTTP and HTTPS protocols, but blocks dangerous schemes like javascript:, data:, etc.
 *
 * @param url - The URL string to validate
 * @returns true if the URL is safe for markdown links, false otherwise
 *
 * @example
 * isValidMarkdownLinkUrl('https://example.com') // true
 * isValidMarkdownLinkUrl('http://example.com') // true
 * isValidMarkdownLinkUrl('javascript:alert(1)') // false (dangerous scheme)
 * isValidMarkdownLinkUrl('data:text/html,<script>alert(1)</script>') // false (dangerous scheme)
 */
export function isValidMarkdownLinkUrl(
  url: string | null | undefined,
): boolean {
  if (!url || typeof url !== 'string' || url.trim() === '') {
    return false;
  }

  try {
    const parsedUrl = new URL(url);
    const protocol = parsedUrl.protocol.toLowerCase();

    // Only allow http and https protocols for security
    // Block dangerous protocols like javascript:, data:, file:, etc.
    return protocol === 'http:' || protocol === 'https:';
  } catch {
    // If URL parsing fails, it's not a valid URL
    return false;
  }
}
