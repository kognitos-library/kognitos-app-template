/**
 * Theme Utilities
 * Utility functions for theme management and CSS variable access
 */

import type { TTheme } from '../../theme/theme-context';

/**
 * Get the computed value of a CSS variable from the document root
 * @param variableName - The CSS variable name (with or without -- prefix)
 * @returns The computed value of the CSS variable
 *
 * @example
 * ```typescript
 * // Get shadow value
 * const shadowValue = getTokenValue('--shadow-xl');
 *
 * // Get theme color
 * const primaryColor = getTokenValue('--primary');
 *
 * // Works with or without -- prefix
 * const accentColor = getTokenValue('accent-foreground');
 * ```
 */
export function getTokenValue(variableName: string): string {
  if (typeof document === 'undefined') {
    return ''; // Return empty string for SSR
  }

  // Ensure variable name has -- prefix
  const normalizedName = variableName.startsWith('--')
    ? variableName
    : `--${variableName}`;

  const styles = getComputedStyle(document.documentElement);
  return styles.getPropertyValue(normalizedName).trim();
}

/**
 * Apply theme to document root
 * @param theme - The theme to apply ('light', 'dark', or 'system')
 */
export const applyTheme = (theme: TTheme = 'light') => {
  if (typeof document === 'undefined') {
    return; // No-op for SSR
  }

  const root = document.documentElement;

  // Remove existing theme classes
  root.classList.remove('light', 'dark');

  if (theme === 'system') {
    const systemTheme = window.matchMedia('(prefers-color-scheme: dark)')
      .matches
      ? 'dark'
      : 'light';
    root.classList.add(systemTheme);
    return;
  }

  // Add theme class - CSS variables automatically switch based on this class
  root.classList.add(theme);
};
