import { describe, it, expect } from 'vitest';
import { isValidMarkdownLinkUrl } from './markdown';

describe('isValidMarkdownLinkUrl', () => {
  it('should return true for valid HTTPS URLs', () => {
    expect(isValidMarkdownLinkUrl('https://example.com')).toBe(true);
    expect(isValidMarkdownLinkUrl('https://example.com/path')).toBe(true);
    expect(
      isValidMarkdownLinkUrl('https://example.com/path?query=value#fragment'),
    ).toBe(true);
  });

  it('should return true for valid HTTP URLs', () => {
    expect(isValidMarkdownLinkUrl('http://example.com')).toBe(true);
    expect(isValidMarkdownLinkUrl('http://localhost:3000')).toBe(true);
  });

  it('should return false for dangerous URL schemes', () => {
    expect(isValidMarkdownLinkUrl('javascript:alert(1)')).toBe(false);
    expect(
      isValidMarkdownLinkUrl('data:text/html,<script>alert(1)</script>'),
    ).toBe(false);
    expect(isValidMarkdownLinkUrl('file:///etc/passwd')).toBe(false);
    expect(isValidMarkdownLinkUrl('ftp://example.com')).toBe(false);
    expect(isValidMarkdownLinkUrl('vbscript:msgbox("XSS")')).toBe(false);
  });

  it('should return false for invalid URLs', () => {
    expect(isValidMarkdownLinkUrl('not-a-url')).toBe(false);
    expect(isValidMarkdownLinkUrl('')).toBe(false);
    expect(isValidMarkdownLinkUrl('   ')).toBe(false);
  });

  it('should return false for null or undefined', () => {
    expect(isValidMarkdownLinkUrl(null)).toBe(false);
    expect(isValidMarkdownLinkUrl(undefined)).toBe(false);
  });

  it('should return false for non-string values', () => {
    expect(isValidMarkdownLinkUrl(123 as unknown as string)).toBe(false);
    expect(isValidMarkdownLinkUrl({} as unknown as string)).toBe(false);
    expect(isValidMarkdownLinkUrl([] as unknown as string)).toBe(false);
  });
});
