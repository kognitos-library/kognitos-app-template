import { describe, it, expect } from 'vitest';
import { toISO8601 } from './date';

// ============================================================================
// DATE UTILITIES TESTS
// ============================================================================

describe('toISO8601', () => {
  describe('Date object input', () => {
    it('should convert Date object to ISO 8601 string', () => {
      const date = new Date('2024-01-15T14:30:00Z');
      const result = toISO8601(date);

      expect(result).toBe('2024-01-15T14:30:00.000Z');
    });

    it('should handle Date objects with milliseconds', () => {
      const date = new Date('2024-01-15T14:30:00.123Z');
      const result = toISO8601(date);

      expect(result).toBe('2024-01-15T14:30:00.123Z');
    });

    it('should handle Date objects in different timezones', () => {
      const date = new Date('2024-01-15T14:30:00');
      const result = toISO8601(date);

      // Should always return UTC format
      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });

    it('should handle Date objects at midnight', () => {
      const date = new Date('2024-01-15T00:00:00Z');
      const result = toISO8601(date);

      expect(result).toBe('2024-01-15T00:00:00.000Z');
    });

    it('should handle Date objects at end of day', () => {
      const date = new Date('2024-01-15T23:59:59.999Z');
      const result = toISO8601(date);

      expect(result).toBe('2024-01-15T23:59:59.999Z');
    });
  });

  describe('String input', () => {
    it('should convert ISO string to ISO 8601 format', () => {
      const isoString = '2024-01-15T14:30:00Z';
      const result = toISO8601(isoString);

      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });

    it('should convert date string without timezone to ISO 8601', () => {
      const dateString = '2024-01-15T14:30:00';
      const result = toISO8601(dateString);

      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });

    it('should convert date-only string to ISO 8601', () => {
      const dateString = '2024-01-15';
      const result = toISO8601(dateString);

      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });

    it('should handle RFC 2822 format string', () => {
      const rfcString = 'Mon, 15 Jan 2024 14:30:00 GMT';
      const result = toISO8601(rfcString);

      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });

    it('should handle timestamp string with milliseconds', () => {
      const timestampString = '2024-01-15T14:30:00.123Z';
      const result = toISO8601(timestampString);

      expect(result).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });
  });

  describe('Null and undefined input', () => {
    it('should return null for null input', () => {
      const result = toISO8601(null);
      expect(result).toBeNull();
    });

    it('should return null for undefined input', () => {
      const result = toISO8601(undefined);
      expect(result).toBeNull();
    });
  });

  describe('Edge cases', () => {
    it('should handle leap year dates', () => {
      const leapYearDate = new Date('2024-02-29T12:00:00Z');
      const result = toISO8601(leapYearDate);

      expect(result).toBe('2024-02-29T12:00:00.000Z');
    });

    it('should handle year boundaries', () => {
      const newYearDate = new Date('2024-01-01T00:00:00Z');
      const result = toISO8601(newYearDate);

      expect(result).toBe('2024-01-01T00:00:00.000Z');
    });

    it('should handle end of year', () => {
      const endYearDate = new Date('2024-12-31T23:59:59.999Z');
      const result = toISO8601(endYearDate);

      expect(result).toBe('2024-12-31T23:59:59.999Z');
    });

    it('should handle dates far in the past', () => {
      const pastDate = new Date('1970-01-01T00:00:00Z');
      const result = toISO8601(pastDate);

      expect(result).toBe('1970-01-01T00:00:00.000Z');
    });

    it('should handle dates far in the future', () => {
      const futureDate = new Date('2099-12-31T23:59:59.999Z');
      const result = toISO8601(futureDate);

      expect(result).toBe('2099-12-31T23:59:59.999Z');
    });
  });

  describe('Consistency', () => {
    it('should produce consistent results for same input', () => {
      const date = new Date('2024-01-15T14:30:00Z');
      const result1 = toISO8601(date);
      const result2 = toISO8601(date);
      const result3 = toISO8601(date);

      expect(result1).toBe(result2);
      expect(result2).toBe(result3);
      expect(result1).toBe('2024-01-15T14:30:00.000Z');
    });

    it('should produce same result for Date object and equivalent string', () => {
      const date = new Date('2024-01-15T14:30:00Z');
      const dateString = '2024-01-15T14:30:00Z';

      const resultFromDate = toISO8601(date);
      const resultFromString = toISO8601(dateString);

      // Both should be valid ISO 8601 strings
      expect(resultFromDate).toMatch(
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/,
      );
      expect(resultFromString).toMatch(
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/,
      );
    });
  });

  describe('Format validation', () => {
    it('should always return valid ISO 8601 format', () => {
      const testCases = [
        new Date('2024-01-15T14:30:00Z'),
        '2024-01-15T14:30:00Z',
        '2024-01-15T14:30:00',
        '2024-01-15',
      ];

      testCases.forEach(input => {
        const result = toISO8601(input);
        if (result) {
          // ISO 8601 format: YYYY-MM-DDTHH:mm:ss.sssZ
          expect(result).toMatch(
            /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/,
          );
        }
      });
    });

    it('should return string ending with Z for UTC timezone', () => {
      const date = new Date('2024-01-15T14:30:00Z');
      const result = toISO8601(date);

      expect(result).toMatch(/Z$/);
      expect(result?.endsWith('Z')).toBe(true);
    });
  });
});
