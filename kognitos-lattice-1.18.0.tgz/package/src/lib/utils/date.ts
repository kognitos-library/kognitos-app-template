import dayjs from 'dayjs';

/**
 * Converts a date or string timestamp to ISO 8601 format for use in HTML datetime attributes.
 *
 * @param timestamp - Date object or ISO string
 * @returns ISO 8601 formatted string, or null if timestamp is not provided
 *
 * @example
 * toISO8601(new Date('2024-01-15T14:30:00')) // "2024-01-15T14:30:00.000Z"
 * toISO8601('2024-01-15T14:30:00') // "2024-01-15T14:30:00.000Z"
 * toISO8601(null) // null
 */
export function toISO8601(
  timestamp: Date | string | null | undefined,
): string | null {
  if (!timestamp) {
    return null;
  }

  if (typeof timestamp === 'string') {
    return new Date(timestamp).toISOString();
  }

  return timestamp.toISOString();
}

/**
 * Formats a Date object to a string using the specified format
 * Used for formatting Date objects directly (e.g., in date pickers)
 *
 * Uses dayjs format strings directly. See https://day.js.org/docs/en/display/format
 * Common format tokens:
 * - Date: YYYY (year), YY (2-digit year), MMMM (month name), MMM (short month), MM (month number), DD (day), dddd (day name), ddd (short day), d (day of week 0-6)
 * - Time: HH (24-hour), hh (12-hour), mm (minutes), ss (seconds), A (AM/PM)
 *
 * @param date - Date object to format
 * @param format - Format string in dayjs format (default: "MMMM D, YYYY")
 * @returns Formatted date string
 */
export function formatDate(
  date: Date | undefined,
  format: string = 'MMMM D, YYYY',
): string {
  if (!date) return '';
  const dayjsDate = dayjs(date);
  if (!dayjsDate.isValid()) {
    return '';
  }

  return dayjsDate.format(format);
}
