import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Responsive column configuration for grid layouts.
 * Each breakpoint specifies the number of columns at that screen size.
 */
export interface IResponsiveColumns {
  /** Number of columns for extra small screens (< 640px) */
  xs?: number;
  /** Number of columns for small screens (≥ 640px) */
  sm?: number;
  /** Number of columns for medium screens (≥ 768px) */
  md?: number;
  /** Number of columns for large screens (≥ 1024px) */
  lg?: number;
}

/**
 * Tailwind grid column classes - explicit for Tailwind's purge to work.
 * Use these for responsive grid columns.
 */
export const gridColsClasses: Record<string, Record<number, string>> = {
  xs: {
    1: 'grid-cols-1',
    2: 'grid-cols-2',
    3: 'grid-cols-3',
    4: 'grid-cols-4',
    5: 'grid-cols-5',
    6: 'grid-cols-6',
  },
  sm: {
    1: 'sm:grid-cols-1',
    2: 'sm:grid-cols-2',
    3: 'sm:grid-cols-3',
    4: 'sm:grid-cols-4',
    5: 'sm:grid-cols-5',
    6: 'sm:grid-cols-6',
  },
  md: {
    1: 'md:grid-cols-1',
    2: 'md:grid-cols-2',
    3: 'md:grid-cols-3',
    4: 'md:grid-cols-4',
    5: 'md:grid-cols-5',
    6: 'md:grid-cols-6',
  },
  lg: {
    1: 'lg:grid-cols-1',
    2: 'lg:grid-cols-2',
    3: 'lg:grid-cols-3',
    4: 'lg:grid-cols-4',
    5: 'lg:grid-cols-5',
    6: 'lg:grid-cols-6',
  },
};
