/// <reference types="vite/client" />

// CSS module declarations
declare module '*.css';

// SVG as React component declarations (Vite's ?react suffix)
declare module '*.svg?react' {
  import type { FC, SVGProps } from 'react';
  const ReactComponent: FC<SVGProps<SVGSVGElement>>;
  export default ReactComponent;
}
