import type { Meta, StoryObj } from '@storybook/react';
import { EmptyState } from '@/design-system';

const meta: Meta<typeof EmptyState> = {
  title: 'Design System/Components/Empty State',
  component: EmptyState,
  tags: ['autodocs'],
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A higher-level empty state component for displaying when there is no content to show. Built on top of the Empty primitive with convenient props for common use cases.',
      },
    },
  },
  argTypes: {
    icon: {
      control: { type: 'text' },
      description: 'The icon to display (Lucide icon name)',
    },
    title: {
      control: { type: 'text' },
      description: 'The title text to display',
    },
    description: {
      control: { type: 'text' },
      description: 'The description text to display',
    },
    actionLabel: {
      control: { type: 'text' },
      description: 'The label for the primary action button',
    },
    actionIcon: {
      control: { type: 'text' },
      description: 'The icon for the primary action button',
    },
    actionVariant: {
      control: { type: 'select' },
      options: [
        'default',
        'destructive',
        'outline',
        'secondary',
        'ghost',
        'link',
      ],
      description: 'The variant of the primary action button',
    },
    actionSize: {
      control: { type: 'select' },
      options: ['default', 'sm', 'lg', 'icon'],
      description: 'The size of the primary action button',
    },
    actionLoading: {
      control: { type: 'boolean' },
      description: 'Whether the primary action button is loading',
    },
    secondaryActionLabel: {
      control: { type: 'text' },
      description: 'The label for the secondary action button',
    },
    secondaryActionVariant: {
      control: { type: 'select' },
      options: [
        'default',
        'destructive',
        'outline',
        'secondary',
        'ghost',
        'link',
      ],
      description: 'The variant of the secondary action button',
    },
    secondaryActionSize: {
      control: { type: 'select' },
      options: ['default', 'sm', 'lg', 'icon'],
      description: 'The size of the secondary action button',
    },
    bordered: {
      control: { type: 'boolean' },
      description: 'Whether to show a dashed border',
    },
  },
};

export default meta;
type Story = StoryObj<typeof EmptyState>;

// Basic empty state
export const Basic: Story = {
  args: {
    icon: 'Mail',
    title: 'No messages yet',
    description: 'When you receive messages, they will appear here.',
    actionLabel: 'Send a message',
    onAction: () => console.log('Primary action clicked'),
  },
};

// Empty state with secondary action
export const WithSecondaryAction: Story = {
  args: {
    icon: 'Search',
    title: 'No results found',
    description: 'Try adjusting your search criteria or browse our categories.',
    actionLabel: 'Browse categories',
    secondaryActionLabel: 'Clear filters',
    onAction: () => console.log('Primary action clicked'),
    onSecondaryAction: () => console.log('Secondary action clicked'),
  },
};

// With action icon
export const WithActionIcon: Story = {
  args: {
    icon: 'Settings',
    title: 'Configuration required',
    description: 'Please configure your settings before proceeding.',
    actionLabel: 'Configure now',
    actionIcon: 'Settings',
    onAction: () => console.log('Configure clicked'),
  },
};

// Custom content
export const WithCustomContent: Story = {
  args: {
    icon: 'BarChart3',
    title: 'No data available',
    description:
      'Your analytics data will appear here once you start using the platform.',
    actionLabel: 'Get started',
    onAction: () => console.log('Get started clicked'),
    children: (
      <div className="mt-4 p-4 bg-muted/50 rounded-lg">
        <p className="text-sm text-muted-foreground">
          💡 <strong>Tip:</strong> Connect your first data source to see
          analytics.
        </p>
      </div>
    ),
  },
};

// No icon
export const NoIcon: Story = {
  args: {
    title: 'Page not found',
    description:
      "The page you are looking for doesn't exist or has been moved.",
    actionLabel: 'Go home',
    secondaryActionLabel: 'Go back',
    onAction: () => console.log('Go home clicked'),
    onSecondaryAction: () => console.log('Go back clicked'),
  },
};

// Without border
export const WithoutBorder: Story = {
  args: {
    bordered: false,
    icon: 'Heart',
    title: 'No favorites',
    description: 'Items you favorite will appear here.',
    actionLabel: 'Explore items',
    onAction: () => console.log('Explore clicked'),
  },
};

// Loading state
export const LoadingAction: Story = {
  args: {
    icon: 'Star',
    title: 'No reviews yet',
    description: 'Be the first to leave a review for this product.',
    actionLabel: 'Write a review',
    actionLoading: true,
    onAction: () => console.log('Write review clicked'),
  },
};
