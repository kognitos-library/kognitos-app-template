import { Flex } from '../primitives/flex';
import { Text } from '../primitives/typography';
import { Icon } from '../icons';
import { cn } from '../lib/utils';

/**
 * @deprecated Use EStepCardState from primitives instead. This enum will be removed in a future version.
 */
export enum EStepState {
  Pending = 'pending',
  Active = 'active',
  Completed = 'completed',
}

/**
 * @deprecated Use IStepperCardProps from primitives instead. This interface will be removed in a future version.
 */
export interface IStepCardProps {
  /** Step number to display in the indicator */
  stepNumber: number;
  /** Primary label/title for the step */
  label: string;
  /** Optional description text (displayed below the label) */
  description?: string;
  /** Current state of the step */
  state: EStepState;
  /** Optional click handler (makes the component interactive) */
  onClick?: () => void;
  /** Optional className for custom styling */
  className?: string;
  /** Optional data-testid for testing */
  'data-testid'?: string;
}

/**
 * @deprecated Use StepperCard from primitives instead. This component will be removed in a future version.
 * Import the new component: `import { StepperCard } from '@/design-system/primitives/stepper-card'`
 */
export function StepCard({
  stepNumber,
  label,
  description,
  state,
  onClick,
  className,
  'data-testid': testId,
}: IStepCardProps) {
  const isActive = state === EStepState.Active;
  const isPending = state === EStepState.Pending;
  const isCompleted = state === EStepState.Completed;
  const isInteractive = !!onClick;
  const isClickable = isInteractive && (isCompleted || isActive);

  const cardClasses = cn(
    'flex-1 rounded-md border p-3 min-w-[144px] transition-all duration-200',
    // State-based styling
    isActive && 'border-primary bg-primary/5',
    isPending && 'border-border',
    isCompleted && 'border-success bg-success/5',
    // Interactive states
    isInteractive && isClickable && 'hover:opacity-80 cursor-pointer',
    isInteractive && !isClickable && 'cursor-not-allowed opacity-50',
    className,
  );

  const indicatorClasses = cn(
    'size-6 rounded-full shrink-0',
    isActive && 'bg-primary',
    isPending && 'border border-border',
    isCompleted && 'bg-success',
  );

  const getIndicatorTextColor = () => {
    if (isActive) return 'text-primary-foreground';
    if (isCompleted) return 'text-success-foreground';
    return undefined;
  };

  const content = (
    <Flex
      align={description ? 'start' : 'center'}
      gap={2}
      className={isInteractive ? undefined : cardClasses}
      data-testid={isInteractive ? undefined : testId}
    >
      <Flex
        align="center"
        justify="center"
        className={indicatorClasses}
        data-testid="step-indicator"
      >
        {isCompleted ? (
          <Icon type="Check" size={14} data-testid="check-icon" />
        ) : (
          <Text
            level="small"
            weight="medium"
            className={getIndicatorTextColor()}
          >
            {stepNumber}
          </Text>
        )}
      </Flex>
      {description ? (
        <Flex direction="column" gap={1} className="min-w-0">
          <Text weight="medium">{label}</Text>
          <Text level="small" color="muted">
            {description}
          </Text>
        </Flex>
      ) : (
        <Text weight="medium">{label}</Text>
      )}
    </Flex>
  );

  if (isInteractive) {
    return (
      <button
        type="button"
        onClick={onClick}
        disabled={!isClickable}
        className={cn(cardClasses, 'text-left')}
        data-testid={testId}
      >
        {content}
      </button>
    );
  }

  return content;
}

StepCard.displayName = 'StepCard';
