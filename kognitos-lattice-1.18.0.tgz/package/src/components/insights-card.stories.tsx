import type { Meta, StoryObj } from '@storybook/react';

import { InsightsCard } from './insights-card';
import { Grid } from '../primitives/grid';

const meta = {
  title: 'Design System/Components/InsightsCard',
  component: InsightsCard,
  parameters: {
    layout: 'centered',
  },
  decorators: [
    (Story, context) => {
      // For stories that render custom content (multiple cards), use full width
      const isMultiCardStory = [
        'Multiple Cards',
        'Mixed States',
        'Without Trend',
      ].includes(context.name);

      return (
        <div
          style={{
            width: '100%',
            minWidth: isMultiCardStory ? '800px' : '400px',
            maxWidth: isMultiCardStory ? '1200px' : '500px',
          }}
        >
          <Story />
        </div>
      );
    },
  ],
  tags: ['autodocs'],
  argTypes: {
    title: {
      control: 'text',
      description: 'The title/label of the metric',
    },
    value: {
      control: 'text',
      description: 'The main value to display',
    },
    trend: {
      control: 'object',
      description: 'Optional trend indicator with value and type',
    },
    loading: {
      control: 'boolean',
      description: 'Loading state showing skeleton placeholders',
    },
    variant: {
      control: 'select',
      options: ['default', 'destructive', 'success'],
      description: 'Visual variant of the card',
    },
  },
} satisfies Meta<typeof InsightsCard>;

export default meta;
type Story = StoryObj<typeof meta>;

/**
 * Default state shows a metric with a title and value in neutral colors.
 */
export const Default: Story = {
  args: {
    title: 'Revenue',
    value: '$40,199.05',
    variant: 'default',
  },
};

/**
 * Card with a positive trend indicator showing growth.
 */
export const WithPositiveTrend: Story = {
  args: {
    title: 'Revenue',
    value: '$40,199.05',
    trend: {
      value: '+15.1%',
      type: 'positive',
    },
    variant: 'default',
  },
};

/**
 * Card with a negative trend indicator showing decline.
 */
export const WithNegativeTrend: Story = {
  args: {
    title: 'Revenue',
    value: '$40,199.05',
    trend: {
      value: '-8.2%',
      type: 'negative',
    },
    variant: 'default',
  },
};

/**
 * Loading state displays skeleton placeholders while data is being fetched.
 */
export const Loading: Story = {
  args: {
    title: 'Revenue',
    loading: true,
    trend: {
      value: '+15.1%',
      type: 'positive',
    },
  },
};

/**
 * Success variant highlights positive metrics with green text.
 */
export const Success: Story = {
  args: {
    title: 'Revenue',
    value: '$40,199.05',
    trend: {
      value: '+15.1%',
      type: 'positive',
    },
    variant: 'success',
  },
};

/**
 * Destructive variant highlights concerning metrics with red text.
 */
export const Destructive: Story = {
  args: {
    title: 'Revenue',
    value: '$40,199.05',
    trend: {
      value: '-15.1%',
      type: 'negative',
    },
    variant: 'destructive',
  },
};

/**
 * Display multiple insights cards in a grid layout.
 */
export const MultipleCards: Story = {
  args: {
    title: '',
  },
  render: () => (
    <Grid cols={2} gap={4}>
      <InsightsCard
        title="Total Revenue"
        value="$45,231.89"
        trend={{ value: '+20.1%', type: 'positive' }}
        variant="success"
      />
      <InsightsCard
        title="Subscriptions"
        value="+2,350"
        trend={{ value: '+180.1%', type: 'positive' }}
      />
    </Grid>
  ),
};

/**
 * Example with mixed states showing different metric conditions.
 */
export const MixedStates: Story = {
  args: {
    title: '',
  },
  render: () => (
    <Grid cols={2} gap={4}>
      <InsightsCard
        title="Revenue Growth"
        value="$40,199.05"
        trend={{ value: '+15.1%', type: 'positive' }}
        variant="success"
      />
      <InsightsCard
        title="Customer Churn"
        value="8.2%"
        trend={{ value: '-2.4%', type: 'negative' }}
        variant="destructive"
      />
      <InsightsCard
        title="New Signups"
        value="1,234"
        trend={{ value: '+12%', type: 'positive' }}
      />
      <InsightsCard title="Conversion Rate" loading />
    </Grid>
  ),
};

/**
 * Cards without trend indicators for simple metric display.
 */
export const WithoutTrend: Story = {
  args: {
    title: '',
  },
  render: () => (
    <Grid cols={3} gap={4}>
      <InsightsCard title="Total Users" value="2,847" />
      <InsightsCard title="Average Session" value="4m 32s" />
      <InsightsCard title="Bounce Rate" value="42.3%" />
    </Grid>
  ),
};
