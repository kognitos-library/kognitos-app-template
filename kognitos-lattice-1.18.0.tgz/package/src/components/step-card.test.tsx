import { render, screen, fireEvent } from '@testing-library/react';
import { StepCard, EStepState } from './step-card';
import { describe, it, expect, vi } from 'vitest';

describe('StepCard', () => {
  describe('Rendering', () => {
    it('should render step number and label', () => {
      render(
        <StepCard stepNumber={1} label="Configure" state={EStepState.Active} />,
      );

      expect(screen.getByText('1')).toBeInTheDocument();
      expect(screen.getByText('Configure')).toBeInTheDocument();
    });

    it('should render description when provided', () => {
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          description="Set up your configuration"
          state={EStepState.Active}
        />,
      );

      expect(screen.getByText('Configure')).toBeInTheDocument();
      expect(screen.getByText('Set up your configuration')).toBeInTheDocument();
    });

    it('should not render description when not provided', () => {
      render(
        <StepCard stepNumber={1} label="Configure" state={EStepState.Active} />,
      );

      expect(
        screen.queryByText('Set up your configuration'),
      ).not.toBeInTheDocument();
    });
  });

  describe('States', () => {
    it('should render pending state correctly', () => {
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Pending}
          data-testid="step-card"
        />,
      );

      expect(screen.getByText('1')).toBeInTheDocument();
      const indicator = screen.getByTestId('step-indicator');
      expect(indicator).toHaveClass('border');
    });

    it('should render active state correctly', () => {
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Active}
          data-testid="step-card"
        />,
      );

      expect(screen.getByText('1')).toBeInTheDocument();
      const indicator = screen.getByTestId('step-indicator');
      expect(indicator).toHaveClass('bg-primary');
    });

    it('should render completed state with check icon', () => {
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Completed}
          data-testid="step-card"
        />,
      );

      expect(screen.queryByText('1')).not.toBeInTheDocument();
      expect(screen.getByTestId('check-icon')).toBeInTheDocument();
      const indicator = screen.getByTestId('step-indicator');
      expect(indicator).toHaveClass('bg-success');
    });
  });

  describe('Interactive Mode', () => {
    it('should render as button when onClick is provided', () => {
      const handleClick = vi.fn();
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Active}
          onClick={handleClick}
          data-testid="step-card"
        />,
      );

      const button = screen.getByTestId('step-card');
      expect(button.tagName).toBe('BUTTON');
    });

    it('should call onClick when clicked and active', () => {
      const handleClick = vi.fn();
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Active}
          onClick={handleClick}
          data-testid="step-card"
        />,
      );

      fireEvent.click(screen.getByTestId('step-card'));
      expect(handleClick).toHaveBeenCalledTimes(1);
    });

    it('should call onClick when clicked and completed', () => {
      const handleClick = vi.fn();
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Completed}
          onClick={handleClick}
          data-testid="step-card"
        />,
      );

      fireEvent.click(screen.getByTestId('step-card'));
      expect(handleClick).toHaveBeenCalledTimes(1);
    });

    it('should be disabled when pending and interactive', () => {
      const handleClick = vi.fn();
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Pending}
          onClick={handleClick}
          data-testid="step-card"
        />,
      );

      const button = screen.getByTestId('step-card');
      expect(button).toBeDisabled();
      fireEvent.click(button);
      expect(handleClick).not.toHaveBeenCalled();
    });

    it('should not render as button when onClick is not provided', () => {
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Active}
          data-testid="step-card"
        />,
      );

      const element = screen.getByTestId('step-card');
      expect(element.tagName).not.toBe('BUTTON');
    });
  });

  describe('Custom Styling', () => {
    it('should apply custom className', () => {
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Active}
          className="custom-class"
          data-testid="step-card"
        />,
      );

      const element = screen.getByTestId('step-card');
      expect(element).toHaveClass('custom-class');
    });
  });

  describe('Accessibility', () => {
    it('should have accessible text content', () => {
      render(
        <StepCard
          stepNumber={1}
          label="Configure Settings"
          description="Set up your configuration"
          state={EStepState.Active}
        />,
      );

      expect(screen.getByText('Configure Settings')).toBeInTheDocument();
      expect(screen.getByText('Set up your configuration')).toBeInTheDocument();
    });

    it('should have type="button" on interactive element', () => {
      const handleClick = vi.fn();
      render(
        <StepCard
          stepNumber={1}
          label="Configure"
          state={EStepState.Active}
          onClick={handleClick}
          data-testid="step-card"
        />,
      );

      const button = screen.getByTestId('step-card');
      expect(button).toHaveAttribute('type', 'button');
    });
  });
});
