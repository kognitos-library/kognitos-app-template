import type { Meta, StoryObj } from '@storybook/react-vite';
import { ChatMessage, type IChatMessage } from '@/design-system';
import { Flex } from '../../primitives/flex';
import { Icon } from '../../icons';

const meta: Meta<typeof ChatMessage> = {
  title: 'Design System/Components/Chat/ChatMessage',
  component: ChatMessage,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A chat message component that displays individual messages with support for incoming/outgoing directions, variants (default/inline), attachments, widgets, and timestamps.',
      },
    },
  },
  argTypes: {
    message: {
      control: { type: 'object' },
      description: 'The message object to display',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatMessage>;

// Sample message data
const incomingMessage: IChatMessage = {
  id: '1',
  content: 'Hello! How can I help you today?',
  direction: 'incoming',
  timestamp: new Date('2024-01-15T10:00:00'),
  avatarFallback: 'AI',
};

const outgoingMessage: IChatMessage = {
  id: '2',
  content: 'I need help with setting up my account.',
  direction: 'outgoing',
  timestamp: new Date('2024-01-15T10:01:00'),
  avatarFallback: 'U',
};

/**
 * Default incoming message.
 */
export const IncomingDefault: Story = {
  args: {
    message: incomingMessage,
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Default outgoing message.
 */
export const OutgoingDefault: Story = {
  args: {
    message: outgoingMessage,
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Inline incoming message.
 */
export const IncomingInline: Story = {
  args: {
    message: {
      ...incomingMessage,
      content: 'This is an inline incoming message.',
      variant: 'inline',
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Inline outgoing message.
 */
export const OutgoingInline: Story = {
  args: {
    message: {
      ...outgoingMessage,
      content: 'This is an inline outgoing message.',
      variant: 'inline',
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message with avatar image.
 */
export const WithAvatarImage: Story = {
  args: {
    message: {
      ...incomingMessage,
      avatarUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=AI',
      avatarFallback: 'AI',
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message with attachments.
 */
export const WithAttachments: Story = {
  args: {
    message: {
      ...incomingMessage,
      content: 'I have attached the documents you requested.',
      attachments: [
        {
          id: 'att1',
          name: 'document.pdf',
          type: 'pdf',
        },
        {
          id: 'att2',
          name: 'data.xlsx',
          type: 'excel',
        },
      ],
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message with multiple attachment types.
 */
export const WithMultipleAttachments: Story = {
  args: {
    message: {
      ...incomingMessage,
      content: 'Here are all the files you requested.',
      attachments: [
        {
          id: 'att1',
          name: 'document.pdf',
          type: 'pdf',
        },
        {
          id: 'att2',
          name: 'spreadsheet.xlsx',
          type: 'excel',
        },
        {
          id: 'att3',
          name: 'notes.txt',
          type: 'text',
        },
        {
          id: 'att4',
          name: 'photo.jpg',
          type: 'image',
        },
      ],
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message with widget (button group).
 */
export const WithButtonGroupWidget: Story = {
  args: {
    message: {
      ...incomingMessage,
      content: undefined,
      widget: {
        type: 'button-group',
        buttons: [
          {
            id: 'btn1',
            label: 'Yes, please',
            variant: 'default',
            onClick: () => console.log('Yes clicked'),
          },
          {
            id: 'btn2',
            label: 'No, thanks',
            variant: 'outline',
            onClick: () => console.log('No clicked'),
          },
        ],
      },
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message with widget (action cards).
 */
export const WithActionCardsWidget: Story = {
  args: {
    message: {
      ...incomingMessage,
      content: undefined,
      widget: {
        type: 'action-cards',
        actionCards: [
          {
            id: 'card1',
            title: 'View Dashboard',
            imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=1',
            fallbackIcon: <Icon type="BarChart" className="size-4" />,
            actionProps: {
              label: 'Open',
              onClick: () => console.log('Dashboard clicked'),
            },
          },
          {
            id: 'card2',
            title: 'Check Settings',
            imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=2',
            fallbackIcon: <Icon type="Settings" className="size-4" />,
            actionProps: {
              label: 'View',
              onClick: () => console.log('Settings clicked'),
            },
          },
        ],
      },
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message without timestamp.
 */
export const WithoutTimestamp: Story = {
  args: {
    message: {
      ...incomingMessage,
      timestamp: undefined,
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message without avatar.
 */
export const WithoutAvatar: Story = {
  args: {
    message: {
      ...incomingMessage,
      avatarUrl: undefined,
      avatarFallback: undefined,
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Long message to test text wrapping.
 */
export const LongMessage: Story = {
  args: {
    message: {
      ...incomingMessage,
      content:
        'This is a very long message that should wrap properly within the chat bubble. It contains multiple sentences and should demonstrate how the component handles text overflow and wrapping in different scenarios. The message continues here with even more content to ensure proper wrapping behavior.',
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Message variants comparison.
 */
export const VariantsComparison: Story = {
  render: () => (
    <Flex className="w-full max-w-md p-4">
      <Flex direction="column" gap={4}>
        <ChatMessage
          message={{
            id: '1',
            content: 'Default incoming message',
            direction: 'incoming',
            variant: 'default',
            timestamp: new Date('2024-01-15T10:00:00'),
            avatarFallback: 'AI',
          }}
        />
        <ChatMessage
          message={{
            id: '2',
            content: 'Inline incoming message',
            direction: 'incoming',
            variant: 'inline',
            timestamp: new Date('2024-01-15T10:01:00'),
            avatarFallback: 'AI',
          }}
        />
        <ChatMessage
          message={{
            id: '3',
            content: 'Default outgoing message',
            direction: 'outgoing',
            variant: 'default',
            timestamp: new Date('2024-01-15T10:02:00'),
            avatarFallback: 'U',
          }}
        />
        <ChatMessage
          message={{
            id: '4',
            content: 'Inline outgoing message',
            direction: 'outgoing',
            variant: 'inline',
            timestamp: new Date('2024-01-15T10:03:00'),
            avatarFallback: 'U',
          }}
        />
      </Flex>
    </Flex>
  ),
};

/**
 * Message with markdown formatting showcasing all supported markdown features.
 * Demonstrates headings, bold, italic, code blocks, lists, links, blockquotes, and more.
 */
export const WithMarkdown: Story = {
  args: {
    message: {
      id: 'markdown-1',
      content: `
This message demonstrates **all** the markdown features supported in chat messages.

You can use **bold text**, *italic text*, and \`inline code\` in your messages.

You can also use \\n to create a \n \n new line.

Here's a code block example:

\`\`\`javascript
function greet(name) {
  return \`Hello, \${name}!\`;
}
\`\`\`

**Unordered List**
- First item
- Second item
- Third item with **bold** and *italic*

**Ordered List**
1. First step
2. Second step
3. Third step


Visit [our documentation](https://example.com/docs) for more information.

> This is a blockquote. It's useful for highlighting important information or quotes.
`,
      direction: 'incoming',
      timestamp: new Date('2024-01-15T10:00:00'),
      avatarFallback: 'AI',
    },
  },
  render: args => (
    <Flex className="w-full max-w-2xl p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

/**
 * Incoming message with markdown formatting (default variant).
 */
export const IncomingMarkdown: Story = {
  args: {
    message: {
      id: 'markdown-2',
      content: `Here's a helpful guide:

## Quick Tips

1. Use **bold** for emphasis
2. Use \`code\` for technical terms
3. Use [links](https://example.com) for references

> Remember: Markdown makes messages more readable!`,
      direction: 'incoming',
      timestamp: new Date('2024-01-15T10:00:00'),
      avatarFallback: 'AI',
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};

export const WithMarkdownLongText: Story = {
  args: {
    message: {
      id: 'markdown-3',
      direction: 'incoming',
      timestamp: new Date('2024-01-15T10:00:00'),
      avatarFallback: 'AI',
      content:
        "## Exception Analysis\n\nI found the issue. Here's what happened:\n\n**Original Problem:** Step 4 of your process tried to divide 1 by 0, which caused an arithmetic error (division by zero).\n\n**Current Problem:** Someone attempted to fix this by replacing the division with `pass # Skipping division by zero`, but Spy (the language running your automation) doesn't recognize the `pass` keyword. That's why you're now seeing the error \"variable not found: pass\".\n\n## Context\n\nLooking at your process:\n1. Step 1: Calculate 4 × 345 ✓ (completed: 1380)\n2. Step 2: Calculate 4 + 45 ✓ (completed: 49)\n3. Step 3: Calculate 234 + 56 ✓ (completed: 290)\n4. Step 4: **Divide 1 by 0** ← This is where it failed\n5. Steps 5-6: Comments about division-by-zero halting the automation\n6. Steps 7-8: Additional calculations that haven't run yet\n\n## Suggested Fix\n\nSince dividing by zero isn't mathematically possible, I recommend setting the result to a placeholder value that allows the process to continue. Here's what I suggest:\n\n**Replace the failing operation with:**\n```python\nresult4 = None  # Division by zero not possible\n```\n\nThis will:\n- Skip the impossible calculation\n- Store a clear indicator that this step couldn't be completed\n- Allow steps 7-8 to continue and complete the process\n\nWould you like me to apply this fix and resume the automation?",
    },
  },
  render: args => (
    <Flex className="w-full max-w-md p-4">
      <ChatMessage {...args} />
    </Flex>
  ),
};
