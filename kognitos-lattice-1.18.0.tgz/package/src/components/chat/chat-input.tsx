import { use, useRef, useState } from 'react';

import { cn, useI18n } from '@/design-system/lib/utils';
import {
  InputGroup,
  InputGroupTextarea,
  InputGroupAddon,
  InputGroupButton,
} from '../../primitives/input-group';
import { Textarea } from '../../primitives/textarea';
import { Flex } from '../../primitives/flex';
import { Icon, type IconType } from '../../icons';
import { Spinner } from '../../primitives/spinner';
import { Button } from '../../primitives/button';
import { ChatMessageAttachment } from './chat-message-attachment';
import type { IChatAttachment } from './types';
import { Text } from '../../primitives/typography';
import { ChatContext } from './chat';
import { calculateMultilineLayout } from './utils';
import { cva } from 'class-variance-authority';

const chatInputBackgrounds = cva('', {
  variants: {
    background: {
      transparent: 'bg-transparent',
      background: 'bg-background dark:bg-white/4.5',
      muted: 'bg-muted',
      primary: 'bg-primary',
      secondary: 'bg-secondary',
      accent: 'bg-accent',
      destructive: 'bg-destructive',
      card: 'bg-card',
    },
  },
  defaultVariants: {
    background: 'background',
  },
});

export type TChatInputBackground =
  | 'transparent'
  | 'muted'
  | 'primary'
  | 'secondary'
  | 'accent'
  | 'destructive'
  | 'card';

// ============================================================================
// TYPES
// ============================================================================

export interface IChatInputProps extends React.ComponentProps<'textarea'> {
  attachments?: IChatAttachment[];
  /** Callback when files are selected via the attachment button or pasted from clipboard */
  onAddAttachments?: (files: File[]) => void;
  /** Accepted file types for the attachment input (e.g., "image/*,.pdf") */
  acceptedFileTypes?: string;
  /** Allow pasting files from clipboard. When enabled and files are pasted, onAddAttachments is called. Defaults to false. */
  allowFilePaste?: boolean;
  onAttachmentRemove?: (attachmentId: string) => void;
  onSend?: (value: string) => void;
  onStop?: () => void;
  showAttachmentButton?: boolean;
  showSendButton?: boolean;
  isLoading?: boolean;
  loadingMode?: 'stop' | 'loader';
  placeholder?: string;
  maxRows?: number;
  /** The 'minimal' variant is deprecated. Use 'inline' instead. */
  variant?: 'default' | 'minimal' | 'inline';
  /** Icon type for inline variant */
  inlineIcon?: IconType;
  /** Error message to display for inline variant */
  errorMessage?: string;
  /** Background color for the input container. Defaults to 'background'. */
  background?: TChatInputBackground;
  /** Class name for the input container. */
  inputClassName?: string;
}

// ============================================================================
// CHAT INPUT COMPONENT
// ============================================================================

const defaultAttachments: IChatAttachment[] = [];

/**
 * Chat input field with support for attachments and send/stop controls.
 *
 * Supports both controlled and uncontrolled modes:
 * - Controlled: Provide both `value` and `onChange` props together
 * - Uncontrolled: Omit both `value` and `onChange` props
 *
 * ⚠️ Warning: Providing `value` without `onChange` will make the input readonly.
 *
 * Supports three variants:
 * - `default`: Full-featured multi-line textarea with attachments, buttons, and loading states
 * - `minimal`: Single-line input with transparent background, no border, and no attachments (deprecated, use 'inline' instead)
 * - `inline`: Single-line input with transparent background, no border, and left icon
 *
 * Supports Enter to send (Shift+Enter for new line in default variant), attachment preview,
 * and loading states with stop button (default variant only).
 *
 * @param {IChatInputProps} props - Component props
 * @param {'default' | 'minimal' | 'inline'} [props.variant='default'] - Visual variant of the input
 * @param {string} [props.value] - Controlled value
 * @param {(e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>) => void} [props.onChange] - Change handler
 * @param {(value: string) => void} [props.onSend] - Callback when message should be sent
 * @param {IChatAttachment[]} [props.attachments] - Attachment list (default variant only)
 * @param {boolean} [props.isLoading] - Loading state (default variant only)
 *
 * @example
 * ```tsx
 * // Default variant - Controlled usage
 * <ChatInput
 *   value={inputValue}
 *   onChange={e => setInputValue(e.target.value)}
 *   onSend={value => handleSend(value)}
 *   attachments={attachments}
 *   onAddAttachments={files => handleAddAttachments(files)}
 *   onAttachmentRemove={id => handleRemoveAttachment(id)}
 *   isLoading={isLoading}
 *   loadingMode="stop"
 *   onStop={() => handleStop()}
 * />
 *
 * // Inline variant
 * <ChatInput
 *   variant="inline"
 *   value={inputValue}
 *   onChange={e => setInputValue(e.target.value)}
 *   onSend={value => handleSend(value)}
 *   placeholder="Type your message"
 *   inlineIcon="Sparkle"
 * />
 * ```
 */
function ChatInput({
  className,
  attachments = defaultAttachments,
  onAddAttachments,
  acceptedFileTypes,
  allowFilePaste = false,
  onAttachmentRemove,
  onSend,
  onStop,
  showAttachmentButton = true,
  showSendButton = true,
  isLoading = false,
  loadingMode = 'stop',
  placeholder,
  maxRows = 10,
  disabled,
  value,
  onChange,
  onKeyDown,
  onPaste,
  variant,
  inlineIcon = 'Sparkle',
  errorMessage,
  background,
  inputClassName,
  ...props
}: IChatInputProps) {
  if (process.env.NODE_ENV !== 'production' && variant === 'minimal') {
    console.warn(
      '[ChatInput] The "minimal" variant is deprecated. Use "inline" instead. This will be removed in the next major version.',
    );
  }

  const { t } = useI18n();
  const resolvedPlaceholder = placeholder ?? t('chat.input.placeholder');
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const context = use(ChatContext);

  // Resolve variant: prioritize prop > context from parent > default
  const resolvedVariant = variant ?? context.variant ?? 'default';

  const hasAttachments = attachments && attachments.length > 0;
  const isDisabled = disabled || isLoading;
  const isInline =
    resolvedVariant === 'inline' || resolvedVariant === 'minimal';
  const maxRowsToDisplay = hasAttachments ? Math.max(maxRows - 3, 1) : maxRows;

  const [isMultiLine, setIsMultiLine] = useState(false);

  // Show stop button when parent says isLoading with stop mode
  const showStopButton =
    isLoading && loadingMode === 'stop' && showSendButton && !!onStop;

  // Runtime check: warn if value is provided without onChange (readonly input)
  if (value !== undefined && !onChange) {
    console.warn(
      'ChatInput: `value` prop provided without `onChange`. Input will be readonly.',
    );
  }

  // Component supports both controlled and uncontrolled modes
  const isControlled = value !== undefined;
  const currentValue = isControlled ? value : '';

  // Reusable canvas for measuring text width (avoids creating new canvas on every keystroke)
  const measureCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Checks for multiline vs single line layout changes for inline
  const handleChange = (
    e: React.ChangeEvent<HTMLTextAreaElement | HTMLInputElement>,
  ) => {
    onChange?.(e as React.ChangeEvent<HTMLTextAreaElement>);

    if (isInline) {
      const textarea = e.target as HTMLTextAreaElement;
      const result = calculateMultilineLayout({
        textarea,
        isMultiLine,
        measureCanvas: measureCanvasRef.current,
      });

      // Update canvas ref for reuse
      measureCanvasRef.current = result.measureCanvas;

      // Only update state if it changed
      if (result.shouldBeMultiLine !== isMultiLine) {
        setIsMultiLine(result.shouldBeMultiLine);
      }
    }
  };

  const handleKeyDown = (
    e: React.KeyboardEvent<HTMLTextAreaElement | HTMLInputElement>,
  ) => {
    // Send on Enter (but not Shift+Enter) - disabled when loading or disabled
    if (e.key === 'Enter' && !e.shiftKey && !isDisabled && onSend) {
      e.preventDefault();
      const stringValue = String(currentValue || '');
      const hasText = stringValue.trim().length > 0;
      // Allow sending if there's text or attachments
      if (hasText || hasAttachments) {
        onSend(stringValue);
        setIsMultiLine(false);
        // Parent component should clear the value via the value prop
      }
    }
    onKeyDown?.(e as React.KeyboardEvent<HTMLTextAreaElement>);
  };

  const handleSend = () => {
    const stringValue = String(currentValue || '');
    const hasText = stringValue.trim().length > 0;
    // Allow sending if there's text or attachments (attachments only in default variant)
    if ((hasText || hasAttachments) && onSend) {
      onSend(stringValue);
      setIsMultiLine(false);
      // Parent component should clear the value via the value prop
    }
  };

  const handleStop = () => {
    onStop?.();
  };

  const handleAttachmentButtonClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0 && onAddAttachments) {
      onAddAttachments(Array.from(files));
    }
    // Reset the input so the same file can be selected again
    e.target.value = '';
    // Refocus the textarea so Enter sends the message
    textareaRef.current?.focus();
  };

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    // Only handle file paste if enabled and onAddAttachments is provided
    if (allowFilePaste && onAddAttachments) {
      const clipboardFiles = e.clipboardData?.files;
      if (clipboardFiles && clipboardFiles.length > 0) {
        e.preventDefault();
        onAddAttachments(Array.from(clipboardFiles));
        return; // Skip user's onPaste when files are handled
      }
    }
    // Call user's onPaste handler for non-file paste events
    onPaste?.(e);
  };

  // Shared attachments list component
  const attachmentsList = hasAttachments ? (
    <div className="w-full overflow-x-auto overflow-y-hidden">
      <Flex direction="row" gap={2} align="start" className="min-w-max">
        {attachments.map(attachment => (
          <div key={attachment.id}>
            <ChatMessageAttachment
              attachment={attachment}
              onRemove={() => onAttachmentRemove?.(attachment.id)}
            />
          </div>
        ))}
      </Flex>
    </div>
  ) : null;

  // Inline variant - minimal borderless design
  if (isInline) {
    return (
      <Flex
        width="full"
        align="start"
        gap={2}
        paddingY={2}
        paddingX={0}
        data-slot="chat-input"
        data-testid="chat-input"
        data-type="inline"
        data-loading={isLoading ? 'true' : 'false'}
        data-disabled={isDisabled ? 'true' : 'false'}
        className={cn('group relative min-h-10 rounded-md', className)}
      >
        <Flex direction="row" gap={2} align="center" width="full">
          <Icon
            type={inlineIcon}
            size={16}
            className={cn(
              'shrink-0 self-start mt-4 text-foreground',
              isDisabled && 'opacity-50',
            )}
          />
          <Flex
            direction="column"
            width="full"
            gap={2}
            align="start"
            className="min-w-0"
          >
            <Flex
              direction="column"
              width="full"
              paddingY={1.5}
              paddingX={3.5}
              className={cn(
                'shadow-sm border border-input rounded-md min-w-0',
                // Focus state - border-ring and shadow-md
                'focus-within:border-ring focus-within:shadow-md',
                // Error state - destructive border persists on focus, but shadow-md still applies
                errorMessage &&
                  'border-destructive focus-within:border-destructive',
                hasAttachments && 'pt-3.5',
                chatInputBackgrounds({ background }),
                inputClassName,
              )}
            >
              {/* Attachments row */}
              {attachmentsList && (
                <div className="w-full pb-2 overflow-x-auto">
                  {attachmentsList}
                </div>
              )}

              {/* Textarea + buttons row (single-line) OR just textarea (multi-line) */}
              <Flex
                direction="row"
                width="full"
                align="center"
                justify="between"
              >
                <Textarea
                  ref={textareaRef}
                  variant="inline"
                  placeholder={placeholder}
                  value={currentValue}
                  onChange={handleChange}
                  onKeyDown={handleKeyDown}
                  onPaste={handlePaste}
                  disabled={isDisabled}
                  aria-invalid={!!errorMessage}
                  aria-describedby={
                    errorMessage ? 'chat-input-error' : undefined
                  }
                  rows={1}
                  {...props}
                />

                {/* Hidden file input */}
                <input
                  ref={fileInputRef}
                  type="file"
                  multiple
                  accept={acceptedFileTypes}
                  onChange={handleFileInputChange}
                  className="hidden"
                  aria-hidden="true"
                  tabIndex={-1}
                />

                {/* Buttons on the right - only when single-line */}
                {!isMultiLine && (showAttachmentButton || showSendButton) && (
                  <Flex
                    direction="row"
                    gap={2}
                    align="center"
                    className="shrink-0"
                  >
                    {showAttachmentButton && (
                      <Button
                        variant="ghost"
                        size="icon-xs"
                        onClick={handleAttachmentButtonClick}
                        disabled={isDisabled}
                        aria-label="Add attachment"
                        className="text-muted-foreground"
                      >
                        <Icon type="Paperclip" size={16} />
                      </Button>
                    )}
                    {showSendButton && (
                      <Button
                        variant="ghost"
                        size="icon-xs"
                        onClick={showStopButton ? handleStop : handleSend}
                        disabled={
                          !showStopButton &&
                          (isDisabled ||
                            !!errorMessage ||
                            (String(currentValue || '').trim().length === 0 &&
                              !hasAttachments))
                        }
                        aria-label={showStopButton ? 'Stop' : 'Send message'}
                        className="text-muted-foreground"
                      >
                        <Icon
                          type={showStopButton ? 'CircleStop' : 'ArrowUp'}
                          size={16}
                        />
                      </Button>
                    )}
                  </Flex>
                )}
              </Flex>

              {/* Buttons row - only when multi-line, paperclip left, send right */}
              {isMultiLine && (
                <Flex
                  direction="row"
                  width="full"
                  align="center"
                  justify="between"
                  paddingY={1.5}
                >
                  {showAttachmentButton && (
                    <Button
                      variant="ghost"
                      size="icon-xs"
                      onClick={handleAttachmentButtonClick}
                      disabled={isDisabled}
                      aria-label="Add attachment"
                      className="text-muted-foreground"
                    >
                      <Icon type="Paperclip" size={16} />
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon-xs"
                    onClick={showStopButton ? handleStop : handleSend}
                    disabled={isDisabled || !!errorMessage}
                    aria-label="Send message"
                    className="text-muted-foreground ml-auto"
                  >
                    <Icon
                      type={showStopButton ? 'CircleStop' : 'ArrowUp'}
                      size={16}
                    />
                  </Button>
                </Flex>
              )}
            </Flex>
            {/* Error message */}
            {errorMessage && (
              <Text
                level="small"
                color="destructive"
                role="alert"
                aria-live="polite"
                id="chat-input-error"
              >
                {errorMessage}
              </Text>
            )}
          </Flex>
        </Flex>
      </Flex>
    );
  }

  // Default variant: Full-featured multi-line textarea with attachments and buttons
  return (
    <div
      data-slot="chat-input"
      data-testid="chat-input"
      data-type="default"
      data-loading={isLoading ? 'true' : 'false'}
      data-disabled={isDisabled ? 'true' : 'false'}
      data-has-attachments={hasAttachments ? 'true' : 'false'}
      className={cn('relative w-full', className)}
      style={
        {
          '--chat-input-max-rows': maxRowsToDisplay,
        } as React.CSSProperties
      }
    >
      <Flex direction="column" gap={2.5} className="relative h-full">
        {/* Input Group with Textarea */}
        <InputGroup
          data-disabled={isDisabled ? 'true' : undefined}
          className={cn(
            'max-h-full',
            chatInputBackgrounds({ background }),
            inputClassName,
          )}
        >
          {/* Attachments - using block-start addon for proper spacing */}
          {attachmentsList && (
            <InputGroupAddon align="block-start">
              {attachmentsList}
            </InputGroupAddon>
          )}

          <InputGroupTextarea
            ref={textareaRef}
            placeholder={resolvedPlaceholder}
            value={currentValue}
            onChange={handleChange}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            className="overflow-y-auto resize-none max-h-[calc(var(--chat-input-max-rows)*1.3rem)]"
            {...props}
          />

          {/* Hidden file input for multi-file selection */}
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept={acceptedFileTypes}
            onChange={handleFileInputChange}
            className="hidden"
            aria-hidden="true"
            tabIndex={-1}
          />

          {/* Buttons at bottom - visible by default, can be hidden via props */}
          {(showAttachmentButton || showSendButton || isLoading) && (
            <InputGroupAddon align="block-end">
              {showAttachmentButton && (
                <InputGroupButton
                  type="button"
                  variant="ghost"
                  size="icon-xs"
                  onClick={handleAttachmentButtonClick}
                  aria-label={t('chat.input.ariaLabelAddAttachment')}
                  className="rounded-sm"
                >
                  <Icon type="Paperclip" />
                </InputGroupButton>
              )}

              {showStopButton && (
                <InputGroupButton
                  type="button"
                  variant="ghost"
                  size="icon-xs"
                  onClick={onStop}
                  disabled={false}
                  aria-label={t('chat.input.ariaLabelStop')}
                  className="ml-auto rounded-sm"
                >
                  <Icon type="CircleStop" />
                </InputGroupButton>
              )}

              {isLoading && loadingMode === 'loader' && showSendButton && (
                <Flex
                  align="center"
                  justify="center"
                  className="ml-auto size-6"
                >
                  <Spinner size="sm" variant="muted" />
                </Flex>
              )}

              {!isLoading && showSendButton && (
                <InputGroupButton
                  type="button"
                  variant="ghost"
                  size="icon-xs"
                  onClick={handleSend}
                  disabled={
                    isDisabled ||
                    !!errorMessage ||
                    (String(currentValue || '').trim().length === 0 &&
                      !hasAttachments)
                  }
                  aria-label={t('chat.input.ariaLabelSendMessage')}
                  className="ml-auto rounded-sm"
                  data-testid="chat-input-send-button"
                >
                  <Icon type="ArrowUp" />
                </InputGroupButton>
              )}
            </InputGroupAddon>
          )}
        </InputGroup>
      </Flex>
    </div>
  );
}

ChatInput.displayName = 'ChatInput';

export { ChatInput };
