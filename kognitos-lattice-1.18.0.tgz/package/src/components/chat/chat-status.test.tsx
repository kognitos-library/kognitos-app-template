import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChatStatus } from './chat-status';
import { EMessageUpdateState } from './types';

describe('ChatStatus', () => {
  describe('Rendering', () => {
    it('should render with default state and shimmering text', () => {
      render(<ChatStatus text="Neurosymbolizing..." />);

      const status = screen.getByTestId('chat-status');
      expect(status).toBeInTheDocument();
      expect(status).toHaveAttribute('data-state', EMessageUpdateState.DEFAULT);

      // ShimmeringText splits text into character spans, so check textContent
      const shimmeringText = screen.getByTestId('shimmering-text');
      expect(shimmeringText.textContent).toBe('Neurosymbolizing...');
    });

    it('should render with default text when text prop is not provided', () => {
      render(<ChatStatus />);

      // ShimmeringText splits text into character spans, so check textContent
      const shimmeringText = screen.getByTestId('shimmering-text');
      expect(shimmeringText.textContent).toBe('Neurosymbolizing...');
    });

    it('should have correct data attributes', () => {
      render(<ChatStatus state={EMessageUpdateState.ERROR} />);

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveAttribute('data-slot', 'chat-status');
      expect(status).toHaveAttribute('data-testid', 'chat-status');
      expect(status).toHaveAttribute('data-state', EMessageUpdateState.ERROR);
    });
  });

  describe('States', () => {
    it('should render default state with shimmering text', () => {
      render(
        <ChatStatus state={EMessageUpdateState.DEFAULT} text="Processing..." />,
      );

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveAttribute('data-state', EMessageUpdateState.DEFAULT);

      // ShimmeringText splits text into character spans, so check textContent
      const shimmeringText = screen.getByTestId('shimmering-text');
      expect(shimmeringText.textContent).toBe('Processing...');
    });

    it('should render error state with error text', () => {
      render(
        <ChatStatus state={EMessageUpdateState.ERROR} text="Error occurred" />,
      );

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveAttribute('data-state', EMessageUpdateState.ERROR);
      expect(screen.getByText('Error occurred')).toBeInTheDocument();
    });

    it('should render warning state with warning text', () => {
      render(
        <ChatStatus
          state={EMessageUpdateState.WARNING}
          text="Warning message"
        />,
      );

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveAttribute('data-state', EMessageUpdateState.WARNING);
      expect(screen.getByText('Warning message')).toBeInTheDocument();
    });
  });

  describe('Icon Display', () => {
    it('should not render icon when showIcon is false (default)', () => {
      render(<ChatStatus state={EMessageUpdateState.ERROR} />);

      // Icon container should not be present
      expect(
        screen.queryByTestId('chat-status-icon-container'),
      ).not.toBeInTheDocument();
    });

    it('should render icon container when showIcon is true', () => {
      render(
        <ChatStatus
          state={EMessageUpdateState.ERROR}
          showIcon
          text="Error message"
        />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      expect(iconContainer).toBeInTheDocument();
      expect(iconContainer).toHaveAttribute('data-slot', 'chat-status-icon');
    });

    it('should render default AlertCircle icon for error state', () => {
      render(
        <ChatStatus state={EMessageUpdateState.ERROR} showIcon text="Error" />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      expect(iconContainer).toBeInTheDocument();

      // Icon should have error styling
      const icon = iconContainer.querySelector('svg');
      expect(icon).toBeInTheDocument();
      expect(icon).toHaveClass('text-destructive');
      expect(icon).toHaveClass('size-3');
      expect(icon).not.toHaveClass('animate-spin');
    });

    it('should render default AlertTriangle icon for warning state', () => {
      render(
        <ChatStatus
          state={EMessageUpdateState.WARNING}
          showIcon
          text="Warning"
        />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      expect(iconContainer).toBeInTheDocument();

      // Icon should have warning styling
      const icon = iconContainer.querySelector('svg');
      expect(icon).toBeInTheDocument();
      expect(icon).toHaveClass('text-warning');
      expect(icon).toHaveClass('size-3');
      expect(icon).not.toHaveClass('animate-spin');
    });

    it('should render default Loader2 icon for default state with animation', () => {
      render(
        <ChatStatus
          state={EMessageUpdateState.DEFAULT}
          showIcon
          text="Loading"
        />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      expect(iconContainer).toBeInTheDocument();

      // Icon should have default state styling with animation
      const icon = iconContainer.querySelector('svg');
      expect(icon).toBeInTheDocument();
      expect(icon).toHaveClass('animate-spin');
      expect(icon).toHaveClass('text-muted-foreground');
      expect(icon).toHaveClass('size-3');
    });

    it('should render default CircleCheckBig icon for success state', () => {
      render(
        <ChatStatus
          state={EMessageUpdateState.SUCCESS}
          showIcon
          text="Success"
        />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      expect(iconContainer).toBeInTheDocument();

      // Icon should have success styling
      const icon = iconContainer.querySelector('svg');
      expect(icon).toBeInTheDocument();
      expect(icon).toHaveClass('text-success');
      expect(icon).toHaveClass('size-3');
      expect(icon).not.toHaveClass('animate-spin');
    });

    it('should render custom icon when icon prop is provided', () => {
      render(
        <ChatStatus
          state={EMessageUpdateState.ERROR}
          showIcon
          icon="Info"
          text="Custom icon"
        />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      expect(iconContainer).toBeInTheDocument();

      // Custom icon should still have error state styling
      const icon = iconContainer.querySelector('svg');
      expect(icon).toBeInTheDocument();
      expect(icon).toHaveClass('text-destructive');
      expect(icon).toHaveClass('size-3');
    });

    it('should apply correct icon classes for each state', () => {
      // Test error state icon classes
      const { rerender } = render(
        <ChatStatus state={EMessageUpdateState.ERROR} showIcon />,
      );
      let icon = screen
        .getByTestId('chat-status-icon-container')
        .querySelector('svg');
      expect(icon).toHaveClass('text-destructive');
      expect(icon).not.toHaveClass('animate-spin');
      expect(icon).not.toHaveClass('text-warning');

      // Test warning state icon classes
      rerender(<ChatStatus state={EMessageUpdateState.WARNING} showIcon />);
      icon = screen
        .getByTestId('chat-status-icon-container')
        .querySelector('svg');
      expect(icon).toHaveClass('text-warning');
      expect(icon).not.toHaveClass('animate-spin');
      expect(icon).not.toHaveClass('text-destructive');

      // Test default state icon classes
      rerender(<ChatStatus state={EMessageUpdateState.DEFAULT} showIcon />);
      icon = screen
        .getByTestId('chat-status-icon-container')
        .querySelector('svg');
      expect(icon).toHaveClass('animate-spin');
      expect(icon).toHaveClass('text-muted-foreground');
      expect(icon).not.toHaveClass('text-destructive');
      expect(icon).not.toHaveClass('text-warning');
    });
  });

  describe('Accessibility', () => {
    it('should have aria-live="polite" for default state', () => {
      render(<ChatStatus state={EMessageUpdateState.DEFAULT} />);

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveAttribute('aria-live', 'polite');
    });

    it('should not have aria-live for error state', () => {
      render(<ChatStatus state={EMessageUpdateState.ERROR} />);

      const status = screen.getByTestId('chat-status');
      expect(status).not.toHaveAttribute('aria-live');
    });

    it('should not have aria-live for warning state', () => {
      render(<ChatStatus state={EMessageUpdateState.WARNING} />);

      const status = screen.getByTestId('chat-status');
      expect(status).not.toHaveAttribute('aria-live');
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      render(<ChatStatus className="custom-class" />);

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveClass('custom-class');
    });

    it('should apply default padding classes', () => {
      render(<ChatStatus />);

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveClass('py-2');
    });
  });

  describe('Props Spreading', () => {
    it('should spread HTML attributes to root element', () => {
      render(
        <ChatStatus data-custom="test" id="status-id" aria-label="Status" />,
      );

      const status = screen.getByTestId('chat-status');
      expect(status).toHaveAttribute('data-custom', 'test');
      expect(status).toHaveAttribute('id', 'status-id');
      expect(status).toHaveAttribute('aria-label', 'Status');
    });
  });

  describe('Text Rendering', () => {
    it('should render ShimmeringText for default state', () => {
      render(
        <ChatStatus state={EMessageUpdateState.DEFAULT} text="Loading..." />,
      );

      // ShimmeringText should be rendered with test ID
      const shimmeringText = screen.getByTestId('shimmering-text');
      expect(shimmeringText).toBeInTheDocument();
      expect(shimmeringText).toHaveClass('text-xs');
      expect(shimmeringText.textContent).toBe('Loading...');
    });

    it('should render regular Text for error state with error color', () => {
      render(
        <ChatStatus state={EMessageUpdateState.ERROR} text="Error message" />,
      );

      const textElement = screen.getByTestId('chat-status-text');
      expect(textElement).toBeInTheDocument();
      expect(textElement).toHaveTextContent('Error message');
      expect(textElement).toHaveClass('text-xs');
      expect(textElement).toHaveClass('text-destructive');
      expect(textElement).toHaveAttribute('data-slot', 'chat-status-text');
    });

    it('should render regular Text for warning state with warning color', () => {
      render(
        <ChatStatus
          state={EMessageUpdateState.WARNING}
          text="Warning message"
        />,
      );

      const textElement = screen.getByTestId('chat-status-text');
      expect(textElement).toBeInTheDocument();
      expect(textElement).toHaveTextContent('Warning message');
      expect(textElement).toHaveClass('text-xs');
      expect(textElement).toHaveClass('text-warning');
      expect(textElement).toHaveAttribute('data-slot', 'chat-status-text');
    });

    it('should apply correct text color classes for each state', () => {
      // Test error state text color
      const { rerender } = render(
        <ChatStatus state={EMessageUpdateState.ERROR} text="Error" />,
      );
      let textElement = screen.getByTestId('chat-status-text');
      expect(textElement).toHaveClass('text-destructive');
      expect(textElement).not.toHaveClass('text-warning');

      // Test warning state text color
      rerender(
        <ChatStatus state={EMessageUpdateState.WARNING} text="Warning" />,
      );
      textElement = screen.getByTestId('chat-status-text');
      expect(textElement).toHaveClass('text-warning');
      expect(textElement).not.toHaveClass('text-destructive');

      // Test default state - should use ShimmeringText, not regular Text
      rerender(
        <ChatStatus state={EMessageUpdateState.DEFAULT} text="Loading" />,
      );
      expect(screen.queryByTestId('chat-status-text')).not.toBeInTheDocument();
      expect(screen.getByTestId('shimmering-text')).toBeInTheDocument();
    });
  });

  describe('Action Button', () => {
    it('should not render action button when action prop is not provided', () => {
      render(<ChatStatus text="Status message" />);

      const actionButton = screen.queryByTestId('chat-status-action');
      expect(actionButton).not.toBeInTheDocument();
    });

    it('should render action button when action prop is provided', () => {
      const handleClick = vi.fn();
      render(
        <ChatStatus
          text="Status message"
          action={{ label: 'Retry', onClick: handleClick }}
        />,
      );

      const actionButton = screen.getByTestId('chat-status-action');
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveTextContent('Retry');
      expect(actionButton).toHaveAttribute('data-slot', 'chat-status-action');
    });

    it('should call action onClick when action button is clicked', async () => {
      const user = userEvent.setup();
      const handleClick = vi.fn();
      render(
        <ChatStatus
          text="Status message"
          action={{ label: 'Stop', onClick: handleClick }}
        />,
      );

      const actionButton = screen.getByTestId('chat-status-action');
      await user.click(actionButton);

      expect(handleClick).toHaveBeenCalledTimes(1);
    });

    it('should render action button for default state', () => {
      const handleClick = vi.fn();
      render(
        <ChatStatus
          state={EMessageUpdateState.DEFAULT}
          text="Thinking..."
          action={{ label: 'Stop', onClick: handleClick }}
        />,
      );

      const actionButton = screen.getByTestId('chat-status-action');
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveTextContent('Stop');
    });

    it('should call action onClick when action button is clicked in default state', async () => {
      const user = userEvent.setup();
      const handleClick = vi.fn();
      render(
        <ChatStatus
          state={EMessageUpdateState.DEFAULT}
          text="Thinking..."
          action={{ label: 'Stop', onClick: handleClick }}
        />,
      );

      const actionButton = screen.getByTestId('chat-status-action');
      await user.click(actionButton);

      expect(handleClick).toHaveBeenCalledTimes(1);
    });

    it('should render action button for error state', () => {
      const handleClick = vi.fn();
      render(
        <ChatStatus
          state={EMessageUpdateState.ERROR}
          text="Something went wrong"
          action={{ label: 'Retry', onClick: handleClick }}
        />,
      );

      const actionButton = screen.getByTestId('chat-status-action');
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveTextContent('Retry');
    });

    it('should render action button for warning state', () => {
      const handleClick = vi.fn();
      render(
        <ChatStatus
          state={EMessageUpdateState.WARNING}
          text="Please review"
          action={{ label: 'Retry', onClick: handleClick }}
        />,
      );

      const actionButton = screen.getByTestId('chat-status-action');
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveTextContent('Retry');
    });

    it('should render action button for success state', () => {
      const handleClick = vi.fn();
      render(
        <ChatStatus
          state={EMessageUpdateState.SUCCESS}
          text="Completed successfully"
          action={{ label: 'Retry', onClick: handleClick }}
        />,
      );

      const actionButton = screen.getByTestId('chat-status-action');
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveTextContent('Retry');

      // Success state should have success text color
      const textElement = screen.getByTestId('chat-status-text');
      expect(textElement).toHaveClass('text-success');
    });

    it('should render both icon and action button when both are provided', () => {
      const handleClick = vi.fn();
      render(
        <ChatStatus
          state={EMessageUpdateState.ERROR}
          text="Error message"
          showIcon
          action={{ label: 'Retry', onClick: handleClick }}
        />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      const actionButton = screen.getByTestId('chat-status-action');

      expect(iconContainer).toBeInTheDocument();
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveTextContent('Retry');
    });

    it('should render action button with custom icon', () => {
      const handleClick = vi.fn();
      render(
        <ChatStatus
          state={EMessageUpdateState.ERROR}
          text="Error message"
          showIcon
          icon="Info"
          action={{ label: 'Retry', onClick: handleClick }}
        />,
      );

      const iconContainer = screen.getByTestId('chat-status-icon-container');
      const actionButton = screen.getByTestId('chat-status-action');

      expect(iconContainer).toBeInTheDocument();
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveTextContent('Retry');

      // Custom icon should still have error state styling
      const icon = iconContainer.querySelector('svg');
      expect(icon).toBeInTheDocument();
      expect(icon).toHaveClass('text-destructive');
      expect(icon).toHaveClass('size-3');
    });
  });
});
