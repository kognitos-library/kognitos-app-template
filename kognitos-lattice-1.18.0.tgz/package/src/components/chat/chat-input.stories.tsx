import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { ChatInput, type IChatAttachment } from '@/design-system';
import { Card } from '../../primitives/card';
import { Flex } from '../../primitives/flex';
import { Text } from '../../primitives/typography';

// NOTE: Hard coded texts here instead of using translations since this is a Storybook file.

/**
 * Helper to convert File objects to IChatAttachment format
 */
const fileToAttachment = (file: File): IChatAttachment => {
  const extension = file.name.split('.').pop()?.toLowerCase() || '';
  let type: IChatAttachment['type'] = 'file';

  if (['pdf'].includes(extension)) {
    type = 'pdf';
  } else if (['xls', 'xlsx', 'csv'].includes(extension)) {
    type = 'excel';
  } else if (['txt', 'md', 'json'].includes(extension)) {
    type = 'text';
  } else if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension)) {
    type = 'image';
  }

  return {
    id: `${file.name}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
    name: file.name,
    type,
  };
};

const meta: Meta<typeof ChatInput> = {
  title: 'Design System/Components/Chat/ChatInput',
  component: ChatInput,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A chat input component with textarea, attachment support, and send functionality. Supports Enter to send and Shift+Enter for new lines. Files can be added via the attachment button or by pasting from clipboard. Supports both default and inline versions.',
      },
    },
  },
  argTypes: {
    placeholder: {
      control: { type: 'text' },
      description: 'Placeholder text for the input',
    },
    variant: {
      control: { type: 'select' },
      options: ['default', 'inline'],
      description: 'Variant type of the chat input',
    },
    inlineIcon: {
      control: { type: 'text' },
      description: 'Icon type for inline variant (default: Sparkle)',
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the input is disabled',
    },
    showAttachmentButton: {
      control: { type: 'boolean' },
      description: 'Whether to show the attachment button',
    },
    showSendButton: {
      control: { type: 'boolean' },
      description: 'Whether to show the send button',
    },
    attachments: {
      control: { type: 'object' },
      description: 'Array of attachments to display',
    },
    acceptedFileTypes: {
      control: { type: 'text' },
      description:
        'Accepted file types for the attachment input (e.g., "image/*,.pdf")',
    },
    allowFilePaste: {
      control: { type: 'boolean' },
      description:
        'Allow pasting files from clipboard. When enabled and files are pasted, onAddAttachments is called. Defaults to false.',
    },
    onSend: {
      action: 'sent',
      description: 'Callback when message is sent',
    },
    onAddAttachments: {
      action: 'attachments-added',
      description:
        'Callback when files are selected via the attachment button or pasted from clipboard',
    },
    onAttachmentRemove: {
      action: 'attachment-removed',
      description: 'Callback when attachment is removed',
    },
    errorMessage: {
      control: { type: 'text' },
      description: 'Error message to display below the input',
    },
    isLoading: {
      table: {
        disable: true,
      },
    },
    loadingMode: {
      table: {
        disable: true,
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatInput>;

/**
 * Default chat input with basic functionality.
 * Click the attachment button or paste files from clipboard to add attachments.
 */
export const Default: Story = {
  args: {
    placeholder: 'Type your message...',
    showAttachmentButton: true,
    showSendButton: true,
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Chat input with attachments displayed.
 * Starts with sample attachments, click the attachment button to add more files.
 */
export const WithAttachments: Story = {
  args: {
    placeholder: 'Type your message...',
    showAttachmentButton: true,
    showSendButton: true,
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([
      {
        id: 'att1',
        name: 'document.pdf',
        type: 'pdf',
      },
      {
        id: 'att2',
        name: 'data.xlsx',
        type: 'excel',
      },
    ]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            args.onAttachmentRemove?.(id);
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Chat input with multiple attachment types.
 * Starts with various file types, click the attachment button to add more.
 */
export const WithMultipleAttachmentTypes: Story = {
  args: {
    placeholder: 'Type your message...',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([
      {
        id: 'att1',
        name: 'document.pdf',
        type: 'pdf',
      },
      {
        id: 'att2',
        name: 'spreadsheet.xlsx',
        type: 'excel',
      },
      {
        id: 'att3',
        name: 'notes.txt',
        type: 'text',
      },
      {
        id: 'att4',
        name: 'photo.jpg',
        type: 'image',
      },
    ]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Chat input without attachment button.
 */
export const WithoutAttachmentButton: Story = {
  args: {
    placeholder: 'Type your message...',
    showAttachmentButton: false,
    showSendButton: true,
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
          }}
        />
      </Card>
    );
  },
};

/**
 * Chat input without send button.
 * Click the attachment button to add files, press Enter to send.
 */
export const WithoutSendButton: Story = {
  args: {
    placeholder: 'Type your message...',
    showAttachmentButton: true,
    showSendButton: false,
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Chat input with no action buttons.
 */
export const NoButtons: Story = {
  args: {
    placeholder: 'Type your message...',
    showAttachmentButton: false,
    showSendButton: false,
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
          }}
        />
      </Card>
    );
  },
};

/**
 * Interactive example showing how attachments can be added and removed.
 * Click the attachment button to open a file picker, or paste files from clipboard (Ctrl/Cmd+V).
 */
export const Interactive: Story = {
  render: function Render() {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
      console.log(
        'Files added:',
        files.map(f => f.name),
      );
    };

    const handleRemoveAttachment = (id: string) => {
      setAttachments(prev => prev.filter(att => att.id !== id));
    };

    const handleSend = (message: string) => {
      // Allow sending with attachments only (empty message is valid)
      const hasMessage = message.trim().length > 0;
      const hasAttachments = attachments.length > 0;

      if (hasMessage || hasAttachments) {
        console.log(
          'Sent:',
          hasMessage ? message : '(no message)',
          'with attachments:',
          attachments,
        );
        setValue('');
        setAttachments([]);
      }
    };

    return (
      <div style={{ width: '100%', maxWidth: '500px' }}>
        <Card className="w-full max-w-md p-4">
          <ChatInput
            value={value}
            onChange={e => setValue(e.target.value)}
            attachments={attachments}
            onAddAttachments={handleAddAttachments}
            onAttachmentRemove={handleRemoveAttachment}
            onSend={handleSend}
            placeholder="Type your message..."
          />
        </Card>
      </div>
    );
  },
  parameters: {
    layout: 'centered',
  },
};

/**
 * Example with restricted file types. Only images and PDFs can be selected.
 */
export const WithAcceptedFileTypes: Story = {
  args: {
    placeholder: 'Type your message...',
    acceptedFileTypes: 'image/*,.pdf',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
      console.log(
        'Files added:',
        files.map(f => f.name),
      );
    };

    return (
      <Card className="w-full max-w-md p-4">
        <Flex direction="column" gap={2}>
          <Text level="small" color="muted">
            Only images and PDFs can be attached
          </Text>
          <ChatInput
            {...args}
            value={value}
            onChange={e => setValue(e.target.value)}
            attachments={attachments}
            onAddAttachments={handleAddAttachments}
            onAttachmentRemove={id => {
              setAttachments(prev => prev.filter(att => att.id !== id));
            }}
            onSend={value => {
              args.onSend?.(value);
              setValue('');
              setAttachments([]);
            }}
          />
        </Flex>
      </Card>
    );
  },
};

/**
 * Inline variant - minimal borderless design with icon. No max height constraint.
 * Hover over the input to reveal the attachment button.
 */
export const Inline: Story = {
  args: {
    placeholder: 'Type your message...',
    variant: 'inline',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Inline variant with custom icon.
 * Hover over the input to reveal the attachment button.
 */
export const InlineCustomIcon: Story = {
  args: {
    placeholder: 'Type your message...',
    variant: 'inline',
    inlineIcon: 'MessageCircle',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Inline variant with error state.
 * Hover over the input to reveal the attachment button.
 */
export const InlineError: Story = {
  args: {
    placeholder: 'Type your message...',
    variant: 'inline',
    errorMessage: 'This field is required',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Inline variant with scrollable attachments.
 */
export const InlineWithAttachments: Story = {
  args: {
    placeholder: 'Type your message...',
    variant: 'inline',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([
      { id: 'att1', name: 'document.pdf', type: 'pdf' },
      { id: 'att2', name: 'spreadsheet.xlsx', type: 'excel' },
      { id: 'att3', name: 'notes.txt', type: 'text' },
      { id: 'att4', name: 'photo.jpg', type: 'image' },
      { id: 'att5', name: 'report.pdf', type: 'pdf' },
    ]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Inline variant with error message and attachments.
 */
export const InlineErrorWithAttachments: Story = {
  args: {
    placeholder: 'Type your message...',
    variant: 'inline',
    errorMessage: 'File size exceeds the maximum limit',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([
      { id: 'att2', name: 'document.pdf', type: 'pdf' },
    ]);

    const handleAddAttachments = (files: File[]) => {
      const newAttachments = files.map(fileToAttachment);
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    return (
      <Card className="w-full max-w-md p-4">
        <ChatInput
          {...args}
          value={value}
          onChange={e => setValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={id => {
            setAttachments(prev => prev.filter(att => att.id !== id));
          }}
          onSend={value => {
            args.onSend?.(value);
            setValue('');
            setAttachments([]);
          }}
        />
      </Card>
    );
  },
};

/**
 * Inline variant showing stop button after sending.
 * Demonstrates how the parent controls the loading state to show the stop button.
 */
export const InlineWithStopButton: Story = {
  args: {
    placeholder: 'Type your message...',
    variant: 'inline',
  },
  render: function Render(args) {
    const [value, setValue] = useState('');
    const [isLoading, setIsLoading] = useState(false);

    const handleSend = (message: string) => {
      args.onSend?.(message);
      setValue('');
      setIsLoading(true);
      // Simulate async operation - stop button will show during this time
    };

    const handleStop = () => {
      args.onStop?.();
      setIsLoading(false);
    };

    return (
      <Flex direction="column" gap={4} className="w-full max-w-md">
        <Text level="small" color="muted">
          Click send to see the stop button. Click stop to return to send
          button.
        </Text>
        <Card className="w-full p-4">
          <ChatInput
            {...args}
            value={value}
            onChange={e => setValue(e.target.value)}
            onSend={handleSend}
            onStop={handleStop}
            isLoading={isLoading}
            loadingMode="stop"
          />
        </Card>
      </Flex>
    );
  },
};

/**
 * Disabled chat input showing both default and inline variants.
 */
export const Disabled: Story = {
  args: {
    placeholder: 'Type your message...',
    disabled: true,
    showAttachmentButton: true,
    showSendButton: true,
  },
  render: args => {
    return (
      <Flex direction="row" gap={6} width="full" justify="center">
        <Flex direction="column" gap={2} width="full">
          <Text level="small" weight="medium" className="mb-2 block">
            Default Variant
          </Text>
          <Card className="w-full p-4">
            <ChatInput {...args} value="This input is disabled" />
          </Card>
        </Flex>
        <Flex direction="column" gap={2} width="full">
          <Text level="small" weight="medium" className="mb-2 block">
            Inline Variant
          </Text>
          <Card className="w-full p-4">
            <ChatInput
              {...args}
              variant="inline"
              value="This input is disabled"
            />
          </Card>
        </Flex>
      </Flex>
    );
  },
};

/**
 * Chat input with custom background colors for both default and inline variants.
 * Uses the `background` prop with predefined color options.
 */
export const CustomBackgroundColor: Story = {
  args: {
    placeholder: 'Type your message...',
    showAttachmentButton: true,
    showSendButton: true,
  },
  render: function Render(args) {
    const [defaultValue, setDefaultValue] = useState('');
    const [inlineValue, setInlineValue] = useState('');

    return (
      <Flex direction="row" gap={6} width="full" justify="center">
        <Flex direction="column" gap={2} width="full">
          <Text level="small" weight="medium" className="mb-2 block">
            Default Variant with Muted Background
          </Text>
          <Card className="w-full p-4">
            <ChatInput
              {...args}
              value={defaultValue}
              onChange={e => setDefaultValue(e.target.value)}
              background="muted"
            />
          </Card>
        </Flex>
        <Flex direction="column" gap={2} width="full">
          <Text level="small" weight="medium" className="mb-2 block">
            Inline Variant with custom input class name (bg-black)
          </Text>
          <Card className="w-full p-4">
            <ChatInput
              {...args}
              variant="inline"
              value={inlineValue}
              onChange={e => setInlineValue(e.target.value)}
              inputClassName="bg-black"
            />
          </Card>
        </Flex>
      </Flex>
    );
  },
};
