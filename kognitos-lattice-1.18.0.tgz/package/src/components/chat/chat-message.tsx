import * as React from 'react';
import { cva } from 'class-variance-authority';

import { cn, toISO8601, useI18n } from '@/design-system/lib/utils';
import { Flex } from '../../primitives/flex';
import { Text } from '../../primitives/typography';
import { Avatar, AvatarImage, AvatarFallback } from '../../primitives/avatar';
import {
  type IChatMessageProps,
  EMessageDirection,
  EMessageVariant,
  type TMessageDirection,
  type TMessageVariant,
} from './types';
import { ChatMessageAttachment } from './chat-message-attachment';
import { ChatMessageWidget } from './widgets/chat-message-widget';
import { formatTimestamp, getMessageTextProps } from './utils';
import { Markdown } from '../../primitives/markdown';

// ============================================================================
// VARIANTS
// ============================================================================

export const messageContainerVariants = cva(
  'flex flex-col gap-2 relative w-full',
  {
    variants: {
      direction: {
        [EMessageDirection.INCOMING]: 'items-start pr-8',
        [EMessageDirection.OUTGOING]: 'items-end pl-6', // Outgoing messages align to the right
      },
      variant: {
        [EMessageVariant.DEFAULT]: '',
        [EMessageVariant.INLINE]: 'pr-0 pl-0',
      },
    },
    defaultVariants: {
      direction: EMessageDirection.INCOMING,
      variant: EMessageVariant.DEFAULT,
    },
    compoundVariants: [
      {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.DEFAULT,
        class: 'pl-6 pr-0',
      },
      {
        variant: EMessageVariant.INLINE,
        class: 'items-start', // All inline messages align to the left
      },
    ],
  },
);

export const messageBubbleVariants = cva(
  'flex gap-2 items-start relative rounded-md',
  {
    variants: {
      direction: {
        [EMessageDirection.INCOMING]: 'flex-row',
        [EMessageDirection.OUTGOING]: 'flex-row', // Outgoing inline uses flex-row, default uses flex-row-reverse
      },
      variant: {
        [EMessageVariant.DEFAULT]: '',
        [EMessageVariant.INLINE]: '',
      },
    },
    defaultVariants: {
      direction: EMessageDirection.INCOMING,
      variant: EMessageVariant.DEFAULT,
    },
  },
);

// ============================================================================
// CHAT MESSAGE COMPONENT
// ============================================================================

/**
 * Individual message component with support for incoming/outgoing variants, attachments, and widgets.
 *
 * Supports two variants:
 * - **default**: Traditional chat bubbles with avatars on sides
 * - **inline**: Full-width messages with avatars inline (outgoing messages bold)
 *
 * Message-level `showSender` and `showTimestamp` props override Chat-level defaults.
 */
const ChatMessage = React.memo(function ChatMessage({
  className,
  message,
  defaultVariant = EMessageVariant.DEFAULT,
  defaultShowSender = true,
  defaultShowTimestamp = true,
  timestampFormatter = formatTimestamp,
  ...props
}: IChatMessageProps) {
  const { t } = useI18n();
  const direction: TMessageDirection = message.direction;
  const variant: TMessageVariant = message.variant || defaultVariant;

  // Determine if sender should be shown (message-level override takes precedence)
  const shouldShowSender =
    message.showSender !== undefined ? message.showSender : defaultShowSender;

  // Determine if timestamp should be shown (message-level override takes precedence)
  const shouldShowTimestamp =
    message.showTimestamp !== undefined
      ? message.showTimestamp
      : defaultShowTimestamp;

  const timestamp = message.timestamp
    ? timestampFormatter(message.timestamp)
    : null;

  // Format timestamp for datetime attribute (must be ISO 8601)
  const timestampDateTime = toISO8601(message.timestamp);

  // Determine if outgoing default (uses flex-row-reverse and border)
  const isOutgoingDefault =
    direction === EMessageDirection.OUTGOING &&
    variant === EMessageVariant.DEFAULT;
  // Don't apply background if message has a widget or attachments
  const shouldApplyBackground = isOutgoingDefault && !message.widget;

  const messageContentAlignment =
    direction === EMessageDirection.OUTGOING &&
    variant === EMessageVariant.DEFAULT
      ? 'end'
      : 'start';

  // Determine text styling based on variant and direction
  const textProps = getMessageTextProps(variant, direction);

  return (
    <div
      key={`message-${message.id}`}
      data-slot="chat-message"
      data-testid={`chat-message-${message.id}`}
      data-direction={direction}
      data-variant={variant}
      className={cn(
        messageContainerVariants({
          direction: direction as EMessageDirection,
          variant: variant as EMessageVariant,
        }),
        className,
      )}
      role="article"
      aria-label={t('chat.message.ariaLabel', {
        direction:
          direction === EMessageDirection.INCOMING
            ? t('chat.message.incoming')
            : t('chat.message.outgoing'),
        timestamp: timestamp
          ? ` at ${timestampFormatter(message.timestamp!)}`
          : '',
      })}
      {...props}
    >
      <div
        key={`message-bubble-${message.id}`}
        className={cn(
          messageBubbleVariants({
            direction: direction as EMessageDirection,
            variant: variant as EMessageVariant,
          }),
          // Outgoing default uses reverse order
          isOutgoingDefault && 'flex-row-reverse justify-end',
          'min-w-0 max-w-full w-full',
        )}
      >
        {/* Avatar */}
        {shouldShowSender && (message.avatarUrl || message.avatarFallback) ? (
          <div
            key={`message-sender-${message.id}`}
            className={cn(
              'flex items-center shrink-0',
              variant === EMessageVariant.INLINE &&
                direction === EMessageDirection.OUTGOING
                ? 'h-7'
                : 'h-6',
            )}
          >
            <Avatar className="size-4">
              {message.avatarUrl && (
                <AvatarImage
                  src={message.avatarUrl}
                  alt={`Avatar for ${message.avatarFallback || t('chat.message.avatarAltDefault')}`}
                />
              )}
              {message.avatarFallback && (
                <AvatarFallback className="text-xs">
                  {message.avatarFallback}
                </AvatarFallback>
              )}
            </Avatar>
          </div>
        ) : null}

        {/* Message Content */}
        <Flex
          direction={'column'}
          gap={2.5}
          align={messageContentAlignment}
          className="min-w-0 max-w-full flex-1"
          key={`message-content-${message.id}`}
        >
          {/* Attachments - shown alongside text when no widget */}
          {message.attachments && message.attachments.length > 0 ? (
            <Flex
              direction="column"
              gap={2}
              width="full"
              align={messageContentAlignment}
            >
              {message.attachments.map(attachment => (
                <ChatMessageAttachment
                  key={attachment.id}
                  attachment={attachment}
                  showRemove={false}
                  onClick={attachment.onClick}
                  className={'max-w-64'}
                />
              ))}
            </Flex>
          ) : null}

          {/* Widget Content - replaces text and attachments */}
          {message.widget ? (
            <ChatMessageWidget widget={message.widget} />
          ) : (
            <>
              {/* Text Content - shown when no widget */}
              {message.content ? (
                <Flex
                  direction="column"
                  gap={2.5}
                  align={messageContentAlignment}
                  className={cn(
                    // Outgoing default has background and padding (unless it has a widget)
                    shouldApplyBackground && 'bg-muted py-2.5 px-4 rounded-md',
                    'min-w-0 max-w-full',
                  )}
                >
                  <div
                    className={cn(
                      // For default variant, text hugs content initially but can break long content
                      variant === EMessageVariant.DEFAULT && 'max-w-full',
                      // For inline variant, text takes full width
                      variant === EMessageVariant.INLINE && 'w-full',
                      // Break long unbreakable strings (URLs, long words, etc.)
                      'break-anywhere',
                    )}
                  >
                    <Markdown
                      textProps={textProps}
                      textClassName={textProps.className}
                    >
                      {message.content}
                    </Markdown>
                  </div>
                </Flex>
              ) : null}
            </>
          )}
        </Flex>
      </div>

      {/* Timestamp */}
      {shouldShowTimestamp && timestamp && timestampDateTime && (
        <Flex
          key={`message-timestamp-${message.id}`}
          justify={
            variant === EMessageVariant.INLINE || !isOutgoingDefault
              ? 'start'
              : 'end'
          }
          className="w-full"
        >
          <Text level="xSmall" color="muted" className="opacity-50">
            <time dateTime={timestampDateTime}>{timestamp}</time>
          </Text>
        </Flex>
      )}
    </div>
  );
});

ChatMessage.displayName = 'ChatMessage';

export { ChatMessage };
