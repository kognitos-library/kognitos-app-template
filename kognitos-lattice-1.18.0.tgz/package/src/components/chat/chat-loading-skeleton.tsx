import { Flex } from '../../primitives/flex';
import { Skeleton } from '../../primitives/skeleton';

/**
 * Skeleton loader for chat messages.
 */
function ChatLoadingSkeleton() {
  return (
    <Flex
      direction="column"
      gap={4}
      width="full"
      className="pb-4"
      data-testid="chat-loading-skeleton"
    >
      <Skeleton className="h-8 w-4/7 ml-auto" />
      <Skeleton className="h-12 w-5/7" />
      <Skeleton className="h-8 w-3/7 ml-auto" />
      <Skeleton className="h-8 w-6/7" />
      <Skeleton className="h-8 w-5/7 ml-auto" />
      <Skeleton className="h-12 w-5/7" />
    </Flex>
  );
}

ChatLoadingSkeleton.displayName = 'ChatLoadingSkeleton';

export { ChatLoadingSkeleton };
