import * as React from 'react';
import { cn, useI18n } from '@/design-system/lib/utils';
import { Flex } from '../../primitives/flex';
import { Text } from '../../primitives/typography';
import { ShimmeringText } from '../../primitives/shimmering-text';
import { Icon } from '../../icons';
import { type IChatThinkingMessageProps } from './types';
import { formatThinkingDuration } from './utils';

/**
 * Duration constants for the expand/collapse animation transition
 * The below two values should match and be updated together
 */
const THINKING_MESSAGE_EXPAND_DURATION = 300;
const THINKING_MESSAGE_EXPAND_DURATION_CLASSNAME = 'duration-300';

// ============================================================================
// CHAT THINKING MESSAGE COMPONENT
// ============================================================================

/**
 * Component for displaying grouped thinking messages in a collapsible format.
 *
 * Supports two visual states based on the Figma design:
 * - **Streaming** (`isComplete=false`): Shows "Neurosymbolizing..." with shimmering text
 *   animation as loading indicator. Click to expand and see messages.
 * - **Complete** (`isComplete=true`): Shows "Neurosymbolized for Xs" in regular italic gray text.
 *   Click to expand and see messages.
 *
 * The shimmering text serves as the loading indicator - no separate spinner needed.
 * Click the header to expand and see all thinking messages in a scrollable area (max 200px).
 *
 * @example
 * ```tsx
 * // Streaming state - shimmering text indicates loading
 * <ChatThinkingMessage
 *   messages={thinkingMessages}
 *   isComplete={false}
 * />
 *
 * // Complete state - static italic text
 * <ChatThinkingMessage
 *   messages={thinkingMessages}
 *   isComplete={true}
 * />
 * ```
 */
const ChatThinkingMessage = React.memo(function ChatThinkingMessage({
  className,
  messages,
  title,
  isComplete = false,
  onComplete,
  ...props
}: IChatThinkingMessageProps) {
  const { t } = useI18n();
  const resolvedTitle = title ?? t('chat.thinking.title');
  const [isExpanded, setIsExpanded] = React.useState(false);
  const prevIsCompleteRef = React.useRef(isComplete);

  React.useEffect(() => {
    if (!isComplete) {
      prevIsCompleteRef.current = false;
      return;
    }

    // Collapse and fire onComplete after the CSS transition (THINKING_MESSAGE_EXPAND_DURATION)
    setIsExpanded(false);
    const wasStreaming = !prevIsCompleteRef.current;
    prevIsCompleteRef.current = true;

    if (!wasStreaming || !onComplete) return;

    const timeout = setTimeout(onComplete, THINKING_MESSAGE_EXPAND_DURATION);
    return () => clearTimeout(timeout);
  }, [isComplete, onComplete]);

  // Calculate duration for complete state
  const duration = React.useMemo(
    () => (isComplete ? formatThinkingDuration(messages) : null),
    [isComplete, messages],
  );

  // Combine all message content into one text block
  const allMessagesText = React.useMemo(
    () =>
      messages.map(m => {
        return (
          <span key={m.id} className="text-xs p-2 block">
            {m.content}
          </span>
        );
      }),
    [messages],
  );

  /**
   * Handles toggling the expanded state (header click).
   */
  const handleToggleExpand = () => {
    setIsExpanded(prev => !prev);
  };

  // Don't render if there are no messages
  if (messages.length === 0) {
    return null;
  }

  // Build header title based on state
  const headerTitle = isComplete
    ? duration
      ? t('chat.thinking.completedWithDuration', { duration })
      : t('chat.thinking.completed')
    : resolvedTitle;

  // Always show title when collapsed, expand to see messages
  const displayText = headerTitle;

  return (
    <Flex
      data-slot="chat-thinking-message"
      data-testid="chat-thinking-message"
      data-expanded={isExpanded}
      data-complete={isComplete}
      direction="column"
      width="full"
      overflow="hidden"
      gap={2}
      className={cn(
        'min-w-0 min-h-0 rounded-sm transition-colors duration-200',
        isExpanded && 'bg-secondary',
        className,
      )}
      {...props}
    >
      {/* Header with toggle - simplified design per Figma */}
      <Flex
        align="center"
        justify="between"
        gap={2}
        className={cn(
          'cursor-pointer rounded-sm transition-colors hover:bg-secondary p-2',
        )}
        onClick={handleToggleExpand}
        role="button"
        tabIndex={0}
        aria-expanded={isExpanded}
        aria-label={
          isExpanded
            ? t('chat.thinking.ariaLabelCollapse')
            : t('chat.thinking.ariaLabelExpand')
        }
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            handleToggleExpand();
          }
        }}
      >
        <Flex align="center" gap={2} className="min-w-0 flex-1 w-full">
          {/* Text - shimmer during streaming (serves as loading indicator), italic gray when complete */}
          {isComplete ? (
            <Text
              level="xSmall"
              color="muted"
              className="truncate italic alpha-80"
              data-testid="chat-thinking-title"
            >
              {displayText}
            </Text>
          ) : (
            <ShimmeringText
              text={displayText}
              duration={1.2}
              className="truncate italic text-xs"
              data-testid="chat-thinking-title"
            />
          )}
        </Flex>
        {/* Chevron toggle icon */}
        <Icon
          type="ChevronDown"
          className={cn(
            'size-3 shrink-0 text-muted-foreground alpha-80 transition-transform',
            THINKING_MESSAGE_EXPAND_DURATION_CLASSNAME,
            isExpanded && 'rotate-180',
          )}
          data-testid="chat-thinking-chevron"
        />
      </Flex>

      {/* Expanded content - CSS grid-rows trick for smooth height animation */}
      <div
        className={cn(
          'grid transition-[grid-template-rows,opacity] ease-in-out',
          THINKING_MESSAGE_EXPAND_DURATION_CLASSNAME,
          isExpanded
            ? 'grid-rows-[1fr] opacity-100'
            : 'grid-rows-[0fr] opacity-0',
        )}
        data-testid="chat-thinking-messages"
      >
        <div className="min-w-0 min-h-0 overflow-hidden">
          <div className="max-h-[200px] overflow-y-auto px-2 pb-2">
            <Text
              level="xSmall"
              color="muted"
              className="whitespace-pre-wrap wrap-break-word break-anywhere italic alpha-80"
              data-testid="chat-thinking-content"
            >
              {allMessagesText}
            </Text>
          </div>
        </div>
      </div>
    </Flex>
  );
});

ChatThinkingMessage.displayName = 'ChatThinkingMessage';

export { ChatThinkingMessage };
