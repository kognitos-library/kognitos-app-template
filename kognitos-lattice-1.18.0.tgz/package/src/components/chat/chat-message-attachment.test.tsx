import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChatMessageAttachment } from './chat-message-attachment';
import { EAttachmentType, type IChatAttachment } from './types';

describe('ChatMessageAttachment', () => {
  const createMockAttachment = (
    overrides?: Partial<IChatAttachment>,
  ): IChatAttachment => ({
    id: 'att1',
    name: 'document.pdf',
    type: EAttachmentType.PDF,
    ...overrides,
  });

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Rendering', () => {
    it('should render attachment with name', () => {
      const attachment = createMockAttachment();
      render(<ChatMessageAttachment attachment={attachment} />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
    });

    it('should render attachment with correct data-slot attribute', () => {
      const attachment = createMockAttachment();
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toBeInTheDocument();
    });

    it('should render attachment icon based on type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.PDF,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      // Icon should be rendered (checking for aria-label on icon container)
      const iconContainer = container.querySelector(
        '[aria-label="pdf file type"]',
      );
      expect(iconContainer).toBeInTheDocument();
    });

    it('should render correct icon for TEXT type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.TEXT,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector(
        '[aria-label="text file type"]',
      );
      expect(iconContainer).toBeInTheDocument();
    });

    it('should render correct icon for EXCEL type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.EXCEL,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector(
        '[aria-label="excel file type"]',
      );
      expect(iconContainer).toBeInTheDocument();
    });

    it('should render correct icon for IMAGE type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.IMAGE,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector(
        '[aria-label="image file type"]',
      );
      expect(iconContainer).toBeInTheDocument();
    });

    it('should render correct icon for FILE type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.FILE,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector(
        '[aria-label="file file type"]',
      );
      expect(iconContainer).toBeInTheDocument();
    });

    it('should apply correct color class for TEXT type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.TEXT,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector('.bg-alternate-7');
      expect(iconContainer).toBeInTheDocument();
    });

    it('should apply correct color class for EXCEL type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.EXCEL,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector('.bg-alternate-5');
      expect(iconContainer).toBeInTheDocument();
    });

    it('should apply correct color class for PDF type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.PDF,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector('.bg-alternate-2');
      expect(iconContainer).toBeInTheDocument();
    });

    it('should apply correct color class for IMAGE type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.IMAGE,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector('.bg-alternate-1');
      expect(iconContainer).toBeInTheDocument();
    });

    it('should apply correct color class for FILE type', () => {
      const attachment = createMockAttachment({
        type: EAttachmentType.FILE,
      });
      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const iconContainer = container.querySelector('.bg-alternate-1');
      expect(iconContainer).toBeInTheDocument();
    });
  });

  describe('Remove Functionality', () => {
    it('should render remove button when showRemove is true and onRemove is provided', () => {
      const attachment = createMockAttachment();
      const onRemove = vi.fn();

      render(
        <ChatMessageAttachment
          attachment={attachment}
          showRemove
          onRemove={onRemove}
        />,
      );

      const removeButton = screen.getByLabelText('Remove attachment');
      expect(removeButton).toBeInTheDocument();
    });

    it('should not render remove button when showRemove is false', () => {
      const attachment = createMockAttachment();
      const onRemove = vi.fn();

      render(
        <ChatMessageAttachment
          attachment={attachment}
          showRemove={false}
          onRemove={onRemove}
        />,
      );

      const removeButton = screen.queryByLabelText('Remove attachment');
      expect(removeButton).not.toBeInTheDocument();
    });

    it('should not render remove button when onRemove is not provided', () => {
      const attachment = createMockAttachment();

      render(<ChatMessageAttachment attachment={attachment} showRemove />);

      const removeButton = screen.queryByLabelText('Remove attachment');
      expect(removeButton).not.toBeInTheDocument();
    });

    it('should call onRemove when remove button is clicked', async () => {
      const user = userEvent.setup();
      const attachment = createMockAttachment();
      const onRemove = vi.fn();

      render(
        <ChatMessageAttachment
          attachment={attachment}
          showRemove
          onRemove={onRemove}
        />,
      );

      const removeButton = screen.getByLabelText('Remove attachment');
      await user.click(removeButton);

      expect(onRemove).toHaveBeenCalledTimes(1);
    });

    it('should stop propagation when remove button is clicked', async () => {
      const user = userEvent.setup();
      const attachment = createMockAttachment();
      const onRemove = vi.fn();
      const onClick = vi.fn();

      render(
        <ChatMessageAttachment
          attachment={attachment}
          showRemove
          onRemove={onRemove}
          onClick={onClick}
        />,
      );

      const removeButton = screen.getByLabelText('Remove attachment');
      await user.click(removeButton);

      // onClick should not be called when remove button is clicked
      expect(onClick).not.toHaveBeenCalled();
      expect(onRemove).toHaveBeenCalled();
    });
  });

  describe('Click Functionality', () => {
    it('should call onClick when attachment is clicked', async () => {
      const user = userEvent.setup();
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = screen.getByText('document.pdf');
      await user.click(attachmentElement);

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should apply cursor-pointer class when onClick is provided', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toHaveClass('cursor-pointer');
    });

    it('should not apply cursor-pointer class when no onClick is provided', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).not.toHaveClass('cursor-pointer');
    });
  });

  describe('Keyboard Interactions', () => {
    it('should call onClick when Enter key is pressed on clickable attachment', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;

      fireEvent.keyDown(attachmentElement, { key: 'Enter' });

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should call onClick when Space key is pressed on clickable attachment', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;

      fireEvent.keyDown(attachmentElement, { key: ' ' });

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should prevent default behavior when Enter key is pressed', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;

      const keyDownEvent = new KeyboardEvent('keydown', {
        key: 'Enter',
        bubbles: true,
        cancelable: true,
      });
      const preventDefaultSpy = vi.spyOn(keyDownEvent, 'preventDefault');

      attachmentElement.dispatchEvent(keyDownEvent);

      expect(preventDefaultSpy).toHaveBeenCalled();
    });

    it('should prevent default behavior when Space key is pressed', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;

      const keyDownEvent = new KeyboardEvent('keydown', {
        key: ' ',
        bubbles: true,
        cancelable: true,
      });
      const preventDefaultSpy = vi.spyOn(keyDownEvent, 'preventDefault');

      attachmentElement.dispatchEvent(keyDownEvent);

      expect(preventDefaultSpy).toHaveBeenCalled();
    });

    it('should not call onClick when other keys are pressed', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;

      fireEvent.keyDown(attachmentElement, { key: 'a' });

      expect(onClick).not.toHaveBeenCalled();
    });

    it('should not have onKeyDown handler when attachment is not clickable', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;

      // When not clickable, onKeyDown should be undefined
      expect(attachmentElement.getAttribute('tabindex')).toBeNull();
    });
  });

  describe('Accessibility', () => {
    it('should have role="button" when attachment is clickable via onClick prop', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toHaveAttribute('role', 'button');
    });

    it('should not have role attribute when attachment is not clickable', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).not.toHaveAttribute('role');
    });

    it('should have tabIndex={0} when attachment is clickable via onClick prop', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;
      expect(attachmentElement.tabIndex).toBe(0);
    });

    it('should not have tabIndex when attachment is not clickable', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;
      expect(attachmentElement.tabIndex).toBe(-1);
    });
  });

  describe('Attachment Properties', () => {
    it('should render attachment with url when provided', () => {
      const attachment = createMockAttachment({
        url: 'https://example.com/document.pdf',
      });

      render(<ChatMessageAttachment attachment={attachment} />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
    });

    it('should render attachment with size when provided', () => {
      const attachment = createMockAttachment({
        size: 1024,
      });

      render(<ChatMessageAttachment attachment={attachment} />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
    });

    it('should handle long file names with ellipsis', () => {
      const attachment = createMockAttachment({
        name: 'very-long-file-name-that-should-be-truncated.pdf',
      });

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const textElement = container.querySelector('.overflow-ellipsis');
      expect(textElement).toBeInTheDocument();
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment
          attachment={attachment}
          className="custom-class"
        />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toHaveClass('custom-class');
    });

    it('should have border and rounded styling', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toHaveClass(
        'border',
        'border-border',
        'rounded-md',
      );
    });

    it('should have background card styling', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toHaveClass('bg-card');
    });
  });

  describe('Focus Indicators', () => {
    it('should have focus ring styles when attachment is clickable', () => {
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toHaveClass('focus:outline-none');
      expect(attachmentElement).toHaveClass('focus:ring-2');
      expect(attachmentElement).toHaveClass('focus:ring-ring');
      expect(attachmentElement).toHaveClass('focus:ring-offset-2');
    });

    it('should not have focus ring styles when attachment is not clickable', () => {
      const attachment = createMockAttachment();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).not.toHaveClass('focus:outline-none');
      expect(attachmentElement).not.toHaveClass('focus:ring-2');
    });

    it('should be focusable via keyboard when clickable', async () => {
      const user = userEvent.setup();
      const attachment = createMockAttachment();
      const onClick = vi.fn();

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} onClick={onClick} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      ) as HTMLElement;

      // Tab to focus the element
      await user.tab();

      // Verify it's focused (the container div is the focusable element)
      expect(attachmentElement).toHaveFocus();
    });
  });

  describe('Edge Cases', () => {
    it('should handle attachment with empty name', () => {
      const attachment = createMockAttachment({
        name: '',
      });

      const { container } = render(
        <ChatMessageAttachment attachment={attachment} />,
      );

      const attachmentElement = container.querySelector(
        '[data-slot="chat-message-attachment"]',
      );
      expect(attachmentElement).toBeInTheDocument();
    });

    it('should handle attachment with very long name', () => {
      const attachment = createMockAttachment({
        name: 'a'.repeat(200) + '.pdf',
      });

      render(<ChatMessageAttachment attachment={attachment} />);

      const textElement = screen.getByText(new RegExp('a{200}'));
      expect(textElement).toBeInTheDocument();
    });

    it('should handle attachment without url or size', () => {
      const attachment = createMockAttachment({
        url: undefined,
        size: undefined,
      });

      render(<ChatMessageAttachment attachment={attachment} />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
    });
  });
});
