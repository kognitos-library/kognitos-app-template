import { describe, it, expect, vi } from 'vitest';
import {
  generateMessageId,
  formatTimestamp,
  formatThinkingDuration,
  getAttachmentIcon,
  getAttachmentColorClass,
  getStatusIcon,
  getStatusTextColor,
  getMessageTextProps,
  isChatInput,
  filterChatInputFromChildren,
  isChatToast,
  filterChatToastFromChildren,
  isChatStatus,
  hasChatStatus,
  isThinkingMessageGroup,
  isThinkingMessage,
  isCompleteMessage,
  groupConsecutiveThinkingMessages,
  calculateMultilineLayout,
} from './utils';
import {
  EAttachmentType,
  EMessageDirection,
  EMessageType,
  EMessageUpdateState,
  EMessageVariant,
} from './types';
import { createElement } from 'react';
import { ChatInput } from './chat-input';
import { ChatToast } from './chat-toast';
import { ChatStatus } from './chat-status';

// ============================================================================
// ID GENERATION UTILITIES TESTS
// ============================================================================

describe('generateMessageId', () => {
  it('should generate an ID with default "msg" prefix', () => {
    const id = generateMessageId();
    expect(id).toMatch(/^msg-/);
  });

  it('should generate an ID with custom prefix', () => {
    const id = generateMessageId('chat');
    expect(id).toMatch(/^chat-/);
  });

  it('should generate unique IDs', () => {
    const id1 = generateMessageId();
    const id2 = generateMessageId();
    const id3 = generateMessageId();

    // All IDs should be different
    expect(id1).not.toBe(id2);
    expect(id2).not.toBe(id3);
    expect(id1).not.toBe(id3);
  });

  it('should use crypto.randomUUID when available', () => {
    // Mock crypto.randomUUID
    const mockUUID = '550e8400-e29b-41d4-a716-446655440000';
    const originalCrypto = global.crypto;

    Object.defineProperty(global, 'crypto', {
      value: {
        ...originalCrypto,
        randomUUID: vi.fn(() => mockUUID),
      },
      writable: true,
      configurable: true,
    });

    const id = generateMessageId();
    expect(id).toBe(`msg-${mockUUID}`);
    expect(global.crypto.randomUUID).toHaveBeenCalled();

    // Restore original crypto
    Object.defineProperty(global, 'crypto', {
      value: originalCrypto,
      writable: true,
      configurable: true,
    });
  });

  it('should fallback to timestamp + random when crypto.randomUUID is not available', () => {
    const originalCrypto = global.crypto;

    // Remove crypto.randomUUID
    Object.defineProperty(global, 'crypto', {
      value: {
        ...originalCrypto,
        randomUUID: undefined,
      },
      writable: true,
      configurable: true,
    });

    const id = generateMessageId();

    // Should still match the prefix pattern and have some unique suffix
    expect(id).toMatch(/^msg-\d+-[a-z0-9]+$/);

    // Restore original crypto
    Object.defineProperty(global, 'crypto', {
      value: originalCrypto,
      writable: true,
      configurable: true,
    });
  });

  it('should handle rapid successive calls without collisions', () => {
    const ids = new Set<string>();
    const count = 1000;

    for (let i = 0; i < count; i++) {
      ids.add(generateMessageId());
    }

    // All IDs should be unique (no collisions)
    expect(ids.size).toBe(count);
  });

  it('should work with different prefixes', () => {
    const prefixes = ['msg', 'chat', 'user', 'system', 'notification'];

    prefixes.forEach(prefix => {
      const id = generateMessageId(prefix);
      expect(id).toMatch(new RegExp(`^${prefix}-`));
    });
  });

  it('should work with empty prefix', () => {
    const id = generateMessageId('');
    expect(id).toMatch(/^-/);
  });
});

// ============================================================================
// TIMESTAMP UTILITIES TESTS
// ============================================================================

describe('formatTimestamp', () => {
  it('should format Date object to time string', () => {
    const date = new Date('2024-01-15T14:30:00');
    const result = formatTimestamp(date);

    // Should return time in format like "2:30 PM"
    expect(result).toMatch(/^\d{1,2}:\d{2}\s[AP]M$/);
  });

  it('should format ISO string to time string', () => {
    const isoString = '2024-01-15T14:30:00';
    const result = formatTimestamp(isoString);

    expect(result).toMatch(/^\d{1,2}:\d{2}\s[AP]M$/);
  });

  it('should handle different times consistently', () => {
    const morning = new Date('2024-01-15T09:15:00');
    const afternoon = new Date('2024-01-15T14:30:00');
    const evening = new Date('2024-01-15T20:45:00');

    expect(formatTimestamp(morning)).toMatch(/9:15\sAM/);
    expect(formatTimestamp(afternoon)).toMatch(/2:30\sPM/);
    expect(formatTimestamp(evening)).toMatch(/8:45\sPM/);
  });

  it('should handle midnight and noon correctly', () => {
    const midnight = new Date('2024-01-15T00:00:00');
    const noon = new Date('2024-01-15T12:00:00');

    expect(formatTimestamp(midnight)).toMatch(/12:00\sAM/);
    expect(formatTimestamp(noon)).toMatch(/12:00\sPM/);
  });
});

// ============================================================================
// ATTACHMENT UTILITIES TESTS
// ============================================================================

describe('getAttachmentIcon', () => {
  it('should return FileText icon for TEXT type', () => {
    expect(getAttachmentIcon(EAttachmentType.TEXT)).toBe('FileText');
  });

  it('should return FileSpreadsheet icon for EXCEL type', () => {
    expect(getAttachmentIcon(EAttachmentType.EXCEL)).toBe('FileSpreadsheet');
  });

  it('should return File icon for PDF type', () => {
    expect(getAttachmentIcon(EAttachmentType.PDF)).toBe('File');
  });

  it('should return Image icon for IMAGE type', () => {
    expect(getAttachmentIcon(EAttachmentType.IMAGE)).toBe('Image');
  });

  it('should return File icon for FILE type (default)', () => {
    expect(getAttachmentIcon(EAttachmentType.FILE)).toBe('File');
  });
});

describe('getAttachmentColorClass', () => {
  it('should return bg-alternate-7 for TEXT type', () => {
    expect(getAttachmentColorClass(EAttachmentType.TEXT)).toBe(
      'bg-alternate-7',
    );
  });

  it('should return bg-alternate-5 for EXCEL type', () => {
    expect(getAttachmentColorClass(EAttachmentType.EXCEL)).toBe(
      'bg-alternate-5',
    );
  });

  it('should return bg-alternate-2 for PDF type', () => {
    expect(getAttachmentColorClass(EAttachmentType.PDF)).toBe('bg-alternate-2');
  });

  it('should return bg-alternate-1 for IMAGE type (default)', () => {
    expect(getAttachmentColorClass(EAttachmentType.IMAGE)).toBe(
      'bg-alternate-1',
    );
  });

  it('should return bg-alternate-1 for FILE type (default)', () => {
    expect(getAttachmentColorClass(EAttachmentType.FILE)).toBe(
      'bg-alternate-1',
    );
  });
});

// ============================================================================
// STATUS UTILITIES TESTS
// ============================================================================

describe('getStatusIcon', () => {
  it('should return AlertCircle for ERROR state', () => {
    expect(getStatusIcon(EMessageUpdateState.ERROR)).toBe('AlertCircle');
  });

  it('should return AlertTriangle for WARNING state', () => {
    expect(getStatusIcon(EMessageUpdateState.WARNING)).toBe('AlertTriangle');
  });

  it('should return Loader2 for DEFAULT state', () => {
    expect(getStatusIcon(EMessageUpdateState.DEFAULT)).toBe('Loader2');
  });

  it('should return CircleCheckBig for SUCCESS state', () => {
    expect(getStatusIcon(EMessageUpdateState.SUCCESS)).toBe('CircleCheckBig');
  });

  it('should return custom icon when provided', () => {
    expect(getStatusIcon(EMessageUpdateState.DEFAULT, 'Info')).toBe('Info');
    expect(getStatusIcon(EMessageUpdateState.ERROR, 'X')).toBe('X');
  });

  it('should prioritize custom icon over state', () => {
    expect(getStatusIcon(EMessageUpdateState.ERROR, 'AlertCircle')).toBe(
      'AlertCircle',
    );
  });
});

describe('getStatusTextColor', () => {
  it('should return text-destructive for ERROR state', () => {
    expect(getStatusTextColor(EMessageUpdateState.ERROR)).toBe(
      'text-destructive',
    );
  });

  it('should return text-warning for WARNING state', () => {
    expect(getStatusTextColor(EMessageUpdateState.WARNING)).toBe(
      'text-warning',
    );
  });

  it('should return empty string for DEFAULT state', () => {
    expect(getStatusTextColor(EMessageUpdateState.DEFAULT)).toBe('');
  });

  it('should return text-success for SUCCESS state', () => {
    expect(getStatusTextColor(EMessageUpdateState.SUCCESS)).toBe(
      'text-success',
    );
  });
});

// ============================================================================
// MESSAGE TEXT STYLING UTILITIES TESTS
// ============================================================================

describe('getMessageTextProps', () => {
  it('should return large/default/medium for inline variant with outgoing direction', () => {
    const result = getMessageTextProps(
      EMessageVariant.INLINE,
      EMessageDirection.OUTGOING,
    );

    expect(result).toEqual({
      level: 'large',
      color: 'default',
      weight: 'medium',
    });
  });

  it('should return base/default/normal with foreground/80 for inline variant with incoming direction', () => {
    const result = getMessageTextProps(
      EMessageVariant.INLINE,
      EMessageDirection.INCOMING,
    );

    expect(result).toEqual({
      level: 'base',
      color: 'default',
      weight: 'normal',
      className: 'text-foreground/80',
    });
  });

  it('should return base/default/normal with foreground/80 for default variant with outgoing direction', () => {
    const result = getMessageTextProps(
      EMessageVariant.DEFAULT,
      EMessageDirection.OUTGOING,
    );

    expect(result).toEqual({
      level: 'base',
      color: 'default',
      weight: 'normal',
      className: 'text-foreground/80',
    });
  });

  it('should return base/default/normal with foreground/80 for default variant with incoming direction', () => {
    const result = getMessageTextProps(
      EMessageVariant.DEFAULT,
      EMessageDirection.INCOMING,
    );

    expect(result).toEqual({
      level: 'base',
      color: 'default',
      weight: 'normal',
      className: 'text-foreground/80',
    });
  });

  it('should work with string literal values', () => {
    expect(getMessageTextProps('inline', 'outgoing')).toEqual({
      level: 'large',
      color: 'default',
      weight: 'medium',
    });

    expect(getMessageTextProps('default', 'incoming')).toEqual({
      level: 'base',
      color: 'default',
      weight: 'normal',
      className: 'text-foreground/80',
    });
  });

  it('should only return special styling when BOTH inline AND outgoing', () => {
    expect(getMessageTextProps('inline', 'incoming')).toEqual({
      level: 'base',
      color: 'default',
      weight: 'normal',
      className: 'text-foreground/80',
    });

    expect(getMessageTextProps('default', 'outgoing')).toEqual({
      level: 'base',
      color: 'default',
      weight: 'normal',
      className: 'text-foreground/80',
    });
  });
});

// ============================================================================
// REACT CHILDREN UTILITIES TESTS
// ============================================================================

describe('isChatInput', () => {
  it('should return true for ChatInput component', () => {
    const chatInputElement = createElement(ChatInput, { placeholder: 'Test' });
    expect(isChatInput(chatInputElement)).toBe(true);
  });

  it('should return false for non-React elements', () => {
    expect(isChatInput('string')).toBe(false);
    expect(isChatInput(123)).toBe(false);
    expect(isChatInput(null)).toBe(false);
    expect(isChatInput(undefined)).toBe(false);
  });

  it('should return false for other React elements', () => {
    const divElement = createElement('div', {}, 'content');
    expect(isChatInput(divElement)).toBe(false);
  });

  it('should check displayName for wrapped components', () => {
    const WrappedComponent = () => null;
    WrappedComponent.displayName = 'ChatInput';
    const wrappedElement = createElement(WrappedComponent, {});
    expect(isChatInput(wrappedElement)).toBe(true);
  });
});

describe('filterChatInputFromChildren', () => {
  it('should return null chatInput when children is null/undefined', () => {
    expect(filterChatInputFromChildren(null)).toEqual({
      chatInput: null,
      otherChildren: null,
    });
    expect(filterChatInputFromChildren(undefined)).toEqual({
      chatInput: null,
      otherChildren: undefined,
    });
  });

  it('should extract ChatInput from array of children', () => {
    const chatInputElement = createElement(ChatInput, { placeholder: 'Test' });
    const divElement = createElement('div', {}, 'content');
    const children = [divElement, chatInputElement];

    const result = filterChatInputFromChildren(children);

    expect(result.chatInput).toBe(chatInputElement);
    expect(result.otherChildren).toEqual([divElement]);
  });

  it('should return single ChatInput when it is the only child', () => {
    const chatInputElement = createElement(ChatInput, { placeholder: 'Test' });

    const result = filterChatInputFromChildren(chatInputElement);

    expect(result.chatInput).toBe(chatInputElement);
    expect(result.otherChildren).toBe(null);
  });

  it('should return null chatInput when no ChatInput in children', () => {
    const divElement = createElement('div', {}, 'content');
    const spanElement = createElement('span', {}, 'text');
    const children = [divElement, spanElement];

    const result = filterChatInputFromChildren(children);

    expect(result.chatInput).toBe(null);
    expect(result.otherChildren).toEqual(children);
  });

  it('should handle single non-ChatInput child', () => {
    const divElement = createElement('div', {}, 'content');

    const result = filterChatInputFromChildren(divElement);

    expect(result.chatInput).toBe(null);
    expect(result.otherChildren).toBe(divElement);
  });

  it('should filter out ChatInput and keep other children', () => {
    const chatInputElement = createElement(ChatInput, { placeholder: 'Test' });
    const div1 = createElement('div', { key: '1' }, 'content1');
    const div2 = createElement('div', { key: '2' }, 'content2');
    const children = [div1, chatInputElement, div2];

    const result = filterChatInputFromChildren(children);

    expect(result.chatInput).toBe(chatInputElement);
    expect(result.otherChildren).toEqual([div1, div2]);
  });
});

describe('isChatToast', () => {
  it('should return true for ChatToast component', () => {
    const chatToastElement = createElement(ChatToast, {
      text: 'Test',
      onClick: () => {},
    });
    expect(isChatToast(chatToastElement)).toBe(true);
  });

  it('should return false for non-React elements', () => {
    expect(isChatToast('string')).toBe(false);
    expect(isChatToast(123)).toBe(false);
    expect(isChatToast(null)).toBe(false);
    expect(isChatToast(undefined)).toBe(false);
  });

  it('should return false for other React elements', () => {
    const divElement = createElement('div', {}, 'content');
    expect(isChatToast(divElement)).toBe(false);
  });

  it('should check displayName for wrapped components', () => {
    const WrappedComponent = () => null;
    WrappedComponent.displayName = 'ChatToast';
    const wrappedElement = createElement(WrappedComponent, {});
    expect(isChatToast(wrappedElement)).toBe(true);
  });
});

describe('filterChatToastFromChildren', () => {
  it('should return null chatToast when children is null/undefined', () => {
    expect(filterChatToastFromChildren(null)).toEqual({
      chatToast: null,
      otherChildren: null,
    });
    expect(filterChatToastFromChildren(undefined)).toEqual({
      chatToast: null,
      otherChildren: undefined,
    });
  });

  it('should extract ChatToast from array of children', () => {
    const chatToastElement = createElement(ChatToast, {
      text: 'Test',
      onClick: () => {},
    });
    const divElement = createElement('div', {}, 'content');
    const children = [divElement, chatToastElement];

    const result = filterChatToastFromChildren(children);

    expect(result.chatToast).toBe(chatToastElement);
    expect(result.otherChildren).toEqual([divElement]);
  });

  it('should return null chatToast when no ChatToast in children', () => {
    const divElement = createElement('div', {}, 'content');
    const spanElement = createElement('span', {}, 'text');
    const children = [divElement, spanElement];

    const result = filterChatToastFromChildren(children);

    expect(result.chatToast).toBe(null);
    expect(result.otherChildren).toEqual(children);
  });

  it('should handle single non-ChatToast child', () => {
    const divElement = createElement('div', {}, 'content');

    const result = filterChatToastFromChildren(divElement);

    expect(result.chatToast).toBe(null);
    expect(result.otherChildren).toBe(divElement);
  });

  it('should filter out ChatToast and keep other children', () => {
    const chatToastElement = createElement(ChatToast, {
      text: 'Test',
      onClick: () => {},
    });
    const div1 = createElement('div', { key: '1' }, 'content1');
    const div2 = createElement('div', { key: '2' }, 'content2');
    const children = [div1, chatToastElement, div2];

    const result = filterChatToastFromChildren(children);

    expect(result.chatToast).toBe(chatToastElement);
    expect(result.otherChildren).toEqual([div1, div2]);
  });
});

describe('isChatStatus', () => {
  it('should return true for ChatStatus component', () => {
    const chatStatusElement = createElement(ChatStatus, { text: 'Loading...' });
    expect(isChatStatus(chatStatusElement)).toBe(true);
  });

  it('should return false for non-React elements', () => {
    expect(isChatStatus('string')).toBe(false);
    expect(isChatStatus(123)).toBe(false);
    expect(isChatStatus(null)).toBe(false);
    expect(isChatStatus(undefined)).toBe(false);
  });

  it('should return false for other React elements', () => {
    const divElement = createElement('div', {}, 'content');
    expect(isChatStatus(divElement)).toBe(false);
  });

  it('should check displayName for wrapped components', () => {
    const WrappedComponent = () => null;
    WrappedComponent.displayName = 'ChatStatus';
    const wrappedElement = createElement(WrappedComponent, {});
    expect(isChatStatus(wrappedElement)).toBe(true);
  });
});

describe('hasChatStatus', () => {
  it('should return true when children contain ChatStatus', () => {
    const chatStatusElement = createElement(ChatStatus, { text: 'Loading...' });
    const divElement = createElement('div', {}, 'content');
    const children = [divElement, chatStatusElement];

    expect(hasChatStatus(children)).toBe(true);
  });

  it('should return false when children do not contain ChatStatus', () => {
    const divElement = createElement('div', {}, 'content');
    const spanElement = createElement('span', {}, 'text');
    const children = [divElement, spanElement];

    expect(hasChatStatus(children)).toBe(false);
  });

  it('should return true for single ChatStatus child', () => {
    const chatStatusElement = createElement(ChatStatus, { text: 'Loading...' });
    expect(hasChatStatus(chatStatusElement)).toBe(true);
  });

  it('should return false for single non-ChatStatus child', () => {
    const divElement = createElement('div', {}, 'content');
    expect(hasChatStatus(divElement)).toBe(false);
  });

  it('should return false for null/undefined children', () => {
    expect(hasChatStatus(null)).toBe(false);
    expect(hasChatStatus(undefined)).toBe(false);
  });
});

// ============================================================================
// MESSAGE GROUPING UTILITIES TESTS
// ============================================================================

describe('isThinkingMessageGroup', () => {
  it('should return true for thinking message group', () => {
    const group = {
      type: 'thinking-group' as const,
      id: 'group-1',
      messages: [],
    };
    expect(isThinkingMessageGroup(group)).toBe(true);
  });

  it('should return false for regular message', () => {
    const message = {
      id: 'msg-1',
      content: 'Hello',
      direction: EMessageDirection.INCOMING,
    };
    expect(isThinkingMessageGroup(message)).toBe(false);
  });
});

describe('isThinkingMessage', () => {
  it('should return true for thinking type message', () => {
    const message = {
      id: 'msg-1',
      content: 'Thinking...',
      direction: EMessageDirection.INCOMING,
      type: EMessageType.THINKING,
    };
    expect(isThinkingMessage(message)).toBe(true);
  });

  it('should return false for default type message', () => {
    const message = {
      id: 'msg-1',
      content: 'Hello',
      direction: EMessageDirection.INCOMING,
      type: EMessageType.DEFAULT,
    };
    expect(isThinkingMessage(message)).toBe(false);
  });

  it('should return false for message without type (defaults to default)', () => {
    const message = {
      id: 'msg-1',
      content: 'Hello',
      direction: EMessageDirection.INCOMING,
    };
    expect(isThinkingMessage(message)).toBe(false);
  });

  it('should return false for complete type message', () => {
    const message = {
      id: 'msg-1',
      content: '',
      direction: EMessageDirection.INCOMING,
      type: EMessageType.COMPLETE,
    };
    expect(isThinkingMessage(message)).toBe(false);
  });
});

describe('isCompleteMessage', () => {
  it('should return true for complete type message', () => {
    const message = {
      id: 'msg-1',
      content: '',
      direction: EMessageDirection.INCOMING,
      type: EMessageType.COMPLETE,
    };
    expect(isCompleteMessage(message)).toBe(true);
  });

  it('should return false for default type message', () => {
    const message = {
      id: 'msg-1',
      content: 'Hello',
      direction: EMessageDirection.INCOMING,
      type: EMessageType.DEFAULT,
    };
    expect(isCompleteMessage(message)).toBe(false);
  });

  it('should return false for thinking type message', () => {
    const message = {
      id: 'msg-1',
      content: 'Thinking...',
      direction: EMessageDirection.INCOMING,
      type: EMessageType.THINKING,
    };
    expect(isCompleteMessage(message)).toBe(false);
  });

  it('should return false for message without type', () => {
    const message = {
      id: 'msg-1',
      content: 'Hello',
      direction: EMessageDirection.INCOMING,
    };
    expect(isCompleteMessage(message)).toBe(false);
  });
});

describe('groupConsecutiveThinkingMessages', () => {
  it('should return empty array for undefined messages', () => {
    expect(groupConsecutiveThinkingMessages(undefined)).toEqual([]);
  });

  it('should return empty array for empty messages', () => {
    expect(groupConsecutiveThinkingMessages([])).toEqual([]);
  });

  it('should return regular messages as-is', () => {
    const messages = [
      {
        id: 'msg-1',
        content: 'Hello',
        direction: EMessageDirection.INCOMING as const,
      },
      {
        id: 'msg-2',
        content: 'World',
        direction: EMessageDirection.OUTGOING as const,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    expect(result).toHaveLength(2);
    expect(result[0]).toEqual(messages[0]);
    expect(result[1]).toEqual(messages[1]);
  });

  it('should group consecutive thinking messages', () => {
    const messages = [
      {
        id: 'think-1',
        content: 'Analyzing...',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: 'think-2',
        content: 'Processing...',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    expect(result).toHaveLength(1);
    expect(isThinkingMessageGroup(result[0])).toBe(true);
    const group = result[0] as {
      type: 'thinking-group';
      id: string;
      messages: typeof messages;
    };
    expect(group.id).toBe('think-1');
    expect(group.messages).toHaveLength(2);
  });

  it('should mix regular and thinking messages correctly', () => {
    const messages = [
      {
        id: 'msg-1',
        content: 'Hello',
        direction: EMessageDirection.INCOMING as const,
      },
      {
        id: 'think-1',
        content: 'Analyzing...',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: 'think-2',
        content: 'Processing...',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: 'msg-2',
        content: 'Done!',
        direction: EMessageDirection.INCOMING as const,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    expect(result).toHaveLength(3);

    // First: regular message
    expect(isThinkingMessageGroup(result[0])).toBe(false);
    expect(result[0]).toEqual(messages[0]);

    // Second: thinking group
    expect(isThinkingMessageGroup(result[1])).toBe(true);
    const group = result[1] as {
      type: 'thinking-group';
      id: string;
      messages: typeof messages;
    };
    expect(group.messages).toHaveLength(2);

    // Third: regular message
    expect(isThinkingMessageGroup(result[2])).toBe(false);
    expect(result[2]).toEqual(messages[3]);
  });

  it('should create separate groups for non-consecutive thinking messages', () => {
    const messages = [
      {
        id: 'think-1',
        content: 'Thinking 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: 'msg-1',
        content: 'Regular',
        direction: EMessageDirection.INCOMING as const,
      },
      {
        id: 'think-2',
        content: 'Thinking 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    expect(result).toHaveLength(3);

    // First: thinking group with 1 message
    expect(isThinkingMessageGroup(result[0])).toBe(true);
    const group1 = result[0] as {
      type: 'thinking-group';
      id: string;
      messages: typeof messages;
    };
    expect(group1.messages).toHaveLength(1);
    expect(group1.id).toBe('think-1');

    // Second: regular message
    expect(isThinkingMessageGroup(result[1])).toBe(false);

    // Third: thinking group with 1 message
    expect(isThinkingMessageGroup(result[2])).toBe(true);
    const group2 = result[2] as {
      type: 'thinking-group';
      id: string;
      messages: typeof messages;
    };
    expect(group2.messages).toHaveLength(1);
    expect(group2.id).toBe('think-2');
  });

  it('should handle thinking messages at the end', () => {
    const messages = [
      {
        id: 'msg-1',
        content: 'Start',
        direction: EMessageDirection.INCOMING as const,
      },
      {
        id: 'think-1',
        content: 'Thinking...',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    expect(result).toHaveLength(2);
    expect(isThinkingMessageGroup(result[0])).toBe(false);
    expect(isThinkingMessageGroup(result[1])).toBe(true);
  });

  it('should use first message ID as group ID', () => {
    const messages = [
      {
        id: 'first-think',
        content: 'First',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: 'second-think',
        content: 'Second',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    expect(result).toHaveLength(1);
    const group = result[0] as {
      type: 'thinking-group';
      id: string;
      messages: typeof messages;
    };
    expect(group.id).toBe('first-think');
  });

  it('should pass through complete type messages (handled by Chat component)', () => {
    const messages = [
      {
        id: 'msg-1',
        content: 'Hello',
        direction: EMessageDirection.INCOMING as const,
      },
      {
        id: 'complete-1',
        content: '',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.COMPLETE,
      },
      {
        id: 'msg-2',
        content: 'World',
        direction: EMessageDirection.INCOMING as const,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    // Complete message should pass through (Chat component handles rendering)
    expect(result).toHaveLength(3);
    expect(result[0]).toEqual(messages[0]);
    expect(result[1]).toEqual(messages[1]);
    expect(result[2]).toEqual(messages[2]);
  });

  it('should pass through complete messages while grouping thinking messages', () => {
    const messages = [
      {
        id: 'think-1',
        content: 'Thinking...',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: 'complete-1',
        content: '',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.COMPLETE,
      },
      {
        id: 'think-2',
        content: 'Still thinking...',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: 'msg-1',
        content: 'Done!',
        direction: EMessageDirection.INCOMING as const,
      },
    ];

    const result = groupConsecutiveThinkingMessages(messages);

    // Complete message breaks thinking group, passes through as separate message
    expect(result).toHaveLength(4);
    // First thinking group
    expect(isThinkingMessageGroup(result[0])).toBe(true);
    const group1 = result[0] as {
      type: 'thinking-group';
      id: string;
      messages: typeof messages;
    };
    expect(group1.messages).toHaveLength(1);
    // Complete message passes through
    expect(result[1]).toEqual(messages[1]);
    // Second thinking group
    expect(isThinkingMessageGroup(result[2])).toBe(true);
    const group2 = result[2] as {
      type: 'thinking-group';
      id: string;
      messages: typeof messages;
    };
    expect(group2.messages).toHaveLength(1);
    // Regular message
    expect(result[3]).toEqual(messages[3]);
  });
});

// ============================================================================
// THINKING DURATION UTILITIES TESTS
// ============================================================================

describe('formatThinkingDuration', () => {
  it('should return null for empty messages array', () => {
    const result = formatThinkingDuration([]);
    expect(result).toBeNull();
  });

  it('should return null when first message has no timestamp', () => {
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:45Z'),
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBeNull();
  });

  it('should return null when last message has no timestamp', () => {
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:00Z'),
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBeNull();
  });

  it('should format duration in seconds when under 60 seconds', () => {
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:00Z'),
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:45Z'),
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBe('45s');
  });

  it('should format duration with minutes and seconds when over 60 seconds', () => {
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:00Z'),
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:32:30Z'),
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBe('2m 30s');
  });

  it('should format duration with only minutes when seconds are zero', () => {
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:00Z'),
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:32:00Z'),
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBe('2m');
  });

  it('should handle zero duration', () => {
    const timestamp = new Date('2024-01-15T14:30:00Z');
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp,
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp,
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBe('a few seconds');
  });

  it('should handle string timestamps (ISO format)', () => {
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: '2024-01-15T14:30:00Z',
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: '2024-01-15T14:30:30Z',
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBe('30s');
  });

  it('should work with a single message', () => {
    const timestamp = new Date('2024-01-15T14:30:00Z');
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp,
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBe('a few seconds');
  });

  it('should handle negative duration (end before start) gracefully', () => {
    const messages = [
      {
        id: '1',
        content: 'Step 1',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:30Z'),
      },
      {
        id: '2',
        content: 'Step 2',
        direction: EMessageDirection.INCOMING as const,
        type: EMessageType.THINKING,
        timestamp: new Date('2024-01-15T14:30:00Z'),
      },
    ];

    const result = formatThinkingDuration(messages);
    expect(result).toBe('a few seconds');
  });
});

// ============================================================================
// MULTILINE LAYOUT UTILITIES TESTS
// ============================================================================

describe('calculateMultilineLayout', () => {
  it('should return shouldBeMultiLine: false for single-line layout', () => {
    const textarea = document.createElement('textarea');
    textarea.value = 'Hello';
    const result = calculateMultilineLayout({
      textarea,
      isMultiLine: false,
      measureCanvas: null,
    });
    expect(result.shouldBeMultiLine).toBe(false);
  });

  it('should return shouldBeMultiLine: true when text contains newlines', () => {
    const textarea = document.createElement('textarea');
    textarea.value = 'Hello\nWorld';
    const result = calculateMultilineLayout({
      textarea,
      isMultiLine: false,
      measureCanvas: null,
    });
    expect(result.shouldBeMultiLine).toBe(true);
  });

  it('should return measureCanvas: null when transitioning to multiline', () => {
    const textarea = document.createElement('textarea');
    textarea.value = 'Hello\nWorld';
    const result = calculateMultilineLayout({
      textarea,
      isMultiLine: false,
      measureCanvas: null,
    });
    // Canvas is not needed when transitioning to multiline
    expect(result.measureCanvas).toBe(null);
  });

  it('should preserve isMultiLine state when no change needed', () => {
    const textarea = document.createElement('textarea');
    textarea.value = 'Short text';

    // When already single-line and text is short, should stay single-line
    const result1 = calculateMultilineLayout({
      textarea,
      isMultiLine: false,
      measureCanvas: null,
    });
    expect(result1.shouldBeMultiLine).toBe(false);
  });

  it('should reuse provided measureCanvas', () => {
    const textarea = document.createElement('textarea');
    textarea.value = 'Hello\nWorld';
    const existingCanvas = document.createElement('canvas');

    const result = calculateMultilineLayout({
      textarea,
      isMultiLine: false,
      measureCanvas: existingCanvas,
    });

    // When transitioning to multiline, canvas is passed through
    expect(result.measureCanvas).toBe(existingCanvas);
  });

  it('should handle empty textarea', () => {
    const textarea = document.createElement('textarea');
    textarea.value = '';

    const result = calculateMultilineLayout({
      textarea,
      isMultiLine: false,
      measureCanvas: null,
    });

    expect(result.shouldBeMultiLine).toBe(false);
  });
});
