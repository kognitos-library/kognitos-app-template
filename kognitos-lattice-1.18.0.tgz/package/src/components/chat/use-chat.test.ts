import { describe, it, expect, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useChat } from './use-chat';
import { EMessageDirection, type IChatMessage } from './types';

// Helper to create mock messages
const createMockMessage = (
  id: string,
  content: string,
  direction: EMessageDirection = EMessageDirection.INCOMING,
): IChatMessage => ({
  id,
  content,
  direction,
  timestamp: new Date('2024-01-15T14:30:00'),
});

describe('useChat', () => {
  beforeEach(() => {
    // Reset any state between tests
  });

  describe('Initial State', () => {
    it('should initialize with empty messages array when no initial messages provided', () => {
      const { result } = renderHook(() => useChat());

      expect(result.current.messages).toEqual([]);
    });

    it('should initialize with provided initial messages', () => {
      const initialMessages = [
        createMockMessage('1', 'Hello'),
        createMockMessage('2', 'World'),
      ];

      const { result } = renderHook(() => useChat(initialMessages));

      expect(result.current.messages).toEqual(initialMessages);
      expect(result.current.messages).toHaveLength(2);
    });
  });

  describe('addMessage', () => {
    it('should add a message without id and generate one', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'Hello',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].content).toBe('Hello');
      expect(result.current.messages[0].id).toBeDefined();
      expect(result.current.messages[0].id).toMatch(/^msg-/);
    });

    it('should add a message with existing id', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          id: 'custom-id',
          content: 'Hello',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].id).toBe('custom-id');
      expect(result.current.messages[0].content).toBe('Hello');
    });

    it('should add multiple messages sequentially', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'First',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      act(() => {
        result.current.addMessage({
          content: 'Second',
          direction: EMessageDirection.OUTGOING,
          timestamp: new Date('2024-01-15T14:31:00'),
        });
      });

      expect(result.current.messages).toHaveLength(2);
      expect(result.current.messages[0].content).toBe('First');
      expect(result.current.messages[1].content).toBe('Second');
    });

    it('should append messages to existing messages', () => {
      const initialMessages = [createMockMessage('1', 'Initial')];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.addMessage({
          content: 'New',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      expect(result.current.messages).toHaveLength(2);
      expect(result.current.messages[0].content).toBe('Initial');
      expect(result.current.messages[1].content).toBe('New');
    });
  });

  describe('setMessages', () => {
    it('should replace all messages with new messages', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      const newMessages = [
        createMockMessage('3', 'Third'),
        createMockMessage('4', 'Fourth'),
        createMockMessage('5', 'Fifth'),
      ];

      act(() => {
        result.current.setMessages(newMessages);
      });

      expect(result.current.messages).toEqual(newMessages);
      expect(result.current.messages).toHaveLength(3);
      expect(result.current.messages[0].content).toBe('Third');
    });

    it('should clear messages when set to empty array', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.setMessages([]);
      });

      expect(result.current.messages).toEqual([]);
      expect(result.current.messages).toHaveLength(0);
    });
  });

  describe('removeMessage', () => {
    it('should remove message by id', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
        createMockMessage('3', 'Third'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.removeMessage('2');
      });

      expect(result.current.messages).toHaveLength(2);
      expect(result.current.messages[0].id).toBe('1');
      expect(result.current.messages[1].id).toBe('3');
      expect(
        result.current.messages.find(msg => msg.id === '2'),
      ).toBeUndefined();
    });

    it('should not remove anything when message id does not exist', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.removeMessage('non-existent');
      });

      expect(result.current.messages).toHaveLength(2);
      expect(result.current.messages).toEqual(initialMessages);
    });

    it('should remove first message', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.removeMessage('1');
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].id).toBe('2');
    });

    it('should remove last message', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.removeMessage('2');
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].id).toBe('1');
    });
  });

  describe('updateMessage', () => {
    it('should update message by id with partial updates', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', { content: 'Updated First' });
      });

      expect(result.current.messages[0].content).toBe('Updated First');
      expect(result.current.messages[0].id).toBe('1');
      expect(result.current.messages[1].content).toBe('Second');
    });

    it('should update multiple properties of a message', () => {
      const initialMessages = [
        createMockMessage('1', 'First', EMessageDirection.INCOMING),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', {
          content: 'Updated',
          direction: EMessageDirection.OUTGOING,
          status: 'sent',
        });
      });

      expect(result.current.messages[0].content).toBe('Updated');
      expect(result.current.messages[0].direction).toBe(
        EMessageDirection.OUTGOING,
      );
      expect(result.current.messages[0].status).toBe('sent');
    });

    it('should not update anything when message id does not exist', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('non-existent', {
          content: 'Updated',
        });
      });

      expect(result.current.messages).toEqual(initialMessages);
    });

    it('should preserve other message properties when updating', () => {
      const initialMessages = [
        {
          ...createMockMessage('1', 'First'),
          avatarUrl: 'https://example.com/avatar.jpg',
          status: 'sent' as const,
        },
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', { content: 'Updated' });
      });

      expect(result.current.messages[0].content).toBe('Updated');
      expect(result.current.messages[0].avatarUrl).toBe(
        'https://example.com/avatar.jpg',
      );
      expect(result.current.messages[0].status).toBe('sent');
    });
  });

  describe('clearMessages', () => {
    it('should clear all messages', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
        createMockMessage('3', 'Third'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.clearMessages();
      });

      expect(result.current.messages).toEqual([]);
      expect(result.current.messages).toHaveLength(0);
    });

    it('should clear messages when already empty', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.clearMessages();
      });

      expect(result.current.messages).toEqual([]);
    });
  });

  describe('Complex Operations', () => {
    it('should handle multiple operations in sequence', () => {
      const { result } = renderHook(() => useChat());

      // Add messages
      act(() => {
        result.current.addMessage({
          content: 'First',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
        result.current.addMessage({
          content: 'Second',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:31:00'),
        });
        result.current.addMessage({
          content: 'Third',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:32:00'),
        });
      });

      expect(result.current.messages).toHaveLength(3);

      // Remove middle message
      act(() => {
        result.current.removeMessage(result.current.messages[1].id);
      });

      expect(result.current.messages).toHaveLength(2);

      // Update first message
      act(() => {
        result.current.updateMessage(result.current.messages[0].id, {
          content: 'Updated First',
        });
      });

      expect(result.current.messages[0].content).toBe('Updated First');
      expect(result.current.messages).toHaveLength(2);

      // Clear all
      act(() => {
        result.current.clearMessages();
      });

      expect(result.current.messages).toEqual([]);
    });

    it('should maintain message order after operations', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
        createMockMessage('3', 'Third'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.removeMessage('2');
        result.current.addMessage({
          content: 'New Second',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      expect(result.current.messages[0].content).toBe('First');
      expect(result.current.messages[1].content).toBe('Third');
      expect(result.current.messages[2].content).toBe('New Second');
    });
  });

  describe('Function Stability', () => {
    it('should return stable function references', () => {
      const { result, rerender } = renderHook(() => useChat());

      const firstAddMessage = result.current.addMessage;
      const firstSetMessages = result.current.setMessages;
      const firstRemoveMessage = result.current.removeMessage;
      const firstUpdateMessage = result.current.updateMessage;
      const firstClearMessages = result.current.clearMessages;

      rerender();

      expect(result.current.addMessage).toBe(firstAddMessage);
      expect(result.current.setMessages).toBe(firstSetMessages);
      expect(result.current.removeMessage).toBe(firstRemoveMessage);
      expect(result.current.updateMessage).toBe(firstUpdateMessage);
      expect(result.current.clearMessages).toBe(firstClearMessages);
    });
  });

  describe('Edge Cases', () => {
    it('should handle adding message with all optional properties', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          id: 'full-message',
          content: 'Full Message',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
          avatarUrl: 'https://example.com/avatar.jpg',
          avatarFallback: 'FM',
          status: 'sent',
          variant: 'default',
          showSender: true,
          showTimestamp: true,
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0]).toMatchObject({
        id: 'full-message',
        content: 'Full Message',
        direction: EMessageDirection.INCOMING,
        avatarUrl: 'https://example.com/avatar.jpg',
        avatarFallback: 'FM',
        status: 'sent',
        variant: 'default',
        showSender: true,
        showTimestamp: true,
      });
    });

    it('should handle updating with empty partial object', () => {
      const initialMessages = [createMockMessage('1', 'First')];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', {} as Partial<IChatMessage>);
      });

      expect(result.current.messages[0]).toEqual(initialMessages[0]);
    });

    it('should handle removing from empty array', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.removeMessage('non-existent');
      });

      expect(result.current.messages).toEqual([]);
    });

    it('should handle messages with special characters', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: '<script>alert("xss")</script>',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
        result.current.addMessage({
          content: 'Hello 👋 World 🌍',
          direction: EMessageDirection.OUTGOING,
          timestamp: new Date('2024-01-15T14:31:00'),
        });
        result.current.addMessage({
          content: 'Line 1\nLine 2\nLine 3',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:32:00'),
        });
        result.current.addMessage({
          content: '   Leading and trailing spaces   ',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:33:00'),
        });
      });

      expect(result.current.messages).toHaveLength(4);
      expect(result.current.messages[0].content).toBe(
        '<script>alert("xss")</script>',
      );
      expect(result.current.messages[1].content).toBe('Hello 👋 World 🌍');
      expect(result.current.messages[2].content).toBe('Line 1\nLine 2\nLine 3');
      expect(result.current.messages[3].content).toBe(
        '   Leading and trailing spaces   ',
      );
    });

    it('should handle messages with very long content', () => {
      const { result } = renderHook(() => useChat());

      const longContent = 'A'.repeat(10000);

      act(() => {
        result.current.addMessage({
          content: longContent,
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].content).toBe(longContent);
      expect(result.current.messages[0].content).toHaveLength(10000);
    });

    it('should handle messages with empty string content', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: '',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].content).toBe('');
    });

    it('should handle messages without content property', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        } as IChatMessage);
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].content).toBeUndefined();
      expect(result.current.messages[0].direction).toBe(
        EMessageDirection.INCOMING,
      );
    });

    it('should handle rapid successive add operations', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        for (let i = 0; i < 100; i++) {
          result.current.addMessage({
            content: `Message ${i}`,
            direction: EMessageDirection.INCOMING,
            timestamp: new Date(`2024-01-15T14:${30 + i}:00`),
          });
        }
      });

      expect(result.current.messages).toHaveLength(100);
      expect(result.current.messages[0].content).toBe('Message 0');
      expect(result.current.messages[99].content).toBe('Message 99');
    });

    it('should handle rapid successive remove operations', () => {
      const initialMessages = Array.from({ length: 50 }, (_, i) =>
        createMockMessage(`msg-${i}`, `Message ${i}`),
      );
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        for (let i = 0; i < 25; i++) {
          result.current.removeMessage(`msg-${i * 2}`);
        }
      });

      expect(result.current.messages).toHaveLength(25);
      expect(
        result.current.messages.every(msg => msg.id.startsWith('msg-')),
      ).toBe(true);
    });

    it('should handle rapid successive update operations', () => {
      const initialMessages = Array.from({ length: 10 }, (_, i) =>
        createMockMessage(`msg-${i}`, `Message ${i}`),
      );
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        for (let i = 0; i < 10; i++) {
          result.current.updateMessage(`msg-${i}`, {
            content: `Updated ${i}`,
          });
        }
      });

      expect(result.current.messages).toHaveLength(10);
      expect(result.current.messages[0].content).toBe('Updated 0');
      expect(result.current.messages[9].content).toBe('Updated 9');
    });

    it('should handle messages with string timestamp', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'String timestamp',
          direction: EMessageDirection.INCOMING,
          timestamp: '2024-01-15T14:30:00',
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].timestamp).toBe('2024-01-15T14:30:00');
    });

    it('should handle messages with Date timestamp', () => {
      const { result } = renderHook(() => useChat());

      const date = new Date('2024-01-15T14:30:00');
      act(() => {
        result.current.addMessage({
          content: 'Date timestamp',
          direction: EMessageDirection.INCOMING,
          timestamp: date,
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].timestamp).toBe(date);
    });

    it('should handle messages without timestamp', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'No timestamp',
          direction: EMessageDirection.INCOMING,
        } as IChatMessage);
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].timestamp).toBeUndefined();
    });

    it('should handle updating all optional properties', () => {
      const initialMessages = [
        createMockMessage('1', 'Original', EMessageDirection.INCOMING),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', {
          content: 'Updated Content',
          direction: EMessageDirection.OUTGOING,
          variant: 'inline',
          avatarUrl: 'https://example.com/new-avatar.jpg',
          avatarFallback: 'UC',
          status: 'delivered',
          showSender: false,
          showTimestamp: false,
        });
      });

      expect(result.current.messages[0]).toMatchObject({
        id: '1',
        content: 'Updated Content',
        direction: EMessageDirection.OUTGOING,
        variant: 'inline',
        avatarUrl: 'https://example.com/new-avatar.jpg',
        avatarFallback: 'UC',
        status: 'delivered',
        showSender: false,
        showTimestamp: false,
      });
    });

    it('should handle messages with attachments', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'Message with attachment',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
          attachments: [
            {
              id: 'att-1',
              name: 'document.pdf',
              type: 'pdf',
              url: 'https://example.com/document.pdf',
              size: 1024,
            },
          ],
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].attachments).toHaveLength(1);
      expect(result.current.messages[0].attachments?.[0].name).toBe(
        'document.pdf',
      );
    });

    it('should handle updating message attachments', () => {
      const initialMessages = [
        {
          ...createMockMessage('1', 'Original'),
          attachments: [
            {
              id: 'att-1',
              name: 'old.pdf',
              type: 'pdf' as const,
            },
          ],
        },
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', {
          attachments: [
            {
              id: 'att-2',
              name: 'new.pdf',
              type: 'pdf' as const,
              url: 'https://example.com/new.pdf',
            },
          ],
        });
      });

      expect(result.current.messages[0].attachments).toHaveLength(1);
      expect(result.current.messages[0].attachments?.[0].name).toBe('new.pdf');
      expect(result.current.messages[0].attachments?.[0].id).toBe('att-2');
    });

    it('should handle messages with widgets', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'Message with widget',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
          widget: {
            type: 'button-group',
            buttons: [
              {
                id: 'btn-1',
                label: 'Button 1',
                variant: 'default',
              },
              {
                id: 'btn-2',
                label: 'Button 2',
                variant: 'secondary',
              },
            ],
          },
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].widget?.type).toBe('button-group');
      expect(result.current.messages[0].widget?.buttons).toHaveLength(2);
    });

    it('should handle updating message widget', () => {
      const initialMessages = [
        {
          ...createMockMessage('1', 'Original'),
          widget: {
            type: 'button-group' as const,
            buttons: [{ id: 'btn-1', label: 'Old Button' }],
          },
        },
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', {
          widget: {
            type: 'action-cards' as const,
            actionCards: [
              {
                id: 'card-1',
                title: 'New Card',
                description: 'Card description',
              },
            ],
          },
        });
      });

      expect(result.current.messages[0].widget?.type).toBe('action-cards');
      expect(result.current.messages[0].widget?.actionCards).toHaveLength(1);
      expect(result.current.messages[0].widget?.actionCards?.[0].title).toBe(
        'New Card',
      );
    });

    it('should handle concurrent add and remove operations', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        // Add messages
        result.current.addMessage({
          content: 'Message 1',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
        result.current.addMessage({
          content: 'Message 2',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:31:00'),
        });
        result.current.addMessage({
          content: 'Message 3',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:32:00'),
        });
      });

      act(() => {
        // Remove middle message
        const messageId = result.current.messages[1].id;
        result.current.removeMessage(messageId);
      });

      act(() => {
        // Add another message
        result.current.addMessage({
          content: 'Message 4',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:33:00'),
        });
      });

      expect(result.current.messages).toHaveLength(3);
      expect(result.current.messages[0].content).toBe('Message 1');
      expect(result.current.messages[1].content).toBe('Message 3');
      expect(result.current.messages[2].content).toBe('Message 4');
    });

    it('should handle concurrent update and remove operations', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
        createMockMessage('3', 'Third'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        // Update first message
        result.current.updateMessage('1', { content: 'Updated First' });

        // Remove second message
        result.current.removeMessage('2');

        // Update third message
        result.current.updateMessage('3', { content: 'Updated Third' });
      });

      expect(result.current.messages).toHaveLength(2);
      expect(result.current.messages[0].content).toBe('Updated First');
      expect(result.current.messages[1].content).toBe('Updated Third');
    });

    it('should handle setMessages with large array', () => {
      const { result } = renderHook(() => useChat());

      const largeArray = Array.from({ length: 1000 }, (_, i) =>
        createMockMessage(`msg-${i}`, `Message ${i}`),
      );

      act(() => {
        result.current.setMessages(largeArray);
      });

      expect(result.current.messages).toHaveLength(1000);
      expect(result.current.messages[0].id).toBe('msg-0');
      expect(result.current.messages[999].id).toBe('msg-999');
    });

    it('should handle adding message with duplicate id when id is provided', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          id: 'duplicate-id',
          content: 'First',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
        result.current.addMessage({
          id: 'duplicate-id',
          content: 'Second',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:31:00'),
        });
      });

      // Both messages should be added (duplicate IDs are allowed)
      expect(result.current.messages).toHaveLength(2);
      expect(result.current.messages[0].id).toBe('duplicate-id');
      expect(result.current.messages[1].id).toBe('duplicate-id');
      expect(result.current.messages[0].content).toBe('First');
      expect(result.current.messages[1].content).toBe('Second');
    });

    it('should handle clearing and then adding messages', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.clearMessages();
        result.current.addMessage({
          content: 'New Message',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].content).toBe('New Message');
    });

    it('should handle updating message that was just added', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'Original',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      act(() => {
        const messageId = result.current.messages[0].id;
        result.current.updateMessage(messageId, { content: 'Updated' });
      });

      expect(result.current.messages).toHaveLength(1);
      expect(result.current.messages[0].content).toBe('Updated');
    });

    it('should handle removing message that was just added', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        result.current.addMessage({
          content: 'Temporary',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      act(() => {
        const messageId = result.current.messages[0].id;
        result.current.removeMessage(messageId);
      });

      expect(result.current.messages).toHaveLength(0);
    });

    it('should handle updating multiple messages in sequence', () => {
      const initialMessages = [
        createMockMessage('1', 'First'),
        createMockMessage('2', 'Second'),
        createMockMessage('3', 'Third'),
      ];
      const { result } = renderHook(() => useChat(initialMessages));

      act(() => {
        result.current.updateMessage('1', { status: 'sent' });
        result.current.updateMessage('2', { status: 'delivered' });
        result.current.updateMessage('3', { status: 'error' });
      });

      expect(result.current.messages[0].status).toBe('sent');
      expect(result.current.messages[1].status).toBe('delivered');
      expect(result.current.messages[2].status).toBe('error');
    });

    it('should handle all operations on single message', () => {
      const { result } = renderHook(() => useChat());

      act(() => {
        // Add
        result.current.addMessage({
          content: 'Original',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        });
      });

      act(() => {
        const messageId = result.current.messages[0].id;

        // Update
        result.current.updateMessage(messageId, { content: 'Updated' });
      });

      act(() => {
        const messageId = result.current.messages[0].id;

        // Update again
        result.current.updateMessage(messageId, { status: 'sent' });
      });

      act(() => {
        const messageId = result.current.messages[0].id;

        // Remove
        result.current.removeMessage(messageId);
      });

      expect(result.current.messages).toHaveLength(0);
    });
  });
});
