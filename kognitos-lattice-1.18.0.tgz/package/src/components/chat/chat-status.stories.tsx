import type { Meta, StoryObj } from '@storybook/react-vite';
import { ChatStatus, Flex, type IconType } from '@/design-system';
import { EMessageUpdateState } from './types';

// Example icon types for Storybook controls
const exampleIcons: IconType[] = [
  'Loader2',
  'AlertCircle',
  'AlertTriangle',
  'CircleCheckBig',
  'Info',
  'X',
  'RefreshCw',
];

const meta: Meta<typeof ChatStatus> = {
  title: 'Design System/Components/Chat/ChatStatus',
  component: ChatStatus,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Status indicator component for displaying loading, error, or warning states. Place between messages in Chat component children to show system status. Supports optional action buttons that match the status color.',
      },
    },
  },
  argTypes: {
    state: {
      control: 'select',
      options: [
        EMessageUpdateState.DEFAULT,
        EMessageUpdateState.ERROR,
        EMessageUpdateState.WARNING,
        EMessageUpdateState.SUCCESS,
      ],
      description: 'Status state that determines color and icon',
    },
    text: {
      control: { type: 'text' },
      description: 'Status text to display',
    },
    icon: {
      control: 'select',
      options: exampleIcons,
      description:
        'Optional custom icon type. If not provided, defaults based on state.',
    },
    showIcon: {
      control: 'boolean',
      description: 'Whether to display the status icon',
    },
    action: {
      control: 'object',
      description: 'Optional action button with label and onClick handler',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatStatus>;

// Default chat status in default/thinking state
export const Default: Story = {
  render: args => (
    <div className="w-[200px]">
      <ChatStatus {...args} />
    </div>
  ),
  args: {
    state: EMessageUpdateState.DEFAULT,
    text: 'Thinking...',
    showIcon: false,
  },
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'Default chat status in thinking/loading state. Shows shimmering text animation.',
      },
    },
  },
};

// Chat status with icon
export const WithIcon: Story = {
  render: args => (
    <div className="w-[200px]">
      <ChatStatus {...args} />
    </div>
  ),
  args: {
    state: EMessageUpdateState.DEFAULT,
    text: 'Thinking...',
    showIcon: true,
  },
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'Chat status with icon displayed. Icon animates when in default/thinking state.',
      },
    },
  },
};

// Other states
export const OtherStates: Story = {
  render: () => (
    <Flex direction="column" gap={4}>
      {/* Error state */}
      <div>
        <p className="text-sm text-muted-foreground mb-2">Error</p>
        <div className="w-[200px]">
          <ChatStatus
            state={EMessageUpdateState.ERROR}
            text="Something went wrong"
            showIcon
          />
        </div>
      </div>

      {/* Warning state */}
      <div>
        <p className="text-sm text-muted-foreground mb-2">Warning</p>
        <div className="w-[200px]">
          <ChatStatus
            state={EMessageUpdateState.WARNING}
            text="Needs attention"
            showIcon
          />
        </div>
      </div>

      {/* Success state */}
      <div>
        <p className="text-sm text-muted-foreground mb-2">Success</p>
        <div className="w-[200px]">
          <ChatStatus
            state={EMessageUpdateState.SUCCESS}
            text="Completed"
            showIcon
          />
        </div>
      </div>
    </Flex>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'Error, warning, and success states. Error state displays with red text and error icon. Warning state displays with orange text and warning icon. Success state displays with green text and success icon.',
      },
    },
  },
};

// With action button
export const WithActionButton: Story = {
  render: () => (
    <Flex direction="column" gap={4}>
      {/* Default state with action */}
      <div>
        <p className="text-sm text-muted-foreground mb-2">
          Default with Action
        </p>
        <div className="w-[240px]">
          <ChatStatus
            state={EMessageUpdateState.DEFAULT}
            text="Thinking..."
            showIcon
            action={{
              label: 'Stop',
              onClick: () => console.log('Stop clicked'),
            }}
          />
        </div>
      </div>

      {/* Error state with icon and action */}
      <div>
        <p className="text-sm text-muted-foreground mb-2">Error with Action</p>
        <div className="w-[240px]">
          <ChatStatus
            state={EMessageUpdateState.ERROR}
            text="Something went wrong"
            showIcon
            action={{
              label: 'Retry',
              onClick: () => console.log('Retry clicked'),
            }}
          />
        </div>
      </div>

      {/* Warning state with icon and action */}
      <div>
        <p className="text-sm text-muted-foreground mb-2">
          Warning with Action
        </p>
        <div className="w-[240px]">
          <ChatStatus
            state={EMessageUpdateState.WARNING}
            text="Needs attention"
            showIcon
            action={{
              label: 'Retry',
              onClick: () => console.log('Retry clicked'),
            }}
          />
        </div>
      </div>

      {/* Success state with icon and action */}
      <div>
        <p className="text-sm text-muted-foreground mb-2">
          Success with Action
        </p>
        <div className="w-[240px]">
          <ChatStatus
            state={EMessageUpdateState.SUCCESS}
            text="Completed"
            showIcon
            action={{
              label: 'View Details',
              onClick: () => console.log('View Details clicked'),
            }}
          />
        </div>
      </div>
    </Flex>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'All states with action buttons displayed. Action button text uses the base foreground color.',
      },
    },
  },
};
