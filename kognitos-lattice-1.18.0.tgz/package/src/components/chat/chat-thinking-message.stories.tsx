import type { Meta, StoryObj } from '@storybook/react-vite';
import { ChatThinkingMessage, type IChatMessage, Flex } from '@/design-system';

const meta: Meta<typeof ChatThinkingMessage> = {
  title: 'Design System/Components/Chat/ChatThinkingMessage',
  component: ChatThinkingMessage,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A collapsible component for displaying grouped thinking messages during AI processing. Supports streaming and complete states with animated transitions.',
      },
    },
  },
  argTypes: {
    messages: {
      control: { type: 'object' },
      description: 'Array of thinking messages to display',
    },
    isComplete: {
      control: { type: 'boolean' },
      description:
        'Whether the thinking process is complete. When true, displays "Thought for Xs" instead of shimmering text.',
    },
    title: {
      control: { type: 'text' },
      description:
        'Custom title for the thinking message. Defaults to "Neurosymbolizing..."',
    },
    onComplete: {
      action: 'onComplete',
      description:
        'Callback function called when the thinking process completes and collapses',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatThinkingMessage>;

// Sample thinking messages
const sampleThinkingMessages: IChatMessage[] = [
  {
    id: 'think-1',
    content: 'Analyzing the user request and breaking down the problem...',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:00'),
  },
  {
    id: 'think-2',
    content: 'Searching through relevant data sources and documentation...',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:02'),
  },
  {
    id: 'think-3',
    content: 'Formulating the most appropriate response based on findings...',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:05'),
  },
];

// Code/automation-style thinking messages
const codeThinkingMessages: IChatMessage[] = [
  {
    id: 'code-think-1',
    content: `The user confirmed they want to save this as an automation. I need to use \`create_automation\` since the automation is currently empty.

I need to:
1. Add proper SOP comments with \`# @step\`, \`# @vars:\`, and \`#:\` detail lines
2. Provide a clear title and overview
3. The code reads the string input and gets the 4th character (index 3)

Let me write this with proper SOP formatting:

\`\`\`spy
# @step Extract 4th character from string
# @vars: input string=input_string, fourth character=fourth_char
#: Read the input string
input_string = read_input("This_is_very_long_input_name_that_can_cause_overflow_issues", type=str)
#: Get the character at position 4 (index 3)
fourth_char = input_string[3]

set_output("fourth_character", value=fourth_char)
\`\`\`

Title: "Get 4th Character"
Overview: "Extracts the 4th character from a string."`,
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:00'),
  },
];

// More detailed thinking messages for longer content
const detailedThinkingMessages: IChatMessage[] = [
  {
    id: 'think-1',
    content:
      'Step 1: Parsing the input query to identify key entities and intent. The user appears to be asking about data transformation in the pipeline.',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:00'),
  },
  {
    id: 'think-2',
    content:
      'Step 2: Retrieving relevant context from the knowledge base. Found 3 related documents about ETL processes and data mapping.',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:03'),
  },
  {
    id: 'think-3',
    content:
      'Step 3: Cross-referencing the retrieved information with the current pipeline configuration to ensure accuracy.',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:06'),
  },
  {
    id: 'think-4',
    content:
      'Step 4: Generating a comprehensive response that addresses all aspects of the query while maintaining clarity.',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:09'),
  },
  {
    id: 'think-5',
    content:
      'Step 5: Final validation of the response to ensure technical accuracy and completeness.',
    direction: 'incoming',
    type: 'thinking',
    timestamp: new Date('2024-01-15T10:00:12'),
  },
];

/**
 * Streaming state - shows shimmering text animation as loading indicator.
 * Click to expand and see thinking messages.
 */
export const Streaming: Story = {
  args: {
    messages: sampleThinkingMessages,
    isComplete: false,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * Complete state - shows "Thought for Xs" in italic gray text.
 * Duration is calculated from message timestamps.
 */
export const Complete: Story = {
  args: {
    messages: sampleThinkingMessages,
    isComplete: true,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * With custom title - override the default "Neurosymbolizing..." text.
 */
export const CustomTitle: Story = {
  args: {
    messages: sampleThinkingMessages,
    isComplete: false,
    title: 'Processing your request...',
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * Many messages - demonstrates scrollable content when expanded.
 * Messages area has a max height of 200px with overflow scroll.
 */
export const ManyMessages: Story = {
  args: {
    messages: detailedThinkingMessages,
    isComplete: false,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * Many messages in complete state - shows longer duration calculation.
 */
export const ManyMessagesComplete: Story = {
  args: {
    messages: detailedThinkingMessages,
    isComplete: true,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * Single message - minimal thinking display.
 */
export const SingleMessage: Story = {
  args: {
    messages: [sampleThinkingMessages[0]],
    isComplete: false,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * Long message content - tests text wrapping in the expanded state.
 */
export const LongMessageContent: Story = {
  args: {
    messages: [
      {
        id: 'long-1',
        content:
          'This is a very long thinking message that demonstrates how the component handles text wrapping. The content should wrap properly within the container and remain readable even when the thinking process generates verbose output. This helps ensure the UI remains clean and usable regardless of content length.',
        direction: 'incoming' as const,
        type: 'thinking' as const,
        timestamp: new Date('2024-01-15T10:00:00'),
      },
      {
        id: 'long-2',
        content:
          'Another lengthy message continues the thought process, showing that multiple long messages can be displayed together in the scrollable area. The max-height constraint ensures the component does not take up too much vertical space while still allowing users to review all thinking steps.',
        direction: 'incoming' as const,
        type: 'thinking' as const,
        timestamp: new Date('2024-01-15T10:00:05'),
      },
    ],
    isComplete: false,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * States comparison - shows streaming vs complete side by side.
 */
export const StatesComparison: Story = {
  render: () => (
    <Flex direction="column" gap={6} className="w-full max-w-md p-4">
      <div>
        <p className="text-sm text-muted-foreground mb-2">
          Streaming (shimmering text)
        </p>
        <ChatThinkingMessage
          messages={sampleThinkingMessages}
          isComplete={false}
        />
      </div>
      <div>
        <p className="text-sm text-muted-foreground mb-2">
          Complete (static italic text)
        </p>
        <ChatThinkingMessage messages={sampleThinkingMessages} isComplete />
      </div>
    </Flex>
  ),
};

/**
 * Code content - demonstrates rendering of code blocks and structured
 * automation content within thinking messages.
 */
export const CodeContent: Story = {
  args: {
    messages: codeThinkingMessages,
    isComplete: false,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * Code content complete - code/automation thinking in complete state.
 */
export const CodeContentComplete: Story = {
  args: {
    messages: codeThinkingMessages,
    isComplete: true,
  },
  render: args => (
    <div className="w-full max-w-md p-4">
      <ChatThinkingMessage {...args} />
    </div>
  ),
};

/**
 * Interactive demo - shows state transition behavior.
 * In a real app, isComplete would be set to true when streaming finishes.
 */
export const InteractiveDemo: Story = {
  render: () => {
    // Note: In actual implementation, state would be managed by the parent component
    return (
      <Flex direction="column" gap={4} className="w-full max-w-md p-4">
        <div className="p-4 bg-muted/50 rounded-lg">
          <p className="text-sm text-muted-foreground mb-4">
            💡 <strong>Tip:</strong> Click on the thinking message header to
            expand/collapse and view the detailed thinking steps.
          </p>
          <ChatThinkingMessage
            messages={detailedThinkingMessages}
            isComplete={false}
            onComplete={() => console.log('Thinking complete!')}
          />
        </div>
      </Flex>
    );
  },
};
