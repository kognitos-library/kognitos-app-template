import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { Chat } from './chat';
import { ChatInput } from './chat-input';
import { EMessageDirection, EMessageVariant, type IChatMessage } from './types';

// Mock requestAnimationFrame for scroll tests
const mockRAF = vi.fn((cb: FrameRequestCallback) => {
  setTimeout(cb, 0);
  return 0;
});
const mockCancelRAF = vi.fn();

// Mock ResizeObserver for scroll tests
const mockResizeObserverObserve = vi.fn();
const mockResizeObserverDisconnect = vi.fn();

class MockResizeObserver implements ResizeObserver {
  observe = mockResizeObserverObserve;
  unobserve = vi.fn();
  disconnect = mockResizeObserverDisconnect;
}

beforeEach(() => {
  global.requestAnimationFrame = mockRAF as typeof global.requestAnimationFrame;
  global.cancelAnimationFrame =
    mockCancelRAF as typeof global.cancelAnimationFrame;
  global.ResizeObserver =
    MockResizeObserver as unknown as typeof ResizeObserver;
});

afterEach(() => {
  vi.clearAllMocks();
});

// Helper to create mock messages
const createMockMessage = (
  id: string,
  content: string,
  direction: EMessageDirection = EMessageDirection.INCOMING,
): IChatMessage => ({
  id,
  content,
  direction,
  timestamp: new Date('2024-01-15T14:30:00'),
});

describe('Chat', () => {
  describe('Rendering', () => {
    it('should render chat container with correct attributes', () => {
      render(<Chat messages={[]} />);

      const chatContainer = screen.getByRole('region', {
        name: 'Chat conversation',
      });
      expect(chatContainer).toBeInTheDocument();
      expect(chatContainer).toHaveAttribute('data-slot', 'chat');
    });

    it('should render messages when provided', () => {
      const messages = [
        createMockMessage('1', 'Hello'),
        createMockMessage('2', 'World'),
      ];

      render(<Chat messages={messages} />);

      expect(screen.getByText('Hello')).toBeInTheDocument();
      expect(screen.getByText('World')).toBeInTheDocument();
    });

    it('should render empty state when no messages', () => {
      render(<Chat messages={[]} showEmptyState />);

      expect(screen.getByText('No messages yet')).toBeInTheDocument();
      expect(
        screen.getByText(
          'Your Agent is ready to assist — type anything to begin.',
        ),
      ).toBeInTheDocument();
    });

    it('should not render empty state when showEmptyState is false', () => {
      render(<Chat messages={[]} showEmptyState={false} />);

      expect(screen.queryByText('No messages yet')).not.toBeInTheDocument();
    });

    it('should render custom empty state props', () => {
      render(
        <Chat
          messages={[]}
          emptyStateTitle="Custom Title"
          emptyStateDescription="Custom Description"
          emptyStateIcon="Info"
        />,
      );

      expect(screen.getByText('Custom Title')).toBeInTheDocument();
      expect(screen.getByText('Custom Description')).toBeInTheDocument();
    });

    it('should render ChatInput when provided as child', () => {
      const handleSend = vi.fn();
      render(
        <Chat messages={[]}>
          <ChatInput value="" onChange={() => {}} onSend={handleSend} />
        </Chat>,
      );

      const chatInput = screen.getByRole('textbox');
      expect(chatInput).toBeInTheDocument();
    });

    it('should render other children alongside messages', () => {
      const messages = [createMockMessage('1', 'Hello')];

      render(
        <Chat messages={messages}>
          <div data-testid="other-child">Other Content</div>
        </Chat>,
      );

      expect(screen.getByText('Hello')).toBeInTheDocument();
      expect(screen.getByTestId('other-child')).toBeInTheDocument();
    });

    it('should use custom renderMessage function', () => {
      const messages = [createMockMessage('1', 'Hello')];
      const renderMessage = vi.fn((message: IChatMessage) => (
        <div data-testid={`custom-${message.id}`}>{message.content}</div>
      ));

      render(<Chat messages={messages} renderMessage={renderMessage} />);

      expect(renderMessage).toHaveBeenCalledWith(messages[0]);
      expect(screen.getByTestId('custom-1')).toBeInTheDocument();
      expect(screen.getByText('Hello')).toBeInTheDocument();
    });
  });

  describe('Variants', () => {
    it('should render with default variant', () => {
      const { container } = render(<Chat messages={[]} />);
      const chatContainer = container.querySelector('[data-slot="chat"]');
      expect(chatContainer).toBeInTheDocument();
    });
  });

  describe('Scroll Behavior', () => {
    it('should scroll to bottom on initial render with messages', async () => {
      const messages = [createMockMessage('1', 'Hello')];
      const { container } = render(<Chat messages={messages} />);

      // Wait for viewport to be set up
      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      // Set up scroll properties on the viewport element
      const viewport = container.querySelector(
        '[data-slot="scroll-area-viewport"]',
      ) as HTMLElement;
      if (viewport) {
        Object.defineProperty(viewport, 'scrollTop', {
          value: 0,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'scrollHeight', {
          value: 1000,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'clientHeight', {
          value: 500,
          writable: true,
          configurable: true,
        });
      }

      // Wait for requestAnimationFrame to be called for initial scroll
      await waitFor(
        () => {
          expect(mockRAF).toHaveBeenCalled();
        },
        { timeout: 1000 },
      );

      // Flush any pending timers to ensure all async operations complete
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    it('should scroll to bottom when new outgoing message is added', async () => {
      const messages1 = [createMockMessage('1', 'Hello')];
      const { rerender, container } = render(<Chat messages={messages1} />);

      // Wait for viewport and mock scrollTo
      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      const viewport = container.querySelector(
        '[data-slot="scroll-area-viewport"]',
      ) as HTMLElement;
      if (viewport) {
        Object.defineProperty(viewport, 'scrollTop', {
          value: 0,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'scrollHeight', {
          value: 1000,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'clientHeight', {
          value: 500,
          writable: true,
          configurable: true,
        });
      }

      // Wait for initial scroll to complete via requestAnimationFrame
      await waitFor(
        () => {
          expect(mockRAF).toHaveBeenCalled();
        },
        { timeout: 1000 },
      );

      // Flush any pending timers
      await new Promise(resolve => setTimeout(resolve, 10));

      vi.clearAllMocks();

      const messages2 = [
        ...messages1,
        createMockMessage('2', 'World', EMessageDirection.OUTGOING),
      ];

      rerender(<Chat messages={messages2} />);

      // For new outgoing messages, requestAnimationFrame is used (not ResizeObserver)
      await waitFor(
        () => {
          expect(mockRAF).toHaveBeenCalled();
        },
        { timeout: 1000 },
      );

      // Flush any pending timers
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    it('should scroll to bottom when new incoming message is added and user is at bottom', async () => {
      const messages1 = [createMockMessage('1', 'Hello')];
      const { rerender, container } = render(<Chat messages={messages1} />);

      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      const viewport = container.querySelector(
        '[data-slot="scroll-area-viewport"]',
      ) as HTMLElement;
      if (viewport) {
        // Simulate user at bottom
        Object.defineProperty(viewport, 'scrollTop', {
          value: 500,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'scrollHeight', {
          value: 1000,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'clientHeight', {
          value: 500,
          writable: true,
          configurable: true,
        });
      }

      vi.clearAllMocks();

      const messages2 = [
        ...messages1,
        createMockMessage('2', 'World', EMessageDirection.INCOMING),
      ];

      rerender(<Chat messages={messages2} />);

      await waitFor(
        () => {
          expect(mockRAF).toHaveBeenCalled();
        },
        { timeout: 1000 },
      );

      // Flush any pending timers
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    it('should not scroll when user has scrolled up and new incoming message arrives', async () => {
      const messages1 = [createMockMessage('1', 'Hello')];
      const { rerender, container } = render(
        <Chat messages={messages1} scrollThreshold={100} />,
      );

      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      const viewport = container.querySelector(
        '[data-slot="scroll-area-viewport"]',
      ) as HTMLElement;
      if (viewport) {
        // Simulate user scrolled up (more than threshold from bottom)
        Object.defineProperty(viewport, 'scrollTop', {
          value: 0,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'scrollHeight', {
          value: 1000,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'clientHeight', {
          value: 500,
          writable: true,
          configurable: true,
        });
        // Distance from bottom = 1000 - 0 - 500 = 500 (greater than threshold of 100)
      }

      // Trigger scroll event to update isUserScrolledUpRef
      if (viewport) {
        const scrollEvent = new Event('scroll', { bubbles: true });
        viewport.dispatchEvent(scrollEvent);
      }

      vi.clearAllMocks();

      const messages2 = [
        ...messages1,
        createMockMessage('2', 'World', EMessageDirection.INCOMING),
      ];

      rerender(<Chat messages={messages2} />);

      // Should not trigger scroll for incoming messages when user is scrolled up
      // The scroll should not happen because isUserScrolledUpRef.current is true
      await waitFor(
        () => {
          // Give some time for the effect to run
        },
        { timeout: 200 },
      );

      // The scroll should not have been called for incoming messages when scrolled up
      // This is the expected behavior - we preserve user's scroll position

      // Flush any pending timers
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    it('should respect custom scrollThreshold', async () => {
      const messages = [createMockMessage('1', 'Hello')];
      const { container } = render(
        <Chat messages={messages} scrollThreshold={200} />,
      );

      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      const viewport = container.querySelector(
        '[data-slot="scroll-area-viewport"]',
      ) as HTMLElement;
      if (viewport) {
        Object.defineProperty(viewport, 'scrollTop', {
          value: 0,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'scrollHeight', {
          value: 1000,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'clientHeight', {
          value: 500,
          writable: true,
          configurable: true,
        });
      }

      // Flush any pending timers
      await new Promise(resolve => setTimeout(resolve, 10));
    });
  });

  describe('Gradient', () => {
    it('should show gradient when showGradient is true and messages exist', () => {
      const messages = [createMockMessage('1', 'Hello')];
      const { container } = render(<Chat messages={messages} showGradient />);

      const gradient = container.querySelector(
        '.bg-gradient-to-b.from-secondary',
      );
      expect(gradient).toBeInTheDocument();
    });

    it('should not show gradient when showGradient is false', () => {
      const messages = [createMockMessage('1', 'Hello')];
      const { container } = render(
        <Chat messages={messages} showGradient={false} />,
      );

      const gradient = container.querySelector(
        '.bg-gradient-to-b.from-secondary',
      );
      expect(gradient).not.toBeInTheDocument();
    });

    it('should not show gradient when no messages', () => {
      const { container } = render(<Chat messages={[]} showGradient />);

      const gradient = container.querySelector(
        '.bg-gradient-to-b.from-secondary',
      );
      expect(gradient).not.toBeInTheDocument();
    });
  });

  describe('Message Configuration', () => {
    it('should pass messageVariant to messages', () => {
      const messages = [createMockMessage('1', 'Hello')];
      render(
        <Chat messages={messages} messageVariant={EMessageVariant.INLINE} />,
      );

      // The variant should be applied to the message
      const message = screen.getByRole('article');
      expect(message).toBeInTheDocument();
    });

    it('should pass showSender to messages', () => {
      const messages = [
        {
          ...createMockMessage('1', 'Hello'),
          avatarUrl: 'https://example.com/avatar.jpg',
        },
      ];
      const { container } = render(<Chat messages={messages} showSender />);

      // Avatar should be rendered when showSender is true
      // Note: Avatar might not have data-slot, so we check for the message content
      expect(screen.getByText('Hello')).toBeInTheDocument();
      // Check for avatar image or avatar container
      const avatarImage = container.querySelector(
        'img[src="https://example.com/avatar.jpg"]',
      );
      const avatarContainer = container.querySelector('[data-slot="avatar"]');
      expect(avatarImage ?? avatarContainer).toBeInTheDocument();
    });

    it('should pass showTimestamp to messages', () => {
      const messages = [createMockMessage('1', 'Hello')];
      render(<Chat messages={messages} showTimestamp />);

      // Timestamp should be rendered
      const timestamp = screen.getByText(/2:30 PM/);
      expect(timestamp).toBeInTheDocument();
    });

    it('should use custom timestampFormatter', () => {
      const messages = [createMockMessage('1', 'Hello')];
      const customFormatter = vi.fn(() => 'Custom Time');

      render(
        <Chat
          messages={messages}
          timestampFormatter={customFormatter}
          showTimestamp
        />,
      );

      expect(customFormatter).toHaveBeenCalled();
      expect(screen.getByText('Custom Time')).toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    it('should have proper ARIA attributes', () => {
      render(<Chat messages={[]} />);

      const chatContainer = screen.getByRole('region', {
        name: 'Chat conversation',
      });
      expect(chatContainer).toBeInTheDocument();

      const log = screen.getByRole('log');
      expect(log).toHaveAttribute('aria-live', 'polite');
      expect(log).toHaveAttribute('aria-relevant', 'additions');
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      const { container } = render(
        <Chat messages={[]} className="custom-class" />,
      );
      const chatContainer = container.querySelector('[data-slot="chat"]');
      expect(chatContainer).toHaveClass('custom-class');
    });
  });

  describe('Data Attributes', () => {
    it('should set data-message-count attribute', () => {
      const messages = [
        createMockMessage('1', 'Hello'),
        createMockMessage('2', 'World'),
      ];
      const { container } = render(<Chat messages={messages} />);
      const chatContainer = container.querySelector('[data-slot="chat"]');
      expect(chatContainer).toHaveAttribute('data-message-count', '2');
    });

    it('should set data-has-messages to true when messages exist', () => {
      const messages = [createMockMessage('1', 'Hello')];
      const { container } = render(<Chat messages={messages} />);
      const chatContainer = container.querySelector('[data-slot="chat"]');
      expect(chatContainer).toHaveAttribute('data-has-messages', 'true');
    });

    it('should set data-has-messages to false when no messages', () => {
      const { container } = render(<Chat messages={[]} />);
      const chatContainer = container.querySelector('[data-slot="chat"]');
      expect(chatContainer).toHaveAttribute('data-has-messages', 'false');
    });

    describe('ChatInput Variant Inheritance', () => {
      it('should pass messageVariant to ChatInput child via context', () => {
        const { container } = render(
          <Chat messages={[]} messageVariant="inline">
            <ChatInput value="" onChange={() => {}} />
          </Chat>,
        );

        const chatInput = container.querySelector('[data-slot="chat-input"]');
        expect(chatInput).toHaveAttribute('data-type', 'inline');
      });
    });
  });

  describe('Edge Cases', () => {
    it('should handle undefined messages prop', () => {
      render(<Chat messages={undefined} />);
      const chatContainer = screen.getByRole('region', {
        name: 'Chat conversation',
      });
      expect(chatContainer).toBeInTheDocument();
      expect(screen.getByText('No messages yet')).toBeInTheDocument();
    });

    it('should handle empty messages array gracefully', () => {
      render(<Chat messages={[]} />);
      expect(screen.getByText('No messages yet')).toBeInTheDocument();
    });

    it('should handle renderMessage returning null', () => {
      const messages = [createMockMessage('1', 'Hello')];
      const renderMessage = vi.fn(() => null);

      render(<Chat messages={messages} renderMessage={renderMessage} />);

      expect(renderMessage).toHaveBeenCalledWith(messages[0]);
      // Message should not be rendered when renderMessage returns null
      expect(screen.queryByText('Hello')).not.toBeInTheDocument();
    });

    it('should handle renderMessage returning undefined', () => {
      const messages = [createMockMessage('1', 'Hello')];
      const renderMessage = vi.fn(() => undefined);

      render(<Chat messages={messages} renderMessage={renderMessage} />);

      expect(renderMessage).toHaveBeenCalledWith(messages[0]);
      expect(screen.queryByText('Hello')).not.toBeInTheDocument();
    });

    it('should handle message count decreasing', async () => {
      const messages1 = [
        createMockMessage('1', 'Hello'),
        createMockMessage('2', 'World'),
      ];
      const { rerender, container } = render(<Chat messages={messages1} />);

      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      const messages2 = [createMockMessage('1', 'Hello')];
      rerender(<Chat messages={messages2} />);

      // Should still render the remaining message
      expect(screen.getByText('Hello')).toBeInTheDocument();
      expect(screen.queryByText('World')).not.toBeInTheDocument();
    });

    it('should handle when viewport is not found initially', async () => {
      const messages = [createMockMessage('1', 'Hello')];
      render(<Chat messages={messages} />);

      // Wait for effects to run
      await waitFor(
        () => {
          // Component should still render
          expect(screen.getByText('Hello')).toBeInTheDocument();
        },
        { timeout: 1000 },
      );
    });

    it('should handle props being spread to root element', () => {
      const { container } = render(
        <Chat messages={[]} data-custom="test" id="chat-id" />,
      );
      const chatContainer = container.querySelector('[data-slot="chat"]');
      expect(chatContainer).toHaveAttribute('data-custom', 'test');
      expect(chatContainer).toHaveAttribute('id', 'chat-id');
    });

    it('should handle empty messages array with showEmptyState false', () => {
      render(<Chat messages={[]} showEmptyState={false} />);
      const emptyState = screen.queryByText('No Messages Yet');
      expect(emptyState).not.toBeInTheDocument();
    });

    it('should handle messages with no content', () => {
      const messages = [
        {
          ...createMockMessage('1', ''),
          content: undefined,
        },
      ];
      render(<Chat messages={messages} />);
      const messageElement = screen.getByRole('article');
      expect(messageElement).toBeInTheDocument();
    });
  });

  describe('Scroll Behavior Edge Cases', () => {
    it('should handle scroll when viewport is found in second effect', async () => {
      const messages = [createMockMessage('1', 'Hello')];
      const { container } = render(<Chat messages={messages} />);

      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      // Verify scroll was attempted using requestAnimationFrame for initial scroll
      await waitFor(
        () => {
          expect(mockRAF).toHaveBeenCalled();
        },
        { timeout: 1000 },
      );
    });

    it('should not scroll when messages array is empty', async () => {
      render(<Chat messages={[]} />);

      // Wait for component to render
      await waitFor(() => {
        // Component should render without errors
        expect(screen.getByRole('region')).toBeInTheDocument();
      });

      // Flush timers
      await new Promise(resolve => setTimeout(resolve, 10));
    });

    it('should handle scroll threshold edge case (exactly at threshold)', async () => {
      const messages1 = [createMockMessage('1', 'Hello')];
      const { rerender, container } = render(
        <Chat messages={messages1} scrollThreshold={100} />,
      );

      await waitFor(() => {
        const viewport = container.querySelector(
          '[data-slot="scroll-area-viewport"]',
        );
        expect(viewport).toBeInTheDocument();
      });

      const viewport = container.querySelector(
        '[data-slot="scroll-area-viewport"]',
      ) as HTMLElement;
      if (viewport) {
        // Simulate user exactly at threshold (distance = 100)
        Object.defineProperty(viewport, 'scrollTop', {
          value: 400,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'scrollHeight', {
          value: 1000,
          writable: true,
          configurable: true,
        });
        Object.defineProperty(viewport, 'clientHeight', {
          value: 500,
          writable: true,
          configurable: true,
        });
        // Distance from bottom = 1000 - 400 - 500 = 100 (exactly at threshold)
      }

      if (viewport) {
        const scrollEvent = new Event('scroll', { bubbles: true });
        viewport.dispatchEvent(scrollEvent);
      }

      vi.clearAllMocks();

      const messages2 = [
        ...messages1,
        createMockMessage('2', 'World', EMessageDirection.INCOMING),
      ];

      rerender(<Chat messages={messages2} scrollThreshold={100} />);

      await waitFor(
        () => {
          // Should still scroll since distance is exactly at threshold (not greater)
          expect(mockRAF).toHaveBeenCalled();
        },
        { timeout: 1000 },
      );

      await new Promise(resolve => setTimeout(resolve, 10));
    });
  });
});
