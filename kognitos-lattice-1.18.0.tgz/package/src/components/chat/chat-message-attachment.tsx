import { cn, useI18n } from '@/design-system/lib/utils';
import { Flex } from '../../primitives/flex';
import { Text } from '../../primitives/typography';
import { Button } from '../../primitives/button';
import { Icon } from '../../icons';
import type { IChatMessageAttachmentProps } from './types';
import { getAttachmentIcon, getAttachmentColorClass } from './utils';

// ============================================================================
// CHAT MESSAGE ATTACHMENT COMPONENT
// ============================================================================

/**
 * Displays a file attachment with icon, name, and optional remove button.
 *
 * Supports file types: text, excel, pdf, image, file (with color-coded icons).
 * Can be made clickable via `onClick` prop.
 */
function ChatMessageAttachment({
  className,
  attachment,
  showRemove = true,
  onRemove,
  onClick,
  ...props
}: IChatMessageAttachmentProps) {
  const { t } = useI18n();

  const handleClick = () => {
    if (onClick) {
      onClick();
    }
  };

  const isClickable = !!onClick;

  return (
    <Flex
      data-slot="chat-message-attachment"
      data-testid={`chat-message-attachment-${attachment.id}`}
      data-attachment-type={attachment.type}
      data-attachment-name={attachment.name}
      gap={2}
      align="center"
      paddingX={2}
      paddingY={2}
      className={cn(
        'border border-border rounded-md bg-card',
        isClickable &&
          'cursor-pointer focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2',
        className,
      )}
      onClick={handleClick}
      role={isClickable ? 'button' : undefined}
      tabIndex={isClickable ? 0 : undefined}
      onKeyDown={
        isClickable
          ? (e: React.KeyboardEvent) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleClick();
              }
            }
          : undefined
      }
      {...props}
    >
      <Flex align="start" className="shrink-0">
        <Flex
          align="center"
          justify="center"
          className={cn(
            'size-7 p-2 rounded-sm',
            getAttachmentColorClass(attachment.type),
          )}
          aria-label={t('chat.attachment.ariaLabelFileType', {
            type: attachment.type,
          })}
        >
          <Icon
            type={getAttachmentIcon(attachment.type)}
            className="size-3 text-white"
          />
        </Flex>
      </Flex>

      <Flex
        direction="row"
        justify="between"
        align="center"
        className="flex-1 min-w-0"
        gap={2}
      >
        <Text
          level="small"
          color="muted"
          className="flex-1 min-w-0 overflow-ellipsis overflow-hidden text-nowrap"
        >
          {attachment.name}
        </Text>

        {showRemove && onRemove && (
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            onClick={e => {
              e.stopPropagation();
              onRemove();
            }}
            className="shrink-0"
            aria-label={t('chat.attachment.ariaLabelRemove')}
          >
            <Icon type="X" />
          </Button>
        )}
      </Flex>
    </Flex>
  );
}

ChatMessageAttachment.displayName = 'ChatMessageAttachment';

export { ChatMessageAttachment };
