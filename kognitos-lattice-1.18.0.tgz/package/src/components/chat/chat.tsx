import * as React from 'react';
import { cva } from 'class-variance-authority';

import { cn, useI18n } from '@/design-system/lib/utils';
import { Flex } from '../../primitives/flex';
import { ScrollArea } from '../../primitives/scroll-area';
import { EmptyState } from '../empty-state';
import { ChatLoadingSkeleton } from './chat-loading-skeleton';
import { MemoizedMessageList } from './chat-message-list';
import { useChatScroll } from './use-chat-scroll';
import {
  filterChatInputFromChildren,
  filterChatToastFromChildren,
  groupConsecutiveThinkingMessages,
} from './utils';
import { type IChatProps, type TMessageVariant } from './types';

// ============================================================================
// CHAT CONTEXT
// ============================================================================

export const ChatContext = React.createContext<{ variant?: TMessageVariant }>(
  {},
);

// ============================================================================
// CHAT COMPONENT
// ============================================================================

const chatVariants = cva('flex flex-col flex-1 w-full overflow-hidden', {
  variants: {
    variant: {
      default: '',
      bordered: 'border rounded-md',
    },
  },
  defaultVariants: {
    variant: 'default',
  },
});

/**
 * Chat container with automatic scroll management and message rendering.
 *
 * Scroll is managed internally by `useChatScroll`:
 * - Auto-scrolls to bottom for new messages and streaming updates
 * - Preserves position when the user scrolls up (wheel/touch detection)
 * - Throttles scroll during streaming; applies cooldown after manual scroll
 * - Uses `scrollThreshold` (default 100 px) to decide "at bottom"
 *
 * Pass `ChatInput` as a child for automatic positioning at the bottom.
 */
function Chat({
  className,
  messages,
  showGradient = false,
  showEmptyState = true,
  emptyStateTitle,
  emptyStateDescription,
  emptyStateIcon = 'MessagesSquare',
  renderMessage,
  children,
  messageVariant,
  showSender = true,
  showTimestamp = true,
  timestampFormatter,
  scrollThreshold = 100,
  isLoading = false,
  chatContainerClassName,
  topComponent,
  ref,
  ...props
}: IChatProps) {
  const { t } = useI18n();

  // Use translations as fallback for empty state
  const resolvedEmptyStateTitle = emptyStateTitle ?? t('chat.emptyStateTitle');
  const resolvedEmptyStateDescription =
    emptyStateDescription ?? t('chat.emptyStateDescription');
  const messagesCount = messages?.length || 0;
  const hasMessages = messagesCount > 0;
  const showLoadingSkeletons = isLoading && !hasMessages;

  // Group consecutive thinking messages for unified display
  const processedMessages = React.useMemo(
    () => groupConsecutiveThinkingMessages(messages),
    [messages],
  );

  // Scroll management (auto-scroll, user intent detection, throttling)
  const { scrollAreaRef, handleThinkingComplete } = useChatScroll({
    messages,
    scrollThreshold,
  });

  // Extract ChatInput and ChatToast from children and filter them out
  const { chatInput, otherChildren: childrenWithoutInput } =
    filterChatInputFromChildren(children);
  const { chatToast, otherChildren } =
    filterChatToastFromChildren(childrenWithoutInput);

  // Context value for child components to inherit props
  const chatContextValue = React.useMemo(
    () => ({ variant: messageVariant }),
    [messageVariant],
  );

  return (
    <ChatContext value={chatContextValue}>
      <Flex
        ref={ref as React.RefObject<HTMLDivElement | null>}
        direction="column"
        className={cn(chatVariants(), className)}
        width="full"
        height="full"
        data-slot="chat"
        data-testid="chat"
        data-message-count={messagesCount}
        data-has-messages={hasMessages ? 'true' : 'false'}
        role="region"
        aria-label={t('chat.ariaLabelConversation')}
        {...props}
      >
        <Flex
          ref={scrollAreaRef}
          direction="column"
          gap={4}
          className={cn(
            'flex-1 min-h-0 overflow-hidden',
            showGradient && hasMessages && 'relative',
          )}
          width="full"
        >
          <ScrollArea className="flex-1 min-h-0 w-full" height="full">
            <Flex
              direction="column"
              gap={4}
              className={cn(
                'pb-4',
                (hasMessages || showLoadingSkeletons) && 'self-end',
                chatContainerClassName,
              )}
              width="full"
              justify={
                !hasMessages && !showLoadingSkeletons && showEmptyState
                  ? 'center'
                  : undefined
              }
              role="log"
              aria-live="polite"
              aria-relevant="additions"
            >
              {hasMessages ? (
                <>
                  {topComponent}
                  <MemoizedMessageList
                    processedMessages={processedMessages}
                    messageVariant={messageVariant}
                    showSender={showSender}
                    showTimestamp={showTimestamp}
                    timestampFormatter={timestampFormatter}
                    renderMessage={renderMessage}
                    onThinkingComplete={handleThinkingComplete}
                  />
                  {otherChildren}
                </>
              ) : showLoadingSkeletons ? (
                <ChatLoadingSkeleton />
              ) : showEmptyState ? (
                <Flex width="full" justify="center">
                  <EmptyState
                    icon={emptyStateIcon}
                    title={resolvedEmptyStateTitle}
                    description={resolvedEmptyStateDescription}
                    bordered={false}
                  />
                </Flex>
              ) : null}
            </Flex>
          </ScrollArea>
          {showGradient && hasMessages && (
            <div
              className="pointer-events-none absolute inset-x-0 top-0 z-0 h-70 bg-gradient-to-b from-secondary to-transparent"
              aria-hidden="true"
            />
          )}
        </Flex>
        {chatInput && (
          <Flex width="full" direction="column" className="shrink-0">
            {!!chatToast && (
              <Flex width="full" paddingX={2} className="-mb-px">
                {chatToast}
              </Flex>
            )}
            <Flex
              width="full"
              justify="center"
              align="center"
              className="shrink-0"
            >
              {chatInput}
            </Flex>
          </Flex>
        )}
      </Flex>
    </ChatContext>
  );
}

Chat.displayName = 'Chat';

// ============================================================================
// RE-EXPORTS
// ============================================================================

export { Chat };
export { ChatMessage } from './chat-message';
export { ChatLoadingSkeleton } from './chat-loading-skeleton';
export { ChatMessageAttachment } from './chat-message-attachment';
export { ChatStatus } from './chat-status';
export { ChatThinkingMessage } from './chat-thinking-message';
export { ChatToast } from './chat-toast';
export { ChatMessageWidget } from './widgets/chat-message-widget';
export {
  messageContainerVariants,
  messageBubbleVariants,
} from './chat-message';

// Re-export all types and enums
export type {
  IChatMessage,
  IChatAttachment,
  IChatMessageWidget,
  IChatMessageButton,
  IChatMessageActionCard,
  TMessageDirection,
  TMessageVariant,
  TMessageStatus,
  TAttachmentType,
  TMessageUpdateState,
  TWidgetType,
  TMessageType,
  IChatProps,
  IChatMessageProps,
  IChatMessageAttachmentProps,
  IChatStatusProps,
  IChatThinkingMessageProps,
} from './types';

export {
  EMessageDirection,
  EMessageVariant,
  EMessageStatus,
  EAttachmentType,
  EMessageUpdateState,
  EWidgetType,
  EMessageType,
} from './types';

export { chatVariants };
