import * as React from 'react';
import dayjs from 'dayjs';
import duration from 'dayjs/plugin/duration';
import type { IconType } from '../../icons';
import { ChatInput } from './chat-input';
import { ChatToast } from './chat-toast';
import {
  EAttachmentType,
  EMessageDirection,
  EMessageType,
  EMessageUpdateState,
  EMessageVariant,
  type IChatMessage,
  type TAttachmentType,
  type TMessageDirection,
  type TMessageUpdateState,
  type TMessageVariant,
} from './types';
import type { ITextProps } from '@/design-system/primitives/typography';

// Extend dayjs with duration plugin
dayjs.extend(duration);

// ============================================================================
// REACT CHILDREN UTILITIES
// ============================================================================

/**
 * Checks if a React element is a ChatInput component
 */
export function isChatInput(child: React.ReactNode): boolean {
  if (!React.isValidElement(child)) {
    return false;
  }

  if (child.type === ChatInput) {
    return true;
  }

  // Check displayName for wrapped components (functions or objects)
  if (
    (typeof child.type === 'function' || typeof child.type === 'object') &&
    child.type !== null &&
    'displayName' in child.type
  ) {
    const type = child.type as { displayName?: string };
    return type.displayName === 'ChatInput';
  }

  return false;
}

/**
 * Checks if a React element is a ChatToast component
 */
export function isChatToast(child: React.ReactNode): boolean {
  if (!React.isValidElement(child)) {
    return false;
  }

  if (child.type === ChatToast) {
    return true;
  }

  // Check displayName for wrapped components (functions or objects)
  if (
    (typeof child.type === 'function' || typeof child.type === 'object') &&
    child.type !== null &&
    'displayName' in child.type
  ) {
    const type = child.type as { displayName?: string };
    return type.displayName === 'ChatToast';
  }

  return false;
}

/**
 * Checks if a React element is a ChatStatus component
 *
 * Uses displayName check to avoid circular dependency with chat-status.tsx.
 * ChatStatus component sets displayName='ChatStatus', so this check is sufficient.
 */
export function isChatStatus(child: React.ReactNode): boolean {
  if (!React.isValidElement(child)) {
    return false;
  }

  // Check displayName for both direct and wrapped components
  // This avoids circular dependency since we don't need to import ChatStatus
  if (
    (typeof child.type === 'function' || typeof child.type === 'object') &&
    child.type !== null &&
    'displayName' in child.type
  ) {
    const type = child.type as { displayName?: string };
    return type.displayName === 'ChatStatus';
  }

  return false;
}

/**
 * Checks if children contain a ChatStatus component
 *
 * @param children - React children to check
 * @returns True if any child is a ChatStatus component
 *
 * @example
 * hasChatStatus([<div />, <ChatStatus text="Loading..." />]) // true
 * hasChatStatus([<div />, <span />]) // false
 */
export function hasChatStatus(children: React.ReactNode): boolean {
  if (!children) {
    return false;
  }

  // Handle array of children
  if (Array.isArray(children)) {
    return children.some(isChatStatus);
  }

  // Handle single child
  return isChatStatus(children);
}

/**
 * Filters out ChatInput components from children
 */
export function filterChatInputFromChildren(children: React.ReactNode): {
  chatInput: React.ReactElement | null;
  otherChildren: React.ReactNode;
} {
  if (!children) {
    return { chatInput: null, otherChildren: children };
  }

  // Handle array of children
  if (Array.isArray(children)) {
    const chatInput = children.find(isChatInput) as
      | React.ReactElement
      | undefined;

    const otherChildren = children.filter(child => !isChatInput(child));

    return { chatInput: chatInput || null, otherChildren };
  }

  // Handle single child
  if (isChatInput(children)) {
    return { chatInput: children as React.ReactElement, otherChildren: null };
  }

  return { chatInput: null, otherChildren: children };
}

/**
 * Filters out ChatToast components from children
 */
export function filterChatToastFromChildren(children: React.ReactNode): {
  chatToast: React.ReactElement | null;
  otherChildren: React.ReactNode;
} {
  if (!children) {
    return { chatToast: null, otherChildren: children };
  }

  // Handle array of children
  if (Array.isArray(children)) {
    const chatToast = children.find(isChatToast) as
      | React.ReactElement
      | undefined;

    const otherChildren = children.filter(child => !isChatToast(child));

    return { chatToast: chatToast || null, otherChildren };
  }

  // Handle single child
  if (isChatToast(children)) {
    return { chatToast: children as React.ReactElement, otherChildren: null };
  }

  return { chatToast: null, otherChildren: children };
}

// ============================================================================
// ID GENERATION UTILITIES
// ============================================================================

/**
 * Generates a unique ID for chat messages
 * Uses crypto.randomUUID() when available, falls back to timestamp + random
 *
 * @param prefix - Optional prefix for the ID (defaults to "msg")
 * @returns A unique message ID string
 *
 * @example
 * generateMessageId() // "msg-550e8400-e29b-41d4-a716-446655440000"
 * generateMessageId('chat') // "chat-550e8400-e29b-41d4-a716-446655440000"
 */
export function generateMessageId(prefix = 'msg'): string {
  // Use crypto.randomUUID() for better collision resistance (available in modern browsers)
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return `${prefix}-${crypto.randomUUID()}`;
  }

  // Fallback for older browsers: timestamp + random number
  // This has lower collision resistance but still works in most cases
  return `${prefix}-${Date.now()}-${Math.random().toString(36).substring(2, 11)}`;
}

// ============================================================================
// TIMESTAMP UTILITIES
// ============================================================================

/**
 * Default timestamp formatter
 * Formats a date/string to a localized time string (e.g., "2:30 PM")
 *
 * @param timestamp - Date object or ISO string
 * @returns Formatted time string
 *
 * @example
 * formatTimestamp(new Date('2024-01-15T14:30:00')) // "2:30 PM"
 * formatTimestamp('2024-01-15T14:30:00') // "2:30 PM"
 */
export function formatTimestamp(timestamp: Date | string): string {
  const date = typeof timestamp === 'string' ? new Date(timestamp) : timestamp;

  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
  });
}

/**
 * Type definition for custom timestamp formatter function
 */
export type TTimestampFormatter = (timestamp: Date | string) => string;

/**
 * Calculates and formats the duration of thinking messages.
 *
 * Extracts timestamps from the first and last messages in the array
 * and calculates the time difference. Returns a human-readable string
 * like "45s" or "2m 30s".
 *
 * @param messages - Array of thinking messages with optional timestamps
 * @returns Formatted duration string, or null if timestamps are unavailable
 *
 * @example
 * const messages = [
 *   { id: '1', timestamp: '2024-01-15T14:30:00' },
 *   { id: '2', timestamp: '2024-01-15T14:30:45' },
 * ];
 * formatThinkingDuration(messages); // "45s"
 *
 * @example
 * const messages = [
 *   { id: '1', timestamp: '2024-01-15T14:30:00' },
 *   { id: '2', timestamp: '2024-01-15T14:32:30' },
 * ];
 * formatThinkingDuration(messages); // "2m 30s"
 */
export function formatThinkingDuration(
  messages: IChatMessage[],
): string | null {
  if (messages.length === 0) {
    return null;
  }

  const firstMessage = messages[0];
  const lastMessage = messages[messages.length - 1];

  // Need timestamps on both first and last messages
  if (!firstMessage.timestamp || !lastMessage.timestamp) {
    return null;
  }

  const startDate = dayjs(firstMessage.timestamp);
  const endDate = dayjs(lastMessage.timestamp);

  // Calculate duration using dayjs
  const durationMs = endDate.diff(startDate);
  const dur = dayjs.duration(Math.max(0, durationMs));

  const minutes = Math.floor(dur.asMinutes());
  const seconds = dur.seconds();

  // Format duration
  if (minutes === 0 && seconds === 0) {
    return 'a few seconds';
  }

  if (minutes === 0) {
    return `${seconds}s`;
  }

  if (seconds === 0) {
    return `${minutes}m`;
  }

  return `${minutes}m ${seconds}s`;
}

// ============================================================================
// ATTACHMENT UTILITIES
// ============================================================================

/**
 * Maps attachment type to corresponding icon type
 *
 * @param attachmentType - The type of attachment
 * @returns Icon type string for the attachment
 *
 * @example
 * getAttachmentIcon(EAttachmentType.TEXT) // "FileText"
 * getAttachmentIcon(EAttachmentType.PDF) // "File"
 */
export function getAttachmentIcon(attachmentType: TAttachmentType): IconType {
  switch (attachmentType) {
    case EAttachmentType.TEXT:
      return 'FileText';
    case EAttachmentType.EXCEL:
      return 'FileSpreadsheet';
    case EAttachmentType.PDF:
      return 'File';
    case EAttachmentType.IMAGE:
      return 'Image';
    default:
      return 'File';
  }
}

/**
 * Maps attachment type to corresponding Tailwind background color class
 *
 * @param attachmentType - The type of attachment
 * @returns Tailwind bg-* class name
 *
 * @example
 * getAttachmentColorClass(EAttachmentType.TEXT) // "bg-alternate-7"
 * getAttachmentColorClass(EAttachmentType.PDF) // "bg-alternate-2"
 */
export function getAttachmentColorClass(
  attachmentType: TAttachmentType,
): string {
  switch (attachmentType) {
    case EAttachmentType.TEXT:
      return 'bg-alternate-7';
    case EAttachmentType.EXCEL:
      return 'bg-alternate-5';
    case EAttachmentType.PDF:
      return 'bg-alternate-2';
    default:
      return 'bg-alternate-1';
  }
}

// ============================================================================
// MESSAGE TEXT STYLING UTILITIES
// ============================================================================

export interface IMessageTextProps {
  level: ITextProps['level'];
  color: ITextProps['color'];
  weight: ITextProps['weight'];
  className?: string;
}

/**
 * Determines text styling properties based on message variant and direction.
 *
 * @param variant - Message variant ('default' | 'inline')
 * @param direction - Message direction ('incoming' | 'outgoing')
 * @returns Text styling props for level, color, and weight
 *
 * @example
 * const textProps = getMessageTextProps('inline', 'outgoing');
 * // Returns: { level: 'large', color: 'default', weight: 'medium' }
 */
export function getMessageTextProps(
  variant: TMessageVariant,
  direction: TMessageDirection,
): IMessageTextProps {
  if (
    variant === EMessageVariant.INLINE &&
    direction === EMessageDirection.OUTGOING
  ) {
    return {
      level: 'large',
      color: 'default',
      weight: 'medium',
    };
  }
  return {
    level: 'base',
    color: 'default',
    weight: 'normal',
    className: 'text-foreground/80',
  };
}

// ============================================================================
// STATUS UTILITIES
// ============================================================================

/**
 * Maps message update state to corresponding icon type
 *
 * @param state - The message update state
 * @param customIcon - Optional custom icon to override default
 * @returns Icon type string for the state
 *
 * @example
 * getStatusIcon(EMessageUpdateState.ERROR) // "AlertCircle"
 * getStatusIcon(EMessageUpdateState.DEFAULT) // "Loader2"
 * getStatusIcon(EMessageUpdateState.WARNING, 'Info') // "Info"
 */
export function getStatusIcon(
  state: TMessageUpdateState,
  customIcon?: IconType,
): IconType {
  if (customIcon) {
    return customIcon;
  }

  switch (state) {
    case EMessageUpdateState.ERROR:
      return 'AlertCircle';
    case EMessageUpdateState.WARNING:
      return 'AlertTriangle';
    case EMessageUpdateState.SUCCESS:
      return 'CircleCheckBig';
    default:
      return 'Loader2';
  }
}

/**
 * Maps message update state to corresponding Tailwind text color class
 *
 * @param state - The message update state
 * @returns Tailwind text-* class name
 *
 * @example
 * getStatusTextColor(EMessageUpdateState.ERROR) // "text-destructive"
 * getStatusTextColor(EMessageUpdateState.WARNING) // "text-warning"
 * getStatusTextColor(EMessageUpdateState.DEFAULT) // ""
 */
export function getStatusTextColor(state: TMessageUpdateState): string {
  switch (state) {
    case EMessageUpdateState.ERROR:
      return 'text-destructive';
    case EMessageUpdateState.WARNING:
      return 'text-warning';
    case EMessageUpdateState.SUCCESS:
      return 'text-success';
    default:
      return '';
  }
}

// ============================================================================
// MESSAGE GROUPING UTILITIES
// ============================================================================

/**
 * Represents a group of consecutive thinking messages.
 */
export interface IThinkingMessageGroup {
  type: 'thinking-group';
  /** Unique ID for the group (uses first message's ID) */
  id: string;
  /** Array of thinking messages in this group */
  messages: IChatMessage[];
}

/**
 * Union type for processed message items that can be either
 * a regular message or a group of thinking messages.
 */
export type TProcessedMessageItem = IChatMessage | IThinkingMessageGroup;

/**
 * Type guard to check if an item is a thinking message group.
 *
 * @param item - The item to check
 * @returns True if the item is a thinking message group
 *
 * @example
 * if (isThinkingMessageGroup(item)) {
 *   // item.messages is available
 * }
 */
export function isThinkingMessageGroup(
  item: TProcessedMessageItem,
): item is IThinkingMessageGroup {
  return 'type' in item && item.type === 'thinking-group';
}

/**
 * Checks if a message is a thinking type message.
 *
 * @param message - The message to check
 * @returns True if the message is a thinking type
 */
export function isThinkingMessage(message: IChatMessage): boolean {
  return message.type === EMessageType.THINKING;
}

/**
 * Checks if a message is a complete type message.
 * Complete messages signal that processing of previous messages is done
 * and should not render anything in the UI.
 *
 * @param message - The message to check
 * @returns True if the message is a complete type
 */
export function isCompleteMessage(message: IChatMessage): boolean {
  return message.type === EMessageType.COMPLETE;
}

/**
 * Groups consecutive thinking messages together while preserving
 * the order of other messages.
 *
 * Takes an array of chat messages and returns a new array where
 * consecutive thinking messages are grouped into IThinkingMessageGroup objects.
 * Non-thinking messages remain as individual IChatMessage objects.
 * Complete type messages pass through and should be handled by the Chat component
 * (render nothing in UI).
 *
 * @param messages - Array of chat messages to process
 * @returns Array of processed items (regular messages or thinking groups)
 *
 * @example
 * const messages = [
 *   { id: '1', content: 'Hello', direction: 'incoming' },
 *   { id: '2', content: 'Thinking...', type: 'thinking', direction: 'incoming' },
 *   { id: '3', content: 'Still thinking...', type: 'thinking', direction: 'incoming' },
 *   { id: '4', content: 'Done!', direction: 'incoming' },
 *   { id: '5', type: 'complete', direction: 'incoming' }, // Passed through, handled by Chat
 * ];
 *
 * const grouped = groupConsecutiveThinkingMessages(messages);
 * // Result:
 * // [
 * //   { id: '1', content: 'Hello', direction: 'incoming' },
 * //   { type: 'thinking-group', id: '2', messages: [msg2, msg3] },
 * //   { id: '4', content: 'Done!', direction: 'incoming' },
 * //   { id: '5', type: 'complete', direction: 'incoming' },
 * // ]
 */
export function groupConsecutiveThinkingMessages(
  messages: IChatMessage[] | undefined,
): TProcessedMessageItem[] {
  if (!messages || messages.length === 0) {
    return [];
  }

  const result: TProcessedMessageItem[] = [];
  let currentThinkingGroup: IChatMessage[] = [];

  for (const message of messages) {
    if (isThinkingMessage(message)) {
      // Add to current thinking group
      currentThinkingGroup.push(message);
    } else {
      // Flush any pending thinking group
      if (currentThinkingGroup.length > 0) {
        result.push({
          type: 'thinking-group',
          id: currentThinkingGroup[0].id,
          messages: currentThinkingGroup,
        });
        currentThinkingGroup = [];
      }
      // Add regular message
      result.push(message);
    }
  }

  // Flush any remaining thinking group at the end
  if (currentThinkingGroup.length > 0) {
    result.push({
      type: 'thinking-group',
      id: currentThinkingGroup[0].id,
      messages: currentThinkingGroup,
    });
  }

  return result;
}

// ============================================================================
// MULTILINE LAYOUT UTILITIES
// ============================================================================

/**
 * Options for calculating multiline layout state
 */
export interface IMultilineLayoutOptions {
  /** The textarea element */
  textarea: HTMLTextAreaElement;
  /** Current multiline state */
  isMultiLine: boolean;
  /** Reusable canvas for text measurement (will be created if null) */
  measureCanvas: HTMLCanvasElement | null;
  /** Estimated width of buttons in single-line layout (default: 60) */
  buttonsWidth?: number;
}

/**
 * Result of multiline layout calculation
 */
export interface IMultilineLayoutResult {
  shouldBeMultiLine: boolean;
  measureCanvas: HTMLCanvasElement | null;
}

/**
 * Calculates whether a textarea should use multiline or single-line layout.
 * Used by inline chat input to determine button placement.
 *
 * @param options - Configuration options
 * @returns The calculated multiline state and whether it changed
 */
export function calculateMultilineLayout(
  options: IMultilineLayoutOptions,
): IMultilineLayoutResult {
  const { textarea, isMultiLine, measureCanvas, buttonsWidth = 80 } = options;

  const style = getComputedStyle(textarea);
  const hasNewLines = textarea.value.includes('\n');

  // Check for text wrapping
  const lineHeight = parseInt(style.lineHeight, 10);
  const paddingTop = parseInt(style.paddingTop, 10);
  const paddingBottom = parseInt(style.paddingBottom, 10);
  const contentHeight = textarea.scrollHeight - paddingTop - paddingBottom;

  const isWrapping = contentHeight > lineHeight;
  const numLines = Math.round(contentHeight / lineHeight);

  // Transition single-line -> multi-line
  if (!isMultiLine && (hasNewLines || isWrapping)) {
    return { shouldBeMultiLine: true, measureCanvas };
  }

  // Check for transition back to single-line only at the boundary (2 lines or less)
  if (isMultiLine && numLines <= 2 && !hasNewLines) {
    // Calculate if text would fit in single-line layout
    // Single-line has less width due to buttons on the same row
    let canvas = measureCanvas;
    if (!canvas) {
      canvas = document.createElement('canvas');
    }
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.font = style.font;
      const textWidth = ctx.measureText(textarea.value).width;

      const paddingLeft = parseInt(style.paddingLeft, 10);
      const paddingRight = parseInt(style.paddingRight, 10);
      const singleLineAvailableWidth =
        textarea.clientWidth - paddingLeft - paddingRight - buttonsWidth;

      if (textWidth <= singleLineAvailableWidth) {
        return { shouldBeMultiLine: false, measureCanvas: canvas };
      }
    }
    return { shouldBeMultiLine: true, measureCanvas: canvas };
  }

  // No change needed
  return { shouldBeMultiLine: isMultiLine, measureCanvas };
}
