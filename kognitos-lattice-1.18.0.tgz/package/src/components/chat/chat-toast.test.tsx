import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChatToast } from './chat-toast';
import { Chat } from './chat';
import { ChatInput } from './chat-input';

describe('ChatToast', () => {
  const defaultProps = {
    text: 'Resolve with Run Assistant',
    onClick: () => {
      window.open('https://docs.kognitos.com/', '_blank');
    },
  };

  beforeEach(() => {
    // Mock window.open
    window.open = vi.fn();
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  describe('Rendering', () => {
    it('should render with text', () => {
      render(<ChatToast {...defaultProps} />);

      expect(
        screen.getByText('Resolve with Run Assistant'),
      ).toBeInTheDocument();
    });

    it('should render with default text when not provided', () => {
      render(
        <ChatToast
          text="Resolve with Run Assistant"
          onClick={() => {
            window.open('https://docs.kognitos.com/', '_blank');
          }}
        />,
      );

      expect(
        screen.getByText('Resolve with Run Assistant'),
      ).toBeInTheDocument();
    });

    it('should render with custom text', () => {
      render(
        <ChatToast
          text="Custom toast message"
          onClick={() => {
            window.open('https://docs.kognitos.com/', '_blank');
          }}
        />,
      );

      expect(screen.getByText('Custom toast message')).toBeInTheDocument();
    });
  });

  describe('Icons', () => {
    it('should render with default icon (Sparkle) and default actionIcon (ArrowUpRight) when neither is provided', () => {
      const { container } = render(<ChatToast {...defaultProps} />);

      // Should have two icons: one for the left icon (Sparkle) and one for the action button (ArrowUpRight)
      const icons = container.querySelectorAll('svg');
      expect(icons.length).toBeGreaterThanOrEqual(2);
    });

    it('should render with custom icon and actionIcon when provided', () => {
      const { container } = render(
        <ChatToast {...defaultProps} icon="Settings" actionIcon="X" />,
      );

      // Should have two icons: one for the left icon and one for the action button
      const icons = container.querySelectorAll('svg');
      expect(icons.length).toBeGreaterThanOrEqual(2);
    });
  });

  describe('Interactions', () => {
    it('should call onClick when action button is clicked', async () => {
      const user = userEvent.setup();
      const onClick = vi.fn(() => {
        window.open('https://docs.kognitos.com/', '_blank');
      });
      render(<ChatToast text="Test" onClick={onClick} />);

      const actionButton = screen.getByLabelText('Test action');
      await user.click(actionButton);

      // onClick is called from the parent Flex container (event bubbles from button)
      expect(onClick).toHaveBeenCalledTimes(1);
      expect(window.open).toHaveBeenCalledWith(
        'https://docs.kognitos.com/',
        '_blank',
      );
    });
  });

  describe('Accessibility', () => {
    it('should have aria-label on action button', () => {
      render(<ChatToast {...defaultProps} />);

      const actionButton = screen.getByLabelText(
        'Resolve with Run Assistant action',
      );
      expect(actionButton).toBeInTheDocument();
      expect(actionButton).toHaveAttribute(
        'aria-label',
        'Resolve with Run Assistant action',
      );
    });
  });

  describe('Integration with Chat', () => {
    it('should render correctly and appear above ChatInput when both are children of Chat', () => {
      const { container } = render(
        <Chat messages={[]}>
          <ChatToast {...defaultProps} />
          <ChatInput value="" onChange={() => {}} />
        </Chat>,
      );

      // ChatToast should be rendered
      expect(
        screen.getByText('Resolve with Run Assistant'),
      ).toBeInTheDocument();
      expect(
        screen.getByLabelText('Resolve with Run Assistant action'),
      ).toBeInTheDocument();

      // Find ChatToast and ChatInput in the DOM
      const toast = screen.getByText('Resolve with Run Assistant');
      const input = screen.getByRole('textbox');

      // ChatToast should appear before ChatInput in the DOM order
      const toastIndex = Array.from(container.querySelectorAll('*')).indexOf(
        toast.closest('[class*="flex"]') || toast,
      );
      const inputIndex = Array.from(container.querySelectorAll('*')).indexOf(
        input.closest('[class*="flex"]') || input,
      );

      expect(toastIndex).toBeLessThan(inputIndex);
    });

    it('should not render when ChatInput is not present', () => {
      render(
        <Chat messages={[]}>
          <ChatToast {...defaultProps} />
        </Chat>,
      );

      // ChatToast should not be rendered when ChatInput is absent
      expect(
        screen.queryByText('Resolve with Run Assistant'),
      ).not.toBeInTheDocument();
    });
  });
});
