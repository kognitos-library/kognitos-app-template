import { cn, useI18n } from '@/design-system/lib/utils';
import { Flex } from '../../primitives/flex';
import { Text } from '../../primitives/typography';
import { ShimmeringText } from '../../primitives/shimmering-text';
import { Icon } from '../../icons';
import { Button } from '../../primitives/button';
import {
  EMessageUpdateState,
  type IChatStatusProps,
  type TMessageUpdateState,
} from './types';
import { getStatusIcon, getStatusTextColor } from './utils';

// ============================================================================
// CHAT STATUS COMPONENT
// ============================================================================

/**
 * Status indicator component for displaying loading, error, or warning states.
 * Place between messages in Chat component children to show system status.
 *
 * @example
 * ```tsx
 * // For error states only
 * <Chat messages={messages}>
 *   <ChatStatus state="error" text="Failed to send message" showIcon />
 *   <ChatInput onSend={handleSend} />
 * </Chat>
 *
 * // For thinking states, use thinking messages instead:
 * const messages = [
 *   { id: '1', content: 'Analyzing...', type: 'thinking', direction: 'incoming' },
 * ];
 * <Chat messages={messages}>
 *   <ChatInput onSend={handleSend} />
 * </Chat>
 * ```
 */
function ChatStatus({
  className,
  state = EMessageUpdateState.DEFAULT as TMessageUpdateState,
  text,
  icon,
  showIcon = false,
  action,
  ...props
}: IChatStatusProps) {
  const { t } = useI18n();
  const resolvedText = text ?? t('chat.status.defaultText');
  const isDefaultState = state === EMessageUpdateState.DEFAULT;

  return (
    <Flex
      data-slot="chat-status"
      data-testid="chat-status"
      data-state={state}
      gap={2}
      align="center"
      justify="between"
      className={cn('py-2', className)}
      aria-live={isDefaultState ? 'polite' : undefined}
      {...props}
    >
      <Flex gap={2} align="center">
        {showIcon && (
          <Flex
            align="center"
            justify="center"
            data-testid="chat-status-icon-container"
            data-slot="chat-status-icon"
            padding={0.5}
          >
            <Icon
              type={getStatusIcon(state, icon)}
              strokeWidth={1.25}
              className={cn(
                'size-3',
                state === EMessageUpdateState.DEFAULT &&
                  'animate-spin text-muted-foreground',
                state === EMessageUpdateState.ERROR && 'text-destructive',
                state === EMessageUpdateState.WARNING && 'text-warning',
                state === EMessageUpdateState.SUCCESS && 'text-success',
              )}
            />
          </Flex>
        )}
        {state === EMessageUpdateState.DEFAULT ? (
          <ShimmeringText
            text={resolvedText}
            duration={1.2}
            className="text-xs"
          />
        ) : (
          <Text
            data-testid="chat-status-text"
            data-slot="chat-status-text"
            level="small"
            className={cn('text-xs', getStatusTextColor(state))}
          >
            {resolvedText}
          </Text>
        )}
      </Flex>

      {/* Action button */}
      {action && (
        <Button
          variant="ghost"
          size="sm"
          onClick={action.onClick}
          data-testid="chat-status-action"
          data-slot="chat-status-action"
          className="text-xs" // to override ghost variant text size, matching design
          aria-label={action.label}
        >
          {action.label}
        </Button>
      )}
    </Flex>
  );
}

ChatStatus.displayName = 'ChatStatus';

export { ChatStatus };
