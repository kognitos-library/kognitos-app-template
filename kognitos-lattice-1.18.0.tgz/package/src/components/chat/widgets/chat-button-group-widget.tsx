import { Flex } from '../../../primitives/flex';
import { Button } from '../../../primitives/button';
import type { IChatMessageButton } from '../types';

// ============================================================================
// BUTTON GROUP WIDGET
// ============================================================================

interface IChatButtonGroupWidgetProps {
  buttons: IChatMessageButton[];
}

/**
 * Renders a horizontal group of action buttons within a message.
 * First button defaults to primary variant, rest default to outline.
 */
export function ChatButtonGroupWidget({
  buttons,
}: IChatButtonGroupWidgetProps) {
  return (
    <Flex
      direction="row"
      gap={2}
      wrap="wrap"
      data-slot="chat-message-widget-button-group"
      data-testid="chat-message-widget-button-group"
      data-button-count={buttons.length}
    >
      {buttons.map((button, index) => (
        <Button
          key={button.id}
          variant={button.variant || (index === 0 ? 'default' : 'outline')}
          size="sm"
          onClick={button.onClick}
          disabled={button.disabled}
          isLoading={button.isLoading}
          data-testid={`chat-message-widget-button-${button.id}`}
        >
          {button.label}
        </Button>
      ))}
    </Flex>
  );
}
