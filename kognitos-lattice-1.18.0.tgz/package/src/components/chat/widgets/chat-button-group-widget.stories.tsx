import type { Meta, StoryObj } from '@storybook/react-vite';
import { ChatButtonGroupWidget } from '@/design-system';
import { Card } from '../../../primitives/card';

const meta: Meta<typeof ChatButtonGroupWidget> = {
  title: 'Design System/Components/Chat/Widgets/ChatButtonGroupWidget',
  component: ChatButtonGroupWidget,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A widget component that displays a group of buttons in a flexible row layout. Used within chat messages to provide interactive button-based elements. The first button defaults to "default" variant, while subsequent buttons default to "outline" if no variant is specified.',
      },
    },
  },
  argTypes: {
    buttons: {
      control: { type: 'object' },
      description: 'Array of buttons to display',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatButtonGroupWidget>;

/**
 * Basic button group with default styling.
 * First button uses "default" variant, others use "outline" by default.
 */
export const Default: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Yes, please',
        onClick: () => console.log('Yes clicked'),
      },
      {
        id: 'btn2',
        label: 'No, thanks',
        onClick: () => console.log('No clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Button group with explicitly set variants.
 */
export const WithVariants: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Primary',
        variant: 'default',
        onClick: () => console.log('Primary clicked'),
      },
      {
        id: 'btn2',
        label: 'Outline',
        variant: 'outline',
        onClick: () => console.log('Outline clicked'),
      },
      {
        id: 'btn3',
        label: 'Secondary',
        variant: 'secondary',
        onClick: () => console.log('Secondary clicked'),
      },
      {
        id: 'btn4',
        label: 'Ghost',
        variant: 'ghost',
        onClick: () => console.log('Ghost clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Button group with destructive variant.
 */
export const WithDestructive: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Cancel',
        variant: 'outline',
        onClick: () => console.log('Cancel clicked'),
      },
      {
        id: 'btn2',
        label: 'Delete',
        variant: 'destructive',
        onClick: () => console.log('Delete clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Button group with link variant.
 */
export const WithLink: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Learn More',
        variant: 'link',
        onClick: () => console.log('Learn More clicked'),
      },
      {
        id: 'btn2',
        label: 'Get Started',
        variant: 'default',
        onClick: () => console.log('Get Started clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Button group with disabled and loading states.
 */
export const ButtonStates: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Enabled',
        variant: 'default',
        onClick: () => console.log('Enabled clicked'),
      },
      {
        id: 'btn2',
        label: 'Disabled',
        variant: 'outline',
        disabled: true,
        onClick: () => console.log('Disabled clicked'),
      },
      {
        id: 'btn3',
        label: 'Loading',
        variant: 'default',
        isLoading: true,
        onClick: () => console.log('Loading clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Single button in the group.
 */
export const SingleButton: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Continue',
        variant: 'default',
        onClick: () => console.log('Continue clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Multiple buttons that will wrap to multiple lines.
 */
export const ManyButtons: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Option 1',
        variant: 'default',
        onClick: () => console.log('Option 1 clicked'),
      },
      {
        id: 'btn2',
        label: 'Option 2',
        onClick: () => console.log('Option 2 clicked'),
      },
      {
        id: 'btn3',
        label: 'Option 3',
        onClick: () => console.log('Option 3 clicked'),
      },
      {
        id: 'btn4',
        label: 'Option 4',
        onClick: () => console.log('Option 4 clicked'),
      },
      {
        id: 'btn5',
        label: 'Option 5',
        onClick: () => console.log('Option 5 clicked'),
      },
      {
        id: 'btn6',
        label: 'Option 6',
        onClick: () => console.log('Option 6 clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * All button variants showcased together.
 */
export const AllVariants: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Default',
        variant: 'default',
        onClick: () => console.log('Default clicked'),
      },
      {
        id: 'btn2',
        label: 'Outline',
        variant: 'outline',
        onClick: () => console.log('Outline clicked'),
      },
      {
        id: 'btn3',
        label: 'Secondary',
        variant: 'secondary',
        onClick: () => console.log('Secondary clicked'),
      },
      {
        id: 'btn4',
        label: 'Ghost',
        variant: 'ghost',
        onClick: () => console.log('Ghost clicked'),
      },
      {
        id: 'btn5',
        label: 'Destructive',
        variant: 'destructive',
        onClick: () => console.log('Destructive clicked'),
      },
      {
        id: 'btn6',
        label: 'Link',
        variant: 'link',
        onClick: () => console.log('Link clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Common use case: Yes/No confirmation buttons.
 */
export const Confirmation: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Yes, please',
        variant: 'default',
        onClick: () => console.log('Yes clicked'),
      },
      {
        id: 'btn2',
        label: 'No, thanks',
        variant: 'outline',
        onClick: () => console.log('No clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Common use case: Accept/Decline buttons.
 */
export const AcceptDecline: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Accept',
        variant: 'default',
        onClick: () => console.log('Accept clicked'),
      },
      {
        id: 'btn2',
        label: 'Decline',
        variant: 'outline',
        onClick: () => console.log('Decline clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};

/**
 * Common use case: Action buttons with different priorities.
 */
export const ActionButtons: Story = {
  args: {
    buttons: [
      {
        id: 'btn1',
        label: 'Save',
        variant: 'default',
        onClick: () => console.log('Save clicked'),
      },
      {
        id: 'btn2',
        label: 'Cancel',
        variant: 'outline',
        onClick: () => console.log('Cancel clicked'),
      },
      {
        id: 'btn3',
        label: 'Delete',
        variant: 'destructive',
        onClick: () => console.log('Delete clicked'),
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatButtonGroupWidget {...args} />
    </Card>
  ),
};
