import type { Meta, StoryObj } from '@storybook/react-vite';
import { ChatActionCardWidget } from '@/design-system';
import { Card, CardContent } from '../../../primitives/card';
import { Icon } from '../../../icons';

const meta: Meta<typeof ChatActionCardWidget> = {
  title: 'Design System/Components/Chat/Widgets/ChatActionCardWidget',
  component: ChatActionCardWidget,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A widget component that displays action cards with images, icons, titles, descriptions, and customizable action buttons. Used within chat messages to provide interactive card-based elements.',
      },
    },
  },
  argTypes: {
    actionCards: {
      control: { type: 'object' },
      description: 'Array of action cards to display',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatActionCardWidget>;

/**
 * Action cards with images and fallback icons.
 */
export const WithImages: Story = {
  args: {
    actionCards: [
      {
        id: 'card1',
        title: 'Slack',
        description: 'Work Admin v1.1',
        imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=slack',
        fallbackIcon: <Icon type="MessageSquare" className="size-4" />,
        actionProps: {
          label: 'Manage',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Slack clicked'),
        },
      },
      {
        id: 'card2',
        title: 'GitHub',
        description: 'Repository Manager',
        imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=github',
        fallbackIcon: <Icon type="Github" className="size-4" />,
        actionProps: {
          label: 'Manage',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('GitHub clicked'),
        },
      },
      {
        id: 'card3',
        title: 'Notion',
        description: 'Workspace v2.0',
        imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=notion',
        fallbackIcon: <Icon type="FileText" className="size-4" />,
        actionProps: {
          label: 'Manage',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Notion clicked'),
        },
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md">
      <CardContent>
        <ChatActionCardWidget {...args} />
      </CardContent>
    </Card>
  ),
};

/**
 * Action cards with only fallback icons (no images).
 */
export const WithIconsOnly: Story = {
  args: {
    actionCards: [
      {
        id: 'card1',
        title: 'Dashboard',
        description: 'View analytics and metrics',
        fallbackIcon: <Icon type="BarChart" className="size-4" />,
        actionProps: {
          label: 'Open',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Dashboard clicked'),
        },
      },
      {
        id: 'card2',
        title: 'Settings',
        description: 'Configure your preferences',
        fallbackIcon: <Icon type="Settings" className="size-4" />,
        actionProps: {
          label: 'View',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Settings clicked'),
        },
      },
      {
        id: 'card3',
        title: 'Users',
        description: 'Manage team members',
        fallbackIcon: <Icon type="Users" className="size-4" />,
        actionProps: {
          label: 'Manage',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Users clicked'),
        },
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md">
      <CardContent>
        {' '}
        <ChatActionCardWidget {...args} />
      </CardContent>
    </Card>
  ),
};

/**
 * Action cards without icons or images.
 */
export const WithoutIcons: Story = {
  args: {
    actionCards: [
      {
        id: 'card1',
        title: 'View Dashboard',
        description: 'Access your analytics',
        actionProps: {
          label: 'Open',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Dashboard clicked'),
        },
      },
      {
        id: 'card2',
        title: 'Check Settings',
        description: 'Update your configuration',
        actionProps: {
          label: 'View',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Settings clicked'),
        },
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md">
      <CardContent>
        <ChatActionCardWidget {...args} />
      </CardContent>
    </Card>
  ),
};

/**
 * Action cards with different button variants.
 */
export const ButtonVariants: Story = {
  args: {
    actionCards: [
      {
        id: 'card1',
        title: 'Primary Action',
        description: 'Default button variant',
        fallbackIcon: <Icon type="Check" className="size-4" />,
        actionProps: {
          label: 'Primary',
          variant: 'default',
          size: 'sm',
          onClick: () => console.log('Primary clicked'),
        },
      },
      {
        id: 'card2',
        title: 'Outline Action',
        description: 'Outline button variant',
        fallbackIcon: <Icon type="Info" className="size-4" />,
        actionProps: {
          label: 'Outline',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Outline clicked'),
        },
      },
      {
        id: 'card3',
        title: 'Secondary Action',
        description: 'Secondary button variant',
        fallbackIcon: <Icon type="Star" className="size-4" />,
        actionProps: {
          label: 'Secondary',
          variant: 'secondary',
          size: 'sm',
          onClick: () => console.log('Secondary clicked'),
        },
      },
      {
        id: 'card4',
        title: 'Ghost Action',
        description: 'Ghost button variant',
        fallbackIcon: <Icon type="MoreHorizontal" className="size-4" />,
        actionProps: {
          label: 'Ghost',
          variant: 'ghost',
          size: 'sm',
          onClick: () => console.log('Ghost clicked'),
        },
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md">
      <CardContent>
        <ChatActionCardWidget {...args} />
      </CardContent>
    </Card>
  ),
};

/**
 * Action cards with different button sizes.
 */
export const ButtonSizes: Story = {
  args: {
    actionCards: [
      {
        id: 'card1',
        title: 'Small Button',
        description: 'Size: sm',
        fallbackIcon: <Icon type="Minus" className="size-4" />,
        actionProps: {
          label: 'Small',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Small clicked'),
        },
      },
      {
        id: 'card2',
        title: 'Default Button',
        description: 'Size: default',
        fallbackIcon: <Icon type="Circle" className="size-4" />,
        actionProps: {
          label: 'Default',
          variant: 'outline',
          size: 'default',
          onClick: () => console.log('Default clicked'),
        },
      },
      {
        id: 'card3',
        title: 'Large Button',
        description: 'Size: lg',
        fallbackIcon: <Icon type="Plus" className="size-4" />,
        actionProps: {
          label: 'Large',
          variant: 'outline',
          size: 'lg',
          onClick: () => console.log('Large clicked'),
        },
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md">
      <CardContent>
        <ChatActionCardWidget {...args} />
      </CardContent>
    </Card>
  ),
};

/**
 * Action cards with disabled and loading states.
 */
export const ButtonStates: Story = {
  args: {
    actionCards: [
      {
        id: 'card1',
        title: 'Enabled Action',
        description: 'Button is enabled',
        fallbackIcon: <Icon type="Check" className="size-4" />,
        actionProps: {
          label: 'Enabled',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Enabled clicked'),
        },
      },
      {
        id: 'card2',
        title: 'Disabled Action',
        description: 'Button is disabled',
        fallbackIcon: <Icon type="Circle" className="size-4" />,
        actionProps: {
          label: 'Disabled',
          variant: 'outline',
          size: 'sm',
          disabled: true,
          onClick: () => console.log('Disabled clicked'),
        },
      },
      {
        id: 'card3',
        title: 'Loading Action',
        description: 'Button is loading',
        fallbackIcon: <Icon type="Loader2" className="size-4" />,
        actionProps: {
          label: 'Loading',
          variant: 'outline',
          size: 'sm',
          isLoading: true,
          onClick: () => console.log('Loading clicked'),
        },
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md">
      <CardContent>
        <ChatActionCardWidget {...args} />
      </CardContent>
    </Card>
  ),
};

/**
 * Action cards with custom button labels.
 */
export const CustomLabels: Story = {
  args: {
    actionCards: [
      {
        id: 'card1',
        title: 'Launch Application',
        description: 'Start the application',
        imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=app1',
        fallbackIcon: <Icon type="Rocket" className="size-4" />,
        actionProps: {
          label: 'Launch',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Launch clicked'),
        },
      },
      {
        id: 'card2',
        title: 'Configure Settings',
        description: 'Update configuration',
        imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=app2',
        fallbackIcon: <Icon type="Settings" className="size-4" />,
        actionProps: {
          label: 'Configure',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Configure clicked'),
        },
      },
      {
        id: 'card3',
        title: 'Edit Details',
        description: 'Modify information',
        imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=app3',
        fallbackIcon: <Icon type="Edit" className="size-4" />,
        actionProps: {
          label: 'Edit',
          variant: 'outline',
          size: 'sm',
          onClick: () => console.log('Edit clicked'),
        },
      },
    ],
  },
  render: args => (
    <Card className="w-full max-w-md">
      <CardContent>
        <ChatActionCardWidget {...args} />
      </CardContent>
    </Card>
  ),
};
