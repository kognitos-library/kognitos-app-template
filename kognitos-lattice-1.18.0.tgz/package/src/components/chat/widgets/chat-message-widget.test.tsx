import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChatMessageWidget } from './chat-message-widget';
import { EWidgetType, type IChatMessageWidget } from '../types';

describe('ChatMessageWidget', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Button Group Widget', () => {
    it('should render button group widget', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
          },
          {
            id: 'btn2',
            label: 'Button 2',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Button 1')).toBeInTheDocument();
      expect(screen.getByText('Button 2')).toBeInTheDocument();
    });

    it('should render first button with default variant', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
          },
          {
            id: 'btn2',
            label: 'Button 2',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const buttons = screen.getAllByRole('button');
      // First button should have default variant (primary)
      expect(buttons[0]).toBeInTheDocument();
    });

    it('should render subsequent buttons with outline variant by default', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
          },
          {
            id: 'btn2',
            label: 'Button 2',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const buttons = screen.getAllByRole('button');
      expect(buttons.length).toBe(2);
    });

    it('should use custom variant when provided', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
            variant: 'ghost',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const button = screen.getByText('Button 1');
      expect(button).toBeInTheDocument();
    });

    it('should call onClick when button is clicked', async () => {
      const user = userEvent.setup();
      const onClick = vi.fn();
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
            onClick,
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const button = screen.getByText('Button 1');
      await user.click(button);

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should disable button when disabled prop is true', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
            disabled: true,
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const button = screen.getByText('Button 1');
      expect(button).toBeDisabled();
    });

    it('should show loading state when isLoading is true', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
            isLoading: true,
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const button = screen.getByText('Button 1');
      expect(button).toBeInTheDocument();
    });

    it('should return null when buttons array is empty', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [],
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      expect(container.firstChild).toBeNull();
    });

    it('should return null when buttons is undefined', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      expect(container.firstChild).toBeNull();
    });

    it('should render multiple buttons correctly', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
          },
          {
            id: 'btn2',
            label: 'Button 2',
          },
          {
            id: 'btn3',
            label: 'Button 3',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Button 1')).toBeInTheDocument();
      expect(screen.getByText('Button 2')).toBeInTheDocument();
      expect(screen.getByText('Button 3')).toBeInTheDocument();
    });

    it('should have correct data-slot attribute', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
          },
        ],
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      const widgetElement = container.querySelector(
        '[data-slot="chat-message-widget-button-group"]',
      );
      expect(widgetElement).toBeInTheDocument();
    });

    it('should have visible focus indicator on buttons', async () => {
      const user = userEvent.setup();
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
          },
          {
            id: 'btn2',
            label: 'Button 2',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const button1 = screen.getByText('Button 1');

      // Tab to focus the button
      await user.tab();

      // Verify it's focused (buttons should have focus indicators from design system)
      expect(button1).toHaveFocus();
    });
  });

  describe('Action Cards Widget', () => {
    it('should render action cards widget', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            description: 'Description 1',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Card 1')).toBeInTheDocument();
      expect(screen.getByText('Description 1')).toBeInTheDocument();
    });

    it('should render action card with image', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            imageUrl: 'https://example.com/image.jpg',
          },
        ],
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      // Avatar component renders the image, check for img element or avatar
      const image = container.querySelector('img');
      const avatar = container.querySelector('[data-slot="avatar"]');
      expect(image ?? avatar).toBeInTheDocument();
    });

    it('should render action card with fallback icon', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            fallbackIcon: <span data-testid="fallback-icon">Icon</span>,
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByTestId('fallback-icon')).toBeInTheDocument();
    });

    it('should render action card without description', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Card 1')).toBeInTheDocument();
    });

    it('should render action card with action button', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            actionProps: {
              label: 'Action',
              onClick: vi.fn(),
            },
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Action')).toBeInTheDocument();
    });

    it('should call onClick when action button is clicked', async () => {
      const user = userEvent.setup();
      const onClick = vi.fn();
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            actionProps: {
              label: 'Action',
              onClick,
            },
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const button = screen.getByText('Action');
      await user.click(button);

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should have visible focus indicator on action card buttons', async () => {
      const user = userEvent.setup();
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            actionProps: {
              label: 'Action',
              onClick: vi.fn(),
            },
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      const button = screen.getByText('Action');

      // Tab to focus the button
      await user.tab();

      // Verify it's focused (buttons should have focus indicators from design system)
      expect(button).toHaveFocus();
    });

    it('should use default action button label when not provided', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            actionProps: {
              onClick: vi.fn(),
            },
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Action')).toBeInTheDocument();
    });

    it('should render multiple action cards', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
          },
          {
            id: 'card2',
            title: 'Card 2',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Card 1')).toBeInTheDocument();
      expect(screen.getByText('Card 2')).toBeInTheDocument();
    });

    it('should return null when actionCards array is empty', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [],
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      expect(container.firstChild).toBeNull();
    });

    it('should return null when actionCards is undefined', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      expect(container.firstChild).toBeNull();
    });

    it('should render action card without image or fallback icon', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.ACTION_CARDS,
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
          },
        ],
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Card 1')).toBeInTheDocument();
      // No image or fallback icon should be rendered
      const image = document.querySelector('img');
      expect(image).not.toBeInTheDocument();
    });
  });

  describe('Custom Widget', () => {
    it('should render custom widget content', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.CUSTOM,
        customContent: <div data-testid="custom-content">Custom Content</div>,
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByTestId('custom-content')).toBeInTheDocument();
      expect(screen.getByText('Custom Content')).toBeInTheDocument();
    });

    it('should render complex custom content', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.CUSTOM,
        customContent: (
          <div>
            <h2>Title</h2>
            <p>Description</p>
            <button>Click me</button>
          </div>
        ),
      };

      render(<ChatMessageWidget widget={widget} />);

      expect(screen.getByText('Title')).toBeInTheDocument();
      expect(screen.getByText('Description')).toBeInTheDocument();
      expect(screen.getByText('Click me')).toBeInTheDocument();
    });

    it('should have correct data-slot attribute', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.CUSTOM,
        customContent: <div>Content</div>,
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      const widgetElement = container.querySelector(
        '[data-slot="chat-message-widget-custom"]',
      );
      expect(widgetElement).toBeInTheDocument();
    });

    it('should return null when customContent is not provided', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.CUSTOM,
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      expect(container.firstChild).toBeNull();
    });

    it('should return null when customContent is null', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.CUSTOM,
        customContent: null,
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      expect(container.firstChild).toBeNull();
    });
  });

  describe('Edge Cases', () => {
    it('should handle unknown widget type gracefully', () => {
      const widget = {
        type: 'unknown' as EWidgetType,
      };

      const { container } = render(<ChatMessageWidget widget={widget} />);

      expect(container.firstChild).toBeNull();
    });

    it('should handle widget with all properties set', () => {
      const widget: IChatMessageWidget = {
        type: EWidgetType.BUTTON_GROUP,
        buttons: [
          {
            id: 'btn1',
            label: 'Button 1',
            variant: 'default',
            disabled: false,
            isLoading: false,
            onClick: vi.fn(),
          },
        ],
        actionCards: [
          {
            id: 'card1',
            title: 'Card 1',
            description: 'Description',
            imageUrl: 'https://example.com/image.jpg',
            actionProps: {
              label: 'Action',
              onClick: vi.fn(),
            },
          },
        ],
        customContent: <div>Custom</div>,
      };

      render(<ChatMessageWidget widget={widget} />);

      // Should render button group (type takes precedence)
      expect(screen.getByText('Button 1')).toBeInTheDocument();
    });
  });
});
