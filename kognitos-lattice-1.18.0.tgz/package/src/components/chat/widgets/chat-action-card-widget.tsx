import { Flex } from '../../../primitives/flex';
import { Button } from '../../../primitives/button';
import {
  Item,
  ItemMedia,
  ItemContent,
  ItemTitle,
  ItemDescription,
  ItemActions,
} from '../../../primitives/item';
import {
  Avatar,
  AvatarImage,
  AvatarFallback,
} from '../../../primitives/avatar';
import type { IChatMessageActionCard } from '../types';

// ============================================================================
// ACTION CARDS WIDGET
// ============================================================================

interface IChatActionCardWidgetProps {
  actionCards: IChatMessageActionCard[];
}

/**
 * Renders the action area of a card (button or postfix).
 */
function CardActions({ card }: { card: IChatMessageActionCard }) {
  if (card.actionProps) {
    const {
      label = 'Action',
      onClick,
      variant = 'outline',
      size = 'sm',
      ...buttonProps
    } = card.actionProps;

    return (
      <ItemActions>
        <Button
          variant={variant}
          size={size}
          onClick={onClick}
          {...buttonProps}
        >
          {label}
        </Button>
      </ItemActions>
    );
  }

  if (card.postfix) {
    return <ItemActions>{card.postfix}</ItemActions>;
  }

  return null;
}

/**
 * Renders the media area of a card (image or fallback icon).
 */
function CardMedia({ card }: { card: IChatMessageActionCard }) {
  if (card.imageUrl) {
    return (
      <ItemMedia variant="default" className="w-5">
        <Avatar className="size-6">
          <AvatarImage src={card.imageUrl} alt={card.title} />
          <AvatarFallback>
            {card.fallbackIcon || card.title.charAt(0)}
          </AvatarFallback>
        </Avatar>
      </ItemMedia>
    );
  }

  if (card.fallbackIcon) {
    return (
      <ItemMedia variant="image" className="w-5">
        {card.fallbackIcon}
      </ItemMedia>
    );
  }

  return null;
}

/**
 * Renders a vertical stack of action cards with images/icons, titles, descriptions, and buttons.
 * Useful for presenting multiple options or apps to the user.
 */
export function ChatActionCardWidget({
  actionCards,
}: IChatActionCardWidgetProps) {
  return (
    <Flex
      direction="column"
      gap={2}
      className="w-full"
      data-testid="chat-message-widget-action-cards"
      data-card-count={actionCards.length}
    >
      {actionCards.map(card => (
        <Item
          key={card.id}
          variant="outline"
          size="sm"
          className="w-full bg-card"
          data-testid={`chat-message-widget-action-card-${card.id}`}
        >
          <CardMedia card={card} />
          <ItemContent>
            <ItemTitle>{card.title}</ItemTitle>
            {card.description && (
              <ItemDescription>{card.description}</ItemDescription>
            )}
          </ItemContent>
          <CardActions card={card} />
        </Item>
      ))}
    </Flex>
  );
}
