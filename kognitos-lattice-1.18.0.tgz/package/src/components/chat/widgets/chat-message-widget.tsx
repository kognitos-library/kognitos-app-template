import { EWidgetType, type IChatMessageWidget } from '../types';
import { ChatButtonGroupWidget } from './chat-button-group-widget';
import { ChatActionCardWidget } from './chat-action-card-widget';
import { ChatCustomWidget } from './chat-custom-widget';

// ============================================================================
// MAIN WIDGET COMPONENT
// ============================================================================

export interface IChatMessageWidgetProps {
  widget: IChatMessageWidget;
}

/**
 * Widget router component that renders the appropriate widget based on type.
 * Supports button-group, action-cards, and custom widgets.
 */
export function ChatMessageWidget({ widget }: IChatMessageWidgetProps) {
  switch (widget.type) {
    case EWidgetType.BUTTON_GROUP:
      if (!widget.buttons || widget.buttons.length === 0) return null;
      return <ChatButtonGroupWidget buttons={widget.buttons} />;

    case EWidgetType.ACTION_CARDS:
      if (!widget.actionCards || widget.actionCards.length === 0) return null;
      return <ChatActionCardWidget actionCards={widget.actionCards} />;

    case EWidgetType.CUSTOM:
      if (!widget.customContent) return null;
      return <ChatCustomWidget customContent={widget.customContent} />;

    default:
      return null;
  }
}
