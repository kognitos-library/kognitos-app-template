// ============================================================================
// CUSTOM WIDGET
// ============================================================================

interface IChatCustomWidgetProps {
  customContent: React.ReactNode;
}

/**
 * Wrapper for custom React content within a message widget.
 * Accepts any React node for full flexibility.
 */
export function ChatCustomWidget({ customContent }: IChatCustomWidgetProps) {
  return (
    <div
      data-slot="chat-message-widget-custom"
      data-testid="chat-message-widget-custom"
      className="w-full"
    >
      {customContent}
    </div>
  );
}
