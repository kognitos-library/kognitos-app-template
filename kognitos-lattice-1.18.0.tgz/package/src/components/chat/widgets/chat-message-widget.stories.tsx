import type { Meta, StoryObj } from '@storybook/react-vite';
import { ChatMessageWidget, type IChatMessageWidget } from '@/design-system';
import {
  Card,
  CardContent,
  CardTitle,
  CardHeader,
} from '../../../primitives/card';
import { Icon } from '../../../icons';

const meta: Meta<typeof ChatMessageWidget> = {
  title: 'Design System/Components/Chat/ChatMessageWidget',
  component: ChatMessageWidget,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A widget component for chat messages that supports button groups, action cards, and custom content. Used within chat messages to provide interactive elements.',
      },
    },
  },
  argTypes: {
    widget: {
      control: { type: 'object' },
      description: 'The widget object to display',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatMessageWidget>;

/**
 * Button group widget with default buttons.
 */
export const ButtonGroup: Story = {
  args: {
    widget: {
      type: 'button-group',
      buttons: [
        {
          id: 'btn1',
          label: 'Yes, please',
          variant: 'default',
          onClick: () => console.log('Yes clicked'),
        },
        {
          id: 'btn2',
          label: 'No, thanks',
          variant: 'outline',
          onClick: () => console.log('No clicked'),
        },
      ],
    },
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatMessageWidget {...args} />
    </Card>
  ),
};

/**
 * Button group with multiple buttons and variants.
 */
export const ButtonGroupMultiple: Story = {
  args: {
    widget: {
      type: 'button-group',
      buttons: [
        {
          id: 'btn1',
          label: 'Primary Action',
          variant: 'default',
          onClick: () => console.log('Primary clicked'),
        },
        {
          id: 'btn2',
          label: 'Secondary',
          variant: 'outline',
          onClick: () => console.log('Secondary clicked'),
        },
        {
          id: 'btn3',
          label: 'Tertiary',
          variant: 'ghost',
          onClick: () => console.log('Tertiary clicked'),
        },
        {
          id: 'btn4',
          label: 'Danger',
          variant: 'destructive',
          onClick: () => console.log('Danger clicked'),
        },
      ],
    },
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatMessageWidget {...args} />
    </Card>
  ),
};

/**
 * Button group with disabled and loading states.
 */
export const ButtonGroupStates: Story = {
  args: {
    widget: {
      type: 'button-group',
      buttons: [
        {
          id: 'btn1',
          label: 'Normal',
          variant: 'default',
          onClick: () => console.log('Normal clicked'),
        },
        {
          id: 'btn2',
          label: 'Disabled',
          variant: 'outline',
          disabled: true,
          onClick: () => console.log('Disabled clicked'),
        },
        {
          id: 'btn3',
          label: 'Loading',
          variant: 'default',
          isLoading: true,
          onClick: () => console.log('Loading clicked'),
        },
      ],
    },
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatMessageWidget {...args} />
    </Card>
  ),
};

/**
 * Action cards widget with icon URLs.
 */
export const ActionCardsWithIcons: Story = {
  args: {
    widget: {
      type: 'action-cards',
      actionCards: [
        {
          id: 'card1',
          title: 'View Dashboard',
          imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=1',
          fallbackIcon: <Icon type="BarChart" className="size-4" />,
          actionProps: {
            label: 'Open',
            onClick: () => console.log('Dashboard clicked'),
          },
        },
        {
          id: 'card2',
          title: 'Check Settings',
          imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=2',
          fallbackIcon: <Icon type="Settings" className="size-4" />,
          actionProps: {
            label: 'View',
            onClick: () => console.log('Settings clicked'),
          },
        },
        {
          id: 'card3',
          title: 'Manage Users',
          imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=3',
          fallbackIcon: <Icon type="Users" className="size-4" />,
          actionProps: {
            label: 'Go',
            onClick: () => console.log('Users clicked'),
          },
        },
      ],
    },
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatMessageWidget {...args} />
    </Card>
  ),
};

/**
 * Action cards widget with React icon components.
 */
export const ActionCardsWithReactIcons: Story = {
  args: {
    widget: {
      type: 'action-cards',
      actionCards: [
        {
          id: 'card1',
          title: 'Dashboard',
          fallbackIcon: <Icon type="BarChart" className="size-4" />,
          actionProps: {
            label: 'Open',
            onClick: () => console.log('Dashboard clicked'),
          },
        },
        {
          id: 'card2',
          title: 'Settings',
          fallbackIcon: <Icon type="Settings" className="size-4" />,
          actionProps: {
            label: 'View',
            onClick: () => console.log('Settings clicked'),
          },
        },
        {
          id: 'card3',
          title: 'Users',
          fallbackIcon: <Icon type="Users" className="size-4" />,
          actionProps: {
            label: 'Manage',
            onClick: () => console.log('Users clicked'),
          },
        },
      ],
    },
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatMessageWidget {...args} />
    </Card>
  ),
};

/**
 * Action cards without icons.
 */
export const ActionCardsWithoutIcons: Story = {
  args: {
    widget: {
      type: 'action-cards',
      actionCards: [
        {
          id: 'card1',
          title: 'View Dashboard',
          actionProps: {
            label: 'Open',
            onClick: () => console.log('Dashboard clicked'),
          },
        },
        {
          id: 'card2',
          title: 'Check Settings',
          actionProps: {
            label: 'View',
            onClick: () => console.log('Settings clicked'),
          },
        },
      ],
    },
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatMessageWidget {...args} />
    </Card>
  ),
};

/**
 * Action cards with custom button labels.
 */
export const ActionCardsCustomLabels: Story = {
  args: {
    widget: {
      type: 'action-cards',
      actionCards: [
        {
          id: 'card1',
          title: 'View Dashboard',
          imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=1',
          fallbackIcon: <Icon type="BarChart" className="size-4" />,
          actionProps: {
            label: 'Launch',
            onClick: () => console.log('Dashboard clicked'),
          },
        },
        {
          id: 'card2',
          title: 'Check Settings',
          imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=2',
          fallbackIcon: <Icon type="Settings" className="size-4" />,
          actionProps: {
            label: 'Configure',
            onClick: () => console.log('Settings clicked'),
          },
        },
        {
          id: 'card3',
          title: 'Manage Users',
          imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=3',
          fallbackIcon: <Icon type="Users" className="size-4" />,
          actionProps: {
            label: 'Edit',
            onClick: () => console.log('Users clicked'),
          },
        },
      ],
    },
  },
  render: args => (
    <Card className="w-full max-w-md p-4">
      <ChatMessageWidget {...args} />
    </Card>
  ),
};

/**
 * Custom widget with complex content.
 */
export const CustomWidget: Story = {
  args: {
    widget: {
      type: 'custom',
      customContent: (
        <Card className="p-4">
          <CardHeader>
            <CardTitle>Custom Widget</CardTitle>
          </CardHeader>
          <CardContent>
            This is a custom widget with custom content.
          </CardContent>
        </Card>
      ),
    },
  },
  render: args => <ChatMessageWidget {...args} />,
};

/**
 * Widget types comparison.
 */
export const WidgetTypesComparison: Story = {
  render: () => {
    const buttonWidget: IChatMessageWidget = {
      type: 'button-group',
      buttons: [
        {
          id: 'btn1',
          label: 'Option 1',
          variant: 'default',
        },
        {
          id: 'btn2',
          label: 'Option 2',
          variant: 'outline',
        },
      ],
    };

    const actionCardsWidget: IChatMessageWidget = {
      type: 'action-cards',
      actionCards: [
        {
          id: 'card1',
          title: 'Action Card Example',
          imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=1',
          fallbackIcon: <Icon type="File" className="size-4" />,
          actionProps: {
            label: 'Action',
          },
        },
      ],
    };

    const customWidget: IChatMessageWidget = {
      type: 'custom',
      customContent: (
        <div className="p-2 border border-border rounded text-sm">
          Custom Widget Example
        </div>
      ),
    };

    return (
      <Card className="w-full max-w-md p-4">
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-semibold mb-2">Button Group</h3>
            <ChatMessageWidget widget={buttonWidget} />
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-2">Action Cards</h3>
            <ChatMessageWidget widget={actionCardsWidget} />
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-2">Custom</h3>
            <ChatMessageWidget widget={customWidget} />
          </div>
        </div>
      </Card>
    );
  },
};
