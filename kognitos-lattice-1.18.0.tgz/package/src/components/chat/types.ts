import * as React from 'react';
import type { IconType } from '../../icons';
import type { IButtonProps } from '../../primitives/button';
import type { TTimestampFormatter } from './utils';

// ============================================================================
// CHAT TYPES
// ============================================================================

/**
 * Direction of a chat message.
 * - `incoming`: Messages received from others (left-aligned)
 * - `outgoing`: Messages sent by user (right-aligned in default variant)
 */
export enum EMessageDirection {
  INCOMING = 'incoming',
  OUTGOING = 'outgoing',
}

// Creates a union type of string literals from EMessageDirection enum values
// e.g., "incoming" | "outgoing"
export type TMessageDirection = `${EMessageDirection}`;

/**
 * Visual variant of a message.
 * - `default`: Traditional chat bubbles with avatars on sides
 * - `inline`: Full-width messages with inline avatars
 */
export enum EMessageVariant {
  DEFAULT = 'default',
  INLINE = 'inline',
}

// Creates a union type of string literals from EMessageVariant enum values
// e.g., "default" | "inline"
export type TMessageVariant = `${EMessageVariant}`;

/**
 * Delivery status of a message.
 */
export enum EMessageStatus {
  SENDING = 'sending',
  SENT = 'sent',
  DELIVERED = 'delivered',
  ERROR = 'error',
}

// Creates a union type of string literals from EMessageStatus enum values
// e.g., "sending" | "sent" | "delivered" | "error"
export type TMessageStatus = `${EMessageStatus}`;

/**
 * Type of file attachment (determines icon and color).
 */
export enum EAttachmentType {
  TEXT = 'text',
  EXCEL = 'excel',
  PDF = 'pdf',
  IMAGE = 'image',
  FILE = 'file',
}

// Creates a union type of string literals from EAttachmentType enum values
// e.g., "text" | "excel" | "pdf" | "image" | "file"
export type TAttachmentType = `${EAttachmentType}`;

/**
 * State for status indicators (used in ChatStatus component).
 */
export enum EMessageUpdateState {
  DEFAULT = 'default',
  ERROR = 'error',
  WARNING = 'warning',
  SUCCESS = 'success',
}

// Creates a union type of string literals from EMessageUpdateState enum values
// e.g., "default" | "error" | "warning"
export type TMessageUpdateState = `${EMessageUpdateState}`;

/**
 * Type of interactive widget to display in a message.
 */
export enum EWidgetType {
  BUTTON_GROUP = 'button-group',
  ACTION_CARDS = 'action-cards',
  CUSTOM = 'custom',
}

// Creates a union type of string literals from EWidgetType enum values
// e.g., "button-group" | "action-cards" | "custom"
export type TWidgetType = `${EWidgetType}`;

/**
 * Type of a chat message.
 * - `default`: Regular chat message (text, attachments, widgets)
 * - `thinking`: Agent thinking step message (grouped and displayed in collapsible box)
 * - `complete`: Signals that processing of previous messages is complete (renders nothing in UI)
 */
export enum EMessageType {
  DEFAULT = 'default',
  THINKING = 'thinking',
  COMPLETE = 'complete',
}

// Creates a union type of string literals from EMessageType enum values
// e.g., "default" | "thinking" | "complete"
export type TMessageType = `${EMessageType}`;

/**
 * Button configuration for button-group widgets.
 */
export interface IChatMessageButton extends Pick<
  IButtonProps,
  'variant' | 'disabled'
> {
  id: string;
  label: string;
  onClick?: () => void;
  isLoading?: boolean;
}

/**
 * Action card configuration for action-cards widgets.
 */
export interface IChatMessageActionCard {
  id: string;
  title: string;
  description?: string;
  imageUrl?: string;
  fallbackIcon?: React.ReactNode;
  actionProps?: Omit<IButtonProps, 'children'> & {
    label?: string;
    onClick?: () => void;
  };
  postfix?: React.ReactNode;
}

/**
 * Interactive widget displayed within a message.
 * Set `type` to specify widget kind, then provide corresponding data.
 */
export interface IChatMessageWidget {
  type: TWidgetType;
  /** For button-group widgets */
  buttons?: IChatMessageButton[];
  /** For action-cards widgets */
  actionCards?: IChatMessageActionCard[];
  /** For custom widgets */
  customContent?: React.ReactNode;
}

/**
 * Core message data structure.
 * Supports text, attachments, widgets, and display customization.
 */
export interface IChatMessage {
  id: string;
  content?: string;
  direction: TMessageDirection;
  variant?: TMessageVariant;
  timestamp?: Date | string;
  avatarUrl?: string;
  avatarFallback?: React.ReactNode;
  status?: TMessageStatus;
  widget?: IChatMessageWidget;
  attachments?: IChatAttachment[];
  /** Message-level override for Chat-level showSender */
  showSender?: boolean;
  /** Message-level override for Chat-level showTimestamp */
  showTimestamp?: boolean;
  /**
   * Type of message. Defaults to 'default'.
   * - `default`: Regular chat message
   * - `thinking`: Agent thinking step (grouped and displayed in collapsible box)
   * - `complete`: Signals processing complete (renders nothing in UI)
   */
  type?: TMessageType;
}

/**
 * File attachment data structure.
 */
export interface IChatAttachment {
  id: string;
  name: string;
  type: TAttachmentType;
  url?: string;
  size?: number;
  onClick?: () => void;
}

export interface IChatProps extends Omit<
  React.HTMLAttributes<HTMLDivElement>,
  'ref'
> {
  messages?: IChatMessage[];
  showGradient?: boolean;
  showEmptyState?: boolean;
  emptyStateTitle?: string;
  emptyStateDescription?: string;
  emptyStateIcon?: IconType;
  renderMessage?: (message: IChatMessage) => React.ReactNode;
  children?: React.ReactNode;
  messageVariant?: TMessageVariant;
  // Chat-level configuration for all messages
  showSender?: boolean;
  showTimestamp?: boolean;
  /** Custom timestamp formatter function. Defaults to formatTimestamp from chat.utils */
  timestampFormatter?: TTimestampFormatter;
  /**
   * Scroll threshold in pixels. User is considered "scrolled up" if they are
   * more than this distance from the bottom.
   * Default: 100px (common in chat UX)
   */
  scrollThreshold?: number;
  /**
   * Loading state. When true and there are no messages, shows skeleton loaders instead of empty state.
   * Default: false
   */
  isLoading?: boolean;
  /**
   * Chat container class name.
   * Default: ''
   */
  chatContainerClassName?: string;
  /**
   * Text configuration for thinking messages.
   * Pass translated strings for proper i18n support.
   */
  thinkingTexts?: IChatThinkingTexts;
  /**
   * Custom component to render at the top of the chat messages.
   * Useful for infinite scroll triggers or loading indicators.
   */
  topComponent?: React.ReactNode;
  /** Ref to attach to the root element */
  ref?: React.Ref<HTMLDivElement>;
}

export interface IChatMessageProps extends React.HTMLAttributes<HTMLDivElement> {
  message: IChatMessage;
  defaultVariant?: TMessageVariant;
  // Chat-level defaults (can be overridden by message-level props)
  defaultShowSender?: boolean;
  defaultShowTimestamp?: boolean;
  /** Custom timestamp formatter function. Defaults to formatTimestamp from chat.utils */
  timestampFormatter?: TTimestampFormatter;
}

export interface IChatMessageAttachmentProps extends React.HTMLAttributes<HTMLDivElement> {
  attachment: Omit<IChatAttachment, 'onClick'>;
  showRemove?: boolean;
  onRemove?: () => void;
  onClick?: () => void;
}

export interface IChatStatusProps extends React.HTMLAttributes<HTMLDivElement> {
  state?: TMessageUpdateState;
  text?: string;
  icon?: IconType;
  showIcon?: boolean;
  action?: {
    /**
     * Action button label text to display.
     */
    label: string;
    onClick: () => void;
  };
}

/**
 * Text configuration for ChatThinkingMessage component.
 * All text props are optional and have English defaults for backwards compatibility.
 * Consumers should pass translated strings for proper i18n support.
 */
export interface IChatThinkingTexts {
  /** Text shown when streaming (default: "Thinking...") */
  title?: string;
  /** Text shown when complete with duration. Use {duration} placeholder (default: "Thought for {duration}") */
  completedTitle?: string;
  /** Fallback text when complete but no duration available (default: "Thought") */
  completedTitleFallback?: string;
  /** Aria label for collapse action (default: "Collapse thinking") */
  collapseLabel?: string;
  /** Aria label for expand action (default: "Expand thinking") */
  expandLabel?: string;
  /** Text for show more button. Use {count} placeholder (default: "{count} more steps") */
  showMoreLabel?: string;
  /** Text for show less button (default: "Show less") */
  showLessLabel?: string;
}

/**
 * Props for the ChatThinkingMessage component.
 * Displays a collapsible box with grouped thinking messages.
 */
export interface IChatThinkingMessageProps
  extends React.HTMLAttributes<HTMLDivElement>, IChatThinkingTexts {
  /** Array of thinking messages to display */
  messages: IChatMessage[];
  /** Number of messages to show when collapsed (default: 2) */
  collapsedCount?: number;
  /**
   * Whether the thinking process is complete (no more streaming).
   * When true, displays "Thought for Xs" instead of "Thinking..." and
   * defaults to collapsed state. When false, shows shimmer animation
   * and defaults to expanded state.
   * Default: false
   */
  isComplete?: boolean;
  /**
   * Callback function to be called when the thinking process is complete.
   */
  onComplete?: () => void;
}
