import * as React from 'react';

import { ChatMessage } from './chat-message';
import { ChatThinkingMessage } from './chat-thinking-message';
import {
  isCompleteMessage,
  isThinkingMessageGroup,
  type TProcessedMessageItem,
  type TTimestampFormatter,
} from './utils';
import { type IChatMessage, type TMessageVariant } from './types';

// ============================================================================
// MEMOIZED MESSAGE LIST
// ============================================================================

export interface IMemoizedMessageListProps {
  processedMessages: TProcessedMessageItem[];
  messageVariant?: TMessageVariant;
  showSender: boolean;
  showTimestamp: boolean;
  timestampFormatter?: TTimestampFormatter;
  renderMessage?: (message: IChatMessage) => React.ReactNode;
  onThinkingComplete: () => void;
}

/**
 * Memoized message list component to prevent re-rendering of the entire
 * message list when unrelated state changes (e.g., typing in the input).
 *
 * Only re-renders when message data or display configuration actually changes.
 */
export const MemoizedMessageList = React.memo(function MemoizedMessageList({
  processedMessages,
  messageVariant,
  showSender,
  showTimestamp,
  timestampFormatter,
  renderMessage,
  onThinkingComplete,
}: IMemoizedMessageListProps) {
  return (
    <>
      {processedMessages.map((item, index) => {
        if (isThinkingMessageGroup(item)) {
          return (
            <ChatThinkingMessage
              key={item.id}
              messages={item.messages}
              // Thinking is complete if there are more items after this group
              isComplete={index < processedMessages.length - 1}
              onComplete={onThinkingComplete}
            />
          );
        }
        // Skip complete messages - they render nothing in UI
        if (isCompleteMessage(item)) {
          return null;
        }

        if (renderMessage) {
          return (
            <React.Fragment key={item.id}>{renderMessage(item)}</React.Fragment>
          );
        }

        return (
          <ChatMessage
            key={item.id}
            message={item}
            defaultVariant={messageVariant}
            defaultShowSender={showSender}
            defaultShowTimestamp={showTimestamp}
            timestampFormatter={timestampFormatter}
          />
        );
      })}
    </>
  );
});

MemoizedMessageList.displayName = 'MemoizedMessageList';
