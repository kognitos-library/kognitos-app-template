import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import {
  ChatToast,
  Chat,
  ChatInput,
  useChat,
  Flex,
  type IconType,
} from '@/design-system';
import { Card, CardContent } from '../../primitives/card';

// Example icon types for Storybook controls
const exampleIcons: IconType[] = [
  'Sparkle',
  'Settings',
  'ArrowRight',
  'ArrowUpRight',
];

const meta: Meta<typeof ChatToast> = {
  title: 'Design System/Components/Chat/ChatToast',
  component: ChatToast,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A toast component for displaying chat-related actions and messages. Supports default and hover states with different styling. The `icon` and `actionIcon` props accept any `IconType` from the design system (e.g., Lucide icons or custom icons).',
      },
    },
  },
  argTypes: {
    text: {
      control: { type: 'text' },
      description: 'Text content to display in the toast',
    },
    icon: {
      control: 'select',
      options: exampleIcons,
      description:
        'Left icon type to display any `IconType` from the design system. Controls only show a few icons for demonstration purposes.',
    },
    actionIcon: {
      control: 'select',
      options: exampleIcons,
      description:
        'Action button icon type to display any `IconType` from the design system. Controls only show a few icons for demonstration purposes.',
    },
    onClick: {
      action: 'clicked',
      description: 'Callback when action button is clicked',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatToast>;

// Default chat toast in default state. Hover over component to see the hover state.
export const Default: Story = {
  render: args => (
    <div className="w-[312px]">
      <ChatToast {...args} />
    </div>
  ),
  args: {
    text: 'View Kognitos Website',
    icon: 'Sparkle',
    actionIcon: 'ArrowUpRight',
    onClick: () => window.open('https://www.kognitos.com', '_blank'),
  },
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'Default chat toast in default state. Hover over component to see the hover state.',
      },
    },
  },
};

// Chat toast with custom text.
export const CustomTextAndIcons: Story = {
  render: args => (
    <div className="w-[312px]">
      <ChatToast {...args} />
    </div>
  ),
  args: {
    text: 'Configure your settings',
    icon: 'Settings',
    actionIcon: 'ArrowRight',
    onClick: () => console.log('Action clicked'),
  },
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'Chat toast with custom text and icons. Hover over component to see the hover state.',
      },
    },
  },
};

// All variants showcase
export const AllVariants: Story = {
  render: () => (
    <Flex direction="row" gap={8}>
      {/* Column 1 */}
      <Flex direction="column" gap={4}>
        {/* Default variant */}
        <div>
          <p className="text-sm text-muted-foreground mb-2">Default</p>
          <div className="w-[312px]">
            <ChatToast
              text="Resolve with Run Assistant"
              icon="Sparkle"
              actionIcon="ArrowUpRight"
              onClick={() => console.log('Default clicked')}
            />
          </div>
        </div>

        {/* Custom text variants */}
        <div>
          <p className="text-sm text-muted-foreground mb-2">Custom Text</p>
          <Flex direction="column" gap={2}>
            <div className="w-[312px]">
              <ChatToast
                text="Configure your settings"
                icon="Sparkle"
                actionIcon="ArrowUpRight"
                onClick={() => console.log('Settings clicked')}
              />
            </div>
            <div className="w-[312px]">
              <ChatToast
                text="Save your changes"
                icon="Sparkle"
                actionIcon="ArrowUpRight"
                onClick={() => console.log('Save clicked')}
              />
            </div>
            <div className="w-[312px]">
              <ChatToast
                text="Review and approve"
                icon="Sparkle"
                actionIcon="ArrowUpRight"
                onClick={() => console.log('Review clicked')}
              />
            </div>
          </Flex>
        </div>
      </Flex>

      {/* Column 2 */}
      <Flex direction="column" gap={8}>
        {/* Custom action icon variants */}
        <div>
          <p className="text-sm text-muted-foreground mb-2">
            Custom Action Icons
          </p>
          <Flex direction="column" gap={2}>
            <div className="w-[312px]">
              <ChatToast
                text="Resolve with Run Assistant"
                icon="Sparkle"
                actionIcon="X"
                onClick={() => console.log('X icon clicked')}
              />
            </div>
            <div className="w-[312px]">
              <ChatToast
                text="Resolve with Run Assistant"
                icon="Sparkle"
                actionIcon="ExternalLink"
                onClick={() => console.log('ExternalLink icon clicked')}
              />
            </div>
            <div className="w-[312px]">
              <ChatToast
                text="Resolve with Run Assistant"
                icon="Sparkle"
                actionIcon="ChevronRight"
                onClick={() => console.log('ChevronRight icon clicked')}
              />
            </div>
          </Flex>
        </div>

        {/* Custom left icon variants */}
        <div>
          <p className="text-sm text-muted-foreground mb-2">
            Custom Left Icons
          </p>
          <Flex direction="column" gap={2}>
            <div className="w-[312px]">
              <ChatToast
                text="Resolve with Run Assistant"
                icon="Settings"
                actionIcon="ArrowUpRight"
                onClick={() => console.log('Settings icon clicked')}
              />
            </div>
            <div className="w-[312px]">
              <ChatToast
                text="Resolve with Run Assistant"
                icon="Zap"
                actionIcon="ArrowUpRight"
                onClick={() => console.log('Zap icon clicked')}
              />
            </div>
            <div className="w-[312px]">
              <ChatToast
                text="Resolve with Run Assistant"
                icon="Check"
                actionIcon="ArrowUpRight"
                onClick={() => console.log('Check icon clicked')}
              />
            </div>
          </Flex>
        </div>
      </Flex>
    </Flex>
  ),
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'Comprehensive showcase of all ChatToast variants including default, custom texts, custom left icons, and custom action icons. Hover over each component to see the hover state.',
      },
    },
  },
};

/**
 * ChatToast integrated within Chat component.
 * Shows how ChatToast appears above ChatInput when passed as a child to Chat.
 */
export const IntegrationWithChat: Story = {
  render: function InChatRender(args) {
    const { messages, addMessage } = useChat();
    const [inputValue, setInputValue] = useState('');

    const handleSend = (value: string) => {
      if (value.trim().length > 0) {
        addMessage({
          content: value,
          direction: 'outgoing',
          timestamp: new Date(),
          avatarFallback: 'U',
        });
        setInputValue('');

        // Simulate incoming response
        setTimeout(() => {
          addMessage({
            content: 'I can help you with that!',
            direction: 'incoming',
            timestamp: new Date(),
            avatarFallback: 'AI',
          });
        }, 1000);
      }
    };

    return (
      <Flex direction="row" gap={8}>
        <Flex align="center" justify="center" className="h-150 w-100">
          <Card className="w-full h-full">
            <CardContent className="h-full">
              <Chat messages={messages} showGradient>
                <ChatToast
                  text={args.text}
                  icon={args.icon}
                  actionIcon={args.actionIcon}
                  onClick={args.onClick}
                />
                <ChatInput
                  value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  onSend={handleSend}
                  placeholder="Type your message..."
                />
              </Chat>
            </CardContent>
          </Card>
        </Flex>
        <Flex align="center" justify="center" className="h-150 w-100">
          <Card className="w-full h-full">
            <CardContent className="h-full">
              <Chat messages={messages} showGradient>
                <ChatInput
                  value={inputValue}
                  onChange={e => setInputValue(e.target.value)}
                  onSend={handleSend}
                  placeholder="Type your message..."
                />
              </Chat>
            </CardContent>
          </Card>
        </Flex>
      </Flex>
    );
  },
  args: {
    text: 'View Kognitos Website',
    icon: 'Sparkle',
    actionIcon: 'ArrowUpRight',
    onClick: () => window.open('https://www.kognitos.com', '_blank'),
  },
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'This is what the Chat component looks like with and without the ChatToast component. The toast appears above the ChatInput when passed as a child to Chat. This demonstrates the automatic positioning and layout management.',
      },
    },
  },
};
