import * as React from 'react';
import type { IChatMessage } from './types';
import { generateMessageId } from './utils';

// ============================================================================
// TYPES
// ============================================================================

export interface IUseChatReturn {
  messages: IChatMessage[];
  addMessage: (message: Omit<IChatMessage, 'id'> | IChatMessage) => void;
  setMessages: (messages: IChatMessage[]) => void;
  removeMessage: (messageId: string) => void;
  updateMessage: (messageId: string, updates: Partial<IChatMessage>) => void;
  clearMessages: () => void;
}

// ============================================================================
// HOOK
// ============================================================================

/**
 * Hook for managing chat messages
 *
 * @param initialMessages - Initial messages array
 * @returns Object with messages array and utility functions
 *
 * @example
 * ```tsx
 * const { messages, addMessage, setMessages } = useChat();
 *
 * addMessage({
 *   content: 'Hello!',
 *   direction: 'outgoing',
 *   timestamp: new Date(),
 * });
 * ```
 */
export function useChat(initialMessages: IChatMessage[] = []): IUseChatReturn {
  const [messages, setMessages] =
    React.useState<IChatMessage[]>(initialMessages);

  const addMessage = React.useCallback(
    (message: Omit<IChatMessage, 'id'> | IChatMessage) => {
      setMessages(prev => {
        // If message already has an id, use it; otherwise generate a unique one
        const id = 'id' in message ? message.id : generateMessageId();
        const fullMessage: IChatMessage = {
          ...message,
          id,
        } as IChatMessage;

        return [...prev, fullMessage];
      });
    },
    [],
  );

  const setMessagesHandler = React.useCallback(
    (newMessages: IChatMessage[]) => {
      setMessages(newMessages);
    },
    [],
  );

  const removeMessage = React.useCallback((messageId: string) => {
    setMessages(prev => prev.filter(msg => msg.id !== messageId));
  }, []);

  const updateMessage = React.useCallback(
    (messageId: string, updates: Partial<IChatMessage>) => {
      setMessages(prev =>
        prev.map(msg => (msg.id === messageId ? { ...msg, ...updates } : msg)),
      );
    },
    [],
  );

  const clearMessages = React.useCallback(() => {
    setMessages([]);
  }, []);

  return {
    messages,
    addMessage,
    setMessages: setMessagesHandler,
    removeMessage,
    updateMessage,
    clearMessages,
  };
}
