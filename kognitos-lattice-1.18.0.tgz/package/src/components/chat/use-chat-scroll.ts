import * as React from 'react';

import { EMessageDirection, type IChatMessage } from './types';

// ============================================================================
// TYPES
// ============================================================================

export interface IUseChatScrollOptions {
  /** Array of chat messages to track for auto-scroll behavior */
  messages: IChatMessage[] | undefined;
  /**
   * Scroll threshold in pixels. User is considered "scrolled up" if they are
   * more than this distance from the bottom.
   * Default: 100px
   */
  scrollThreshold?: number;
}

export interface IUseChatScrollReturn {
  /** Ref to attach to the scroll area wrapper element */
  scrollAreaRef: React.RefObject<HTMLDivElement | null>;
  /** Programmatically scroll to the bottom of the chat */
  scrollToBottom: (behavior?: ScrollBehavior) => void;
  /** Callback for when a thinking animation completes — scrolls to reveal new content */
  handleThinkingComplete: () => void;
}

// ============================================================================
// CONSTANTS
// ============================================================================

/** Minimum interval between throttled scroll-to-bottom calls during streaming */
const SCROLL_THROTTLE_MS = 150;

/** Cooldown after user manually scrolls before auto-scroll can re-engage */
const USER_SCROLL_COOLDOWN_MS = 1000;

// ============================================================================
// HOOK
// ============================================================================

/**
 * Hook that manages automatic scroll behaviour for a chat container.
 *
 * Features:
 * - Auto-scrolls to bottom for new messages when user is at the bottom
 * - Preserves scroll position when user has scrolled up
 * - Throttles scroll-to-bottom during streaming to prevent render cascade
 * - Detects user scroll intent via wheel / touch events
 * - Handles initial scroll to bottom when messages first appear
 * - Handles thinking-complete transitions with ResizeObserver
 *
 * @example
 * ```tsx
 * const { scrollAreaRef, handleThinkingComplete } = useChatScroll({
 *   messages,
 *   scrollThreshold: 100,
 * });
 * ```
 */
export function useChatScroll({
  messages,
  scrollThreshold = 100,
}: IUseChatScrollOptions): IUseChatScrollReturn {
  const messagesCount = messages?.length || 0;
  const hasMessages = messagesCount > 0;

  // Refs for scroll management
  const scrollAreaRef = React.useRef<HTMLDivElement>(null);
  const isUserScrolledUpRef = React.useRef(false);
  const viewportRef = React.useRef<HTMLElement | null>(null);
  const previousMessageCountRef = React.useRef(messagesCount);
  const previousLastMessageContentRef = React.useRef<string | null>(null);
  const hasInitialScrolledRef = React.useRef(false);

  // Track active ResizeObserver for thinking-complete to prevent stacking
  const thinkingObserverRef = React.useRef<{
    observer: ResizeObserver;
    timeout: ReturnType<typeof setTimeout>;
  } | null>(null);

  // Throttle scroll during streaming to prevent render cascade
  // When tokens arrive faster than SCROLL_THROTTLE_MS, we batch scroll updates
  const lastScrollTimeRef = React.useRef(0);
  const pendingScrollRef = React.useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );
  const rafRef = React.useRef<number | null>(null);

  // Cooldown after user manually scrolls — prevents auto-scroll from
  // re-engaging while a smooth scroll animation settles or the user is still scrolling
  const userScrollCooldownRef = React.useRef(0);

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  /** Lazily resolve the ScrollArea viewport element */
  const getViewport = React.useCallback(() => {
    if (!viewportRef.current && scrollAreaRef.current) {
      viewportRef.current = scrollAreaRef.current.querySelector(
        '[data-slot="scroll-area-viewport"]',
      ) as HTMLElement | null;
    }
    return viewportRef.current;
  }, []);

  /**
   * Throttled scroll to bottom — prevents rapid updates during streaming.
   * Uses requestAnimationFrame for frame-aligned smooth scrolling.
   */
  const scrollToBottom = React.useCallback(
    (behavior: ScrollBehavior = 'smooth') => {
      const viewport = getViewport();
      if (!viewport) return;

      const now = Date.now();
      const timeSinceLastScroll = now - lastScrollTimeRef.current;

      const performScroll = () => {
        // Cancel any pending rAF to avoid stacking frames
        if (rafRef.current) {
          cancelAnimationFrame(rafRef.current);
        }
        // Align scroll to the next paint frame for smoother visual updates
        rafRef.current = requestAnimationFrame(() => {
          const v = getViewport();
          if (!v) return;
          v.scrollTo({
            top: v.scrollHeight,
            behavior,
          });
          isUserScrolledUpRef.current = false;
          lastScrollTimeRef.current = Date.now();
          rafRef.current = null;
        });
      };

      // Clear any pending scroll
      if (pendingScrollRef.current) {
        clearTimeout(pendingScrollRef.current);
        pendingScrollRef.current = null;
      }

      if (timeSinceLastScroll >= SCROLL_THROTTLE_MS) {
        // Enough time passed, scroll immediately
        performScroll();
      } else {
        // Throttle: schedule scroll after remaining time (trailing edge)
        const delay = SCROLL_THROTTLE_MS - timeSinceLastScroll;
        pendingScrollRef.current = setTimeout(performScroll, delay);
      }
    },
    [getViewport],
  );

  /** Cancel any pending or in-progress auto-scroll */
  const cancelPendingAutoScroll = React.useCallback(() => {
    if (pendingScrollRef.current) {
      clearTimeout(pendingScrollRef.current);
      pendingScrollRef.current = null;
    }
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  }, []);

  // ---------------------------------------------------------------------------
  // Cleanup on unmount
  // ---------------------------------------------------------------------------

  React.useEffect(() => {
    return () => {
      if (pendingScrollRef.current) {
        clearTimeout(pendingScrollRef.current);
      }
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
      if (thinkingObserverRef.current) {
        thinkingObserverRef.current.observer.disconnect();
        clearTimeout(thinkingObserverRef.current.timeout);
      }
    };
  }, []);

  // ---------------------------------------------------------------------------
  // Thinking-complete handler
  // ---------------------------------------------------------------------------

  /** Handler for when thinking completes — scroll to show new content */
  const handleThinkingComplete = React.useCallback(() => {
    // Clean up any previous observer to prevent stacking
    if (thinkingObserverRef.current) {
      thinkingObserverRef.current.observer.disconnect();
      clearTimeout(thinkingObserverRef.current.timeout);
      thinkingObserverRef.current = null;
    }

    const viewport = getViewport();
    if (!viewport) return;

    let lastScrollHeight = viewport.scrollHeight;
    let stableCount = 0;

    const observer = new ResizeObserver(() => {
      const v = getViewport();
      if (!v) return;
      const currentScrollHeight = v.scrollHeight;

      if (currentScrollHeight === lastScrollHeight) {
        stableCount++;
        if (stableCount >= 2) {
          scrollToBottom('smooth');
          observer.disconnect();
          thinkingObserverRef.current = null;
        }
      } else {
        stableCount = 0;
        lastScrollHeight = currentScrollHeight;
      }
    });

    const timeout = setTimeout(() => {
      observer.disconnect();
      thinkingObserverRef.current = null;
      scrollToBottom('smooth');
    }, 2000);

    thinkingObserverRef.current = { observer, timeout };
    observer.observe(viewport);
  }, [getViewport, scrollToBottom]);

  // ---------------------------------------------------------------------------
  // Scroll position tracking + user scroll intent detection
  // ---------------------------------------------------------------------------

  React.useEffect(() => {
    const viewport = getViewport();
    if (!viewport) return;

    const checkScrollPosition = () => {
      const v = getViewport();
      if (!v) return;
      // Check if user is near the bottom (within configured threshold)
      const { scrollTop, scrollHeight, clientHeight } = v;
      const distanceFromBottom = scrollHeight - scrollTop - clientHeight;

      // During cooldown after user scroll, preserve the scrolled-up flag
      // so that smooth scroll settling doesn't accidentally re-enable auto-scroll
      const inCooldown =
        Date.now() - userScrollCooldownRef.current < USER_SCROLL_COOLDOWN_MS;
      if (inCooldown && isUserScrolledUpRef.current) return;

      isUserScrolledUpRef.current = distanceFromBottom > scrollThreshold;
    };

    // Wheel events reliably indicate user scroll intent
    // (never fired by programmatic scrolls)
    const handleWheel = (e: WheelEvent) => {
      if (e.deltaY < 0) {
        // User is scrolling up — immediately override auto-scroll
        isUserScrolledUpRef.current = true;
        userScrollCooldownRef.current = Date.now();
        cancelPendingAutoScroll();
        // Stop any in-progress smooth scroll animation by
        // performing an instant scroll to the current position
        viewport.scrollTo({ top: viewport.scrollTop, behavior: 'auto' });
      }
    };

    // Touch events indicate direct user interaction
    let touchStartY = 0;
    const handleTouchStart = (e: TouchEvent) => {
      touchStartY = e.touches[0]?.clientY ?? 0;
      // Any touch means user is interacting — cancel pending auto-scrolls
      cancelPendingAutoScroll();
    };

    const handleTouchMove = (e: TouchEvent) => {
      const currentY = e.touches[0]?.clientY ?? 0;
      if (currentY > touchStartY + 10) {
        // Finger moving down on screen = content scrolling up
        isUserScrolledUpRef.current = true;
        userScrollCooldownRef.current = Date.now();
        cancelPendingAutoScroll();
      }
    };

    checkScrollPosition();
    viewport.addEventListener('scroll', checkScrollPosition, { passive: true });
    viewport.addEventListener('wheel', handleWheel, { passive: true });
    viewport.addEventListener('touchstart', handleTouchStart, {
      passive: true,
    });
    viewport.addEventListener('touchmove', handleTouchMove, { passive: true });

    return () => {
      viewport.removeEventListener('scroll', checkScrollPosition);
      viewport.removeEventListener('wheel', handleWheel);
      viewport.removeEventListener('touchstart', handleTouchStart);
      viewport.removeEventListener('touchmove', handleTouchMove);
    };
  }, [scrollThreshold, getViewport, cancelPendingAutoScroll]);

  // ---------------------------------------------------------------------------
  // Initial scroll to bottom when messages first appear (runs once)
  // ---------------------------------------------------------------------------

  React.useEffect(() => {
    if (!hasMessages || hasInitialScrolledRef.current) return;

    const viewport = getViewport();
    if (!viewport) return;

    // Mark only AFTER confirming viewport exists — prevents permanently
    // skipping initial scroll if viewport isn't ready yet
    hasInitialScrolledRef.current = true;

    // Scroll directly without throttling — initial scroll should be instant
    const doScroll = () => {
      const v = getViewport();
      if (!v) return;
      v.scrollTo({ top: v.scrollHeight, behavior: 'auto' });
      isUserScrolledUpRef.current = false;
      lastScrollTimeRef.current = Date.now();
    };

    // 1. Scroll immediately — content is rendered after React commit
    doScroll();

    // 2. Scroll after next paint — catches late layout shifts
    const raf = requestAnimationFrame(() => {
      doScroll();
    });

    // 3. Scroll after short delay — catches async content (images, etc.)
    const timeout = setTimeout(() => {
      doScroll();
    }, 150);

    return () => {
      cancelAnimationFrame(raf);
      clearTimeout(timeout);
    };
  }, [hasMessages, getViewport]);

  // ---------------------------------------------------------------------------
  // Auto-scroll on new messages or streaming content changes
  // ---------------------------------------------------------------------------

  React.useEffect(() => {
    if (!hasMessages) {
      previousMessageCountRef.current = 0;
      previousLastMessageContentRef.current = null;
      return;
    }

    // Wait for initial scroll to finish
    if (!hasInitialScrolledRef.current) return;

    const messageCountIncreased =
      messagesCount > previousMessageCountRef.current;
    const lastMessage = messages?.[messagesCount - 1];
    const currentContent = lastMessage?.content || null;
    const contentChanged =
      currentContent !== previousLastMessageContentRef.current;

    if (messageCountIncreased || contentChanged) {
      const isIncoming = lastMessage?.direction === EMessageDirection.INCOMING;

      if (!isIncoming) {
        // User sent a message — always scroll to show it & reset cooldown
        userScrollCooldownRef.current = 0;
        scrollToBottom('smooth');
      } else if (!isUserScrolledUpRef.current) {
        // Incoming message/streaming and user is at bottom — scroll
        // unless in cooldown from a recent manual scroll attempt
        const inCooldown =
          Date.now() - userScrollCooldownRef.current < USER_SCROLL_COOLDOWN_MS;
        if (!inCooldown) {
          scrollToBottom('smooth');
        }
      }
    }

    previousMessageCountRef.current = messagesCount;
    previousLastMessageContentRef.current = currentContent;
  }, [messages, messagesCount, hasMessages, scrollToBottom]);

  return {
    scrollAreaRef,
    scrollToBottom,
    handleThinkingComplete,
  };
}
