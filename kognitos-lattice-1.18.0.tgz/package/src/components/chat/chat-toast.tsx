import { cn } from '@/design-system/lib/utils';
import { Flex } from '../../primitives/flex';
import { Text } from '../../primitives/typography';
import { Icon, type IconType } from '../../icons';
import { Button } from '../../primitives/button';

// Props for the ChatToast component
export interface IChatToastProps extends React.HTMLAttributes<HTMLDivElement> {
  text: string;
  icon?: IconType;
  onClick: () => void;
  actionIcon?: IconType;
}

const defaultIcon: IconType = 'Sparkle';
const defaultActionIcon: IconType = 'ArrowUpRight';

/**
 * Chat toast to display message and action and to sit atop the Chat Input component.
 * When hovered over, the toast will change to a different color.
 *
 * The `text` prop must be a translated string from `useTranslation()`.
 * Do not pass hardcoded English strings. All user-facing text must be internationalized.
 */
export function ChatToast({
  icon,
  text,
  onClick,
  actionIcon,
  className,
  ...props
}: IChatToastProps) {
  return (
    <Flex
      gap={2.5}
      align="center"
      paddingX={2.5}
      paddingY={1.5}
      width="full"
      className={cn(
        'group rounded-t-md border transition-colors bg-background/50 border-border/80 hover:bg-primary hover:border-primary overflow-hidden hover:cursor-pointer',
        className,
      )}
      onClick={onClick}
      {...props}
    >
      {/* Left icon */}
      <Flex align="center" justify="center" className="shrink-0">
        <Icon
          type={icon ?? defaultIcon}
          size="sm"
          className="text-muted-foreground group-hover:text-primary-foreground"
        />
      </Flex>

      {/* Text */}
      <Flex flex="1" align="center" className="min-w-0">
        <Text
          level="small"
          className="group-hover:text-primary-foreground truncate"
        >
          {text}
        </Text>
      </Flex>

      {/* Action button */}
      {/* size-6 customization is intentional and variant should remain default to match design specs */}
      <Button
        variant="default"
        className="size-6 group-hover:shadow-none rounded-md"
        aria-label={`${text} action`}
      >
        <Icon
          type={actionIcon ?? defaultActionIcon}
          size="sm"
          className="group-hover:text-primary-foreground"
        />
      </Button>
    </Flex>
  );
}

ChatToast.displayName = 'ChatToast';
