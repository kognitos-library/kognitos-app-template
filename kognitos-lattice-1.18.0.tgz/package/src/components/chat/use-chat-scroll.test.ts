import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, render, act } from '@testing-library/react';
import * as React from 'react';
import {
  useChatScroll,
  type IUseChatScrollOptions,
  type IUseChatScrollReturn,
} from './use-chat-scroll';
import { EMessageDirection, type IChatMessage } from './types';

// ============================================================================
// HELPERS
// ============================================================================

const createMockMessage = (
  id: string,
  content: string,
  direction: EMessageDirection = EMessageDirection.INCOMING,
): IChatMessage => ({
  id,
  content,
  direction,
  timestamp: new Date('2024-01-15T14:30:00'),
});

// ============================================================================
// MOCK: ResizeObserver
// ============================================================================

interface IMockResizeObserverEntry {
  instance: MockResizeObserver;
  callback: ResizeObserverCallback;
}

let resizeObserverEntries: IMockResizeObserverEntry[];

class MockResizeObserver {
  observe = vi.fn();
  unobserve = vi.fn();
  disconnect = vi.fn();
  private _callback: ResizeObserverCallback;

  constructor(callback: ResizeObserverCallback) {
    this._callback = callback;
    resizeObserverEntries.push({ instance: this, callback });
  }

  /** Simulate the observer callback firing */
  trigger(entries: ResizeObserverEntry[] = []) {
    this._callback(entries, this as unknown as ResizeObserver);
  }
}

// ============================================================================
// SETUP HELPER
// ============================================================================

interface ISetupOptions extends IUseChatScrollOptions {
  scrollHeight?: number;
  scrollTop?: number;
  clientHeight?: number;
}

/**
 * Creates a test component that renders the real DOM structure expected by
 * useChatScroll (a scroll area wrapper with a data-slot viewport child),
 * and returns helpers for interacting with the hook and viewport in tests.
 */
function setup(options: ISetupOptions = { messages: [] }) {
  const {
    scrollHeight: initialScrollHeight = 1000,
    scrollTop: initialScrollTop,
    clientHeight = 500,
    ...hookProps
  } = options;

  // Default: user at the bottom
  let _scrollTop = initialScrollTop ?? initialScrollHeight - clientHeight;
  let _scrollHeight = initialScrollHeight;

  let hookResult: IUseChatScrollReturn = null!;

  function Harness(props: IUseChatScrollOptions) {
    const result = useChatScroll(props);
    hookResult = result;
    return React.createElement(
      'div',
      { ref: result.scrollAreaRef },
      React.createElement('div', { 'data-slot': 'scroll-area-viewport' }),
    );
  }

  const { rerender: _rerender, unmount } = render(
    React.createElement(Harness, hookProps),
  );

  const viewport = document.querySelector(
    '[data-slot="scroll-area-viewport"]',
  ) as HTMLElement;

  // Mock scroll properties (jsdom doesn't support layout)
  Object.defineProperty(viewport, 'scrollHeight', {
    get: () => _scrollHeight,
    configurable: true,
  });
  Object.defineProperty(viewport, 'scrollTop', {
    get: () => _scrollTop,
    set: (v: number) => {
      _scrollTop = v;
    },
    configurable: true,
  });
  Object.defineProperty(viewport, 'clientHeight', {
    get: () => clientHeight,
    configurable: true,
  });
  viewport.scrollTo = vi.fn((...args: unknown[]) => {
    const opts =
      typeof args[0] === 'object' ? (args[0] as ScrollToOptions) : undefined;
    if (opts?.top !== undefined) _scrollTop = opts.top;
  });

  const rerender = (newProps: IUseChatScrollOptions) => {
    _rerender(React.createElement(Harness, newProps));
  };

  /** Flush all pending throttled scrolls + rAF (200ms > 150ms throttle + 16ms frame) */
  const flushScrollTimers = () => {
    act(() => {
      vi.advanceTimersByTime(250);
    });
  };

  /** Flush the initial scroll (immediate + rAF + 150ms fallback) */
  const flushInitialScroll = () => {
    act(() => {
      vi.advanceTimersByTime(200);
    });
  };

  return {
    get result() {
      return hookResult;
    },
    viewport,
    rerender,
    unmount,
    flushScrollTimers,
    flushInitialScroll,
    setScrollTop: (v: number) => {
      _scrollTop = v;
    },
    setScrollHeight: (v: number) => {
      _scrollHeight = v;
    },
  };
}

// ============================================================================
// TESTS
// ============================================================================

describe('useChatScroll', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    resizeObserverEntries = [];
    vi.stubGlobal('ResizeObserver', MockResizeObserver);
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  // --------------------------------------------------------------------------
  // Return values
  // --------------------------------------------------------------------------

  describe('Return values', () => {
    it('should return scrollAreaRef, scrollToBottom, and handleThinkingComplete', () => {
      const { result } = renderHook(() => useChatScroll({ messages: [] }));

      expect(result.current).toHaveProperty('scrollAreaRef');
      expect(result.current).toHaveProperty('scrollToBottom');
      expect(result.current).toHaveProperty('handleThinkingComplete');
    });

    it('should return scrollAreaRef as a ref object with null initial value', () => {
      const { result } = renderHook(() => useChatScroll({ messages: [] }));

      expect(result.current.scrollAreaRef).toBeDefined();
      expect(result.current.scrollAreaRef.current).toBeNull();
    });

    it('should return scrollToBottom and handleThinkingComplete as functions', () => {
      const { result } = renderHook(() => useChatScroll({ messages: [] }));

      expect(typeof result.current.scrollToBottom).toBe('function');
      expect(typeof result.current.handleThinkingComplete).toBe('function');
    });
  });

  // --------------------------------------------------------------------------
  // scrollToBottom
  // --------------------------------------------------------------------------

  describe('scrollToBottom', () => {
    it('should scroll viewport to bottom', () => {
      const { result, viewport, flushScrollTimers } = setup({ messages: [] });

      act(() => {
        result.scrollToBottom();
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalledWith(
        expect.objectContaining({ top: viewport.scrollHeight }),
      );
    });

    it('should use smooth behavior by default', () => {
      const { result, viewport, flushScrollTimers } = setup({ messages: [] });

      act(() => {
        result.scrollToBottom();
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalledWith(
        expect.objectContaining({ behavior: 'smooth' }),
      );
    });

    it('should accept custom scroll behavior', () => {
      const { result, viewport, flushScrollTimers } = setup({ messages: [] });

      act(() => {
        result.scrollToBottom('auto');
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalledWith(
        expect.objectContaining({ behavior: 'auto' }),
      );
    });

    it('should throttle rapid consecutive calls', () => {
      const { result, viewport } = setup({ messages: [] });

      // First call — executes immediately via rAF
      act(() => {
        result.scrollToBottom();
      });
      act(() => {
        vi.advanceTimersByTime(20); // rAF fires
      });

      const firstCallCount = (viewport.scrollTo as ReturnType<typeof vi.fn>)
        .mock.calls.length;
      expect(firstCallCount).toBeGreaterThanOrEqual(1);

      // Second call immediately after — should be throttled
      act(() => {
        result.scrollToBottom();
      });
      act(() => {
        vi.advanceTimersByTime(20); // only 20ms, not enough for throttle
      });

      // Should NOT have fired yet (within throttle window)
      expect(
        (viewport.scrollTo as ReturnType<typeof vi.fn>).mock.calls.length,
      ).toBe(firstCallCount);

      // After throttle interval, the pending scroll should fire
      act(() => {
        vi.advanceTimersByTime(200);
      });

      expect(
        (viewport.scrollTo as ReturnType<typeof vi.fn>).mock.calls.length,
      ).toBeGreaterThan(firstCallCount);
    });

    it('should not throw when viewport is not available', () => {
      const { result } = renderHook(() => useChatScroll({ messages: [] }));

      // scrollAreaRef.current is null — should silently do nothing
      expect(() => {
        act(() => {
          result.current.scrollToBottom();
        });
      }).not.toThrow();
    });
  });

  // --------------------------------------------------------------------------
  // Auto-scroll on new messages
  // --------------------------------------------------------------------------

  describe('Auto-scroll on new messages', () => {
    it('should auto-scroll when a new outgoing message is added', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({ messages });

      // Let initial scroll complete
      flushInitialScroll();
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Add outgoing message
      const newMessages = [
        ...messages,
        createMockMessage('2', 'My reply', EMessageDirection.OUTGOING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should auto-scroll for incoming message when user is at bottom', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      // User at bottom: scrollHeight(1000) - scrollTop(500) - clientHeight(500) = 0
      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      const newMessages = [
        ...messages,
        createMockMessage('2', 'New message', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should NOT auto-scroll for incoming message when user has scrolled up', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();

      // Simulate user scrolling up via wheel event
      act(() => {
        viewport.dispatchEvent(
          new WheelEvent('wheel', { deltaY: -100, bubbles: true }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      const newMessages = [
        ...messages,
        createMockMessage('2', 'New incoming', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      // Should NOT auto-scroll because user scrolled up
      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });

    it('should auto-scroll on content change (streaming)', () => {
      const messages = [
        createMockMessage('1', 'Partial', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Simulate streaming: content changes but message count stays the same
      const updatedMessages = [
        createMockMessage(
          '1',
          'Partial content with more tokens',
          EMessageDirection.INCOMING,
        ),
      ];

      act(() => {
        rerender({ messages: updatedMessages });
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should always scroll for outgoing message even when user is scrolled up', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 0, // user scrolled to top
          clientHeight: 500,
        });

      flushInitialScroll();

      // Simulate user scrolling up
      act(() => {
        viewport.dispatchEvent(
          new WheelEvent('wheel', { deltaY: -100, bubbles: true }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Add outgoing message — should ALWAYS scroll
      const newMessages = [
        ...messages,
        createMockMessage('2', 'My reply', EMessageDirection.OUTGOING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should not auto-scroll before initial scroll has completed', () => {
      // Render without messages first (so initial scroll hasn't happened)
      const { viewport, rerender, flushScrollTimers } = setup({
        messages: undefined,
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Add messages without waiting for initial scroll
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages });
      });

      // Don't flush initial scroll — just flush regular scroll timers
      flushScrollTimers();

      // The auto-scroll effect should see hasInitialScrolledRef as false
      // and return early. The initial scroll effect will handle it instead.
      // We can't directly test this internal behavior, but the important thing
      // is that it doesn't crash.
    });
  });

  // --------------------------------------------------------------------------
  // User scroll detection
  // --------------------------------------------------------------------------

  describe('User scroll detection', () => {
    it('should detect scroll-up intent via wheel event (deltaY < 0)', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();

      // Wheel up
      act(() => {
        viewport.dispatchEvent(
          new WheelEvent('wheel', { deltaY: -100, bubbles: true }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // New incoming message should NOT trigger auto-scroll
      const newMessages = [
        ...messages,
        createMockMessage('2', 'Response', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });

    it('should not block auto-scroll on wheel-down (deltaY > 0)', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();

      // Wheel down — does NOT set isUserScrolledUp
      act(() => {
        viewport.dispatchEvent(
          new WheelEvent('wheel', { deltaY: 100, bubbles: true }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      const newMessages = [
        ...messages,
        createMockMessage('2', 'Response', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      // Should still auto-scroll
      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should detect scroll-up via touch events', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();

      // Simulate touch: finger moves down on screen = content scrolls up
      act(() => {
        viewport.dispatchEvent(
          new TouchEvent('touchstart', {
            touches: [{ clientY: 200 } as Touch],
            bubbles: true,
          }),
        );
        viewport.dispatchEvent(
          new TouchEvent('touchmove', {
            touches: [{ clientY: 250 } as Touch], // > 200 + 10
            bubbles: true,
          }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      const newMessages = [
        ...messages,
        createMockMessage('2', 'Response', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      // Should NOT auto-scroll — user is scrolling up via touch
      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });

    it('should cancel pending auto-scroll when user scrolls up', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { result, viewport, flushInitialScroll } = setup({
        messages,
        scrollHeight: 1000,
        scrollTop: 500,
        clientHeight: 500,
      });

      flushInitialScroll();
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Start a scroll that will be throttled (pending)
      act(() => {
        result.scrollToBottom();
      });
      act(() => {
        vi.advanceTimersByTime(20); // first scroll fires
      });
      act(() => {
        result.scrollToBottom(); // this one gets queued
      });

      // User scrolls up — should cancel the pending scroll
      act(() => {
        viewport.dispatchEvent(
          new WheelEvent('wheel', { deltaY: -100, bubbles: true }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Advance past the throttle delay — the cancelled scroll should NOT fire
      act(() => {
        vi.advanceTimersByTime(250);
      });

      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });
  });

  // --------------------------------------------------------------------------
  // handleThinkingComplete
  // --------------------------------------------------------------------------

  describe('handleThinkingComplete', () => {
    it('should create a ResizeObserver when called', () => {
      const { result } = setup({ messages: [] });
      const countBefore = resizeObserverEntries.length;

      act(() => {
        result.handleThinkingComplete();
      });

      expect(resizeObserverEntries.length).toBe(countBefore + 1);
    });

    it('should observe the viewport element', () => {
      const { result, viewport } = setup({ messages: [] });

      act(() => {
        result.handleThinkingComplete();
      });

      const lastEntry = resizeObserverEntries[resizeObserverEntries.length - 1];
      expect(lastEntry.instance.observe).toHaveBeenCalledWith(viewport);
    });

    it('should disconnect previous observer when called again', () => {
      const { result } = setup({ messages: [] });

      act(() => {
        result.handleThinkingComplete();
      });

      const firstEntry =
        resizeObserverEntries[resizeObserverEntries.length - 1];

      act(() => {
        result.handleThinkingComplete();
      });

      expect(firstEntry.instance.disconnect).toHaveBeenCalled();
    });

    it('should scroll to bottom after 2000ms timeout fallback', () => {
      const { result, viewport } = setup({ messages: [] });
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      act(() => {
        result.handleThinkingComplete();
      });

      // Advance past the 2000ms timeout
      act(() => {
        vi.advanceTimersByTime(2100);
      });

      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should scroll when content stabilizes (ResizeObserver fires with stable height)', () => {
      const { result, viewport, setScrollHeight } = setup({ messages: [] });
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      act(() => {
        result.handleThinkingComplete();
      });

      const lastEntry = resizeObserverEntries[resizeObserverEntries.length - 1];

      // Simulate scrollHeight changing then stabilizing
      setScrollHeight(1100);
      act(() => {
        lastEntry.instance.trigger();
      });

      // Now stable (same height)
      act(() => {
        lastEntry.instance.trigger();
      });
      act(() => {
        lastEntry.instance.trigger();
      });

      // Flush the scroll
      act(() => {
        vi.advanceTimersByTime(250);
      });

      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should not throw when viewport is not available', () => {
      const { result } = renderHook(() => useChatScroll({ messages: [] }));

      // No DOM attached — should silently do nothing
      expect(() => {
        act(() => {
          result.current.handleThinkingComplete();
        });
      }).not.toThrow();
    });
  });

  // --------------------------------------------------------------------------
  // Initial scroll
  // --------------------------------------------------------------------------

  describe('Initial scroll', () => {
    it('should scroll to bottom when messages are present on mount', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, flushInitialScroll } = setup({ messages });

      flushInitialScroll();

      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should not scroll when there are no messages', () => {
      const { viewport, flushInitialScroll } = setup({ messages: [] });

      flushInitialScroll();

      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });

    it('should not scroll when messages is undefined', () => {
      const { viewport, flushInitialScroll } = setup({
        messages: undefined,
      });

      flushInitialScroll();

      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });

    it('should use "auto" behavior for initial scroll', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, flushInitialScroll } = setup({ messages });

      flushInitialScroll();

      expect(viewport.scrollTo).toHaveBeenCalledWith(
        expect.objectContaining({ behavior: 'auto' }),
      );
    });

    it('should only run initial scroll once', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll } = setup({ messages });

      flushInitialScroll();
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Rerender with more messages — initial scroll should NOT run again
      const newMessages = [
        ...messages,
        createMockMessage('2', 'World', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });

      // The initial scroll effect should not run again
      // (auto-scroll effect handles subsequent scrolls)
    });
  });

  // --------------------------------------------------------------------------
  // scrollThreshold
  // --------------------------------------------------------------------------

  describe('scrollThreshold', () => {
    it('should use default threshold of 100px', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      // distance from bottom: 1000 - 800 - 100 = 100 → exactly at threshold, NOT scrolled up
      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 800,
          clientHeight: 100,
        });

      flushInitialScroll();

      // Dispatch scroll event to update position check
      act(() => {
        viewport.dispatchEvent(new Event('scroll', { bubbles: true }));
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      const newMessages = [
        ...messages,
        createMockMessage('2', 'New', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      // At exactly 100px with 100px threshold → NOT scrolled up → auto-scroll
      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should respect custom scrollThreshold', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      // distance from bottom: 1000 - 700 - 100 = 200 > custom threshold of 50
      const {
        viewport,
        rerender,
        setScrollTop,
        flushInitialScroll,
        flushScrollTimers,
      } = setup({
        messages,
        scrollThreshold: 50,
        scrollHeight: 1000,
        scrollTop: 700,
        clientHeight: 100,
      });

      flushInitialScroll();

      // Reset scroll position after initial scroll moved it
      setScrollTop(700);

      // Dispatch scroll event to update the internal position check
      act(() => {
        viewport.dispatchEvent(new Event('scroll', { bubbles: true }));
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      const newMessages = [
        ...messages,
        createMockMessage('2', 'New', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      // 200px from bottom > 50px threshold → user IS scrolled up → NO auto-scroll
      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });
  });

  // --------------------------------------------------------------------------
  // User scroll cooldown
  // --------------------------------------------------------------------------

  describe('User scroll cooldown', () => {
    it('should prevent auto-scroll during cooldown after manual scroll up', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();

      // User scrolls up → triggers cooldown
      act(() => {
        viewport.dispatchEvent(
          new WheelEvent('wheel', { deltaY: -100, bubbles: true }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Incoming message within cooldown period
      const newMessages = [
        ...messages,
        createMockMessage('2', 'Quick response', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      // Should NOT auto-scroll during cooldown
      expect(viewport.scrollTo).not.toHaveBeenCalled();
    });

    it('should reset cooldown when user sends an outgoing message', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({
          messages,
          scrollHeight: 1000,
          scrollTop: 500,
          clientHeight: 500,
        });

      flushInitialScroll();

      // User scrolls up
      act(() => {
        viewport.dispatchEvent(
          new WheelEvent('wheel', { deltaY: -100, bubbles: true }),
        );
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // User sends outgoing message — resets cooldown and always scrolls
      const newMessages = [
        ...messages,
        createMockMessage('2', 'My reply', EMessageDirection.OUTGOING),
      ];

      act(() => {
        rerender({ messages: newMessages });
      });
      flushScrollTimers();

      expect(viewport.scrollTo).toHaveBeenCalled();
    });
  });

  // --------------------------------------------------------------------------
  // Cleanup on unmount
  // --------------------------------------------------------------------------

  describe('Cleanup', () => {
    it('should clean up event listeners on unmount', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, unmount } = setup({ messages });
      const removeEventListenerSpy = vi.spyOn(viewport, 'removeEventListener');

      act(() => {
        unmount();
      });

      // Should remove scroll, wheel, touchstart, touchmove listeners
      expect(removeEventListenerSpy).toHaveBeenCalledWith(
        'scroll',
        expect.any(Function),
      );
      expect(removeEventListenerSpy).toHaveBeenCalledWith(
        'wheel',
        expect.any(Function),
      );
      expect(removeEventListenerSpy).toHaveBeenCalledWith(
        'touchstart',
        expect.any(Function),
      );
      expect(removeEventListenerSpy).toHaveBeenCalledWith(
        'touchmove',
        expect.any(Function),
      );
    });

    it('should disconnect ResizeObserver on unmount if thinking was in progress', () => {
      const { result, unmount } = setup({ messages: [] });

      act(() => {
        result.handleThinkingComplete();
      });

      const lastEntry = resizeObserverEntries[resizeObserverEntries.length - 1];

      act(() => {
        unmount();
      });

      expect(lastEntry.instance.disconnect).toHaveBeenCalled();
    });
  });

  // --------------------------------------------------------------------------
  // Function stability
  // --------------------------------------------------------------------------

  describe('Function stability', () => {
    it('should return stable function references across rerenders', () => {
      const { result } = renderHook(() => useChatScroll({ messages: [] }));

      const firstScrollToBottom = result.current.scrollToBottom;
      const firstHandleThinkingComplete = result.current.handleThinkingComplete;

      // Rerender with same props
      act(() => {
        // trigger a rerender (no-op state change)
      });

      expect(result.current.scrollToBottom).toBe(firstScrollToBottom);
      expect(result.current.handleThinkingComplete).toBe(
        firstHandleThinkingComplete,
      );
    });

    it('should maintain stable scrollAreaRef across rerenders', () => {
      const messages1 = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];
      const messages2 = [
        ...messages1,
        createMockMessage('2', 'World', EMessageDirection.INCOMING),
      ];

      let hookResult: IUseChatScrollReturn = null!;

      function Harness(props: IUseChatScrollOptions) {
        const result = useChatScroll(props);
        hookResult = result;
        return React.createElement(
          'div',
          { ref: result.scrollAreaRef },
          React.createElement('div', {
            'data-slot': 'scroll-area-viewport',
          }),
        );
      }

      const { rerender } = render(
        React.createElement(Harness, { messages: messages1 }),
      );

      const firstRef = hookResult.scrollAreaRef;

      rerender(React.createElement(Harness, { messages: messages2 }));

      expect(hookResult.scrollAreaRef).toBe(firstRef);
    });
  });

  // --------------------------------------------------------------------------
  // Edge cases
  // --------------------------------------------------------------------------

  describe('Edge cases', () => {
    it('should handle undefined messages gracefully', () => {
      expect(() => {
        setup({ messages: undefined });
      }).not.toThrow();
    });

    it('should handle empty messages array', () => {
      expect(() => {
        setup({ messages: [] });
      }).not.toThrow();
    });

    it('should handle transition from undefined to messages', () => {
      const { viewport, rerender, flushInitialScroll } = setup({
        messages: undefined,
      });

      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Messages appear
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      act(() => {
        rerender({ messages });
      });

      flushInitialScroll();

      // Initial scroll should fire now that messages appeared
      expect(viewport.scrollTo).toHaveBeenCalled();
    });

    it('should handle transition from messages to empty', () => {
      const messages = [
        createMockMessage('1', 'Hello', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll, flushScrollTimers } =
        setup({ messages });

      flushInitialScroll();
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Clear messages
      act(() => {
        rerender({ messages: [] });
      });
      flushScrollTimers();

      // Should not crash or auto-scroll
    });

    it('should handle rapid streaming updates with throttling', () => {
      const messages = [
        createMockMessage('1', 'T', EMessageDirection.INCOMING),
      ];

      const { viewport, rerender, flushInitialScroll } = setup({
        messages,
        scrollHeight: 1000,
        scrollTop: 500,
        clientHeight: 500,
      });

      flushInitialScroll();
      (viewport.scrollTo as ReturnType<typeof vi.fn>).mockClear();

      // Simulate rapid streaming: 10 content updates in quick succession
      for (let i = 1; i <= 10; i++) {
        const updated = [
          createMockMessage(
            '1',
            'Token '.repeat(i),
            EMessageDirection.INCOMING,
          ),
        ];
        act(() => {
          rerender({ messages: updated });
        });
        act(() => {
          vi.advanceTimersByTime(30); // faster than 150ms throttle
        });
      }

      // Flush remaining
      act(() => {
        vi.advanceTimersByTime(250);
      });

      // scrollTo should have been called, but less than 10 times due to throttling
      const callCount = (viewport.scrollTo as ReturnType<typeof vi.fn>).mock
        .calls.length;
      expect(callCount).toBeGreaterThan(0);
      expect(callCount).toBeLessThan(10);
    });

    it('should handle messages with no content property', () => {
      const messages = [
        {
          id: '1',
          direction: EMessageDirection.INCOMING,
          timestamp: new Date('2024-01-15T14:30:00'),
        } as IChatMessage,
      ];

      expect(() => {
        setup({ messages });
      }).not.toThrow();
    });

    it('should handle multiple messages at once', () => {
      const messages = Array.from({ length: 50 }, (_, i) =>
        createMockMessage(`msg-${i}`, `Message ${i}`),
      );

      const { viewport, flushInitialScroll } = setup({ messages });

      flushInitialScroll();

      expect(viewport.scrollTo).toHaveBeenCalled();
    });
  });
});
