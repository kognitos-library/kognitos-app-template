import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { ChatLoadingSkeleton } from './chat-loading-skeleton';

describe('ChatLoadingSkeleton', () => {
  describe('Rendering', () => {
    it('should render the skeleton container', () => {
      render(<ChatLoadingSkeleton />);

      const container = screen.getByTestId('chat-loading-skeleton');
      expect(container).toBeInTheDocument();
    });

    it('should render six skeleton elements', () => {
      const { container } = render(<ChatLoadingSkeleton />);

      const skeletons = container.querySelectorAll('[data-slot="skeleton"]');
      expect(skeletons).toHaveLength(6);
    });

    it('should have correct data attributes', () => {
      render(<ChatLoadingSkeleton />);

      const container = screen.getByTestId('chat-loading-skeleton');
      expect(container).toHaveAttribute('data-testid', 'chat-loading-skeleton');
    });
  });

  describe('Structure', () => {
    it('should render skeletons with correct width classes', () => {
      const { container } = render(<ChatLoadingSkeleton />);

      const skeletons = container.querySelectorAll('[data-slot="skeleton"]');

      // First skeleton: w-4/7 (right-aligned)
      expect(skeletons[0]).toHaveClass('w-4/7');

      // Second skeleton: w-5/7
      expect(skeletons[1]).toHaveClass('w-5/7');

      // Third skeleton: w-3/7 (right-aligned)
      expect(skeletons[2]).toHaveClass('w-3/7');

      // Fourth skeleton: w-6/7
      expect(skeletons[3]).toHaveClass('w-6/7');

      // Fifth skeleton: w-5/7 (right-aligned)
      expect(skeletons[4]).toHaveClass('w-5/7');

      // Sixth skeleton: w-5/7
      expect(skeletons[5]).toHaveClass('w-5/7');
    });

    it('should render skeletons with correct height classes', () => {
      const { container } = render(<ChatLoadingSkeleton />);

      const skeletons = container.querySelectorAll('[data-slot="skeleton"]');

      // h-8 skeletons
      expect(skeletons[0]).toHaveClass('h-8');
      expect(skeletons[2]).toHaveClass('h-8');
      expect(skeletons[3]).toHaveClass('h-8');
      expect(skeletons[4]).toHaveClass('h-8');

      // h-12 skeletons
      expect(skeletons[1]).toHaveClass('h-12');
      expect(skeletons[5]).toHaveClass('h-12');
    });

    it('should have right-aligned skeletons for user messages', () => {
      const { container } = render(<ChatLoadingSkeleton />);

      const skeletons = container.querySelectorAll('[data-slot="skeleton"]');

      // Right-aligned skeletons (ml-auto)
      expect(skeletons[0]).toHaveClass('ml-auto');
      expect(skeletons[2]).toHaveClass('ml-auto');
      expect(skeletons[4]).toHaveClass('ml-auto');

      // Left-aligned skeletons (no ml-auto)
      expect(skeletons[1]).not.toHaveClass('ml-auto');
      expect(skeletons[3]).not.toHaveClass('ml-auto');
      expect(skeletons[5]).not.toHaveClass('ml-auto');
    });
  });

  describe('Layout', () => {
    it('should render in a flex column layout', () => {
      render(<ChatLoadingSkeleton />);

      const container = screen.getByTestId('chat-loading-skeleton');
      expect(container).toHaveClass('flex');
      expect(container).toHaveClass('flex-col');
    });

    it('should have gap between skeleton elements', () => {
      render(<ChatLoadingSkeleton />);

      const container = screen.getByTestId('chat-loading-skeleton');
      expect(container).toHaveClass('gap-4');
    });

    it('should have full width', () => {
      render(<ChatLoadingSkeleton />);

      const container = screen.getByTestId('chat-loading-skeleton');
      expect(container).toHaveClass('w-full');
    });

    it('should have bottom padding', () => {
      render(<ChatLoadingSkeleton />);

      const container = screen.getByTestId('chat-loading-skeleton');
      expect(container).toHaveClass('pb-4');
    });
  });
});
