import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState, useRef, useCallback } from 'react';
import {
  Chat,
  ChatInput,
  ChatStatus,
  useChat,
  type IChatMessage,
  type IChatAttachment,
  type TMessageDirection,
} from '@/design-system';
import { Flex } from '../../primitives/flex';
import { Button } from '../../primitives/button';
import { Card, CardContent } from '../../primitives/card';
import { Icon } from '../../icons';

const meta: Meta<typeof Chat> = {
  title: 'Design System/Components/Chat',
  component: Chat,
  tags: ['autodocs'],
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A comprehensive chat component system for displaying messages, handling user input, and managing chat state. Includes support for incoming/outgoing messages, attachments, status indicators, and automatic state management.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
  argTypes: {
    messages: {
      control: { type: 'object' },
      description: 'Array of chat messages to display',
    },
    showGradient: {
      control: { type: 'boolean' },
      description: 'Whether to show gradient effect',
    },
    showEmptyState: {
      control: { type: 'boolean' },
      description: 'Whether to show empty state when no messages',
    },
    emptyStateTitle: {
      control: { type: 'text' },
      description: 'Title for empty state',
    },
    emptyStateDescription: {
      control: { type: 'text' },
      description: 'Description for empty state',
    },
    emptyStateIcon: {
      control: { type: 'text' },
      description: 'Icon name for empty state',
    },
    messageVariant: {
      control: { type: 'select' },
      options: ['default', 'inline'],
      description:
        'Default variant for all messages (can be overridden per message)',
    },
    showSender: {
      control: { type: 'boolean' },
      description:
        'Whether to show sender avatars for all messages (can be overridden per message)',
    },
    showTimestamp: {
      control: { type: 'boolean' },
      description:
        'Whether to show timestamps for all messages (can be overridden per message)',
    },
    isLoading: {
      control: { type: 'boolean' },
      description:
        'Loading state. When true and there are no messages, shows skeleton loaders instead of empty state',
    },
  },
  decorators: [
    Story => (
      <Flex align="center" justify="center" className="h-150 w-100">
        <Card className="w-full h-full">
          <CardContent className="h-full">
            <Story />
          </CardContent>
        </Card>
      </Flex>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof Chat>;

/**
 * Interactive chat example with useChat hook and ChatInput.
 * Use the controls panel to adjust Chat props in real-time.
 */
export const Interactive: Story = {
  args: {
    showGradient: false,
    showEmptyState: true,
    emptyStateTitle: 'No messages yet',
    emptyStateDescription:
      'Your Agent is ready to assist — type anything to begin.',
    emptyStateIcon: 'MessagesSquare',
    messageVariant: 'default',
    showSender: true,
    showTimestamp: true,
    isLoading: false,
  },
  render: function InteractiveRender(args) {
    const { messages, addMessage } = useChat();
    const [inputValue, setInputValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);

    const handleSend = (value: string) => {
      if (value.trim().length > 0 || attachments.length > 0) {
        addMessage({
          content: value,
          direction: 'outgoing',
          timestamp: new Date(),
          avatarFallback: 'U',
          attachments: attachments.length > 0 ? attachments : undefined,
        });
        setInputValue('');
        setAttachments([]);

        // Simulate incoming response
        setTimeout(() => {
          addMessage({
            content:
              'Let me understand the situation:\n\n1. **Exception**: "String index 3 out of range for string of length 2"\n2. **Stage**: AUTOMATION_STAGE_PUBLISHED (production mode)\n3. **Failed statement**: `text[3]`\n4. **Input**: The text input is "qw" (length 2)\n5. **What it\'s trying to do**: Extract the 4th character (index 3) from a string\n\n**Analysis (Internal):**\n- The automation is trying to access index 3 (4th character) of a string that only has 2 characters\n- Input text = "qw" (length 2), so valid indices are 0 and 1\n- This is clearly an invalid input - the text is too short for what the automation expects\n- The automation expects text with at least 4 characters\n\n**Stage-aware behavior:**\n- Published stage = production mode\n- I should check for guide entries first\n- Since this is likely a data issue, I should ask the user about the correct value or how to handle short strings\n\n**Resolution approach:**\n1. First, check guide entries (ALWAYS first)\n2. Since the input is invalid (too short), I should ask the user how to handle this\n3. Options: provide longer text, use default value, or handle short strings differently\n\nLet me start by checking for existing guide entries.',
            direction: 'incoming',
            timestamp: new Date(),
            avatarFallback: 'AI',
          });
        }, 1000);
      }
    };

    const handleAddAttachments = (files: File[]) => {
      const newAttachments: IChatAttachment[] = files.map(file => {
        const extension = file.name.split('.').pop()?.toLowerCase() || '';
        let type: IChatAttachment['type'] = 'file';
        if (['pdf'].includes(extension)) type = 'pdf';
        else if (['xls', 'xlsx', 'csv'].includes(extension)) type = 'excel';
        else if (['txt', 'md', 'json'].includes(extension)) type = 'text';
        else if (
          ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension)
        )
          type = 'image';
        return {
          id: `${file.name}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          type,
        };
      });
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    const handleRemoveAttachment = (id: string) => {
      setAttachments(prev => prev.filter(att => att.id !== id));
    };

    return (
      <Chat
        messages={messages}
        showGradient={args.showGradient}
        showEmptyState={args.showEmptyState}
        emptyStateTitle={args.emptyStateTitle}
        emptyStateDescription={args.emptyStateDescription}
        emptyStateIcon={args.emptyStateIcon}
        messageVariant={args.messageVariant}
        showSender={args.showSender}
        showTimestamp={args.showTimestamp}
        isLoading={args.isLoading}
      >
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={handleRemoveAttachment}
          onSend={handleSend}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
  parameters: {
    layout: 'centered',
  },
};

/**
 * Simulates agent streaming behavior. When you send a message,
 * the agent "thinks" briefly, then streams a response token by token
 * with a typing indicator shown during the process.
 */
export const AgentStreaming: Story = {
  render: function AgentStreamingRender() {
    const { messages, addMessage, updateMessage } = useChat();
    const [inputValue, setInputValue] = useState('');
    const [attachments, setAttachments] = useState<IChatAttachment[]>([]);
    const [isStreaming, setIsStreaming] = useState(false);
    const streamIntervalRef = useRef<ReturnType<typeof setInterval> | null>(
      null,
    );

    const streamedResponse =
      `Great question! Let me break this down for you.\n\n` +
      `## Overview\n\n` +
      `Here are the key points to consider:\n\n` +
      `1. **Performance** — Streaming responses provide a better user experience ` +
      `by showing content progressively instead of waiting for the full response.\n` +
      `2. **Responsiveness** — Users get immediate feedback that the system is working.\n` +
      `3. **Perceived speed** — Even though the total time may be similar, ` +
      `streaming feels significantly faster.\n\n` +
      `### Code Example\n\n` +
      '```typescript\n' +
      `async function* streamResponse(prompt: string) {\n` +
      `  const response = await fetch('/api/chat', {\n` +
      `    method: 'POST',\n` +
      `    body: JSON.stringify({ prompt }),\n` +
      `  });\n` +
      `  const reader = response.body?.getReader();\n` +
      `  while (reader) {\n` +
      `    const { done, value } = await reader.read();\n` +
      `    if (done) break;\n` +
      `    yield new TextDecoder().decode(value);\n` +
      `  }\n` +
      `}\n` +
      '```\n\n' +
      `> Streaming is especially useful for long-form responses where ` +
      `the user benefits from reading as content arrives.\n\n` +
      `Let me know if you need more details!`;

    const simulateStreaming = useCallback(
      (messageId: string) => {
        let charIndex = 0;
        setIsStreaming(true);

        streamIntervalRef.current = setInterval(() => {
          // Stream a variable number of characters per tick to feel natural
          const chunkSize = Math.floor(Math.random() * 4) + 2;
          charIndex = Math.min(charIndex + chunkSize, streamedResponse.length);
          const currentContent = streamedResponse.slice(0, charIndex);

          updateMessage(messageId, { content: currentContent });

          if (charIndex >= streamedResponse.length) {
            if (streamIntervalRef.current) {
              clearInterval(streamIntervalRef.current);
              streamIntervalRef.current = null;
            }
            setIsStreaming(false);
          }
        }, 20);
      },
      [updateMessage, streamedResponse],
    );

    const handleSend = (value: string) => {
      if (isStreaming) return;
      if (value.trim().length > 0 || attachments.length > 0) {
        addMessage({
          content: value,
          direction: 'outgoing',
          timestamp: new Date(),
          avatarFallback: 'U',
          attachments: attachments.length > 0 ? attachments : undefined,
        });
        setInputValue('');
        setAttachments([]);

        const responseId = `stream-${Date.now()}`;

        // Brief "thinking" delay, then start streaming
        setTimeout(() => {
          addMessage({
            id: responseId,
            content: '',
            direction: 'incoming',
            timestamp: new Date(),
            avatarFallback: 'AI',
          });

          // Small delay before first token appears
          setTimeout(() => {
            simulateStreaming(responseId);
          }, 300);
        }, 800);
      }
    };

    const handleAddAttachments = (files: File[]) => {
      const newAttachments: IChatAttachment[] = files.map(file => {
        const extension = file.name.split('.').pop()?.toLowerCase() || '';
        let type: IChatAttachment['type'] = 'file';
        if (['pdf'].includes(extension)) type = 'pdf';
        else if (['xls', 'xlsx', 'csv'].includes(extension)) type = 'excel';
        else if (['txt', 'md', 'json'].includes(extension)) type = 'text';
        else if (
          ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(extension)
        )
          type = 'image';
        return {
          id: `${file.name}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: file.name,
          type,
        };
      });
      setAttachments(prev => [...prev, ...newAttachments]);
    };

    const handleRemoveAttachment = (id: string) => {
      setAttachments(prev => prev.filter(att => att.id !== id));
    };

    return (
      <Chat
        messages={messages}
        showEmptyState
        emptyStateTitle="Agent Streaming Demo"
        emptyStateDescription="Send a message to see the agent stream a response token by token."
        emptyStateIcon="MessagesSquare"
        showSender
        showTimestamp={false}
      >
        {/* {isStreaming && (
          <ChatStatus state="default" text="Generating response..." />
        )} */}
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          attachments={attachments}
          onAddAttachments={handleAddAttachments}
          onAttachmentRemove={handleRemoveAttachment}
          onSend={handleSend}
          placeholder="Type a message to see streaming..."
          disabled={isStreaming}
        />
      </Chat>
    );
  },
  parameters: {
    layout: 'centered',
  },
};

// Sample messages for stories
const sampleMessages: IChatMessage[] = [
  {
    id: '1',
    content: 'Hello! How can I help you today?',
    direction: 'incoming',
    timestamp: new Date('2024-01-15T10:00:00'),
    avatarFallback: 'AI',
  },
  {
    id: '2',
    content: 'I need help with setting up my account.',
    direction: 'outgoing',
    timestamp: new Date('2024-01-15T10:01:00'),
    avatarFallback: 'U',
  },
  {
    id: '3',
    content:
      'Sure! I can help you with that. Let me guide you through the process.',
    direction: 'incoming',
    timestamp: new Date('2024-01-15T10:02:00'),
    avatarFallback: 'AI',
  },
];

const messagesWithAttachments: IChatMessage[] = [
  {
    id: '1',
    content: 'I have attached the document you requested.',
    direction: 'incoming',
    timestamp: new Date('2024-01-15T10:00:00'),
    attachments: [
      {
        id: 'att1',
        name: 'document.pdf',
        type: 'pdf',
      },
      {
        id: 'att2',
        name: 'data.xlsx',
        type: 'excel',
      },
    ],
  },
  {
    id: '2',
    content: 'Thank you! Here is my response.',
    direction: 'outgoing',
    timestamp: new Date('2024-01-15T10:01:00'),
    attachments: [
      {
        id: 'att3',
        name: 'response.txt',
        type: 'text',
      },
    ],
  },
];

/**
 * Empty state when there are no messages.
 * Uses default title, description, and icon (all props are optional).
 */
export const Empty: Story = {
  render: function EmptyRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={[]} showEmptyState>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Loading state when initial messages are being fetched.
 * Shows skeleton loaders instead of empty state when isLoading is true.
 * ChatInput is disabled during loading.
 */
export const Loading: Story = {
  render: function LoadingRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={[]} isLoading>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
          isLoading
          disabled
        />
      </Chat>
    );
  },
};

/**
 * Basic chat with incoming and outgoing messages.
 */
export const Basic: Story = {
  render: function BasicRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={sampleMessages} showEmptyState>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with messages that have attachments.
 */
export const WithAttachments: Story = {
  render: function WithAttachmentsRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={messagesWithAttachments}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with status update indicator (thinking, error, warning).
 */
export const WithStatusUpdate: Story = {
  render: function WithStatusUpdateRender() {
    const messagesWithoutSenderAndTimestamp: IChatMessage[] = [
      {
        id: '1',
        content: 'Hello! How can I help you today?',
        direction: 'incoming',
      },
      {
        id: '2',
        content: 'I need help with setting up my account.',
        direction: 'outgoing',
      },
      {
        id: '3',
        content:
          'Sure! I can help you with that. Let me guide you through the process.',
        direction: 'incoming',
      },
    ];

    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={messagesWithoutSenderAndTimestamp}>
        <ChatStatus state="default" text="Neurosymbolizing..." />
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with error status update.
 */
export const WithErrorStatus: Story = {
  render: function WithErrorStatusRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={sampleMessages}>
        <ChatStatus state="error" text="Failed to send message" showIcon />
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with warning status update.
 */
export const WithWarningStatus: Story = {
  render: function WithWarningStatusRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={sampleMessages}>
        <ChatStatus state="warning" text="Message delivery may be delayed" />
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with custom empty state configuration.
 */
export const CustomEmptyState: Story = {
  render: function CustomEmptyStateRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat
        messages={[]}
        emptyStateTitle="Start a Conversation"
        emptyStateDescription="Click the input below to begin chatting with your assistant."
        emptyStateIcon="MessageCircle"
      >
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat without empty state (shows nothing when empty).
 */
export const WithoutEmptyState: Story = {
  render: function WithoutEmptyStateRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={[]} showEmptyState={false}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with programmatic message management.
 */
export const WithProgrammaticControl: Story = {
  render: function ProgrammaticRender() {
    const { messages, addMessage, clearMessages } = useChat([
      {
        id: '1',
        content: 'Initial message',
        direction: 'incoming',
        timestamp: new Date(),
      },
    ]);

    const [inputValue, setInputValue] = useState('');

    return (
      <Flex direction="column" gap={4} className="h-full">
        <Flex gap={2}>
          <Button
            size="sm"
            onClick={() =>
              addMessage({
                content: `New message ${messages.length + 1}`,
                direction: 'outgoing',
                timestamp: new Date(),
              })
            }
          >
            Add Message
          </Button>
          <Button size="sm" variant="outline" onClick={clearMessages}>
            Clear All
          </Button>
        </Flex>
        <Chat messages={messages} className="flex-1">
          <ChatInput
            value={inputValue}
            onChange={e => setInputValue(e.target.value)}
            onSend={() => setInputValue('')}
            placeholder="Type your message..."
          />
        </Chat>
      </Flex>
    );
  },
};

/**
 * Chat with long messages to test text wrapping.
 */
export const LongMessages: Story = {
  render: function LongMessagesRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat
        messages={[
          {
            id: '1',
            content:
              'This is a very long incoming message that should wrap properly within the chat bubble. It contains multiple sentences and should demonstrate how the component handles text overflow and wrapping in different scenarios.',
            direction: 'incoming',
            timestamp: new Date('2024-01-15T10:00:00'),
            avatarFallback: 'AI',
          },
          {
            id: '2',
            content:
              'This is a very long outgoing message that should wrap properly within the chat bubble. It contains multiple sentences and should demonstrate how the component handles text overflow and wrapping in different scenarios.',
            direction: 'outgoing',
            timestamp: new Date('2024-01-15T10:01:00'),
            avatarFallback: 'U',
          },
        ]}
      >
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with many messages to test scrolling.
 */
export const ManyMessages: Story = {
  render: function ManyMessagesRender() {
    const [inputValue, setInputValue] = useState('');
    const messages: IChatMessage[] = Array.from({ length: 20 }, (_, i) => {
      const direction: TMessageDirection =
        i % 2 === 0 ? 'incoming' : 'outgoing';
      return {
        id: `msg-${i}`,
        content: `Message ${i + 1}`,
        direction,
        timestamp: new Date(`2024-01-15T10:${String(i).padStart(2, '0')}:00`),
        avatarFallback: i % 2 === 0 ? 'AI' : 'U',
      };
    });

    return (
      <Chat messages={messages}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Comprehensive showcase of all chat features including:
 * - Incoming and outgoing messages
 * - Attachments (text, excel, pdf, image, file)
 * - Button group widgets
 * - Action card widgets
 * - Custom widgets
 * - Message statuses
 * - Timestamps and avatars
 * - Inline and default variants
 */
export const AllFeatures: Story = {
  render: function AllFeaturesRender() {
    const [inputValue, setInputValue] = useState('');

    const messages: IChatMessage[] = [
      // Basic incoming message
      {
        id: 'msg-1',
        content:
          'Hello! I can help you with various tasks. Here are some examples:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:00:00'),
        avatarFallback: 'AI',
        status: 'delivered',
      },
      // Message with button group widget
      {
        id: 'msg-2',
        content: 'Would you like to proceed?',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:01:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        widget: {
          type: 'button-group',
          buttons: [
            {
              id: 'btn-yes',
              label: 'Yes, please',
              variant: 'default',
              onClick: () => console.log('Yes clicked'),
            },
            {
              id: 'btn-no',
              label: 'No, thanks',
              variant: 'outline',
              onClick: () => console.log('No clicked'),
            },
          ],
        },
      },
      // Message with action cards widget
      {
        id: 'msg-3',
        content: 'Here are some apps you can manage:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:02:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        widget: {
          type: 'action-cards',
          actionCards: [
            {
              id: 'card-1',
              title: 'Slack',
              description: 'Work Admin v1.1',
              imageUrl: 'https://api.dicebear.com/7.x/avataaars/svg?seed=slack',
              fallbackIcon: <Icon type="MessageSquare" className="size-4" />,
              actionProps: {
                label: 'Manage',
                variant: 'outline',
                size: 'sm',
                onClick: () => console.log('Slack clicked'),
              },
            },
            {
              id: 'card-2',
              title: 'GitHub',
              description: 'Repository Manager',
              imageUrl:
                'https://api.dicebear.com/7.x/avataaars/svg?seed=github',
              fallbackIcon: <Icon type="Github" className="size-4" />,
              actionProps: {
                label: 'Manage',
                variant: 'outline',
                size: 'sm',
                onClick: () => console.log('GitHub clicked'),
              },
            },
            {
              id: 'card-3',
              title: 'Notion',
              description: 'Workspace v2.0',
              imageUrl:
                'https://api.dicebear.com/7.x/avataaars/svg?seed=notion',
              fallbackIcon: <Icon type="FileText" className="size-4" />,
              actionProps: {
                label: 'Manage',
                variant: 'outline',
                size: 'sm',
                onClick: () => console.log('Notion clicked'),
              },
            },
          ],
        },
      },
      // Outgoing message with attachments
      {
        id: 'msg-4',
        content: 'I uploaded some files for you to review:',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:03:00'),
        avatarFallback: 'U',
        status: 'sent',
        attachments: [
          {
            id: 'att-1',
            name: 'document.pdf',
            type: 'pdf',
            size: 2457600,
          },
          {
            id: 'att-2',
            name: 'spreadsheet.xlsx',
            type: 'excel',
            size: 1024000,
          },
          {
            id: 'att-3',
            name: 'image.png',
            type: 'image',
            size: 512000,
          },
        ],
      },
      // Message with text attachment
      {
        id: 'msg-5',
        content: 'Here is a text file:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:04:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        attachments: [
          {
            id: 'att-4',
            name: 'notes.txt',
            type: 'text',
            size: 8192,
          },
        ],
      },
      // Message with file attachment
      {
        id: 'msg-6',
        content: 'Here is a generic file:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:05:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        attachments: [
          {
            id: 'att-5',
            name: 'archive.zip',
            type: 'file',
            size: 5242880,
          },
        ],
      },
      // Message with custom widget
      {
        id: 'msg-7',
        content: 'Here is a custom widget:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:06:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        widget: {
          type: 'custom',
          customContent: (
            <div className="p-4 bg-muted rounded-md border">
              <p className="text-sm font-medium mb-2">Custom Content</p>
              <p className="text-sm text-muted-foreground">
                This is a custom widget with any React content you want.
              </p>
            </div>
          ),
        },
      },
      // Message with multiple action cards and button group
      {
        id: 'msg-8',
        content: 'Choose an action:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:07:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        widget: {
          type: 'action-cards',
          actionCards: [
            {
              id: 'card-4',
              title: 'Dashboard',
              description: 'View analytics',
              fallbackIcon: <Icon type="BarChart" className="size-4" />,
              actionProps: {
                label: 'Open',
                variant: 'outline',
                size: 'sm',
                onClick: () => console.log('Dashboard clicked'),
              },
            },
            {
              id: 'card-5',
              title: 'Settings',
              description: 'Configure preferences',
              fallbackIcon: <Icon type="Settings" className="size-4" />,
              actionProps: {
                label: 'View',
                variant: 'outline',
                size: 'sm',
                onClick: () => console.log('Settings clicked'),
              },
            },
          ],
        },
      },
      // Outgoing message with sending status
      {
        id: 'msg-9',
        content: 'This message is being sent...',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:08:00'),
        avatarFallback: 'U',
        status: 'sending',
      },
      // Message with error status
      {
        id: 'msg-10',
        content: 'This message failed to send',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:09:00'),
        avatarFallback: 'U',
        status: 'error',
      },
      // Message with button group (multiple options)
      {
        id: 'msg-12',
        content: 'Select an option:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:11:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        widget: {
          type: 'button-group',
          buttons: [
            {
              id: 'btn-1',
              label: 'Option 1',
              variant: 'default',
              onClick: () => console.log('Option 1 clicked'),
            },
            {
              id: 'btn-2',
              label: 'Option 2',
              variant: 'outline',
              onClick: () => console.log('Option 2 clicked'),
            },
            {
              id: 'btn-3',
              label: 'Option 3',
              variant: 'secondary',
              onClick: () => console.log('Option 3 clicked'),
            },
            {
              id: 'btn-4',
              label: 'Delete',
              variant: 'destructive',
              onClick: () => console.log('Delete clicked'),
            },
          ],
        },
      },
      // Message with action card (icon only, no image)
      {
        id: 'msg-13',
        content: 'Quick actions:',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:12:00'),
        avatarFallback: 'AI',
        status: 'delivered',
        widget: {
          type: 'action-cards',
          actionCards: [
            {
              id: 'card-6',
              title: 'Users',
              description: 'Manage team members',
              fallbackIcon: <Icon type="Users" className="size-4" />,
              actionProps: {
                label: 'Manage',
                variant: 'outline',
                size: 'sm',
                onClick: () => console.log('Users clicked'),
              },
            },
          ],
        },
      },
    ];

    return (
      <Chat messages={messages}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with sender avatars hidden at Chat level.
 * All messages will not show avatars unless explicitly overridden per message.
 */
export const WithoutSender: Story = {
  render: function WithoutSenderRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={sampleMessages} showSender={false}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with timestamps hidden at Chat level.
 * All messages will not show timestamps unless explicitly overridden per message.
 */
export const WithoutTimestamp: Story = {
  render: function WithoutTimestampRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={sampleMessages} showTimestamp={false}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with inline variant configured at Chat level.
 * All messages will use inline variant unless explicitly overridden per message.
 */
export const InlineVariant: Story = {
  render: function InlineVariantRender() {
    const [inputValue, setInputValue] = useState('');

    return (
      <Chat messages={sampleMessages} messageVariant="inline">
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with thinking messages showing AI reasoning process.
 * Demonstrates how thinking messages are grouped and displayed in a collapsible format.
 * - Streaming state: Shows shimmering "Neurosymbolizing..." text
 * - Complete state: Shows "Neurosymbolized for Xs" with duration
 * - Includes both plain-text and code/automation thinking content
 */
export const WithThinkingMessages: Story = {
  render: function WithThinkingMessagesRender() {
    const [inputValue, setInputValue] = useState('');

    const messagesWithThinking: IChatMessage[] = [
      {
        id: '1',
        content: 'Can you help me analyze this data?',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:00:00'),
        avatarFallback: 'U',
      },
      // Thinking messages - these are grouped and displayed in a collapsible box
      {
        id: 'think-1',
        content:
          'Analyzing the user request and identifying key requirements...',
        direction: 'incoming',
        type: 'thinking',
        timestamp: new Date('2024-01-15T10:00:05'),
      },
      {
        id: 'think-2',
        content: 'Searching through relevant data sources and documentation...',
        direction: 'incoming',
        type: 'thinking',
        timestamp: new Date('2024-01-15T10:00:08'),
      },
      {
        id: 'think-3',
        content:
          'Formulating the most appropriate response based on findings...',
        direction: 'incoming',
        type: 'thinking',
        timestamp: new Date('2024-01-15T10:00:12'),
      },
      // Complete message signals end of thinking (renders nothing but triggers completion)
      {
        id: 'complete-1',
        content: '',
        direction: 'incoming',
        type: 'complete',
        timestamp: new Date('2024-01-15T10:00:15'),
      },
      // Regular response after thinking
      {
        id: '2',
        content:
          "Based on my analysis, I found several key insights in your data. Here's what I discovered:\n\n1. **Trend Analysis**: The data shows a 15% increase over the past quarter\n2. **Key Metrics**: Revenue is up, but costs have also increased\n3. **Recommendations**: Consider optimizing the supply chain process",
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:00:16'),
        avatarFallback: 'AI',
      },
      // Second exchange — thinking with code/automation content
      {
        id: '3',
        content:
          'Can you create an automation that extracts the 4th character from a string?',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:01:00'),
        avatarFallback: 'U',
      },
      {
        id: 'think-code-1',
        content: `The user confirmed they want to save this as an automation. I need to use \`create_automation\` since the automation is currently empty.

I need to:
1. Add proper SOP comments with \`# @step\`, \`# @vars:\`, and \`#:\` detail lines
2. Provide a clear title and overview
3. The code reads the string input and gets the 4th character (index 3)

Let me write this with proper SOP formatting:

\`\`\`spy
# @step Extract 4th character from string
# @vars: input string=input_string, fourth character=fourth_char
#: Read the input string
input_string = read_input("This_is_very_long_input_name_that_can_cause_overflow_issues", type=str)
#: Get the character at position 4 (index 3)
fourth_char = input_string[3]

set_output("fourth_character", value=fourth_char)
\`\`\`

Title: "Get 4th Character"
Overview: "Extracts the 4th character from a string."`,
        direction: 'incoming',
        type: 'thinking',
        timestamp: new Date('2024-01-15T10:01:02'),
      },
      {
        id: 'complete-2',
        content: '',
        direction: 'incoming',
        type: 'complete',
        timestamp: new Date('2024-01-15T10:01:10'),
      },
      {
        id: '4',
        content:
          'I\'ve created the automation **"Get 4th Character"** for you. It reads a string input and extracts the character at position 4 (index 3). The automation includes proper SOP comments and formatting.',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:01:11'),
        avatarFallback: 'AI',
      },
    ];

    return (
      <Chat messages={messagesWithThinking}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};

/**
 * Chat with thinking messages in streaming state (not yet complete).
 * Shows the shimmering text animation indicating active processing.
 */
export const WithThinkingStreaming: Story = {
  render: function WithThinkingStreamingRender() {
    const [inputValue, setInputValue] = useState('');

    const messagesWithStreamingThinking: IChatMessage[] = [
      {
        id: '1',
        content: 'What are the best practices for API design?',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:00:00'),
        avatarFallback: 'U',
      },
      // Thinking messages without a 'complete' message - shows streaming state
      {
        id: 'think-1',
        content: 'Processing query about API design best practices...',
        direction: 'incoming',
        type: 'thinking',
        timestamp: new Date('2024-01-15T10:00:02'),
      },
      {
        id: 'think-2',
        content: 'Reviewing REST, GraphQL, and gRPC patterns...',
        direction: 'incoming',
        type: 'thinking',
        timestamp: new Date('2024-01-15T10:00:05'),
      },
      {
        id: 'think-3',
        content: 'Gathering recommendations from industry standards...',
        direction: 'incoming',
        type: 'thinking',
        timestamp: new Date('2024-01-15T10:00:08'),
      },
      // No 'complete' message = streaming state (shimmering animation)
    ];

    return (
      <Chat messages={messagesWithStreamingThinking}>
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
          disabled
        />
      </Chat>
    );
  },
};

/**
 * Chat with message-level overrides.
 * Chat-level config hides sender and timestamp, but some messages override to show them.
 */
export const WithMessageOverrides: Story = {
  render: function WithMessageOverridesRender() {
    const [inputValue, setInputValue] = useState('');

    const messagesWithOverrides: IChatMessage[] = [
      {
        id: '1',
        content:
          'This message hides sender and timestamp (uses Chat-level config)',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:00:00'),
        avatarFallback: 'AI',
      },
      {
        id: '2',
        content:
          'This message shows sender and timestamp (overrides Chat-level config)',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:01:00'),
        avatarFallback: 'U',
        showSender: true, // Override Chat-level config
        showTimestamp: true, // Override Chat-level config
      },
      {
        id: '3',
        content:
          'This message only shows sender (overrides to show sender, hides timestamp)',
        direction: 'incoming',
        timestamp: new Date('2024-01-15T10:02:00'),
        avatarFallback: 'AI',
        showSender: true, // Override Chat-level config
        showTimestamp: false, // Override Chat-level config
      },
      {
        id: '4',
        content:
          'This message only shows timestamp (hides sender, shows timestamp)',
        direction: 'outgoing',
        timestamp: new Date('2024-01-15T10:03:00'),
        avatarFallback: 'U',
        showSender: false, // Override Chat-level config
        showTimestamp: true, // Override Chat-level config
      },
    ];

    return (
      <Chat
        messages={messagesWithOverrides}
        showSender={false}
        showTimestamp={false}
      >
        <ChatInput
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
          onSend={() => setInputValue('')}
          placeholder="Type your message..."
        />
      </Chat>
    );
  },
};
