import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChatInput } from './chat-input';
import { ChatContext } from './chat';
import { EAttachmentType, type IChatAttachment } from './types';

describe('ChatInput', () => {
  const defaultProps = {
    value: '',
    onChange: vi.fn(),
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Rendering', () => {
    it('should render textarea input', () => {
      const { container } = render(<ChatInput {...defaultProps} />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toBeInTheDocument();
      // data-slot="chat-input" is on the wrapper div, not the textarea
      const chatInput = container.querySelector('[data-slot="chat-input"]');
      expect(chatInput).toBeInTheDocument();
    });

    it('should render with correct data-slot attribute', () => {
      const { container } = render(<ChatInput {...defaultProps} />);

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      expect(chatInput).toBeInTheDocument();
    });

    it('should render with placeholder', () => {
      render(<ChatInput {...defaultProps} placeholder="Type your message" />);

      const textarea = screen.getByPlaceholderText('Type your message');
      expect(textarea).toBeInTheDocument();
    });

    it('should render with default placeholder when not provided', () => {
      render(<ChatInput {...defaultProps} />);

      const textarea = screen.getByPlaceholderText('Type here');
      expect(textarea).toBeInTheDocument();
    });

    it('should render with value', () => {
      render(<ChatInput {...defaultProps} value="Hello World" />);

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      expect(textarea.value).toBe('Hello World');
    });
  });

  describe('Input Handling', () => {
    it('should call onChange when text is typed', async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<ChatInput value="" onChange={onChange} />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, 'Hello');

      expect(onChange).toHaveBeenCalled();
    });

    it('should update value when controlled', () => {
      const { rerender } = render(
        <ChatInput value="Hello" onChange={vi.fn()} />,
      );

      let textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      expect(textarea.value).toBe('Hello');

      rerender(<ChatInput value="Hello World" onChange={vi.fn()} />);

      textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      expect(textarea.value).toBe('Hello World');
    });

    it('should work in uncontrolled mode', async () => {
      const user = userEvent.setup();
      render(<ChatInput />);

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      expect(textarea.value).toBe('');

      // Component uses empty string as default value when uncontrolled
      // The textarea should still be functional
      await user.type(textarea, 'Hello');
      // Note: Since value prop is always set (even to empty string),
      // the component is technically controlled with empty string default
      expect(textarea).toBeInTheDocument();
    });

    it('should handle onChange when not provided', async () => {
      const user = userEvent.setup();
      render(<ChatInput value="test" />);

      const textarea = screen.getByRole('textbox');
      // Should not crash when typing without onChange
      await user.type(textarea, 'Hello');
    });

    it('should allow typing but disable send when disabled prop is true', () => {
      render(<ChatInput {...defaultProps} disabled />);

      const textarea = screen.getByRole('textbox');
      const sendButton = screen.getByTestId('chat-input-send-button');

      expect(textarea).not.toBeDisabled();
      expect(sendButton).toBeDisabled();
    });

    it('should allow typing but hide send button when isLoading is true', () => {
      render(<ChatInput {...defaultProps} isLoading />);

      const textarea = screen.getByRole('textbox');
      const sendButton = screen.queryByTestId('chat-input-send-button');

      expect(textarea).not.toBeDisabled();
      expect(sendButton).not.toBeInTheDocument();
    });
  });

  describe('Send Functionality', () => {
    it('should call onSend when Enter is pressed', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(<ChatInput value="Hello" onChange={vi.fn()} onSend={onSend} />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).toHaveBeenCalledWith('Hello');
    });

    it('should not call onSend when Shift+Enter is pressed', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(<ChatInput value="Hello" onChange={vi.fn()} onSend={onSend} />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Shift>}{Enter}{/Shift}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should not call onSend when Enter is pressed and input is empty', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(<ChatInput value="" onChange={vi.fn()} onSend={onSend} />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should not call onSend when Enter is pressed and input is only whitespace', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(<ChatInput value="   " onChange={vi.fn()} onSend={onSend} />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should call onSend when send button is clicked', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(<ChatInput value="Hello" onChange={vi.fn()} onSend={onSend} />);

      const sendButton = screen.getByLabelText('Send message');
      await user.click(sendButton);

      expect(onSend).toHaveBeenCalledWith('Hello');
    });

    it('should not call onSend when send button is clicked and input is empty', () => {
      const onSend = vi.fn();
      render(<ChatInput value="" onChange={vi.fn()} onSend={onSend} />);

      const sendButton = screen.getByLabelText('Send message');
      expect(sendButton).toBeDisabled();
    });

    it('should call onSend when input has attachments even if text is empty', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      const attachments: IChatAttachment[] = [
        {
          id: 'att1',
          name: 'document.pdf',
          type: EAttachmentType.PDF,
        },
      ];

      render(
        <ChatInput
          value=""
          onChange={vi.fn()}
          onSend={onSend}
          attachments={attachments}
        />,
      );

      const sendButton = screen.getByLabelText('Send message');
      await user.click(sendButton);

      expect(onSend).toHaveBeenCalledWith('');
    });

    it('should not call onSend when Enter is pressed and isLoading is true', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(
        <ChatInput
          value="Hello"
          onChange={vi.fn()}
          onSend={onSend}
          isLoading
        />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should not call onSend when Enter is pressed and disabled is true', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(
        <ChatInput value="Hello" onChange={vi.fn()} onSend={onSend} disabled />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should not call onSend when Enter is pressed and onSend is not provided', async () => {
      const user = userEvent.setup();
      render(<ChatInput value="Hello" onChange={vi.fn()} />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      // Should not crash, just not call onSend
      expect(textarea).toBeInTheDocument();
    });

    it('should not call onSend when send button is clicked and onSend is not provided', async () => {
      const user = userEvent.setup();
      render(<ChatInput value="Hello" onChange={vi.fn()} showSendButton />);

      const sendButton = screen.getByLabelText('Send message');
      await user.click(sendButton);

      // Should not crash, just not call onSend
      expect(sendButton).toBeInTheDocument();
    });
  });

  describe('Stop Functionality', () => {
    it('should render stop button when isLoading is true and loadingMode is stop', () => {
      render(
        <ChatInput
          {...defaultProps}
          isLoading
          loadingMode="stop"
          onStop={vi.fn()}
        />,
      );

      const stopButton = screen.getByLabelText('Stop');
      expect(stopButton).toBeInTheDocument();
    });

    it('should call onStop when stop button is clicked', async () => {
      const user = userEvent.setup();
      const onStop = vi.fn();
      render(
        <ChatInput
          {...defaultProps}
          isLoading
          loadingMode="stop"
          onStop={onStop}
        />,
      );

      const stopButton = screen.getByLabelText('Stop');
      await user.click(stopButton);

      expect(onStop).toHaveBeenCalled();
    });

    it('should not render stop button when loadingMode is loader', () => {
      render(<ChatInput {...defaultProps} isLoading loadingMode="loader" />);

      const stopButton = screen.queryByLabelText('Stop');
      expect(stopButton).not.toBeInTheDocument();
    });

    it('should render spinner when isLoading is true and loadingMode is loader', () => {
      const { container } = render(
        <ChatInput {...defaultProps} isLoading loadingMode="loader" />,
      );

      const spinner = container.querySelector('[data-slot="spinner"]');
      expect(spinner).toBeInTheDocument();
    });
  });

  describe('Attachments', () => {
    const mockAttachments: IChatAttachment[] = [
      {
        id: 'att1',
        name: 'document.pdf',
        type: EAttachmentType.PDF,
      },
      {
        id: 'att2',
        name: 'image.jpg',
        type: EAttachmentType.IMAGE,
      },
    ];

    it('should render attachments when provided', () => {
      render(<ChatInput {...defaultProps} attachments={mockAttachments} />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
      expect(screen.getByText('image.jpg')).toBeInTheDocument();
    });

    it('should not render attachments section when no attachments', () => {
      render(<ChatInput {...defaultProps} attachments={[]} />);

      expect(screen.queryByText('document.pdf')).not.toBeInTheDocument();
    });

    it('should call onAttachmentRemove when attachment remove button is clicked', async () => {
      const user = userEvent.setup();
      const onAttachmentRemove = vi.fn();
      render(
        <ChatInput
          {...defaultProps}
          attachments={mockAttachments}
          onAttachmentRemove={onAttachmentRemove}
        />,
      );

      const removeButtons = screen.getAllByLabelText('Remove attachment');
      await user.click(removeButtons[0]);

      expect(onAttachmentRemove).toHaveBeenCalledWith('att1');
    });

    it('should open file input when attachment button is clicked', async () => {
      const user = userEvent.setup();
      const onAddAttachments = vi.fn();
      render(
        <ChatInput {...defaultProps} onAddAttachments={onAddAttachments} />,
      );

      const attachmentButton = screen.getByLabelText('Add attachment');
      await user.click(attachmentButton);

      // The file input should be triggered (we can't easily test file dialog opening,
      // but we can verify the button click doesn't crash)
      expect(attachmentButton).toBeInTheDocument();
    });

    it('should handle attachment button click when onAddAttachments not provided', async () => {
      const user = userEvent.setup();
      render(<ChatInput {...defaultProps} />);

      const attachmentButton = screen.getByLabelText('Add attachment');
      // Should not crash when clicking without onAddAttachments
      await user.click(attachmentButton);
      expect(attachmentButton).toBeInTheDocument();
    });

    it('should handle onAttachmentRemove when not provided', async () => {
      const user = userEvent.setup();
      render(<ChatInput {...defaultProps} attachments={mockAttachments} />);

      const removeButtons = screen.getAllByLabelText('Remove attachment');
      // Should not crash when clicking without onAttachmentRemove
      await user.click(removeButtons[0]);
      expect(removeButtons[0]).toBeInTheDocument();
    });

    it('should not render attachment button when showAttachmentButton is false', () => {
      render(<ChatInput {...defaultProps} showAttachmentButton={false} />);

      const attachmentButton = screen.queryByLabelText('Add attachment');
      expect(attachmentButton).not.toBeInTheDocument();
    });

    it('should allow sending with attachments even when text is empty', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(
        <ChatInput
          value=""
          onChange={vi.fn()}
          onSend={onSend}
          attachments={mockAttachments}
        />,
      );

      const sendButton = screen.getByLabelText('Send message');
      await user.click(sendButton);

      expect(onSend).toHaveBeenCalledWith('');
    });

    it('should focus textarea after adding attachments via file input', async () => {
      const onAddAttachments = vi.fn();
      const { container } = render(
        <ChatInput {...defaultProps} onAddAttachments={onAddAttachments} />,
      );

      const fileInput = container.querySelector(
        'input[type="file"]',
      ) as HTMLInputElement;
      const textarea = screen.getByRole('textbox');

      // Simulate file selection
      const file = new File(['test content'], 'test.pdf', {
        type: 'application/pdf',
      });

      // Create a change event with files
      Object.defineProperty(fileInput, 'files', {
        value: [file],
        writable: false,
      });

      // Trigger the change event
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));

      // Textarea should be focused after file selection
      expect(textarea).toHaveFocus();
    });

    it('should focus textarea after adding attachments in inline variant', async () => {
      const onAddAttachments = vi.fn();
      const { container } = render(
        <ChatInput
          {...defaultProps}
          variant="inline"
          onAddAttachments={onAddAttachments}
        />,
      );

      const fileInput = container.querySelector(
        'input[type="file"]',
      ) as HTMLInputElement;
      const textarea = screen.getByRole('textbox');

      // Simulate file selection
      const file = new File(['test content'], 'test.pdf', {
        type: 'application/pdf',
      });

      // Create a change event with files
      Object.defineProperty(fileInput, 'files', {
        value: [file],
        writable: false,
      });

      // Trigger the change event
      fileInput.dispatchEvent(new Event('change', { bubbles: true }));

      // Textarea should be focused after file selection
      expect(textarea).toHaveFocus();
    });
  });

  describe('Clipboard File Paste', () => {
    it('should call onAddAttachments when files are pasted and allowFilePaste is true', async () => {
      const onAddAttachments = vi.fn();
      render(
        <ChatInput
          {...defaultProps}
          allowFilePaste
          onAddAttachments={onAddAttachments}
        />,
      );

      const textarea = screen.getByRole('textbox');
      const file = new File(['test content'], 'test.pdf', {
        type: 'application/pdf',
      });

      // Create a paste event with files
      const pasteEvent = new Event('paste', { bubbles: true });
      Object.defineProperty(pasteEvent, 'clipboardData', {
        value: {
          files: [file],
        },
      });

      textarea.dispatchEvent(pasteEvent);

      expect(onAddAttachments).toHaveBeenCalledWith([file]);
    });

    it('should not call onAddAttachments when allowFilePaste is false', async () => {
      const onAddAttachments = vi.fn();
      render(
        <ChatInput
          {...defaultProps}
          allowFilePaste={false}
          onAddAttachments={onAddAttachments}
        />,
      );

      const textarea = screen.getByRole('textbox');
      const file = new File(['test content'], 'test.pdf', {
        type: 'application/pdf',
      });

      // Create a paste event with files
      const pasteEvent = new Event('paste', { bubbles: true });
      Object.defineProperty(pasteEvent, 'clipboardData', {
        value: {
          files: [file],
        },
      });

      textarea.dispatchEvent(pasteEvent);

      expect(onAddAttachments).not.toHaveBeenCalled();
    });

    it('should call user onPaste handler when no files are pasted', async () => {
      const onPaste = vi.fn();
      const onAddAttachments = vi.fn();
      render(
        <ChatInput
          {...defaultProps}
          allowFilePaste
          onAddAttachments={onAddAttachments}
          onPaste={onPaste}
        />,
      );

      const textarea = screen.getByRole('textbox');

      // Create a paste event without files (empty FileList)
      const pasteEvent = new Event('paste', { bubbles: true });
      Object.defineProperty(pasteEvent, 'clipboardData', {
        value: {
          files: [],
        },
      });

      textarea.dispatchEvent(pasteEvent);

      expect(onAddAttachments).not.toHaveBeenCalled();
      expect(onPaste).toHaveBeenCalled();
    });
  });

  describe('Button Visibility', () => {
    it('should render send button by default', () => {
      render(<ChatInput {...defaultProps} onSend={vi.fn()} />);

      const sendButton = screen.getByLabelText('Send message');
      expect(sendButton).toBeInTheDocument();
    });

    it('should not render send button when showSendButton is false', () => {
      render(
        <ChatInput {...defaultProps} showSendButton={false} onSend={vi.fn()} />,
      );

      const sendButton = screen.queryByLabelText('Send message');
      expect(sendButton).not.toBeInTheDocument();
    });

    it('should render attachment button by default', () => {
      render(<ChatInput {...defaultProps} />);

      const attachmentButton = screen.getByLabelText('Add attachment');
      expect(attachmentButton).toBeInTheDocument();
    });

    it('should not render attachment button when showAttachmentButton is false', () => {
      render(<ChatInput {...defaultProps} showAttachmentButton={false} />);

      const attachmentButton = screen.queryByLabelText('Add attachment');
      expect(attachmentButton).not.toBeInTheDocument();
    });

    it('should allow attachment button when disabled', () => {
      render(<ChatInput {...defaultProps} disabled />);

      const attachmentButton = screen.getByLabelText('Add attachment');
      expect(attachmentButton).not.toBeDisabled();
    });

    it('should allow attachment button when isLoading is true', () => {
      render(<ChatInput {...defaultProps} isLoading />);

      const attachmentButton = screen.getByLabelText('Add attachment');
      expect(attachmentButton).not.toBeDisabled();
    });

    it('should not render button container when all buttons are hidden', () => {
      const { container } = render(
        <ChatInput
          {...defaultProps}
          showAttachmentButton={false}
          showSendButton={false}
          isLoading={false}
        />,
      );

      // InputGroupAddon should not be rendered when all conditions are false
      const addon = container.querySelector('[data-slot="input-group-addon"]');
      expect(addon).not.toBeInTheDocument();
    });

    it('should render button container when isLoading is true even if buttons are hidden', () => {
      const { container } = render(
        <ChatInput
          {...defaultProps}
          showAttachmentButton={false}
          showSendButton={false}
          isLoading
        />,
      );

      // InputGroupAddon should be rendered when isLoading is true
      const addon = container.querySelector('[data-slot="input-group-addon"]');
      expect(addon).toBeInTheDocument();
    });

    it('should not render stop button when onStop is not provided', () => {
      render(
        <ChatInput
          {...defaultProps}
          isLoading
          loadingMode="stop"
          showSendButton
        />,
      );

      const stopButton = screen.queryByLabelText('Stop');
      expect(stopButton).not.toBeInTheDocument();
    });

    it('should not render stop button when showSendButton is false', () => {
      render(
        <ChatInput
          {...defaultProps}
          isLoading
          loadingMode="stop"
          showSendButton={false}
          onStop={vi.fn()}
        />,
      );

      const stopButton = screen.queryByLabelText('Stop');
      expect(stopButton).not.toBeInTheDocument();
    });

    it('should not render spinner when showSendButton is false', () => {
      const { container } = render(
        <ChatInput
          {...defaultProps}
          isLoading
          loadingMode="loader"
          showSendButton={false}
        />,
      );

      const spinner = container.querySelector('[data-slot="spinner"]');
      expect(spinner).not.toBeInTheDocument();
    });

    it('should not render send button when isLoading is true', () => {
      render(
        <ChatInput
          {...defaultProps}
          isLoading
          showSendButton
          onSend={vi.fn()}
        />,
      );

      const sendButton = screen.queryByLabelText('Send message');
      expect(sendButton).not.toBeInTheDocument();
    });
  });

  describe('Max Rows', () => {
    it('should apply maxRows style attribute', () => {
      const { container } = render(<ChatInput {...defaultProps} maxRows={5} />);

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      expect(chatInput).toHaveStyle({ '--chat-input-max-rows': '5' });
    });

    it('should reduce maxRows when attachments are present', () => {
      const attachments: IChatAttachment[] = [
        {
          id: 'att1',
          name: 'document.pdf',
          type: EAttachmentType.PDF,
        },
      ];

      const { container } = render(
        <ChatInput {...defaultProps} maxRows={10} attachments={attachments} />,
      );

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      // maxRows should be reduced by 3 when attachments are present
      expect(chatInput).toHaveStyle({ '--chat-input-max-rows': '7' });
    });

    it('should ensure maxRows is at least 1 when attachments reduce it below 1', () => {
      const attachments: IChatAttachment[] = [
        {
          id: 'att1',
          name: 'document.pdf',
          type: EAttachmentType.PDF,
        },
      ];

      const { container } = render(
        <ChatInput {...defaultProps} maxRows={2} attachments={attachments} />,
      );

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      // maxRows should be at least 1
      expect(chatInput).toHaveStyle({ '--chat-input-max-rows': '1' });
    });
  });

  describe('Keyboard Events', () => {
    it('should call onKeyDown when provided', async () => {
      const user = userEvent.setup();
      const onKeyDown = vi.fn();
      render(<ChatInput {...defaultProps} onKeyDown={onKeyDown} />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, 'a');

      expect(onKeyDown).toHaveBeenCalled();
    });

    it('should prevent default on Enter when sending', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      const onKeyDown = vi.fn(e => {
        // Check if preventDefault was called
        expect(e.defaultPrevented).toBe(true);
      });

      render(
        <ChatInput
          value="Hello"
          onChange={vi.fn()}
          onSend={onSend}
          onKeyDown={onKeyDown}
        />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).toHaveBeenCalled();
    });
  });

  describe('Focus Indicators', () => {
    it('should have visible focus indicator on send button', async () => {
      const user = userEvent.setup();
      render(<ChatInput value="Hello" onChange={vi.fn()} onSend={vi.fn()} />);

      const textarea = screen.getByRole('textbox');
      const sendButton = screen.getByLabelText('Send message');

      // Focus textarea first, then tab twice (attachment button comes first, then send button)
      await user.click(textarea);
      await user.tab(); // Focuses attachment button
      await user.tab(); // Focuses send button

      // Verify button is focused (buttons should have focus indicators from design system)
      expect(sendButton).toHaveFocus();
    });

    it('should have visible focus indicator on attachment button', async () => {
      const user = userEvent.setup();
      render(<ChatInput value="" onChange={vi.fn()} />);

      const textarea = screen.getByRole('textbox');
      const attachmentButton = screen.getByLabelText('Add attachment');

      // Focus textarea first, then tab to button
      await user.click(textarea);
      await user.tab();

      // Verify button is focused
      expect(attachmentButton).toHaveFocus();
    });

    it('should have visible focus indicator on stop button', async () => {
      const user = userEvent.setup();
      render(
        <ChatInput
          value="Hello"
          onChange={vi.fn()}
          isLoading
          loadingMode="stop"
          onStop={vi.fn()}
        />,
      );

      const textarea = screen.getByRole('textbox');
      const stopButton = screen.getByLabelText('Stop');

      // Focus textarea first, then tab twice (attachment button comes first, then stop button)
      await user.click(textarea);
      await user.tab(); // Focuses attachment button
      await user.tab(); // Focuses stop button

      // Verify button is focused
      expect(stopButton).toHaveFocus();
    });

    it('should have visible focus indicator on textarea', async () => {
      const user = userEvent.setup();
      render(<ChatInput value="" onChange={vi.fn()} />);

      const textarea = screen.getByRole('textbox');

      // Click to focus the textarea
      await user.click(textarea);

      // Verify it's focused
      expect(textarea).toHaveFocus();
    });
  });

  describe('Edge Cases', () => {
    it('should handle undefined value gracefully', () => {
      render(
        <ChatInput value={undefined as unknown as string} onChange={vi.fn()} />,
      );

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      expect(textarea.value).toBe('');
    });

    it('should handle null value gracefully', () => {
      render(
        <ChatInput value={null as unknown as string} onChange={vi.fn()} />,
      );

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      expect(textarea.value).toBe('');
    });

    it('should handle empty attachments array', () => {
      render(<ChatInput {...defaultProps} attachments={[]} />);

      expect(screen.getByRole('textbox')).toBeInTheDocument();
    });

    it('should warn when value is provided without onChange', () => {
      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

      render(<ChatInput value="test" />);

      expect(consoleSpy).toHaveBeenCalledWith(
        'ChatInput: `value` prop provided without `onChange`. Input will be readonly.',
      );

      consoleSpy.mockRestore();
    });

    it('should not warn when both value and onChange are provided', () => {
      const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

      render(<ChatInput value="test" onChange={vi.fn()} />);

      expect(consoleSpy).not.toHaveBeenCalled();

      consoleSpy.mockRestore();
    });
  });

  describe('Inline Variant', () => {
    it('should render inline variant with correct data attributes', () => {
      const { container } = render(
        <ChatInput {...defaultProps} variant="inline" />,
      );

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      expect(chatInput).toHaveAttribute('data-type', 'inline');
      expect(chatInput).toHaveAttribute('data-loading', 'false');
      expect(chatInput).toHaveAttribute('data-disabled', 'false');
    });

    it('should render default Sparkle icon when inlineIcon is not provided', () => {
      const { container } = render(
        <ChatInput {...defaultProps} variant="inline" />,
      );

      // Icon should be present (Icon component renders SVG with shrink-0 class)
      expect(container.querySelector('svg.shrink-0')).toBeInTheDocument();
    });

    it('should render textarea with inline variant', () => {
      render(<ChatInput {...defaultProps} variant="inline" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toBeInTheDocument();
    });

    it('should render placeholder in inline variant', () => {
      render(
        <ChatInput
          {...defaultProps}
          variant="inline"
          placeholder="Type your message"
        />,
      );

      const textarea = screen.getByPlaceholderText('Type your message');
      expect(textarea).toBeInTheDocument();
    });

    it('should render error message when errorMessage is provided', () => {
      render(
        <ChatInput
          {...defaultProps}
          variant="inline"
          errorMessage="This is an error"
        />,
      );

      expect(screen.getByText('This is an error')).toBeInTheDocument();
    });

    it('should not render error message when errorMessage is not provided', () => {
      render(<ChatInput {...defaultProps} variant="inline" />);

      expect(screen.queryByText('This is an error')).not.toBeInTheDocument();
    });

    it('should call onSend when Enter is pressed in inline variant', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(
        <ChatInput
          value="Hello"
          onChange={vi.fn()}
          variant="inline"
          onSend={onSend}
        />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).toHaveBeenCalledWith('Hello');
    });

    it('should not call onSend when Shift+Enter is pressed in inline variant (allows new line)', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(
        <ChatInput
          value="Hello"
          onChange={vi.fn()}
          variant="inline"
          onSend={onSend}
        />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Shift>}{Enter}{/Shift}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should not call onSend when Enter is pressed and input is empty in inline variant', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(
        <ChatInput
          value=""
          onChange={vi.fn()}
          variant="inline"
          onSend={onSend}
        />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should be disabled when disabled prop is true in inline variant', () => {
      render(<ChatInput {...defaultProps} variant="inline" disabled />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toBeDisabled();
    });

    it('should show disabled state in data attribute when disabled is true', () => {
      const { container } = render(
        <ChatInput {...defaultProps} variant="inline" disabled />,
      );

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      expect(chatInput).toHaveAttribute('data-disabled', 'true');
    });

    it('should not call onSend when Enter is pressed and disabled is true in inline variant', async () => {
      const user = userEvent.setup();
      const onSend = vi.fn();
      render(
        <ChatInput
          value="Hello"
          onChange={vi.fn()}
          variant="inline"
          onSend={onSend}
          disabled
        />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, '{Enter}');

      expect(onSend).not.toHaveBeenCalled();
    });

    it('should handle onChange in inline variant', async () => {
      const user = userEvent.setup();
      const onChange = vi.fn();
      render(<ChatInput value="" onChange={onChange} variant="inline" />);

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, 'Hello');

      expect(onChange).toHaveBeenCalled();
    });

    it('should call onKeyDown when provided in inline variant', async () => {
      const user = userEvent.setup();
      const onKeyDown = vi.fn();
      render(
        <ChatInput {...defaultProps} variant="inline" onKeyDown={onKeyDown} />,
      );

      const textarea = screen.getByRole('textbox');
      await user.type(textarea, 'a');

      expect(onKeyDown).toHaveBeenCalled();
    });

    describe('Inline Attachments', () => {
      const mockAttachments: IChatAttachment[] = [
        { id: 'att1', name: 'document.pdf', type: EAttachmentType.PDF },
        { id: 'att2', name: 'image.jpg', type: EAttachmentType.IMAGE },
      ];

      it('should render attachments when provided in inline variant', () => {
        render(
          <ChatInput
            {...defaultProps}
            variant="inline"
            attachments={mockAttachments}
          />,
        );

        expect(screen.getByText('document.pdf')).toBeInTheDocument();
        expect(screen.getByText('image.jpg')).toBeInTheDocument();
      });

      it('should not render attachments section when no attachments in inline variant', () => {
        render(
          <ChatInput {...defaultProps} variant="inline" attachments={[]} />,
        );

        expect(screen.queryByText('document.pdf')).not.toBeInTheDocument();
      });

      it('should call onSend when Enter is pressed with attachments but no text in inline variant', async () => {
        const user = userEvent.setup();
        const onSend = vi.fn();
        render(
          <ChatInput
            value=""
            onChange={vi.fn()}
            variant="inline"
            onSend={onSend}
            attachments={mockAttachments}
          />,
        );

        const textarea = screen.getByRole('textbox');
        await user.type(textarea, '{Enter}');

        expect(onSend).toHaveBeenCalledWith('');
      });
    });

    describe('Inline Attachment Button', () => {
      it('should render attachment button by default (showAttachmentButton defaults to true)', () => {
        render(<ChatInput {...defaultProps} variant="inline" />);

        const attachmentButton = screen.getByLabelText('Add attachment');
        expect(attachmentButton).toBeInTheDocument();
      });

      it('should not render attachment button when showAttachmentButton is false', () => {
        render(
          <ChatInput
            {...defaultProps}
            variant="inline"
            showAttachmentButton={false}
          />,
        );

        const attachmentButton = screen.queryByLabelText('Add attachment');
        expect(attachmentButton).not.toBeInTheDocument();
      });

      it('should open file input when attachment button is clicked in inline variant', async () => {
        const user = userEvent.setup();
        const onAddAttachments = vi.fn();
        render(
          <ChatInput
            {...defaultProps}
            variant="inline"
            onAddAttachments={onAddAttachments}
          />,
        );

        const attachmentButton = screen.getByLabelText('Add attachment');
        await user.click(attachmentButton);

        // The file input should be triggered (we can't easily test file dialog opening,
        // but we can verify the button click doesn't crash)
        expect(attachmentButton).toBeInTheDocument();
      });

      it('should not crash when attachment button is clicked without onAddAttachments', async () => {
        const user = userEvent.setup();
        render(<ChatInput {...defaultProps} variant="inline" />);

        const attachmentButton = screen.getByLabelText('Add attachment');
        await user.click(attachmentButton);

        expect(attachmentButton).toBeInTheDocument();
      });

      it('should disable attachment button when disabled prop is true', () => {
        render(<ChatInput {...defaultProps} variant="inline" disabled />);

        const attachmentButton = screen.getByLabelText('Add attachment');
        expect(attachmentButton).toBeDisabled();
      });

      it('should show attachment button in inline variant', () => {
        render(<ChatInput {...defaultProps} variant="inline" />);

        const attachmentButton = screen.getByLabelText('Add attachment');
        // Button should be visible in inline variant
        expect(attachmentButton).toBeInTheDocument();
        expect(attachmentButton).toHaveClass('text-muted-foreground');
      });

      it('should have attachment button focusable via keyboard', async () => {
        const user = userEvent.setup();
        render(<ChatInput {...defaultProps} variant="inline" />);

        const textarea = screen.getByRole('textbox');
        const attachmentButton = screen.getByLabelText('Add attachment');

        // Focus textarea then tab to attachment button
        await user.click(textarea);
        await user.tab();

        // Attachment button should be focused
        expect(attachmentButton).toHaveFocus();
      });
    });
  });

  describe('Context Variant Inheritance', () => {
    it('should inherit variant from ChatContext when no variant prop is provided', () => {
      const { container } = render(
        <ChatContext value={{ variant: 'inline' }}>
          <ChatInput {...defaultProps} />
        </ChatContext>,
      );

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      expect(chatInput).toHaveAttribute('data-type', 'inline');
    });

    it('should use default variant when context has no variant and no prop is provided', () => {
      const { container } = render(
        <ChatContext value={{}}>
          <ChatInput {...defaultProps} />
        </ChatContext>,
      );

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      // Default variant doesn't have data-type="inline"
      expect(chatInput).not.toHaveAttribute('data-type', 'inline');
    });

    it('should prioritize variant prop over context variant', () => {
      const { container } = render(
        <ChatContext value={{ variant: 'inline' }}>
          <ChatInput {...defaultProps} variant="default" />
        </ChatContext>,
      );

      const chatInput = container.querySelector('[data-slot="chat-input"]');
      // Variant prop should take precedence - default variant doesn't have data-type="inline"
      expect(chatInput).not.toHaveAttribute('data-type', 'inline');
    });
  });

  describe('Custom Background Color', () => {
    it('should apply muted background to inline variant', () => {
      const { container } = render(
        <ChatInput {...defaultProps} variant="inline" background="muted" />,
      );

      // The background class is applied to the inner Flex container with the border
      const inputContainer = container.querySelector('.border.rounded-md');
      expect(inputContainer).toHaveClass('bg-muted');
    });

    it('should default to background background', () => {
      const { container } = render(
        <ChatInput {...defaultProps} variant="inline" />,
      );

      const inputContainer = container.querySelector('.border.rounded-md');
      expect(inputContainer).toHaveClass('bg-background');
    });

    it('should apply custom background color to inline variant if inputClassName is provided', () => {
      const { container } = render(
        <ChatInput
          {...defaultProps}
          variant="inline"
          inputClassName="bg-black"
        />,
      );

      const inputContainer = container.querySelector('.border.rounded-md');
      expect(inputContainer).toHaveClass('bg-black');
    });
  });
});
