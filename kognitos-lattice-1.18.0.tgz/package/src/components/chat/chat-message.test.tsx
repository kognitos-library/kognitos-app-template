import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { ChatMessage } from './chat-message';
import { EMessageDirection, EMessageVariant, type IChatMessage } from './types';

// Helper to create mock messages
const createMockMessage = (
  id: string,
  content: string,
  overrides?: Partial<IChatMessage>,
): IChatMessage => ({
  id,
  content,
  direction: EMessageDirection.INCOMING,
  timestamp: new Date('2024-01-15T14:30:00'),
  ...overrides,
});

describe('ChatMessage', () => {
  describe('Rendering', () => {
    it('should render message content', () => {
      const message = createMockMessage('1', 'Hello World');
      render(<ChatMessage message={message} />);

      expect(screen.getByText('Hello World')).toBeInTheDocument();
    });

    it('should render message with correct data-slot attribute', () => {
      const message = createMockMessage('1', 'Hello');
      const { container } = render(<ChatMessage message={message} />);

      const messageElement = container.querySelector(
        '[data-slot="chat-message"]',
      );
      expect(messageElement).toBeInTheDocument();
    });

    it('should render message with correct ARIA label', () => {
      const message = createMockMessage('1', 'Hello');
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toHaveAttribute(
        'aria-label',
        expect.stringContaining('Incoming message'),
      );
    });
  });

  describe('Message Variants', () => {
    it('should render default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.DEFAULT,
      });
      const { container } = render(<ChatMessage message={message} />);

      const messageElement = container.querySelector(
        '[data-slot="chat-message"]',
      );
      expect(messageElement).toBeInTheDocument();
    });

    it('should render inline variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.INLINE,
      });
      const { container } = render(<ChatMessage message={message} />);

      const messageElement = container.querySelector(
        '[data-slot="chat-message"]',
      );
      expect(messageElement).toBeInTheDocument();
    });

    it('should use defaultVariant prop when message variant is not specified', () => {
      const message = createMockMessage('1', 'Hello');
      render(
        <ChatMessage
          message={message}
          defaultVariant={EMessageVariant.INLINE}
        />,
      );

      expect(screen.getByText('Hello')).toBeInTheDocument();
    });

    it('should prioritize message variant over defaultVariant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.DEFAULT,
      });
      render(
        <ChatMessage
          message={message}
          defaultVariant={EMessageVariant.INLINE}
        />,
      );

      expect(screen.getByText('Hello')).toBeInTheDocument();
    });
  });

  describe('Message Directions', () => {
    it('should render incoming message', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.INCOMING,
      });
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toHaveAttribute(
        'aria-label',
        expect.stringContaining('Incoming message'),
      );
    });

    it('should render outgoing message', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
      });
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toHaveAttribute(
        'aria-label',
        expect.stringContaining('Outgoing message'),
      );
    });

    it('should apply correct styling for outgoing default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.DEFAULT,
      });
      const { container } = render(<ChatMessage message={message} />);

      const messageBubble = container.querySelector('.flex-row-reverse');
      expect(messageBubble).toBeInTheDocument();
    });
  });

  describe('Avatars', () => {
    it('should render avatar when avatarUrl is provided and showSender is true', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarUrl: 'https://example.com/avatar.jpg',
      });
      const { container } = render(
        <ChatMessage message={message} defaultShowSender />,
      );

      // Avatar uses Radix UI AvatarImage which renders an img tag
      const avatarImage = container.querySelector(
        'img[src="https://example.com/avatar.jpg"]',
      );
      const avatarContainer = container.querySelector('[data-slot="avatar"]');
      expect(avatarImage ?? avatarContainer).toBeInTheDocument();
    });

    it('should render avatar fallback when avatarFallback is provided', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarFallback: 'JD',
      });
      render(<ChatMessage message={message} defaultShowSender />);

      const fallback = screen.getByText('JD');
      expect(fallback).toBeInTheDocument();
    });

    it('should not render avatar when showSender is false', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarUrl: 'https://example.com/avatar.jpg',
      });
      render(<ChatMessage message={message} defaultShowSender={false} />);

      const avatar = document.querySelector('img');
      expect(avatar).not.toBeInTheDocument();
    });

    it('should not render avatar when message showSender is false (overrides default)', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarUrl: 'https://example.com/avatar.jpg',
        showSender: false,
      });
      render(<ChatMessage message={message} defaultShowSender />);

      const avatar = document.querySelector('img');
      expect(avatar).not.toBeInTheDocument();
    });

    it('should prioritize message showSender over defaultShowSender', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarUrl: 'https://example.com/avatar.jpg',
        showSender: true,
      });
      const { container } = render(
        <ChatMessage message={message} defaultShowSender={false} />,
      );

      // Avatar uses Radix UI AvatarImage which renders an img tag
      const avatarImage = container.querySelector('img');
      const avatarContainer = container.querySelector('[data-slot="avatar"]');
      expect(avatarImage ?? avatarContainer).toBeInTheDocument();
    });

    it('should not render avatar when no avatarUrl or avatarFallback', () => {
      const message = createMockMessage('1', 'Hello');
      render(<ChatMessage message={message} defaultShowSender />);

      const avatar = document.querySelector('img');
      const fallback = screen.queryByText(/^[A-Z]{2}$/);
      expect(avatar).not.toBeInTheDocument();
      expect(fallback).not.toBeInTheDocument();
    });
  });

  describe('Timestamps', () => {
    it('should render timestamp when timestamp is provided and showTimestamp is true', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.getByText(/2:30 PM/);
      expect(timestamp).toBeInTheDocument();
    });

    it('should not render timestamp when showTimestamp is false', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp={false} />);

      const timestamp = screen.queryByText(/2:30 PM/);
      expect(timestamp).not.toBeInTheDocument();
    });

    it('should not render timestamp when message showTimestamp is false (overrides default)', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
        showTimestamp: false,
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.queryByText(/2:30 PM/);
      expect(timestamp).not.toBeInTheDocument();
    });

    it('should prioritize message showTimestamp over defaultShowTimestamp', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
        showTimestamp: true,
      });
      render(<ChatMessage message={message} defaultShowTimestamp={false} />);

      const timestamp = screen.getByText(/2:30 PM/);
      expect(timestamp).toBeInTheDocument();
    });

    it('should not render timestamp when timestamp is not provided', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: undefined,
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.queryByText(/PM|AM/);
      expect(timestamp).not.toBeInTheDocument();
    });

    it('should use custom timestampFormatter', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      const customFormatter = vi.fn(() => 'Custom Time');

      render(
        <ChatMessage
          message={message}
          defaultShowTimestamp
          timestampFormatter={customFormatter}
        />,
      );

      expect(customFormatter).toHaveBeenCalledWith(message.timestamp);
      expect(screen.getByText('Custom Time')).toBeInTheDocument();
    });

    it('should format timestamp from Date object', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.getByText(/2:30 PM/);
      expect(timestamp).toBeInTheDocument();
    });

    it('should format timestamp from ISO string', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: '2024-01-15T14:30:00',
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.getByText(/2:30 PM/);
      expect(timestamp).toBeInTheDocument();
    });
  });

  describe('Attachments', () => {
    it('should render attachments when provided', () => {
      const message = createMockMessage('1', 'Hello', {
        attachments: [
          {
            id: 'att1',
            name: 'document.pdf',
            type: 'pdf',
          },
        ],
      });
      render(<ChatMessage message={message} />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
    });

    it('should not render remove button for attachments in messages', () => {
      const message = createMockMessage('1', 'Hello', {
        attachments: [
          {
            id: 'att1',
            name: 'document.pdf',
            type: 'pdf',
          },
        ],
      });
      render(<ChatMessage message={message} />);

      // Remove button should not be present (showRemove is false by default in messages)
      const removeButton = screen.queryByLabelText('Remove attachment');
      expect(removeButton).not.toBeInTheDocument();
    });

    it('should render multiple attachments', () => {
      const message = createMockMessage('1', 'Hello', {
        attachments: [
          {
            id: 'att1',
            name: 'document1.pdf',
            type: 'pdf',
          },
          {
            id: 'att2',
            name: 'document2.pdf',
            type: 'pdf',
          },
        ],
      });
      render(<ChatMessage message={message} />);

      expect(screen.getByText('document1.pdf')).toBeInTheDocument();
      expect(screen.getByText('document2.pdf')).toBeInTheDocument();
    });
  });

  describe('Widgets', () => {
    it('should render widget when provided', () => {
      const message = createMockMessage('1', 'Hello', {
        widget: {
          type: 'button-group',
          buttons: [
            {
              id: 'btn1',
              label: 'Button 1',
            },
          ],
        },
      });
      render(<ChatMessage message={message} />);

      expect(screen.getByText('Button 1')).toBeInTheDocument();
    });

    it('should not render text content when widget is present', () => {
      const message = createMockMessage('1', 'Hello', {
        widget: {
          type: 'button-group',
          buttons: [
            {
              id: 'btn1',
              label: 'Button 1',
            },
          ],
        },
      });
      render(<ChatMessage message={message} />);

      // Text content should not be visible when widget is present
      expect(screen.queryByText('Hello')).not.toBeInTheDocument();
    });

    it('should not apply border to outgoing default when widget is present', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.DEFAULT,
        widget: {
          type: 'button-group',
          buttons: [
            {
              id: 'btn1',
              label: 'Button 1',
            },
          ],
        },
      });
      const { container } = render(<ChatMessage message={message} />);

      // Border should not be applied when widget is present
      const borderElement = container.querySelector('.border.border-border');
      expect(borderElement).not.toBeInTheDocument();
    });
  });

  describe('Text Styling', () => {
    it('should apply correct text styling for inline outgoing messages', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.INLINE,
        direction: EMessageDirection.OUTGOING,
      });
      render(<ChatMessage message={message} />);

      const textElement = screen.getByText('Hello');
      expect(textElement).toBeInTheDocument();
    });

    it('should apply correct text styling for inline incoming messages', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.INLINE,
        direction: EMessageDirection.INCOMING,
      });
      render(<ChatMessage message={message} />);

      const textElement = screen.getByText('Hello');
      expect(textElement).toBeInTheDocument();
    });

    it('should apply correct text styling for default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.DEFAULT,
      });
      render(<ChatMessage message={message} />);

      const textElement = screen.getByText('Hello');
      expect(textElement).toBeInTheDocument();
    });
  });

  describe('Edge Cases', () => {
    it('should render message without content', () => {
      const message = createMockMessage('1', '');
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toBeInTheDocument();
    });

    it('should render message with only attachments and no content', () => {
      const message = createMockMessage('1', '', {
        attachments: [
          {
            id: 'att1',
            name: 'document.pdf',
            type: 'pdf',
          },
        ],
      });
      render(<ChatMessage message={message} />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
    });

    it('should render message with only widget and no content', () => {
      const message = createMockMessage('1', '', {
        widget: {
          type: 'button-group',
          buttons: [
            {
              id: 'btn1',
              label: 'Button 1',
            },
          ],
        },
      });
      render(<ChatMessage message={message} />);

      expect(screen.getByText('Button 1')).toBeInTheDocument();
    });

    it('should render message when content is null', () => {
      const message = createMockMessage('1', '', {
        content: null as unknown as string,
      });
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toBeInTheDocument();
    });

    it('should render message when content is undefined', () => {
      const message = createMockMessage('1', '', {
        content: undefined,
      });
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toBeInTheDocument();
    });

    it('should use DEFAULT variant when message has no variant and no defaultVariant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: undefined,
      });
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toBeInTheDocument();
    });
  });

  describe('Avatar Edge Cases', () => {
    it('should render avatarUrl when both avatarUrl and avatarFallback are provided', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarUrl: 'https://example.com/avatar.jpg',
        avatarFallback: 'JD',
      });
      const { container } = render(
        <ChatMessage message={message} defaultShowSender />,
      );

      // Avatar uses Radix UI AvatarImage which renders an img tag
      const avatarImage = container.querySelector(
        'img[src="https://example.com/avatar.jpg"]',
      );
      const avatarContainer = container.querySelector('[data-slot="avatar"]');
      expect(avatarImage ?? avatarContainer).toBeInTheDocument();
    });

    it('should use avatarFallback in alt text when both are provided', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarUrl: 'https://example.com/avatar.jpg',
        avatarFallback: 'JD',
      });
      const { container } = render(
        <ChatMessage message={message} defaultShowSender />,
      );

      // Avatar uses Radix UI AvatarImage which renders an img tag
      const avatarImage = container.querySelector(
        'img[src="https://example.com/avatar.jpg"]',
      );
      const avatarContainer = container.querySelector('[data-slot="avatar"]');
      // Check that avatar is rendered (either image or container)
      expect(avatarImage ?? avatarContainer).toBeInTheDocument();
      // If image exists, check alt text - should include avatarFallback
      if (avatarImage) {
        expect(avatarImage).toHaveAttribute('alt', 'Avatar for JD');
      }
    });

    it('should use fallback alt text when avatarFallback is not provided', () => {
      const message = createMockMessage('1', 'Hello', {
        avatarUrl: 'https://example.com/avatar.jpg',
        direction: EMessageDirection.OUTGOING,
      });
      const { container } = render(
        <ChatMessage message={message} defaultShowSender />,
      );

      // Avatar uses Radix UI AvatarImage which renders an img tag
      const avatarImage = container.querySelector(
        'img[src="https://example.com/avatar.jpg"]',
      );
      const avatarContainer = container.querySelector('[data-slot="avatar"]');
      // Check that avatar is rendered (either image or container)
      expect(avatarImage ?? avatarContainer).toBeInTheDocument();
      // If image exists, check alt text - should use "user" as fallback
      if (avatarImage) {
        expect(avatarImage).toHaveAttribute('alt', 'Avatar for user');
      }
    });
  });

  describe('Timestamp Alignment', () => {
    it('should align timestamp to start for inline variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.INLINE,
        direction: EMessageDirection.INCOMING,
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.getByText(/2:30 PM/);
      expect(timestamp).toBeInTheDocument();
      // Check parent flex container alignment
      const timestampContainer = timestamp.closest('.flex');
      expect(timestampContainer).toHaveClass('justify-start');
    });

    it('should align timestamp to start for incoming default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.DEFAULT,
        direction: EMessageDirection.INCOMING,
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.getByText(/2:30 PM/);
      const timestampContainer = timestamp.closest('.flex');
      expect(timestampContainer).toHaveClass('justify-start');
    });

    it('should align timestamp to end for outgoing default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.DEFAULT,
        direction: EMessageDirection.OUTGOING,
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestamp = screen.getByText(/2:30 PM/);
      const timestampContainer = timestamp.closest('.flex');
      expect(timestampContainer).toHaveClass('justify-end');
    });
  });

  describe('Message Content Alignment', () => {
    it('should align content to start for incoming default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.DEFAULT,
        direction: EMessageDirection.INCOMING,
      });
      const { container } = render(<ChatMessage message={message} />);

      const contentContainer = container.querySelector('.flex.flex-col');
      expect(contentContainer).toHaveClass('items-start');
    });

    it('should align content to end for outgoing default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.DEFAULT,
        direction: EMessageDirection.OUTGOING,
      });
      const { container } = render(<ChatMessage message={message} />);

      const contentContainer = container.querySelector('.flex.flex-col');
      expect(contentContainer).toHaveClass('items-end');
    });

    it('should align content to start for inline variant regardless of direction', () => {
      const message = createMockMessage('1', 'Hello', {
        variant: EMessageVariant.INLINE,
        direction: EMessageDirection.OUTGOING,
      });
      const { container } = render(<ChatMessage message={message} />);

      const contentContainer = container.querySelector('.flex.flex-col');
      expect(contentContainer).toHaveClass('items-start');
    });
  });

  describe('Timestamp DateTime Attribute', () => {
    it('should render timestamp as time element (not plain text)', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timestampText = screen.getByText(/2:30 PM/);
      const timeElement = timestampText.closest('time');

      // Verify timestamp is rendered inside a time element
      expect(timeElement).toBeInTheDocument();
      expect(timeElement?.tagName.toLowerCase()).toBe('time');
      expect(timeElement).toHaveAttribute('dateTime');
    });

    it('should set datetime attribute on timestamp', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timeElement = screen.getByText(/2:30 PM/).closest('time');
      expect(timeElement).toHaveAttribute('dateTime');
      expect(timeElement?.getAttribute('dateTime')).toMatch(
        /2024-01-15T14:30:00/,
      );
    });

    it('should set datetime attribute from ISO string', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: '2024-01-15T14:30:00Z',
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const timeElement = screen.getByText(/2:30 PM/).closest('time');
      expect(timeElement).toHaveAttribute('dateTime');
    });

    it('should include timestamp in aria-label when timestamp exists', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: new Date('2024-01-15T14:30:00'),
      });
      render(<ChatMessage message={message} defaultShowTimestamp />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toHaveAttribute(
        'aria-label',
        expect.stringContaining('at'),
      );
    });

    it('should not include timestamp in aria-label when timestamp is missing', () => {
      const message = createMockMessage('1', 'Hello', {
        timestamp: undefined,
      });
      render(<ChatMessage message={message} />);

      const messageElement = screen.getByRole('article');
      expect(messageElement).toHaveAttribute(
        'aria-label',
        expect.not.stringContaining('at'),
      );
    });
  });

  describe('Attachment onClick', () => {
    it('should call attachment onClick handler when provided', () => {
      const handleClick = vi.fn();
      const message = createMockMessage('1', 'Hello', {
        attachments: [
          {
            id: 'att1',
            name: 'document.pdf',
            type: 'pdf',
            onClick: handleClick,
          },
        ],
      });
      render(<ChatMessage message={message} />);

      // Find and click the attachment
      const attachment = screen.getByText('document.pdf');
      attachment.click();

      expect(handleClick).toHaveBeenCalledTimes(1);
    });

    it('should not throw when attachment onClick is not provided', () => {
      const message = createMockMessage('1', 'Hello', {
        attachments: [
          {
            id: 'att1',
            name: 'document.pdf',
            type: 'pdf',
          },
        ],
      });
      render(<ChatMessage message={message} />);

      const attachment = screen.getByText('document.pdf');
      expect(() => attachment.click()).not.toThrow();
    });
  });

  describe('Border Application', () => {
    it('should apply background to outgoing default variant without widget', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.DEFAULT,
      });
      const { container } = render(<ChatMessage message={message} />);

      const bgElement = container.querySelector('.bg-muted');
      expect(bgElement).toBeInTheDocument();
    });

    it('should not apply background to outgoing default variant with widget', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.DEFAULT,
        widget: {
          type: 'button-group',
          buttons: [{ id: 'btn1', label: 'Button' }],
        },
      });
      const { container } = render(<ChatMessage message={message} />);

      const bgElement = container.querySelector('.bg-muted');
      expect(bgElement).not.toBeInTheDocument();
    });

    it('should not apply background to incoming default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.INCOMING,
        variant: EMessageVariant.DEFAULT,
      });
      const { container } = render(<ChatMessage message={message} />);

      const bgElement = container.querySelector('.bg-muted');
      expect(bgElement).not.toBeInTheDocument();
    });

    it('should not apply background to inline variant', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.INLINE,
      });
      const { container } = render(<ChatMessage message={message} />);

      const bgElement = container.querySelector('.bg-muted');
      expect(bgElement).not.toBeInTheDocument();
    });

    it('should apply background to outgoing default variant with attachments (background only checks for widget)', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.DEFAULT,
        attachments: [
          {
            id: 'att1',
            name: 'document.pdf',
            type: 'pdf',
          },
        ],
      });
      const { container } = render(<ChatMessage message={message} />);

      const bgElement = container.querySelector('.bg-muted');
      expect(bgElement).toBeInTheDocument();
    });
  });

  describe('Compound Variants', () => {
    it('should apply correct classes for outgoing default variant', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.DEFAULT,
      });
      const { container } = render(<ChatMessage message={message} />);

      const messageContainer = container.querySelector(
        '[data-slot="chat-message"]',
      );
      expect(messageContainer).toHaveClass('pl-6', 'pr-0');
    });

    it('should apply correct classes for inline variant (any direction)', () => {
      const message = createMockMessage('1', 'Hello', {
        direction: EMessageDirection.OUTGOING,
        variant: EMessageVariant.INLINE,
      });
      const { container } = render(<ChatMessage message={message} />);

      const messageContainer = container.querySelector(
        '[data-slot="chat-message"]',
      );
      expect(messageContainer).toHaveClass('items-start');
    });
  });

  describe('Custom className', () => {
    it('should apply custom className to message container', () => {
      const message = createMockMessage('1', 'Hello');
      const { container } = render(
        <ChatMessage message={message} className="custom-message-class" />,
      );

      const messageContainer = container.querySelector(
        '[data-slot="chat-message"]',
      );
      expect(messageContainer).toHaveClass('custom-message-class');
    });
  });

  describe('ChatMessage with Markdown', () => {
    it('should render markdown content in messages', () => {
      const message = createMockMessage('1', '**bold** and *italic*');

      render(<ChatMessage message={message} />);

      const bold = screen.getByText('bold');
      expect(bold.tagName).toBe('STRONG');
      expect(bold).toHaveClass('font-semibold');

      const italic = screen.getByText('italic');
      expect(italic.tagName).toBe('EM');
      expect(italic).toHaveClass('italic');
    });

    it('should render code blocks in messages', () => {
      const message = createMockMessage('1', '`code example`');

      render(<ChatMessage message={message} />);

      const codeElement = screen.getByText('code example');
      expect(codeElement.tagName).toBe('CODE');
    });

    it('should handle links safely in messages', () => {
      const message = createMockMessage(
        '1',
        '[safe](https://example.com) and [unsafe](javascript:alert(1))',
      );

      render(<ChatMessage message={message} />);

      // Only one safe link should be rendered
      const links = screen.getAllByRole('link');
      expect(links).toHaveLength(1);
      expect(links[0]).toHaveAttribute('href', 'https://example.com');
      expect(links[0]).toHaveAttribute('target', '_blank');
      expect(links[0]).toHaveAttribute('rel', 'noopener noreferrer');

      // Unsafe link should be rendered as plain text
      expect(screen.getByText('unsafe')).toBeInTheDocument();
      const unsafeElement = screen.getByText('unsafe');
      expect(unsafeElement.tagName).toBe('SPAN');
    });

    it('should render markdown headings in messages', () => {
      const message = createMockMessage(
        '1',
        '# Heading 1\n## Heading 2\n### Heading 3',
      );

      render(<ChatMessage message={message} />);

      expect(screen.getByText('Heading 1')).toBeInTheDocument();
      expect(screen.getByText('Heading 2')).toBeInTheDocument();
      expect(screen.getByText('Heading 3')).toBeInTheDocument();
    });

    it('should render markdown lists in messages', () => {
      const message = createMockMessage('1', '- Item 1\n- Item 2\n- Item 3');

      render(<ChatMessage message={message} />);

      const list = screen.getByRole('list');
      expect(list).toBeInTheDocument();
      expect(list.tagName).toBe('UL');

      expect(screen.getByText('Item 1')).toBeInTheDocument();
      expect(screen.getByText('Item 2')).toBeInTheDocument();
      expect(screen.getByText('Item 3')).toBeInTheDocument();
    });

    it('should render code blocks with syntax highlighting in messages', () => {
      const message = createMockMessage(
        '1',
        '```javascript\nconst x = 1;\n```',
      );

      render(<ChatMessage message={message} />);

      const codeElement = screen.getByText('const x = 1;');
      expect(codeElement.tagName).toBe('CODE');
      expect(codeElement).toHaveClass('block');
    });

    it('should sanitize dangerous data: links in messages', () => {
      const message = createMockMessage('1', '[Click](data:text/plain,test)');

      render(<ChatMessage message={message} />);

      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.getByText('Click')).toBeInTheDocument();
    });

    it('should sanitize dangerous file: links in messages', () => {
      const message = createMockMessage('1', '[File](file:///etc/passwd)');

      render(<ChatMessage message={message} />);

      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.getByText('File')).toBeInTheDocument();
    });

    it('should render complex markdown content in messages', () => {
      const message = createMockMessage(
        '1',
        '# Main Heading\n\nThis is a paragraph with **bold** and *italic* text.\n\n- List item 1\n- List item 2\n\n`inline code` example\n\n[Valid link](https://example.com)',
      );

      render(<ChatMessage message={message} />);

      expect(screen.getByText('Main Heading')).toBeInTheDocument();
      expect(screen.getByText('bold')).toBeInTheDocument();
      expect(screen.getByText('italic')).toBeInTheDocument();
      expect(screen.getByText('List item 1')).toBeInTheDocument();
      expect(screen.getByText('inline code')).toBeInTheDocument();
      expect(
        screen.getByRole('link', { name: 'Valid link' }),
      ).toBeInTheDocument();
    });

    it('should apply textProps to markdown content in messages', () => {
      const message = createMockMessage('1', '**bold** text');

      render(
        <ChatMessage
          message={message}
          defaultVariant={EMessageVariant.INLINE}
          defaultShowSender={false}
        />,
      );

      // Markdown should be rendered with appropriate text props
      const bold = screen.getByText('bold');
      expect(bold.tagName).toBe('STRONG');
      expect(screen.getByText('text')).toBeInTheDocument();
    });
  });
});
