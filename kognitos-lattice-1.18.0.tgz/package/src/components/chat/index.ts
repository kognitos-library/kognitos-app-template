// ============================================================================
// CHAT COMPONENTS
// ============================================================================

export {
  Chat,
  ChatMessage,
  ChatLoadingSkeleton,
  ChatMessageAttachment,
  ChatStatus,
  ChatThinkingMessage,
  ChatMessageWidget,
  chatVariants,
  messageContainerVariants,
  messageBubbleVariants,
  EMessageDirection,
  EMessageVariant,
  EMessageStatus,
  EAttachmentType,
  EMessageUpdateState,
  EWidgetType,
  EMessageType,
} from './chat';
export { getAttachmentIcon, getAttachmentColorClass } from './utils';
export { ChatActionCardWidget } from './widgets/chat-action-card-widget';
export { ChatButtonGroupWidget } from './widgets/chat-button-group-widget';
export type {
  IChatMessage,
  IChatAttachment,
  IChatMessageWidget,
  IChatMessageButton,
  IChatMessageActionCard,
  TMessageDirection,
  TMessageVariant,
  TMessageStatus,
  TAttachmentType,
  TMessageUpdateState,
  TWidgetType,
  TMessageType,
  IChatProps,
  IChatMessageProps,
  IChatMessageAttachmentProps,
  IChatStatusProps,
  IChatThinkingMessageProps,
} from './chat';
export type { IChatThinkingTexts } from './types';

export { ChatInput } from './chat-input';
export type { IChatInputProps } from './chat-input';

export { ChatToast, type IChatToastProps } from './chat-toast';

export { useChat, type IUseChatReturn } from './use-chat';
