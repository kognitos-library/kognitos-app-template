import type { Meta, StoryObj } from '@storybook/react-vite';
import { ChatMessageAttachment, type IChatAttachment } from '@/design-system';
import { Flex } from '../../primitives/flex';

const meta: Meta<typeof ChatMessageAttachment> = {
  title: 'Design System/Components/Chat/ChatMessageAttachment',
  component: ChatMessageAttachment,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A chat message attachment component that displays file attachments with icons, names, and remove functionality. Supports different file types (PDF, Excel, text, image, file).',
      },
    },
  },
  argTypes: {
    attachment: {
      control: { type: 'object' },
      description: 'The attachment object to display',
    },
    showRemove: {
      control: { type: 'boolean' },
      description: 'Whether to show the remove button',
    },
    onRemove: {
      action: 'attachment-removed',
      description: 'Callback when attachment is removed',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ChatMessageAttachment>;

/**
 * PDF attachment.
 */
export const PDF: Story = {
  args: {
    attachment: {
      id: 'att1',
      name: 'document.pdf',
      type: 'pdf',
    },
    showRemove: true,
  },
  render: args => (
    <Flex width="full" className="max-w-md p-4">
      <ChatMessageAttachment {...args} />
    </Flex>
  ),
};

/**
 * Excel attachment.
 */
export const Excel: Story = {
  args: {
    attachment: {
      id: 'att2',
      name: 'spreadsheet.xlsx',
      type: 'excel',
    },
    showRemove: true,
  },
  render: args => (
    <Flex width="full" className="max-w-md p-4">
      <ChatMessageAttachment {...args} />
    </Flex>
  ),
};

/**
 * Text file attachment.
 */
export const Text: Story = {
  args: {
    attachment: {
      id: 'att3',
      name: 'notes.txt',
      type: 'text',
    },
    showRemove: true,
  },
  render: args => (
    <Flex width="full" className="max-w-md p-4">
      <ChatMessageAttachment {...args} />
    </Flex>
  ),
};

/**
 * Image attachment.
 */
export const Image: Story = {
  args: {
    attachment: {
      id: 'att4',
      name: 'photo.jpg',
      type: 'image',
    },
    showRemove: true,
  },
  render: args => (
    <Flex width="full" className="max-w-md p-4">
      <ChatMessageAttachment {...args} />
    </Flex>
  ),
};

/**
 * Generic file attachment.
 */
export const GenericFile: Story = {
  args: {
    attachment: {
      id: 'att5',
      name: 'archive.zip',
      type: 'file',
    },
    showRemove: true,
  },
  render: args => (
    <Flex width="full" className="max-w-md p-4">
      <ChatMessageAttachment {...args} />
    </Flex>
  ),
};

/**
 * Attachment with long filename.
 */
export const LongFilename: Story = {
  args: {
    attachment: {
      id: 'att6',
      name: 'very-long-filename-that-should-truncate-properly-with-ellipsis.pdf',
      type: 'pdf',
    },
    showRemove: true,
  },
  render: args => (
    <Flex width="full" className="max-w-md p-4">
      <ChatMessageAttachment {...args} />
    </Flex>
  ),
};

/**
 * Attachment without remove button.
 */
export const WithoutRemove: Story = {
  args: {
    attachment: {
      id: 'att1',
      name: 'document.pdf',
      type: 'pdf',
    },
    showRemove: false,
  },
  render: args => (
    <Flex width="full" className="max-w-md p-4">
      <ChatMessageAttachment {...args} />
    </Flex>
  ),
};

/**
 * Multiple attachments displayed together.
 */
export const MultipleAttachments: Story = {
  render: () => {
    const attachments: IChatAttachment[] = [
      {
        id: 'att1',
        name: 'document.pdf',
        type: 'pdf',
      },
      {
        id: 'att2',
        name: 'spreadsheet.xlsx',
        type: 'excel',
      },
      {
        id: 'att3',
        name: 'notes.txt',
        type: 'text',
      },
      {
        id: 'att4',
        name: 'photo.jpg',
        type: 'image',
      },
      {
        id: 'att5',
        name: 'archive.zip',
        type: 'file',
      },
    ];

    return (
      <Flex width="full" className="max-w-md p-4">
        <Flex direction="column" gap={2}>
          {attachments.map(attachment => (
            <ChatMessageAttachment
              key={attachment.id}
              attachment={attachment}
              showRemove
              onRemove={() => console.log(`Removed ${attachment.name}`)}
            />
          ))}
        </Flex>
      </Flex>
    );
  },
};

/**
 * All file types comparison.
 */
export const FileTypesComparison: Story = {
  render: () => {
    const fileTypes: IChatAttachment['type'][] = [
      'pdf',
      'excel',
      'text',
      'image',
      'file',
    ];

    return (
      <Flex width="full" className="max-w-md p-4">
        <Flex direction="column" gap={2}>
          {fileTypes.map((type, index) => (
            <ChatMessageAttachment
              key={type}
              attachment={{
                id: `att-${index}`,
                name: `example.${type === 'excel' ? 'xlsx' : type === 'image' ? 'jpg' : type === 'file' ? 'zip' : type}`,
                type,
              }}
              showRemove
            />
          ))}
        </Flex>
      </Flex>
    );
  },
};
