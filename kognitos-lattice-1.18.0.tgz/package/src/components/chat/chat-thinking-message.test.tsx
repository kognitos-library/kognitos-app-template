import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ChatThinkingMessage } from './chat-thinking-message';
import { EMessageDirection, EMessageType, type IChatMessage } from './types';

/**
 * Creates a mock thinking message for testing.
 */
const createThinkingMessage = (
  id: string,
  content: string,
  timestamp?: Date | string,
): IChatMessage => ({
  id,
  content,
  direction: EMessageDirection.INCOMING,
  type: EMessageType.THINKING,
  timestamp: timestamp ?? new Date(),
});

describe('ChatThinkingMessage', () => {
  describe('Rendering', () => {
    it('should render with messages', () => {
      const messages = [
        createThinkingMessage('1', 'Analyzing input...'),
        createThinkingMessage('2', 'Processing data...'),
      ];

      render(<ChatThinkingMessage messages={messages} />);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toBeInTheDocument();
      expect(component).toHaveAttribute('data-slot', 'chat-thinking-message');
    });

    it('should not render when messages array is empty', () => {
      render(<ChatThinkingMessage messages={[]} />);

      expect(
        screen.queryByTestId('chat-thinking-message'),
      ).not.toBeInTheDocument();
    });

    it('should render all messages when expanded', async () => {
      const user = userEvent.setup();
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
        createThinkingMessage('3', 'Third step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete={false} />);

      // Click header to expand
      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      await user.click(header!);

      // Content should be visible
      const content = screen.getByTestId('chat-thinking-content');
      expect(content).toBeInTheDocument();
      expect(content).toHaveTextContent('First step');
      expect(content).toHaveTextContent('Second step');
      expect(content).toHaveTextContent('Third step');
    });
  });

  describe('Streaming State (isComplete=false)', () => {
    it('should show shimmering title with "Neurosymbolizing..." when streaming', () => {
      const messages = [createThinkingMessage('1', 'Working...')];

      render(<ChatThinkingMessage messages={messages} isComplete={false} />);

      const title = screen.getByTestId('chat-thinking-title');
      expect(title).toBeInTheDocument();
      expect(title.textContent).toBe('Neurosymbolizing...');
    });

    it('should show custom title when provided', () => {
      const messages = [createThinkingMessage('1', 'Working...')];

      render(
        <ChatThinkingMessage
          messages={messages}
          title="Processing..."
          isComplete={false}
        />,
      );

      const title = screen.getByTestId('chat-thinking-title');
      expect(title.textContent).toBe('Processing...');
    });

    it('should default to collapsed state when streaming', () => {
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete={false} />);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-expanded', 'false');
      expect(component).toHaveAttribute('data-complete', 'false');

      // Messages wrapper should be visually hidden (opacity-0) when collapsed
      const messagesWrapper = screen.getByTestId('chat-thinking-messages');
      expect(messagesWrapper).toHaveClass('opacity-0');
    });
  });

  describe('Complete State (isComplete=true)', () => {
    it('should show "Neurosymbolized" header when complete', () => {
      const messages = [createThinkingMessage('1', 'Done')];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const title = screen.getByTestId('chat-thinking-title');
      expect(title.textContent).toContain('Neurosymbolized');
    });

    it('should show duration in header when complete with timestamps', () => {
      const startTime = new Date('2024-01-15T14:30:00Z');
      const endTime = new Date('2024-01-15T14:30:45Z');

      const messages = [
        createThinkingMessage('1', 'First step', startTime),
        createThinkingMessage('2', 'Last step', endTime),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const title = screen.getByTestId('chat-thinking-title');
      expect(title.textContent).toContain('Neurosymbolized for 45s');
    });

    it('should show duration with minutes when over 60 seconds', () => {
      const startTime = new Date('2024-01-15T14:30:00Z');
      const endTime = new Date('2024-01-15T14:32:30Z');

      const messages = [
        createThinkingMessage('1', 'First step', startTime),
        createThinkingMessage('2', 'Last step', endTime),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const title = screen.getByTestId('chat-thinking-title');
      expect(title.textContent).toContain('Neurosymbolized for 2m 30s');
    });

    it('should default to collapsed state when complete', () => {
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-expanded', 'false');
      expect(component).toHaveAttribute('data-complete', 'true');

      // Messages wrapper should be visually hidden (opacity-0) when collapsed
      const messagesWrapper = screen.getByTestId('chat-thinking-messages');
      expect(messagesWrapper).toHaveClass('opacity-0');
    });

    it('should have italic title when complete', () => {
      const messages = [createThinkingMessage('1', 'Done')];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const title = screen.getByTestId('chat-thinking-title');
      expect(title).toHaveClass('italic');
    });
  });

  describe('Collapsible Behavior', () => {
    it('should show header only when collapsed', () => {
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
        createThinkingMessage('3', 'Third step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      // Messages wrapper should be visually hidden (opacity-0) when collapsed
      const messagesWrapper = screen.getByTestId('chat-thinking-messages');
      expect(messagesWrapper).toHaveClass('opacity-0');

      // Chevron should be visible
      expect(screen.getByTestId('chat-thinking-chevron')).toBeInTheDocument();
    });

    it('should expand when header is clicked', async () => {
      const user = userEvent.setup();
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
        createThinkingMessage('3', 'Third step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      // Click header to expand
      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      await user.click(header!);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-expanded', 'true');

      // Messages should be visible
      const content = screen.getByTestId('chat-thinking-content');
      expect(content).toBeInTheDocument();
      expect(content).toHaveTextContent('First step');
      expect(content).toHaveTextContent('Second step');
      expect(content).toHaveTextContent('Third step');
    });

    it('should collapse when header is clicked again', async () => {
      const user = userEvent.setup();
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete={false} />);

      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');

      // Click to expand
      await user.click(header!);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-expanded', 'true');

      // Click to collapse
      await user.click(header!);

      expect(component).toHaveAttribute('data-expanded', 'false');

      // Messages wrapper should be visually hidden (opacity-0) after collapse
      const messagesWrapper = screen.getByTestId('chat-thinking-messages');
      expect(messagesWrapper).toHaveClass('opacity-0');
    });

    it('should toggle expand/collapse with keyboard', async () => {
      const user = userEvent.setup();
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]') as HTMLElement;

      // Focus and press Enter
      header.focus();
      await user.keyboard('{Enter}');

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-expanded', 'true');

      // Press Space to collapse
      await user.keyboard(' ');
      expect(component).toHaveAttribute('data-expanded', 'false');
    });

    it('should show scrollable content when expanded with many messages', async () => {
      const user = userEvent.setup();
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
        createThinkingMessage('3', 'Third step'),
        createThinkingMessage('4', 'Fourth step'),
        createThinkingMessage('5', 'Fifth step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete={false} />);

      // Click header to expand
      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      await user.click(header!);

      // Should show scrollable messages container
      const messagesContainer = screen.getByTestId('chat-thinking-messages');
      expect(messagesContainer).toBeInTheDocument();
    });

    it('should rotate chevron when expanded', async () => {
      const user = userEvent.setup();
      const messages = [createThinkingMessage('1', 'Test message')];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const chevron = screen.getByTestId('chat-thinking-chevron');

      // Initially not rotated
      expect(chevron).not.toHaveClass('rotate-180');

      // Click to expand
      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      await user.click(header!);

      // Chevron should be rotated
      expect(chevron).toHaveClass('rotate-180');
    });

    it('should show background when expanded', async () => {
      const user = userEvent.setup();
      const messages = [createThinkingMessage('1', 'Test message')];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const component = screen.getByTestId('chat-thinking-message');

      // Initially no bg-secondary
      expect(component).not.toHaveClass('bg-secondary');

      // Click to expand
      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      await user.click(header!);

      // Should have bg-secondary when expanded
      expect(component).toHaveClass('bg-secondary');
    });
  });

  describe('Data Attributes', () => {
    it('should have correct data attributes when streaming and collapsed', () => {
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete={false} />);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-expanded', 'false');
      expect(component).toHaveAttribute('data-complete', 'false');
    });

    it('should have correct data attributes when complete and expanded', async () => {
      const user = userEvent.setup();
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      // Expand by clicking header
      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      await user.click(header!);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-expanded', 'true');
      expect(component).toHaveAttribute('data-complete', 'true');
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      const messages = [createThinkingMessage('1', 'Test')];

      render(
        <ChatThinkingMessage messages={messages} className="custom-class" />,
      );

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveClass('custom-class');
    });

    it('should have default styling classes', () => {
      const messages = [createThinkingMessage('1', 'Test')];

      render(<ChatThinkingMessage messages={messages} />);

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveClass('rounded-sm');
    });

    it('should have hover styling on header', () => {
      const messages = [createThinkingMessage('1', 'Test')];

      render(<ChatThinkingMessage messages={messages} />);

      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      expect(header).toHaveClass('hover:bg-secondary');
    });
  });

  describe('Props Spreading', () => {
    it('should spread HTML attributes to root element', () => {
      const messages = [createThinkingMessage('1', 'Test')];

      render(
        <ChatThinkingMessage
          messages={messages}
          data-custom="test"
          id="thinking-id"
        />,
      );

      const component = screen.getByTestId('chat-thinking-message');
      expect(component).toHaveAttribute('data-custom', 'test');
      expect(component).toHaveAttribute('id', 'thinking-id');
    });
  });

  describe('Accessibility', () => {
    it('should have correct aria attributes on header', () => {
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      expect(header).toHaveAttribute('role', 'button');
      expect(header).toHaveAttribute('tabindex', '0');
      expect(header).toHaveAttribute('aria-expanded', 'false');
      expect(header).toHaveAttribute('aria-label', 'Expand thinking');
    });

    it('should update aria-expanded when toggled', async () => {
      const user = userEvent.setup();
      const messages = [
        createThinkingMessage('1', 'First step'),
        createThinkingMessage('2', 'Second step'),
      ];

      render(<ChatThinkingMessage messages={messages} isComplete />);

      const header = screen
        .getByTestId('chat-thinking-title')
        .closest('[role="button"]');
      expect(header).toHaveAttribute('aria-expanded', 'false');

      await user.click(header!);
      expect(header).toHaveAttribute('aria-expanded', 'true');
      expect(header).toHaveAttribute('aria-label', 'Collapse thinking');
    });
  });

  describe('Custom Text Props (i18n support)', () => {
    it('should render with custom title when streaming', () => {
      const messages = [createThinkingMessage('1', 'Working...')];

      render(
        <ChatThinkingMessage
          messages={messages}
          title="カスタムタイトル..."
          isComplete={false}
        />,
      );

      const title = screen.getByTestId('chat-thinking-title');
      expect(title.textContent).toBe('カスタムタイトル...');
    });
  });
});
