import { cva, type VariantProps } from 'class-variance-authority';

import { Card, CardContent } from '../primitives/card';
import { Flex } from '../primitives/flex';
import { Skeleton } from '../primitives/skeleton';
import { Text } from '../primitives/typography';
import { cn } from '../lib/utils';

const insightsCardTrendVariants = cva('text-sm font-normal leading-none', {
  variants: {
    type: {
      positive: 'text-success',
      negative: 'text-destructive',
    },
  },
  defaultVariants: {
    type: 'positive',
  },
});

interface IInsightsCardTrendProps extends VariantProps<
  typeof insightsCardTrendVariants
> {
  value: string;
  className?: string;
}

function InsightsCardTrend({
  value,
  type = 'positive',
  className,
}: IInsightsCardTrendProps) {
  return (
    <span className={cn(insightsCardTrendVariants({ type }), className)}>
      {value}
    </span>
  );
}

const insightsCardVariants = cva('', {
  variants: {
    variant: {
      default: '',
      destructive: '',
      success: '',
    },
  },
  defaultVariants: {
    variant: 'default',
  },
});

const valueVariants = cva('text-3xl font-medium leading-9 w-full', {
  variants: {
    variant: {
      default: 'text-foreground',
      destructive: 'text-destructive',
      success: 'text-success',
    },
  },
  defaultVariants: {
    variant: 'default',
  },
});

interface IInsightsCardProps extends VariantProps<typeof insightsCardVariants> {
  title: string;
  value?: string;
  trend?: {
    value: string;
    type?: 'positive' | 'negative';
  };
  loading?: boolean;
  className?: string;
}

/**
 * InsightsCard component displays key metrics with optional trend indicators.
 *
 * @example
 * // Basic usage
 * <InsightsCard title="Revenue" value="$40,199.05" />
 *
 * @example
 * // With trend indicator
 * <InsightsCard
 *   title="Revenue"
 *   value="$40,199.05"
 *   trend={{ value: '+15.1%', type: 'positive' }}
 * />
 *
 * @example
 * // Loading state
 * <InsightsCard title="Revenue" loading />
 *
 * @example
 * // Success variant
 * <InsightsCard
 *   title="Revenue"
 *   value="$40,199.05"
 *   variant="success"
 *   trend={{ value: '+15.1%', type: 'positive' }}
 * />
 */
function InsightsCard({
  title,
  value,
  trend,
  loading = false,
  variant = 'default',
  className,
}: IInsightsCardProps) {
  return (
    <Card
      className={cn(
        insightsCardVariants({ variant }),
        'min-w-[200px]',
        className,
      )}
    >
      <CardContent>
        <Flex direction="column" gap={2} width="full">
          <Flex gap={2} align="center" justify="between" width="full">
            <Text
              level="base"
              color="muted"
              weight="medium"
              className="flex-1 truncate"
            >
              {title}
            </Text>
            {trend && !loading && (
              <InsightsCardTrend value={trend.value} type={trend.type} />
            )}
            {trend && loading && (
              <Skeleton className="h-4 w-16" data-testid="skeleton-trend" />
            )}
          </Flex>
          {loading ? (
            <Flex direction="column" className="h-9 w-full" justify="end">
              <Skeleton className="h-4 w-40" data-testid="skeleton-value" />
            </Flex>
          ) : (
            <span className={valueVariants({ variant })}>{value}</span>
          )}
        </Flex>
      </CardContent>
    </Card>
  );
}

export { InsightsCard, InsightsCardTrend, insightsCardVariants };
export type { IInsightsCardProps, IInsightsCardTrendProps };
