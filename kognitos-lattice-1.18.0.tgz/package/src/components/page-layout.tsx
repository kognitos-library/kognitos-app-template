import React from 'react';
import { cn } from '@/design-system/lib/utils';
import { Flex } from '@/design-system/primitives/flex';

interface IPageHeaderProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  left?: React.ReactNode;
  center?: React.ReactNode;
  right?: React.ReactNode;
}

export function PageHeader({
  className,
  children,
  left,
  center,
  right,
  ...props
}: IPageHeaderProps) {
  return (
    <Flex
      align="center"
      justify="between"
      className={cn(
        'h-16 px-5 py-2.5 bg-layout shadow-sm border-b border-border',
        className,
      )}
      {...props}
    >
      {children || (
        <>
          {left && (
            <Flex flex="1" align="center" gap={4}>
              {left}
            </Flex>
          )}
          {center && (
            <Flex flex="1" align="center" justify="center">
              {center}
            </Flex>
          )}
          {right && (
            <Flex flex="1" align="center" justify="end" gap={2}>
              {right}
            </Flex>
          )}
        </>
      )}
    </Flex>
  );
}

interface IPageContentProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  noPadding?: boolean;
}

export function PageContent({
  className,
  children,
  noPadding = false,
  ...props
}: IPageContentProps) {
  return (
    <Flex
      flex="1"
      direction="row"
      width="full"
      className={cn(!noPadding && 'p-2.5', className)}
      {...props}
    >
      {children}
    </Flex>
  );
}

interface IPageLayoutProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
}

export function PageLayout({
  className,
  children,
  ...props
}: IPageLayoutProps) {
  return (
    <Flex
      direction="column"
      height="screen"
      width="full"
      className={cn('bg-layout flex', className)}
      {...props}
    >
      {children}
    </Flex>
  );
}

interface ICenteredContentProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
}

export function CenteredContent({
  className,
  children,
  ...props
}: ICenteredContentProps) {
  return (
    <Flex
      flex="1"
      align="center"
      justify="center"
      className={className}
      {...props}
    >
      {children}
    </Flex>
  );
}

interface IPillBadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  children?: React.ReactNode;
  count?: number | string;
}

export function PillBadge({
  className,
  children,
  count,
  ...props
}: IPillBadgeProps) {
  return (
    <Flex
      align="center"
      gap={2}
      className={cn('bg-muted px-4 py-2 rounded-3xl shadow-md', className)}
      {...props}
    >
      {children}
      {count !== undefined && (
        <span className="bg-muted-foreground text-background text-xs font-semibold px-1 rounded-full min-w-[20px] h-5 flex items-center justify-center">
          {count}
        </span>
      )}
    </Flex>
  );
}
