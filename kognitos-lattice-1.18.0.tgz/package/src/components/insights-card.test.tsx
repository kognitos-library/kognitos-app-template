import { render, screen } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { InsightsCard } from './insights-card';

describe('InsightsCard', () => {
  describe('Rendering', () => {
    it('should render title and value', () => {
      render(<InsightsCard title="Revenue" value="$40,199.05" />);

      expect(screen.getByText('Revenue')).toBeInTheDocument();
      expect(screen.getByText('$40,199.05')).toBeInTheDocument();
    });

    it('should render without value when not provided', () => {
      render(<InsightsCard title="Revenue" />);

      expect(screen.getByText('Revenue')).toBeInTheDocument();
    });

    it('should render trend indicator when provided', () => {
      render(
        <InsightsCard
          title="Revenue"
          value="$40,199.05"
          trend={{ value: '+15.1%', type: 'positive' }}
        />,
      );

      expect(screen.getByText('+15.1%')).toBeInTheDocument();
    });

    it('should not render trend when not provided', () => {
      render(<InsightsCard title="Revenue" value="$40,199.05" />);

      expect(screen.queryByText('+')).not.toBeInTheDocument();
    });
  });

  describe('Variants', () => {
    it('should render default variant correctly', () => {
      render(
        <InsightsCard
          title="Revenue"
          value="$40,199.05"
          variant="default"
          data-testid="insights-card"
        />,
      );

      const valueElement = screen.getByText('$40,199.05');
      expect(valueElement).toHaveClass('text-foreground');
    });

    it('should render success variant with correct styling', () => {
      render(
        <InsightsCard
          title="Revenue"
          value="$40,199.05"
          variant="success"
          data-testid="insights-card"
        />,
      );

      const valueElement = screen.getByText('$40,199.05');
      expect(valueElement).toHaveClass('text-success');
    });

    it('should render destructive variant with correct styling', () => {
      render(
        <InsightsCard
          title="Revenue"
          value="$40,199.05"
          variant="destructive"
          data-testid="insights-card"
        />,
      );

      const valueElement = screen.getByText('$40,199.05');
      expect(valueElement).toHaveClass('text-destructive');
    });

    it('should render loading state with skeleton', () => {
      render(
        <InsightsCard title="Revenue" loading data-testid="insights-card" />,
      );

      const valueSkeleton = screen.getByTestId('skeleton-value');
      expect(valueSkeleton).toBeInTheDocument();
    });

    it('should show skeleton for trend in loading state', () => {
      render(
        <InsightsCard
          title="Revenue"
          loading
          trend={{ value: '+15.1%', type: 'positive' }}
        />,
      );

      expect(screen.queryByText('+15.1%')).not.toBeInTheDocument();
    });
  });

  describe('Trend Types', () => {
    it('should render positive trend with success color', () => {
      render(
        <InsightsCard
          title="Revenue"
          value="$40,199.05"
          trend={{ value: '+15.1%', type: 'positive' }}
        />,
      );

      const trendElement = screen.getByText('+15.1%');
      expect(trendElement).toHaveClass('text-success');
    });

    it('should render negative trend with destructive color', () => {
      render(
        <InsightsCard
          title="Revenue"
          value="$40,199.05"
          trend={{ value: '-8.2%', type: 'negative' }}
        />,
      );

      const trendElement = screen.getByText('-8.2%');
      expect(trendElement).toHaveClass('text-destructive');
    });
  });

  describe('Custom Styling', () => {
    it('should apply custom className', () => {
      const { container } = render(
        <InsightsCard
          title="Revenue"
          value="$40,199.05"
          className="custom-class"
        />,
      );

      const card = container.querySelector('.custom-class');
      expect(card).toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    it('should have accessible text content', () => {
      render(
        <InsightsCard
          title="Total Revenue"
          value="$40,199.05"
          trend={{ value: '+15.1%', type: 'positive' }}
        />,
      );

      expect(screen.getByText('Total Revenue')).toBeInTheDocument();
      expect(screen.getByText('$40,199.05')).toBeInTheDocument();
      expect(screen.getByText('+15.1%')).toBeInTheDocument();
    });
  });
});
