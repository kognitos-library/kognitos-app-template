import * as React from 'react';
import {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from '../primitives/empty';
import { Icon, type IIconProps } from '../icons';
import { Button, type IButtonProps } from '../primitives/button';
import { Flex } from '../primitives/flex';
import { cn } from '../lib/utils';

interface IEmptyStateProps extends React.HTMLAttributes<HTMLDivElement> {
  // Icon props
  icon?: IIconProps['type'];

  // Content props
  title?: string;
  description?: string | React.ReactNode;

  // Action props
  actionLabel?: string;
  actionIcon?: IIconProps['type'];
  actionVariant?: IButtonProps['variant'];
  actionSize?: IButtonProps['size'];
  onAction?: () => void;
  actionLoading?: boolean;

  // Secondary action props
  secondaryActionLabel?: string;
  secondaryActionVariant?: IButtonProps['variant'];
  secondaryActionSize?: IButtonProps['size'];
  onSecondaryAction?: () => void;

  // Layout props
  bordered?: boolean;

  // Ref
  ref?: React.Ref<HTMLDivElement>;

  // Test IDs
  actionTestId?: string;
  secondaryActionTestId?: string;
}

const EmptyState = ({
  ref,
  className,
  bordered = true,
  icon,
  title,
  description,
  actionLabel,
  actionTestId,
  actionIcon,
  actionLoading = false,
  actionVariant = 'default',
  actionSize = 'default',
  onAction,
  secondaryActionLabel,
  secondaryActionTestId,
  secondaryActionVariant = 'outline',
  secondaryActionSize = 'default',
  onSecondaryAction,
  children,
  ...props
}: IEmptyStateProps) => {
  return (
    <Empty
      ref={ref}
      className={cn(className, bordered && 'border border-dashed rounded-lg')}
      {...props}
    >
      {/* Icon */}
      {icon && (
        <EmptyMedia variant="icon">
          <Icon type={icon} />
        </EmptyMedia>
      )}

      {/* Header with title and description */}
      {(title || description) && (
        <EmptyHeader>
          {title && <EmptyTitle>{title}</EmptyTitle>}
          {description && (
            <EmptyDescription>
              {typeof description === 'string' ? (
                <p>{description}</p>
              ) : (
                description
              )}
            </EmptyDescription>
          )}
        </EmptyHeader>
      )}

      {/* Custom content */}
      {children && <EmptyContent>{children}</EmptyContent>}

      {/* Actions */}
      {(actionLabel || secondaryActionLabel) && (
        <EmptyContent>
          <Flex direction="row" gap={2}>
            {actionLabel && (
              <Button
                variant={actionVariant}
                size={actionSize}
                onClick={onAction}
                isLoading={actionLoading}
                disabled={actionLoading}
                data-testid={actionTestId}
              >
                {actionIcon && !actionLoading && <Icon type={actionIcon} />}
                {actionLabel}
              </Button>
            )}

            {secondaryActionLabel && (
              <Button
                variant={secondaryActionVariant}
                size={secondaryActionSize}
                onClick={onSecondaryAction}
                data-testid={secondaryActionTestId}
              >
                {secondaryActionLabel}
              </Button>
            )}
          </Flex>
        </EmptyContent>
      )}
    </Empty>
  );
};

EmptyState.displayName = 'EmptyState';

export { EmptyState, type IEmptyStateProps };
