import type { Meta, StoryObj } from '@storybook/react';
import { StepCard, EStepState } from './step-card';
import { Flex } from '../primitives/flex';

const meta: Meta<typeof StepCard> = {
  title: 'Design System/Components/Step Card',
  component: StepCard,
  tags: ['autodocs'],
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A step card component that displays step progress with numbered indicators. Supports pending, active, and completed states. Can be interactive (with onClick) or display-only.',
      },
    },
  },
  argTypes: {
    stepNumber: {
      control: { type: 'number' },
      description: 'Step number to display in the indicator',
    },
    label: {
      control: { type: 'text' },
      description: 'Primary label/title for the step',
    },
    description: {
      control: { type: 'text' },
      description: 'Optional description text (displayed below the label)',
    },
    state: {
      control: { type: 'select' },
      options: Object.values(EStepState),
      description: 'Current state of the step',
    },
    onClick: {
      action: 'clicked',
      description: 'Optional click handler (makes the component interactive)',
    },
    className: {
      control: { type: 'text' },
      description: 'Optional className for custom styling',
    },
  },
};

export default meta;
type Story = StoryObj<typeof StepCard>;

// Basic pending step
export const Pending: Story = {
  args: {
    stepNumber: 1,
    label: 'Configure',
    state: EStepState.Pending,
  },
};

// Active step
export const Active: Story = {
  args: {
    stepNumber: 1,
    label: 'Configure',
    state: EStepState.Active,
  },
};

// Completed step
export const Completed: Story = {
  args: {
    stepNumber: 1,
    label: 'Configure',
    state: EStepState.Completed,
  },
};

// With description
export const WithDescription: Story = {
  args: {
    stepNumber: 1,
    label: 'Configure',
    description: 'Set up your configuration settings',
    state: EStepState.Active,
  },
};

// Interactive step (clickable)
export const Interactive: Story = {
  args: {
    stepNumber: 1,
    label: 'Configure',
    description: 'Click to edit this step',
    state: EStepState.Completed,
    onClick: () => console.log('Step clicked'),
  },
};

// Interactive pending (disabled)
export const InteractivePending: Story = {
  args: {
    stepNumber: 2,
    label: 'Review',
    description: 'Not available yet',
    state: EStepState.Pending,
    onClick: () => console.log('Step clicked'),
  },
};

// Step progress flow example
export const StepProgressFlow: Story = {
  render: () => (
    <Flex gap={2} className="w-full max-w-2xl">
      <StepCard
        stepNumber={1}
        label="Configure"
        description="Set up settings"
        state={EStepState.Completed}
        onClick={() => console.log('Go to step 1')}
      />
      <StepCard
        stepNumber={2}
        label="Map Inputs"
        description="Connect your data"
        state={EStepState.Active}
        onClick={() => console.log('Go to step 2')}
      />
      <StepCard
        stepNumber={3}
        label="Test"
        description="Verify setup"
        state={EStepState.Pending}
        onClick={() => console.log('Go to step 3')}
      />
    </Flex>
  ),
};

// Display only (no click handlers)
export const DisplayOnly: Story = {
  render: () => (
    <Flex gap={2} className="w-full max-w-2xl">
      <StepCard stepNumber={1} label="Step 1" state={EStepState.Completed} />
      <StepCard stepNumber={2} label="Step 2" state={EStepState.Active} />
      <StepCard stepNumber={3} label="Step 3" state={EStepState.Pending} />
    </Flex>
  ),
};

// Compact (without descriptions)
export const Compact: Story = {
  render: () => (
    <Flex gap={2} className="w-full max-w-md">
      <StepCard stepNumber={1} label="Setup" state={EStepState.Completed} />
      <StepCard stepNumber={2} label="Review" state={EStepState.Active} />
      <StepCard stepNumber={3} label="Done" state={EStepState.Pending} />
    </Flex>
  ),
};
