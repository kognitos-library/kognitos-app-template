import type { Meta, StoryObj } from '@storybook/react-vite';

const meta: Meta = {
  title: 'Introduction',
  parameters: {
    layout: 'fullscreen',
    docs: {
      autodocs: true,
      description: {
        component:
          'Welcome to our modern design system! This showcases the new Storybook theming and features.',
      },
    },
  },
};

export default meta;
type Story = StoryObj;

// Introduction Component
const IntroductionComponent = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-brand/20 to-gray-400/10"></div>
        <div className="relative container mx-auto px-6 py-16">
          <div className="text-center space-y-8">
            <div className="space-y-4">
              <h1 className="text-6xl font-bold text-gray-900 dark:text-gray-300">
                Lattice Design System
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                A modern, accessible, and beautiful design system built with
                React, TypeScript, and Tailwind CSS. Explore our components,
                design tokens, and guidelines.
              </p>
            </div>

            {/* Feature Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
              {[
                {
                  icon: '⚡',
                  title: 'Fast & Modern',
                  description:
                    'Built with the latest technologies for optimal performance',
                },
                {
                  icon: '♿',
                  title: 'Accessible',
                  description:
                    'WCAG 2.1 AA compliant components out of the box',
                },
                {
                  icon: '🎨',
                  title: 'Customizable',
                  description:
                    'Flexible theming system with light and dark modes',
                },
              ].map(feature => (
                <div
                  key={feature.title}
                  className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg border border-gray-200 dark:border-gray-700 hover:border-brand/30 transition-colors"
                >
                  <div className="text-4xl mb-4">{feature.icon}</div>
                  <div className="text-lg font-semibold mb-2 text-gray-800 dark:text-gray-200">
                    {feature.title}
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {feature.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Content Sections */}
      <div className="container mx-auto px-6 py-8">
        <div className="max-w-4xl mx-auto space-y-12">
          {/* Overview Section */}
          <div className="bg-white dark:bg-slate-800 rounded-xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
            <h2 className="text-2xl font-bold mb-6">Overview</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              This Design System is built with modern web development practices
              in mind, focusing on:
            </p>
            <ul className="space-y-2 text-gray-600 dark:text-gray-400">
              <li className="flex items-start">
                <span className="text-yellow-500 mr-2">•</span>
                <strong>Design Consistency:</strong> A unified design language
                that ensures coherent user experiences
              </li>
              <li className="flex items-start">
                <span className="text-yellow-500 mr-2">•</span>
                <strong>Accessibility:</strong> Components built with WCAG
                guidelines in mind
              </li>
              <li className="flex items-start">
                <span className="text-yellow-500 mr-2">•</span>
                <strong>Performance:</strong> Optimized components that maintain
                smooth application performance
              </li>
              <li className="flex items-start">
                <span className="text-yellow-500 mr-2">•</span>
                <strong>Flexibility:</strong> Customizable components that adapt
                to various use cases
              </li>
              <li className="flex items-start">
                <span className="text-yellow-500 mr-2">•</span>
                <strong>Type Safety:</strong> Full TypeScript support for better
                development experience
              </li>
            </ul>
          </div>

          {/* Categories Section */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
            <h2 className="text-2xl font-bold mb-6">Categories</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Our Design System is organized into the following categories:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                <h3 className="font-semibold mb-2">Components</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Reusable UI components for presenting information effectively
                </p>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <h3 className="font-semibold mb-2">Primitives</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Low-level building blocks and foundational components
                </p>
              </div>
              <div className="p-4 bg-brand/10 dark:bg-brand/20 rounded-lg border border-brand/20">
                <h3 className="font-semibold mb-2">Themes</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Design tokens, colors, and styling utilities
                </p>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
                <h3 className="font-semibold mb-2">Hooks</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Custom React hooks for enhanced functionality
                </p>
              </div>
            </div>
          </div>

          {/* Getting Started Section */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
            <h2 className="text-2xl font-bold mb-6">Getting Started</h2>

            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold mb-3">Installation</h3>
                <p className="text-xs text-muted-foreground mb-2">
                  Published to GitHub Package Registry. Configure your .npmrc to
                  use the @kognitos scope from GitHub.
                </p>
                <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg text-sm overflow-x-auto">
                  npm install @kognitos/lattice
                </pre>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-3">Setup</h3>
                <p className="text-xs text-muted-foreground mb-2">
                  Import the theme CSS in your app entry point:
                </p>
                <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg text-sm overflow-x-auto">
                  {`import '@kognitos/lattice/theme.css';
import '@kognitos/lattice/fonts.css';`}
                </pre>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-3">Basic Usage</h3>
                <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg text-sm overflow-x-auto">
                  {`import { Button, Card } from '@kognitos/lattice';

function MyComponent() {
  return (
    <Card>
      <Button variant="default">Get Started</Button>
    </Card>
  );
}`}
                </pre>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-3">Quick Import</h3>
                <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg text-sm overflow-x-auto">
                  import {'{ Button, Card }'} from '@kognitos/lattice';
                </pre>
              </div>
            </div>
          </div>

          {/* Design Principles Section */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
            <h2 className="text-2xl font-bold mb-6">Design Principles</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Our Design System is built on these core principles:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                <h3 className="font-semibold mb-2 text-gray-800 dark:text-gray-200">
                  Consistency
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Unified visual language and behavior across all components
                </p>
              </div>
              <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                <h3 className="font-semibold mb-2">Simplicity</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Clear, intuitive interfaces that are easy to understand
                </p>
              </div>
              <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                <h3 className="font-semibold mb-2">Flexibility</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Adaptable components that work in different contexts
                </p>
              </div>
              <div className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg">
                <h3 className="font-semibold mb-2">Performance</h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Optimized components for production use
                </p>
              </div>
            </div>
          </div>

          {/* Technology Stack Section */}
          <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-lg border border-gray-200 dark:border-gray-700">
            <h2 className="text-2xl font-bold mb-6">Technology Stack</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-gray-700 dark:text-gray-300">
                  React 19
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-gray-700 dark:text-gray-300">
                  TypeScript
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-gray-700 dark:text-gray-300">
                  Tailwind CSS
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-gray-700 dark:text-gray-300">
                  Radix UI
                </span>
              </div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-gray-500 rounded-full"></div>
                <span className="text-gray-700 dark:text-gray-300">
                  Storybook 9
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-gray-200 dark:border-gray-700 mt-16">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              @kognitos/lattice v1.1.1 • Built with ❤️ using React, TypeScript,
              and Tailwind CSS
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export const Introduction: Story = {
  render: IntroductionComponent,
};
