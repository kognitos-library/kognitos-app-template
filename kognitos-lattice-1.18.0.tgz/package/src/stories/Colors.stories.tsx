import type { Meta, StoryObj } from '@storybook/react-vite';
import { themeColors, baseColors } from '../tokens/colors';

const meta: Meta = {
  title: 'Design System/Tokens/Colors',
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Color tokens used throughout the design system. These colors automatically adapt to light and dark themes.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
};

export default meta;
type Story = StoryObj;

// Color Swatch Component
const ColorSwatch = ({
  name,
  color,
  description,
}: {
  name: string;
  color: string;
  description?: string;
}) => (
  <div className="flex flex-col space-y-2">
    <div
      className="w-20 h-20 rounded-lg border border-border shadow-sm"
      style={{ backgroundColor: color }}
    />
    <div className="text-sm">
      <div className="font-medium text-foreground">{name}</div>
      <div className="text-muted-foreground text-xs font-mono">{color}</div>
      {description && (
        <div className="text-muted-foreground text-xs mt-1">{description}</div>
      )}
    </div>
  </div>
);

// Theme Colors Story
export const ThemeColors: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Theme colors that automatically adapt to light and dark themes using CSS variables. These colors provide semantic meaning and consistent theming across the application.',
      },
    },
  },
  render: () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-4">
          Theme Colors
        </h2>
        <p className="text-muted-foreground mb-6">
          These colors automatically adapt to light and dark themes using CSS
          variables.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {Object.entries(themeColors).map(([name, color]) => (
            <ColorSwatch
              key={name}
              name={name}
              color={color}
              description={
                name.includes('foreground')
                  ? 'Text color'
                  : name.includes('background')
                    ? 'Background color'
                    : name.includes('border')
                      ? 'Border color'
                      : name.includes('ring')
                        ? 'Focus ring color'
                        : name.includes('chart')
                          ? 'Chart color'
                          : name.includes('sidebar')
                            ? 'Sidebar color'
                            : 'Semantic color'
              }
            />
          ))}
        </div>
      </div>
    </div>
  ),
};

// Base Colors Story
export const BaseColors: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Base colors that remain constant regardless of theme. These are fundamental colors used as building blocks for the design system.',
      },
    },
  },
  render: () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-4">Base Colors</h2>
        <p className="text-muted-foreground mb-6">
          Fundamental colors that don't change with theme.
        </p>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {Object.entries(baseColors).map(([name, color]) => (
            <ColorSwatch
              key={name}
              name={name}
              color={color}
              description="Base color"
            />
          ))}
        </div>
      </div>
    </div>
  ),
};

// Color Categories Story
export const ColorCategories: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Colors organized by their semantic meaning and usage patterns. This categorization helps developers understand when and how to use each color in the design system.',
      },
    },
  },
  render: () => (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-4">
          Color Categories
        </h2>
        <p className="text-muted-foreground mb-6">
          Colors organized by their semantic meaning and usage.
        </p>

        {/* Primary Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Primary Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ColorSwatch
              name="primary"
              color={themeColors.primary}
              description="Main brand color"
            />
            <ColorSwatch
              name="primary-foreground"
              color={themeColors['primary-foreground']}
              description="Text on primary"
            />
          </div>
        </div>

        {/* Secondary Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Secondary Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ColorSwatch
              name="secondary"
              color={themeColors.secondary}
              description="Secondary brand color"
            />
            <ColorSwatch
              name="secondary-foreground"
              color={themeColors['secondary-foreground']}
              description="Text on secondary"
            />
          </div>
        </div>

        {/* Background Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Background Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ColorSwatch
              name="background"
              color={themeColors.background}
              description="Main background"
            />
            <ColorSwatch
              name="card"
              color={themeColors.card}
              description="Card background"
            />
            <ColorSwatch
              name="popover"
              color={themeColors.popover}
              description="Popover background"
            />
            <ColorSwatch
              name="muted"
              color={themeColors.muted}
              description="Muted background"
            />
          </div>
        </div>

        {/* Text Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Text Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ColorSwatch
              name="foreground"
              color={themeColors.foreground}
              description="Primary text"
            />
            <ColorSwatch
              name="muted-foreground"
              color={themeColors['muted-foreground']}
              description="Muted text"
            />
            <ColorSwatch
              name="card-foreground"
              color={themeColors['card-foreground']}
              description="Text on cards"
            />
            <ColorSwatch
              name="popover-foreground"
              color={themeColors['popover-foreground']}
              description="Text on popovers"
            />
          </div>
        </div>

        {/* Interactive Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Interactive Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ColorSwatch
              name="accent"
              color={themeColors.accent}
              description="Accent color"
            />
            <ColorSwatch
              name="accent-foreground"
              color={themeColors['accent-foreground']}
              description="Text on accent"
            />
            <ColorSwatch
              name="destructive"
              color={themeColors.destructive}
              description="Error/danger color"
            />
          </div>
        </div>

        {/* Border & Input Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Border & Input Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ColorSwatch
              name="border"
              color={themeColors.border}
              description="Border color"
            />
            <ColorSwatch
              name="input"
              color={themeColors.input}
              description="Input background"
            />
            <ColorSwatch
              name="ring"
              color={themeColors.ring}
              description="Focus ring"
            />
          </div>
        </div>

        {/* Chart Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Chart Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
            <ColorSwatch
              name="chart-1"
              color={themeColors['chart-1']}
              description="Chart color 1"
            />
            <ColorSwatch
              name="chart-2"
              color={themeColors['chart-2']}
              description="Chart color 2"
            />
            <ColorSwatch
              name="chart-3"
              color={themeColors['chart-3']}
              description="Chart color 3"
            />
            <ColorSwatch
              name="chart-4"
              color={themeColors['chart-4']}
              description="Chart color 4"
            />
            <ColorSwatch
              name="chart-5"
              color={themeColors['chart-5']}
              description="Chart color 5"
            />
            <ColorSwatch
              name="chart-6"
              color={themeColors['chart-6']}
              description="Chart color 6"
            />
            <ColorSwatch
              name="chart-7"
              color={themeColors['chart-7']}
              description="Chart color 7"
            />
            <ColorSwatch
              name="chart-8"
              color={themeColors['chart-8']}
              description="Chart color 8"
            />
            <ColorSwatch
              name="chart-9"
              color={themeColors['chart-9']}
              description="Chart color 9"
            />
            <ColorSwatch
              name="chart-10"
              color={themeColors['chart-10']}
              description="Chart color 10"
            />
          </div>
        </div>

        {/* Sidebar Colors */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-foreground mb-4">
            Sidebar Colors
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <ColorSwatch
              name="sidebar"
              color={themeColors.sidebar}
              description="Sidebar background"
            />
            <ColorSwatch
              name="sidebar-foreground"
              color={themeColors['sidebar-foreground']}
              description="Sidebar text"
            />
            <ColorSwatch
              name="sidebar-primary"
              color={themeColors['sidebar-primary']}
              description="Sidebar primary"
            />
            <ColorSwatch
              name="sidebar-primary-foreground"
              color={themeColors['sidebar-primary-foreground']}
              description="Text on sidebar primary"
            />
            <ColorSwatch
              name="sidebar-accent"
              color={themeColors['sidebar-accent']}
              description="Sidebar accent"
            />
            <ColorSwatch
              name="sidebar-accent-foreground"
              color={themeColors['sidebar-accent-foreground']}
              description="Text on sidebar accent"
            />
            <ColorSwatch
              name="sidebar-border"
              color={themeColors['sidebar-border']}
              description="Sidebar border"
            />
            <ColorSwatch
              name="sidebar-ring"
              color={themeColors['sidebar-ring']}
              description="Sidebar focus ring"
            />
          </div>
        </div>
      </div>
    </div>
  ),
};
