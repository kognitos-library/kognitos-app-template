import { render, screen, fireEvent } from '@testing-library/react';
import { StepperCard, type IStepperCardItemData } from './stepper-card';
import { describe, expect, it, vi } from 'vitest';

describe('StepperCard', () => {
  const defaultSteps: IStepperCardItemData[] = [
    { key: '1', title: 'Step 1' },
    { key: '2', title: 'Step 2' },
    { key: '3', title: 'Step 3' },
  ];

  describe('rendering', () => {
    it('should render all steps with titles and step numbers', () => {
      render(<StepperCard steps={defaultSteps} />);

      expect(screen.getByText('Step 1')).toBeInTheDocument();
      expect(screen.getByText('Step 2')).toBeInTheDocument();
      expect(screen.getByText('Step 3')).toBeInTheDocument();
      expect(screen.getByText('1')).toBeInTheDocument();
      expect(screen.getByText('2')).toBeInTheDocument();
      expect(screen.getByText('3')).toBeInTheDocument();
    });

    it('should render empty when no steps provided', () => {
      const { container } = render(<StepperCard steps={[]} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toBeInTheDocument();
      expect(stepperCard?.children).toHaveLength(0);
    });
  });

  describe('direction', () => {
    it('should default to row direction', () => {
      const { container } = render(<StepperCard steps={defaultSteps} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('flex-row');
    });

    it('should apply column direction when specified', () => {
      const { container } = render(
        <StepperCard steps={defaultSteps} direction="column" />,
      );

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('flex-col');
    });
  });

  describe('current selection', () => {
    it('should set SELECTED variant on the defaultCurrent step', () => {
      render(<StepperCard steps={defaultSteps} defaultCurrent="2" />);

      const stepperCard2 = screen
        .getByText('Step 2')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard2).toHaveAttribute('data-variant', 'selected');
      expect(stepperCard2).toHaveAttribute('aria-current', 'true');
    });

    it('should not set SELECTED variant on non-current steps', () => {
      render(<StepperCard steps={defaultSteps} defaultCurrent="2" />);

      const stepperCard1 = screen
        .getByText('Step 1')
        .closest('[data-slot="stepper-card-item"]');
      const stepperCard3 = screen
        .getByText('Step 3')
        .closest('[data-slot="stepper-card-item"]');

      expect(stepperCard1).toHaveAttribute('data-variant', 'default');
      expect(stepperCard3).toHaveAttribute('data-variant', 'default');
    });

    it('should default to first step when defaultCurrent is not provided', () => {
      render(<StepperCard steps={defaultSteps} />);

      const stepperCard1 = screen
        .getByText('Step 1')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard1).toHaveAttribute('data-variant', 'selected');
    });
  });

  describe('uncontrolled mode', () => {
    it('should select clicked step and update internal state', () => {
      render(<StepperCard steps={defaultSteps} defaultCurrent="1" />);

      // Initially Step 1 is selected
      const stepperCard1 = screen
        .getByText('Step 1')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard1).toHaveAttribute('data-variant', 'selected');

      // Click Step 2
      const stepperCard2 = screen
        .getByText('Step 2')
        .closest('[data-slot="stepper-card-item"]');
      fireEvent.click(stepperCard2!);

      // Step 2 should now be selected
      expect(stepperCard2).toHaveAttribute('data-variant', 'selected');
      // Step 1 should no longer be selected
      expect(stepperCard1).toHaveAttribute('data-variant', 'default');
    });

    it('should not select disabled step when clicked', () => {
      const steps: IStepperCardItemData[] = [
        { key: '1', title: 'Step 1' },
        { key: '2', title: 'Step 2', state: 'disabled' },
      ];

      render(<StepperCard steps={steps} defaultCurrent="1" />);

      const stepperCard1 = screen
        .getByText('Step 1')
        .closest('[data-slot="stepper-card-item"]');
      const stepperCard2 = screen
        .getByText('Step 2')
        .closest('[data-slot="stepper-card-item"]');

      // Click disabled Step 2
      fireEvent.click(stepperCard2!);

      // Step 1 should still be selected
      expect(stepperCard1).toHaveAttribute('data-variant', 'selected');
      // Step 2 should not be selected
      expect(stepperCard2).toHaveAttribute('data-variant', 'default');
    });

    it('should call onStepClick callback when step is clicked', () => {
      const onStepClick = vi.fn();
      render(
        <StepperCard
          steps={defaultSteps}
          defaultCurrent="1"
          onStepClick={onStepClick}
        />,
      );

      const stepperCard2 = screen
        .getByText('Step 2')
        .closest('[data-slot="stepper-card-item"]');
      fireEvent.click(stepperCard2!);

      expect(onStepClick).toHaveBeenCalledTimes(1);
      expect(onStepClick).toHaveBeenCalledWith('2');
    });
  });

  describe('controlled mode', () => {
    it('should use current prop for selection', () => {
      render(<StepperCard steps={defaultSteps} current="2" />);

      const stepperCard2 = screen
        .getByText('Step 2')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard2).toHaveAttribute('data-variant', 'selected');
    });

    it('should not update internal state when clicking in controlled mode', () => {
      const onStepClick = vi.fn();
      render(
        <StepperCard
          steps={defaultSteps}
          current="1"
          onStepClick={onStepClick}
        />,
      );

      // Step 1 is selected (controlled)
      const stepperCard1 = screen
        .getByText('Step 1')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard1).toHaveAttribute('data-variant', 'selected');

      // Click Step 2
      const stepperCard2 = screen
        .getByText('Step 2')
        .closest('[data-slot="stepper-card-item"]');
      fireEvent.click(stepperCard2!);

      // Callback should be called
      expect(onStepClick).toHaveBeenCalledWith('2');

      // But Step 1 should still be selected (parent didn't update current)
      expect(stepperCard1).toHaveAttribute('data-variant', 'selected');
      expect(stepperCard2).toHaveAttribute('data-variant', 'default');
    });

    it('should update selection when parent changes current prop', () => {
      const { rerender } = render(
        <StepperCard steps={defaultSteps} current="1" />,
      );

      const stepperCard1 = screen
        .getByText('Step 1')
        .closest('[data-slot="stepper-card-item"]');
      const stepperCard2 = screen
        .getByText('Step 2')
        .closest('[data-slot="stepper-card-item"]');

      expect(stepperCard1).toHaveAttribute('data-variant', 'selected');

      // Parent updates current prop
      rerender(<StepperCard steps={defaultSteps} current="2" />);

      expect(stepperCard2).toHaveAttribute('data-variant', 'selected');
      expect(stepperCard1).toHaveAttribute('data-variant', 'default');
    });
  });

  describe('responsive grid layout', () => {
    it('should render as grid when xs prop is provided', () => {
      const { container } = render(<StepperCard steps={defaultSteps} xs={1} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('grid');
      expect(stepperCard).toHaveClass('grid-cols-1');
    });

    it('should render as grid when sm prop is provided', () => {
      const { container } = render(<StepperCard steps={defaultSteps} sm={2} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('grid');
      expect(stepperCard).toHaveClass('sm:grid-cols-2');
    });

    it('should render as grid when md prop is provided', () => {
      const { container } = render(<StepperCard steps={defaultSteps} md={3} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('grid');
      expect(stepperCard).toHaveClass('md:grid-cols-3');
    });

    it('should render as grid when lg prop is provided', () => {
      const { container } = render(<StepperCard steps={defaultSteps} lg={4} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('grid');
      expect(stepperCard).toHaveClass('lg:grid-cols-4');
    });

    it('should apply multiple responsive breakpoints', () => {
      const { container } = render(
        <StepperCard steps={defaultSteps} xs={1} sm={2} md={3} lg={4} />,
      );

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('grid');
      expect(stepperCard).toHaveClass('grid-cols-1');
      expect(stepperCard).toHaveClass('sm:grid-cols-2');
      expect(stepperCard).toHaveClass('md:grid-cols-3');
      expect(stepperCard).toHaveClass('lg:grid-cols-4');
    });

    it('should default xs to 1 column when other breakpoints are provided', () => {
      const { container } = render(<StepperCard steps={defaultSteps} md={3} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('grid-cols-1');
    });

    it('should render as flex when no responsive props are provided', () => {
      const { container } = render(<StepperCard steps={defaultSteps} />);

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).not.toHaveClass('grid');
      expect(stepperCard).toHaveClass('flex-row');
    });

    it('should ignore direction prop when responsive props are provided', () => {
      const { container } = render(
        <StepperCard steps={defaultSteps} direction="column" xs={2} />,
      );

      const stepperCard = container.querySelector('[data-slot="stepper-card"]');
      expect(stepperCard).toHaveClass('grid');
      expect(stepperCard).not.toHaveClass('flex-col');
    });
  });
});
