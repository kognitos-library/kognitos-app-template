import { render, screen } from '@testing-library/react';
import { ShimmeringText } from './shimmering-text';
import { describe, expect, it } from 'vitest';

describe('ShimmeringText', () => {
  describe('Text Splitting', () => {
    it('should split text into individual characters', () => {
      render(<ShimmeringText text="Hello" />);

      // Verify container has default test ID
      const container = screen.getByTestId('shimmering-text');
      expect(container).toBeInTheDocument();

      // Verify each character span has test ID
      expect(screen.getByTestId('shimmering-text-char-0')).toHaveTextContent(
        'H',
      );
      expect(screen.getByTestId('shimmering-text-char-1')).toHaveTextContent(
        'e',
      );
      expect(screen.getByTestId('shimmering-text-char-2')).toHaveTextContent(
        'l',
      );
      expect(screen.getByTestId('shimmering-text-char-3')).toHaveTextContent(
        'l',
      );
      expect(screen.getByTestId('shimmering-text-char-4')).toHaveTextContent(
        'o',
      );

      // Verify all characters are present
      expect(screen.getByText('H')).toBeInTheDocument();
      expect(screen.getByText('e')).toBeInTheDocument();
      const lChars = screen.getAllByText('l');
      expect(lChars.length).toBe(2); // Two 'l' characters
      expect(screen.getByText('o')).toBeInTheDocument();
    });

    it('should handle empty string', () => {
      render(<ShimmeringText text="" />);
      const container = screen.getByTestId('shimmering-text');
      expect(container).toBeInTheDocument();
    });

    it('should handle single character', () => {
      render(<ShimmeringText text="A" />);
      expect(screen.getByText('A')).toBeInTheDocument();
    });

    it('should handle whitespace characters', () => {
      render(<ShimmeringText text="Hello World" />);

      const container = screen.getByTestId('shimmering-text');

      // Verify space character has test ID and contains space
      const spaceChar = screen.getByTestId('shimmering-text-char-5');
      expect(spaceChar).toBeInTheDocument();
      expect(spaceChar.textContent).toBe(' ');

      // Verify characters are present
      expect(screen.getByText('H')).toBeInTheDocument();
      expect(screen.getByText('W')).toBeInTheDocument();

      // Verify space is rendered (check by container text content)
      expect(container.textContent).toContain('Hello World');
    });

    it('should handle special characters', () => {
      render(<ShimmeringText text="Hello!" />);

      expect(screen.getByText('H')).toBeInTheDocument();
      expect(screen.getByText('!')).toBeInTheDocument();
    });

    it('should handle unicode characters', () => {
      render(<ShimmeringText text="Hello 🌟" />);
      const container = screen.getByTestId('shimmering-text');

      // Verify characters are rendered
      expect(screen.getByText('H')).toBeInTheDocument();

      // Verify emoji is present in the container (may be split into multiple spans)
      expect(container.textContent).toContain('Hello');
      expect(container.textContent).toContain('🌟');
    });
  });

  describe('Animation Props', () => {
    it('should render with default duration', () => {
      render(<ShimmeringText text="Test" />);

      const container = screen.getByTestId('shimmering-text');
      expect(container).toBeInTheDocument();

      // Verify character spans exist
      expect(screen.getByTestId('shimmering-text-char-0')).toBeInTheDocument();
      expect(screen.getByTestId('shimmering-text-char-3')).toBeInTheDocument();
    });

    it('should apply custom duration', () => {
      render(<ShimmeringText text="Test" duration={2} />);
      const container = screen.getByTestId('shimmering-text');
      expect(container).toBeInTheDocument();
    });

    it('should handle wave animation when enabled', () => {
      render(<ShimmeringText text="Wave" wave />);
      const container = screen.getByTestId('shimmering-text');
      expect(container).toBeInTheDocument();
    });

    it('should not apply wave animation when disabled', () => {
      render(<ShimmeringText text="No Wave" wave={false} />);
      const container = screen.getByTestId('shimmering-text');
      expect(container).toBeInTheDocument();
    });
  });

  describe('Color Variations', () => {
    it('should use default colors', () => {
      render(<ShimmeringText text="Default" />);
      const container = screen.getByTestId('shimmering-text');

      expect(container).toBeInTheDocument();
      expect(container).toHaveStyle({
        '--color': 'var(--muted-foreground)',
        '--shimmering-color': 'var(--foreground)',
      });
    });

    it('should apply custom color', () => {
      render(<ShimmeringText text="Custom" color="#ff0000" />);
      const container = screen.getByTestId('shimmering-text');

      expect(container).toBeInTheDocument();
      expect(container).toHaveStyle({
        '--color': '#ff0000',
      });
    });

    it('should apply custom shimmering color', () => {
      render(<ShimmeringText text="Shimmer" shimmeringColor="#00ff00" />);
      const container = screen.getByTestId('shimmering-text');

      expect(container).toBeInTheDocument();
      expect(container).toHaveStyle({
        '--shimmering-color': '#00ff00',
      });
    });

    it('should apply both custom colors', () => {
      render(
        <ShimmeringText
          text="Both"
          color="#0000ff"
          shimmeringColor="#ffff00"
        />,
      );
      const container = screen.getByTestId('shimmering-text');

      expect(container).toBeInTheDocument();
      expect(container).toHaveStyle({
        '--color': '#0000ff',
        '--shimmering-color': '#ffff00',
      });
    });
  });

  describe('Styling', () => {
    it('should apply inline styles to container', () => {
      render(<ShimmeringText text="Styled" />);
      const container = screen.getByTestId('shimmering-text');

      expect(container).toBeInTheDocument();
      expect(container).toHaveStyle({
        position: 'relative',
        display: 'inline-block',
        perspective: '500px',
      });
    });

    it('should apply whiteSpace: pre to character spans', () => {
      render(<ShimmeringText text="Test" />);

      // Verify character spans exist and have correct styling
      const charSpan = screen.getByTestId('shimmering-text-char-0');
      expect(charSpan).toBeInTheDocument();
      expect(charSpan).toHaveStyle({
        whiteSpace: 'pre',
      });
    });
  });

  describe('Additional Props', () => {
    it('should allow custom test ID', () => {
      render(<ShimmeringText text="Props" data-testid="custom-test-id" />);

      const element = screen.getByTestId('custom-test-id');
      expect(element).toBeInTheDocument();

      // Verify character spans use custom test ID prefix
      expect(screen.getByTestId('custom-test-id-char-0')).toHaveTextContent(
        'P',
      );
    });

    it('should apply custom className', () => {
      render(<ShimmeringText text="Class" className="custom-class" />);
      const container = screen.getByTestId('shimmering-text');

      expect(container).toBeInTheDocument();
      expect(container).toHaveClass('custom-class');
    });

    it('should apply custom style', () => {
      render(<ShimmeringText text="Style" style={{ marginTop: '10px' }} />);
      const container = screen.getByTestId('shimmering-text');

      expect(container).toBeInTheDocument();
      expect(container).toHaveStyle({
        marginTop: '10px',
      });
    });
  });

  describe('Edge Cases', () => {
    it('should handle very long text', () => {
      const longText = 'A'.repeat(100);
      render(<ShimmeringText text={longText} />);

      const container = screen.getByTestId('shimmering-text');
      expect(container).toBeInTheDocument();

      // Verify first and last character spans have test IDs
      expect(screen.getByTestId('shimmering-text-char-0')).toHaveTextContent(
        'A',
      );
      expect(screen.getByTestId('shimmering-text-char-99')).toHaveTextContent(
        'A',
      );

      // Should render all characters
      const characters = screen.getAllByText('A');
      expect(characters.length).toBe(100);
    });

    it('should handle text with newlines', () => {
      render(<ShimmeringText text="Line1\nLine2" />);
      const container = screen.getByTestId('shimmering-text');

      // Verify newline character span exists
      const newlineChar = screen.getByTestId('shimmering-text-char-5');
      expect(newlineChar).toBeInTheDocument();

      // Verify all character spans exist (text is split into individual characters)
      const allCharSpans = screen.getAllByTestId(/shimmering-text-char-\d+/);
      expect(allCharSpans.length).toBeGreaterThan(0);

      // Verify newline is present in container and text is split correctly
      expect(container.textContent).toContain('Line1');
      expect(container.textContent).toContain('Line2');
    });

    it('should handle text with tabs', () => {
      render(<ShimmeringText text="Tab\tText" />);
      const container = screen.getByTestId('shimmering-text');

      // Verify tab character span exists
      const tabChar = screen.getByTestId('shimmering-text-char-3');
      expect(tabChar).toBeInTheDocument();

      // Verify all character spans exist (text is split into individual characters)
      const allCharSpans = screen.getAllByTestId(/shimmering-text-char-\d+/);
      expect(allCharSpans.length).toBeGreaterThan(0);

      // Verify tab is present in container and text is split correctly
      expect(container.textContent).toContain('Tab');
      expect(container.textContent).toContain('Text');
    });
  });

  describe('Combined Props', () => {
    it('should work with all props together', () => {
      render(
        <ShimmeringText
          text="Complete"
          duration={1.5}
          wave
          color="#123456"
          shimmeringColor="#abcdef"
          className="test-class"
          data-testid="complete-test"
        />,
      );

      const element = screen.getByTestId('complete-test');
      expect(element).toBeInTheDocument();
      expect(element).toHaveClass('test-class');

      // Verify character spans use custom test ID
      expect(screen.getByTestId('complete-test-char-0')).toHaveTextContent('C');
    });
  });
});
