import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Text } from './typography';

describe('Text', () => {
  describe('Code Block Wrapping and Styling', () => {
    it('should apply wrapping classes and prevent overflow for code blocks', () => {
      const longCodeLine =
        'const veryLongVariableNameThatShouldWrap = "This is a very long string that should cause the code block to wrap to multiple lines instead of overflowing horizontally"';
      const multiLineCode = `function example() {
  const x = 1;
  const y = 2;
  return x + y;
}`;

      render(
        <div style={{ width: '200px' }}>
          <Text type="code" data-testid="code-block">
            {longCodeLine}
          </Text>
          <Text type="code" data-testid="code-block-multiline">
            {multiLineCode}
          </Text>
        </div>,
      );

      const codeElement = screen.getByTestId('code-block');
      expect(codeElement).toBeInTheDocument();
      expect(codeElement.tagName).toBe('CODE');

      // Verify wrapping classes are applied
      expect(codeElement).toHaveClass('whitespace-pre-wrap');
      expect(codeElement).toHaveClass('break-words');
      expect(codeElement).toHaveClass('block');
      expect(codeElement).toHaveClass('w-full');
      // Should not have horizontal scroll
      expect(codeElement).not.toHaveClass('overflow-x-auto');

      // Verify base styling classes
      expect(codeElement).toHaveClass('font-mono');
      expect(codeElement).toHaveClass('bg-muted');
      expect(codeElement).toHaveClass('px-4');
      expect(codeElement).toHaveClass('py-4');
      expect(codeElement).toHaveClass('rounded-md');

      // Verify multi-line code preserves whitespace
      const multiLineElement = screen.getByTestId('code-block-multiline');
      expect(multiLineElement).toHaveClass('whitespace-pre-wrap');
      expect(multiLineElement.textContent).toBe(multiLineCode);
    });
  });

  describe('Inline Code Wrapping and Styling', () => {
    it('should apply break-anywhere class and correct styling to inline code', () => {
      const longInlineCode = 'veryLongInlineCodeThatShouldWrapIfNecessary';

      render(
        <div style={{ width: '100px' }}>
          <Text type="inlineCode" data-testid="inline-code">
            inline code
          </Text>
          <Text type="inlineCode" data-testid="inline-code-long">
            {longInlineCode}
          </Text>
        </div>,
      );

      const codeElement = screen.getByTestId('inline-code');
      expect(codeElement).toBeInTheDocument();
      expect(codeElement.tagName).toBe('CODE');

      // Verify break-anywhere class is applied
      expect(codeElement).toHaveClass('break-anywhere');

      // Verify base styling classes
      expect(codeElement).toHaveClass('font-mono');
      expect(codeElement).toHaveClass('bg-muted');
      expect(codeElement).toHaveClass('px-2');
      expect(codeElement).toHaveClass('py-1');
      expect(codeElement).toHaveClass('rounded-md');

      // Verify long inline code also has break-anywhere
      const longCodeElement = screen.getByTestId('inline-code-long');
      expect(longCodeElement).toHaveClass('break-anywhere');
    });
  });
});
