import { render, screen } from '@testing-library/react';
import { Asset, AssetType } from './asset';
import { describe, it, expect } from 'vitest';

describe('AssetType', () => {
  describe('Rendering', () => {
    it('should render Folder icon for Folder type', () => {
      const { container } = render(<AssetType type="folder" />);

      const icon = container.querySelector('.lucide-folder');
      expect(icon).toBeInTheDocument();
    });

    it('should render FileType icon for Document type', () => {
      const { container } = render(<AssetType type="document" />);

      const icon = container.querySelector('.lucide-file-type');
      expect(icon).toBeInTheDocument();
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      const { container } = render(
        <AssetType type="folder" className="custom-class" />,
      );

      const assetType = container.firstChild;
      expect(assetType).toHaveClass('custom-class');
    });

    it('should have rounded-md class', () => {
      const { container } = render(<AssetType type="folder" />);

      const assetType = container.firstChild;
      expect(assetType).toHaveClass('rounded-md');
    });
  });
});

describe('Asset', () => {
  describe('Rendering', () => {
    it('should render asset name', () => {
      render(<Asset name="Document.pdf" />);

      expect(screen.getByText('Document.pdf')).toBeInTheDocument();
    });

    it('should render subText in default variant', () => {
      render(
        <Asset name="test.pdf" variant="default" description="Complete" />,
      );

      expect(screen.getByText('Complete')).toBeInTheDocument();
    });
  });

  describe('Variants', () => {
    it('should render uploading variant with progress bar', () => {
      render(<Asset name="test.pdf" variant="uploading" progressValue={75} />);

      const progressBar = document.querySelector('[role="progressbar"]');
      expect(progressBar).toBeInTheDocument();
    });

    it('should render error variant with error text', () => {
      render(
        <Asset name="test.pdf" variant="error" errorText="Error message" />,
      );

      expect(screen.getByText('Error message')).toBeInTheDocument();
    });
  });

  describe('Size', () => {
    it('should render with default size', () => {
      const { container } = render(<Asset name="test.pdf" size="default" />);

      const asset = container.firstChild;
      expect(asset).toHaveClass('px-3');
      expect(asset).toHaveClass('py-2');
    });

    it('should render with sm size', () => {
      const { container } = render(<Asset name="test.pdf" size="sm" />);

      const asset = container.firstChild;
      expect(asset).toHaveClass('px-2');
      expect(asset).toHaveClass('py-1');
    });
  });

  describe('Action Icon', () => {
    it('should show action icon when showActionIcon is true', () => {
      render(<Asset name="test.pdf" showActionIcon />);

      const button = screen.getByRole('button');
      expect(button).toBeInTheDocument();
    });

    it('should hide action icon when showActionIcon is false', () => {
      render(<Asset name="test.pdf" showActionIcon={false} />);

      const button = screen.queryByRole('button');
      expect(button).not.toBeInTheDocument();
    });
  });

  describe('Show Text', () => {
    it('should show description when description is provided', () => {
      render(
        <Asset name="test.pdf" variant="default" description="Complete" />,
      );

      expect(screen.getByText('Complete')).toBeInTheDocument();
    });

    it('should show error text when error text is provided', () => {
      render(<Asset name="test.pdf" variant="error" errorText="Error" />);

      expect(screen.getByText('Error')).toBeInTheDocument();
    });
  });

  describe('Asset Type Props', () => {
    it('should render with custom asset type', () => {
      const { container } = render(<Asset name="document.pdf" type="pdf" />);

      expect(screen.getByText('document.pdf')).toBeInTheDocument();
      expect(container.querySelector('.lucide-file')).toBeInTheDocument();
    });

    it('should render with custom icon size', () => {
      const { container } = render(<Asset name="document.pdf" iconSize="lg" />);

      const icon = container.querySelector('.lucide-folder');
      expect(icon).toHaveAttribute('width', '24');
      expect(icon).toHaveAttribute('height', '24');
    });
  });
});
