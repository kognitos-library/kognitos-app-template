import type { Meta, StoryObj } from '@storybook/react-vite';
import { Input } from './input';
import { Text } from './typography';

const meta: Meta<typeof Input> = {
  title: 'Design System/Primitives/Forms/Input',
  component: Input,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A versatile input component with support for variants, various input types, validation states, and proper accessibility features. Use the default variant for standard forms, or ghost variant for inline editing.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['default', 'ghost'],
      description: 'Visual variant of the input',
      table: {
        type: { summary: 'default | ghost' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    type: {
      control: { type: 'select' },
      options: [
        'text',
        'email',
        'password',
        'number',
        'tel',
        'url',
        'search',
        'date',
        'time',
        'file',
      ],
      description: 'The type of input field',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'text' },
        category: 'Content',
      },
    },
    placeholder: {
      control: { type: 'text' },
      description: 'Placeholder text for the input',
      table: {
        type: { summary: 'string' },
        category: 'Content',
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the input is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'State',
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description: 'Whether the input has an invalid state',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'State',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Input>;

// Primary story - This will be the main showcase in autodocs
export const Primary: Story = {
  args: {
    placeholder: 'Type here...',
    variant: 'default',
    type: 'text',
    disabled: false,
  },
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'The primary input variant. Use the controls below to experiment with different variants, types, and states.',
      },
    },
  },
};

// Basic usage
export const Default: Story = {
  args: {
    placeholder: 'Type here...',
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Default input variant with border, shadow, and focus ring effects.',
      },
    },
  },
};

export const Ghost: Story = {
  args: {
    placeholder: 'Type here...',
    variant: 'ghost',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Ghost variant without border or shadow - ideal for inline editing or minimal UI.',
      },
    },
  },
};

export const InputTypes: Story = {
  render: () => (
    <div className="flex w-[350px] flex-col gap-4">
      <div>
        <Text level="small" className="mb-2 block">
          Text
        </Text>
        <Input type="text" placeholder="Enter text..." />
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Email
        </Text>
        <Input type="email" placeholder="Enter email..." />
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Password
        </Text>
        <Input
          type="password"
          placeholder="Enter password..."
          autoComplete="new-password"
        />
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Number
        </Text>
        <Input type="number" placeholder="Enter number..." />
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Search
        </Text>
        <Input type="search" placeholder="Search..." />
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Input supports various HTML5 input types for better UX and validation.',
      },
    },
  },
};

export const WithValue: Story = {
  args: {
    defaultValue: 'Pre-filled content',
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story: 'Input with initial content filled in.',
      },
    },
  },
};

export const Disabled: Story = {
  args: {
    placeholder: 'This input is disabled',
    disabled: true,
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Disabled state with reduced opacity and not-allowed cursor. User cannot interact with the input.',
      },
    },
  },
};

export const Invalid: Story = {
  render: () => (
    <div className="flex w-[350px] flex-col gap-6">
      <div>
        <Text level="small" className="mb-2 block">
          Invalid Default
        </Text>
        <Input
          placeholder="This input has an error"
          aria-invalid
          variant="default"
        />
        <Text level="small" color="muted" className="mt-1">
          This field is required
        </Text>
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Invalid Ghost
        </Text>
        <Input
          placeholder="Ghost variant with error"
          aria-invalid
          variant="ghost"
        />
        <Text level="small" color="muted" className="mt-1">
          Ghost variant stays transparent even when invalid
        </Text>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Invalid state with destructive border and ring colors. The default variant shows error styling, while ghost variant maintains transparent borders.',
      },
    },
  },
};

// Form Examples Story
export const FormExamples: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-4">
          Contact Form
        </h3>
        <div className="space-y-4 max-w-md">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Full Name
            </label>
            <Input placeholder="Enter your full name" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Email Address
            </label>
            <Input type="email" placeholder="Enter your email" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Phone Number
            </label>
            <Input type="tel" placeholder="Enter your phone number" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Message
            </label>
            <Input placeholder="Enter your message" />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-4">
          Search Interface
        </h3>
        <div className="space-y-4 max-w-md">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Search
            </label>
            <Input type="search" placeholder="Search for anything..." />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Filter by Date
            </label>
            <Input type="date" />
          </div>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-4">
          File Upload
        </h3>
        <div className="space-y-4 max-w-md">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Upload Document
            </label>
            <Input type="file" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Upload Image
            </label>
            <Input type="file" accept="image/*" />
          </div>
        </div>
      </div>
    </div>
  ),
};

// Validation Examples Story
export const ValidationExamples: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-4">
          Form Validation Examples
        </h3>
        <div className="space-y-4 max-w-md">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Valid Email
            </label>
            <Input
              type="email"
              placeholder="Enter valid email"
              defaultValue="user@example.com"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Invalid Email
            </label>
            <Input
              type="email"
              placeholder="Enter valid email"
              defaultValue="invalid-email"
              aria-invalid="true"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Required Field (Empty)
            </label>
            <Input
              placeholder="This field is required"
              required
              aria-invalid="true"
            />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Valid Required Field
            </label>
            <Input
              placeholder="This field is required"
              required
              defaultValue="Filled value"
            />
          </div>
        </div>
      </div>
    </div>
  ),
};

// Accessibility Story
export const Accessibility: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Accessibility Features
        </h3>
        <div className="space-y-3">
          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Keyboard Navigation
            </h4>
            <p className="text-xs text-muted-foreground mb-2">
              All inputs are keyboard accessible. Use Tab to navigate and type
              to enter values.
            </p>
            <Input placeholder="Try tabbing to this input" />
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Focus Indicators
            </h4>
            <p className="text-xs text-muted-foreground mb-2">
              Inputs have visible focus indicators that work with the current
              theme.
            </p>
            <Input placeholder="Focus me (Tab to this input)" />
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Screen Reader Support
            </h4>
            <p className="text-xs text-muted-foreground mb-2">
              Inputs include proper ARIA attributes and semantic HTML.
            </p>
            <div className="space-y-2">
              <Input aria-label="Search for products" placeholder="Search..." />
              <Input
                aria-describedby="email-help"
                type="email"
                placeholder="Enter email"
              />
              <p id="email-help" className="text-xs text-muted-foreground">
                We'll never share your email with anyone else.
              </p>
            </div>
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Error States
            </h4>
            <p className="text-xs text-muted-foreground mb-2">
              Invalid inputs are properly marked for screen readers.
            </p>
            <Input
              aria-invalid="true"
              aria-errormessage="email-error"
              placeholder="Invalid email"
            />
            <p id="email-error" className="text-xs text-destructive mt-1">
              Please enter a valid email address.
            </p>
          </div>
        </div>
      </div>
    </div>
  ),
};

// Theme Showcase Story
export const ThemeShowcase: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Text Inputs
        </h3>
        <p className="text-xs text-muted-foreground mb-2">
          Standard text inputs for general use.
        </p>
        <div className="space-y-2">
          <Input placeholder="Default text input" />
          <Input placeholder="Disabled text input" disabled />
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Specialized Inputs
        </h3>
        <p className="text-xs text-muted-foreground mb-2">
          Inputs with specific types for better UX and validation.
        </p>
        <div className="space-y-2">
          <Input
            type="email"
            placeholder="Email input"
            autoComplete="username"
          />
          <Input
            type="password"
            placeholder="Password input"
            autoComplete="current-password"
          />
          <Input type="number" placeholder="Number input" />
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Date and Time
        </h3>
        <p className="text-xs text-muted-foreground mb-2">
          Date and time inputs with native browser controls.
        </p>
        <div className="space-y-2">
          <Input type="date" />
          <Input type="time" />
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          File Uploads
        </h3>
        <p className="text-xs text-muted-foreground mb-2">
          File input for document and media uploads.
        </p>
        <div className="space-y-2">
          <Input type="file" />
          <Input type="file" accept="image/*" />
        </div>
      </div>
    </div>
  ),
};

// All Inputs Story - Simplified version
export const AllInputs: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          All Input Types
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">Text</label>
            <Input type="text" placeholder="Enter text..." />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">Email</label>
            <Input
              type="email"
              placeholder="Enter email..."
              autoComplete="username"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">
              Password
            </label>
            <Input
              type="password"
              placeholder="Enter password..."
              autoComplete="current-password"
            />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">
              Number
            </label>
            <Input type="number" placeholder="Enter number..." />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">Phone</label>
            <Input type="tel" placeholder="Enter phone number..." />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">URL</label>
            <Input type="url" placeholder="Enter URL..." />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">
              Search
            </label>
            <Input type="search" placeholder="Search..." />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">Date</label>
            <Input type="date" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">Time</label>
            <Input type="time" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">File</label>
            <Input type="file" />
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">Input States</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">
              Normal
            </label>
            <Input placeholder="Normal input" />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">
              Disabled
            </label>
            <Input placeholder="Disabled input" disabled />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">
              Required
            </label>
            <Input placeholder="Required input" required />
          </div>
          <div className="space-y-2">
            <label className="text-xs font-medium text-foreground">
              Invalid
            </label>
            <Input placeholder="Invalid input" aria-invalid="true" />
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Form Examples
        </h2>
        <div className="space-y-4 max-w-md">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Full Name
            </label>
            <Input placeholder="Enter your full name" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Email Address
            </label>
            <Input type="email" placeholder="Enter your email" />
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">
              Phone Number
            </label>
            <Input type="tel" placeholder="Enter your phone number" />
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Accessibility
        </h2>
        <div className="space-y-3">
          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Focus Indicators
            </h4>
            <Input placeholder="Focus me (Tab to this input)" />
          </div>
          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Screen Reader Support
            </h4>
            <Input aria-label="Search for products" placeholder="Search..." />
          </div>
        </div>
      </div>
    </div>
  ),
};
