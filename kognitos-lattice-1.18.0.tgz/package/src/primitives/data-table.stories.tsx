import type { Meta, StoryObj } from '@storybook/react';
import {
  DataTable,
  type IDataTableColDef,
  type IDataTableCellRendererParams,
  type IDataTableValueFormatterParams,
} from './data-table';
import { Badge } from './badge';

// Sample data for stories
const sampleData = [
  {
    id: 1,
    name: 'John Doe',
    age: 30,
    email: 'john.doe@example.com',
    department: 'Engineering',
    salary: 75000,
    startDate: '2020-01-15',
    status: 'Active',
    tags: ['Senior', 'Full-stack'],
  },
  {
    id: 2,
    name: 'Jane Smith',
    age: 28,
    email: 'jane.smith@example.com',
    department: 'Marketing',
    salary: 65000,
    startDate: '2021-03-22',
    status: 'Active',
    tags: ['Lead', 'Digital'],
  },
  {
    id: 3,
    name: 'Bob Johnson',
    age: 35,
    email: 'bob.johnson@example.com',
    department: 'Sales',
    salary: 70000,
    startDate: '2019-11-08',
    status: 'Active',
    tags: ['Manager'],
  },
  {
    id: 4,
    name: 'Alice Brown',
    age: 32,
    email: 'alice.brown@example.com',
    department: 'HR',
    salary: 60000,
    startDate: '2022-02-14',
    status: 'Inactive',
    tags: ['Recruiter'],
  },
  {
    id: 5,
    name: 'Charlie Wilson',
    age: 29,
    email: 'charlie.wilson@example.com',
    department: 'Engineering',
    salary: 80000,
    startDate: '2021-07-10',
    status: 'Active',
    tags: ['Senior', 'Backend'],
  },
];

// Basic column definitions
const basicColumns: IDataTableColDef[] = [
  { field: 'id', headerName: 'ID', width: 80 },
  { field: 'name', headerName: 'Name', width: 150 },
  { field: 'age', headerName: 'Age', width: 100 },
  { field: 'email', headerName: 'Email', width: 200 },
];

// Column definitions with sorting and filtering
const sortableColumns: IDataTableColDef[] = [
  {
    field: 'id',
    headerName: 'ID',
    width: 80,
    sortable: true,
    filter: true,
  },
  {
    field: 'name',
    headerName: 'Name',
    width: 150,
    sortable: true,
    filter: true,
  },
  {
    field: 'age',
    headerName: 'Age',
    width: 100,
    sortable: true,
    filter: true,
  },
  {
    field: 'email',
    headerName: 'Email',
    width: 200,
    sortable: true,
    filter: true,
  },
  {
    field: 'department',
    headerName: 'Department',
    width: 120,
    sortable: true,
    filter: true,
  },
  {
    field: 'salary',
    headerName: 'Salary',
    width: 120,
    sortable: true,
    filter: true,
  },
  {
    field: 'status',
    headerName: 'Status',
    width: 100,
    sortable: true,
    filter: true,
  },
];

// Column definitions with custom cell renderer for tags
const customCellColumns: IDataTableColDef[] = [
  {
    field: 'id',
    headerName: 'ID',
    width: 80,
    sortable: true,
    filter: 'agNumberColumnFilter',
  },
  {
    field: 'name',
    headerName: 'Name',
    width: 150,
    sortable: true,
    filter: true,
  },
  {
    field: 'department',
    headerName: 'Department',
    width: 120,
    sortable: true,
    filter: true,
  },
  {
    field: 'tags',
    headerName: 'Tags',
    width: 200,
    sortable: false,
    filter: false,
    valueFormatter: (params: IDataTableValueFormatterParams) => {
      const tags = params.value || [];
      return Array.isArray(tags) ? tags.join(', ') : String(tags);
    },
    cellRenderer: (params: IDataTableCellRendererParams) => {
      const tags = params.value || [];
      return (
        <div className="flex gap-1 flex-wrap items-center h-full">
          {tags.map((tag: string) => (
            <Badge key={tag} variant="secondary">
              {tag}
            </Badge>
          ))}
        </div>
      );
    },
  },
  {
    field: 'status',
    headerName: 'Status',
    width: 100,
    sortable: true,
    filter: true,
    cellRenderer: (params: IDataTableCellRendererParams) => {
      const status = params.value;
      return (
        <Badge variant={status === 'Active' ? 'default' : 'secondary'}>
          {status}
        </Badge>
      );
    },
  },
];

const meta: Meta<typeof DataTable> = {
  title: 'Design System/Primitives/Data Display/Data Table',
  component: DataTable,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      autodocs: true,
      description: {
        component: `
A powerful data table component built on AG Grid React. This component provides advanced features like sorting, filtering, pagination, row selection, and custom cell rendering.

Refer to the [AG Grid React documentation](https://www.ag-grid.com/react-data-grid/getting-started/) for more information on how to use the component.

## Features

- **Sorting**: Enable/disable column sorting
- **Filtering**: Built-in column filters with different filter types
- **Pagination**: Client-side pagination with customizable page sizes
- **Row Selection**: Single or multiple row selection
- **Custom Cell Renderers**: Render custom components in cells
- **Loading States**: Built-in loading overlay
- **Large Datasets**: Optimized for handling large amounts of data

## Usage

\`\`\`tsx
import { DataTable } from '@/design-system';

// Data format type
interface IDataType {
  id: number;
  name: string;
  status: string;
  lastRun: string;
  runs: number;
}

// Column definitions
const columns: IDataTableColDef<IDataType>[] = [
    { field: 'id', headerName: 'ID', width: 80 },
    { field: 'name', headerName: 'Name', flex: 1 },
    { field: 'status', headerName: 'Status', width: 120, filter: true },
    { field: 'lastRun', headerName: 'Last Run', width: 120 },
    { field: 'runs', headerName: 'Runs', width: 100 },
  ];

  const data: IDataType[] = [
    { id: 1, name: 'Email Automation', status: 'Active', lastRun: '2024-01-15', runs: 45 },
    { id: 2, name: 'Data Sync', status: 'Inactive', lastRun: '2024-01-10', runs: 12 },
  ];

  // We need to wrap the DataTable in a div with a height to ensure the table is visible,
  // as the table takes the height of the parent container
  <div className="w-full h-96">
    <div className="w-full h-full">
      <DataTable<IDataType>
        data={data}
        columns={columns}
        variant="borderless"
        gridOptions={{
          pagination: true,
          paginationPageSize: 20,
          paginationPageSizeSelector: [10, 20, 50],
        }}
        rowSelection={{
          mode: 'multiRow',
        }}
      />
    </div>
  </div>
\`\`\`
        `,
      },
    },
  },
  argTypes: {
    data: {
      description: 'The data to display in the table',
      control: false,
    },
    columns: {
      description: 'Column definitions for the table',
      control: false,
    },
    loading: {
      description: 'Whether to show loading state',
      control: { type: 'boolean' },
    },
    variant: {
      description: 'Visual variant of the table',
      control: { type: 'select' },
      options: ['default', 'bordered', 'borderless'],
    },
  },
  args: {
    data: sampleData,
    columns: basicColumns,
    loading: false,
  },
  decorators: [
    Story => (
      <div className="w-full h-96">
        <div className="w-full h-full">
          <Story />
        </div>
      </div>
    ),
  ],
};

export default meta;
type Story = StoryObj<typeof DataTable>;

// Multi Select
export const MultiSelect: Story = {
  name: 'Multi Select',
  args: {
    data: sampleData,
    columns: basicColumns,
    rowSelection: {
      mode: 'multiRow',
    },
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table with multiple row selection enabled. Use checkboxes to select multiple rows.',
      },
    },
  },
};

// Single Select
export const SingleSelect: Story = {
  name: 'Single Select',
  args: {
    data: sampleData,
    columns: basicColumns,
    rowSelection: {
      mode: 'singleRow',
    },
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table with single row selection enabled. Click on any row to select it.',
      },
    },
  },
};

// Sorting
export const Sorting: Story = {
  name: 'Sorting',
  args: {
    data: sampleData,
    columns: sortableColumns,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table with sorting enabled. Click on column headers to sort by that column.',
      },
    },
  },
};

// Filters
export const Filters: Story = {
  name: 'Filters',
  args: {
    data: sampleData,
    columns: sortableColumns,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table with filtering enabled. Use the filter icons in column headers to filter data.',
      },
    },
  },
};

// Custom Cell Renderer with Tags
export const CustomCellRenderer: Story = {
  name: 'Custom Cell Renderer',
  args: {
    data: sampleData,
    columns: customCellColumns,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table with custom cell renderers showing tags and status badges.',
      },
    },
  },
};

// Pagination
export const Pagination: Story = {
  name: 'Pagination',
  args: {
    data: sampleData,
    columns: basicColumns,
    gridOptions: {
      pagination: true,
      paginationPageSize: 20,
      paginationPageSizeSelector: [10, 20, 50],
    },
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table with pagination enabled. Navigate through pages using the pagination controls.',
      },
    },
  },
};

// Loading State
export const LoadingState: Story = {
  name: 'Loading State',
  args: {
    data: sampleData,
    columns: basicColumns,
    loading: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'Table showing loading state with overlay.',
      },
    },
  },
};

// Large Dataset
export const LargeDataset: Story = {
  name: 'Large Dataset',
  args: {
    data: Array.from({ length: 100 }, (_, i) => ({
      id: i + 1,
      name: `User ${i + 1}`,
      age: 20 + (i % 50),
      email: `user${i + 1}@example.com`,
      department: ['Engineering', 'Marketing', 'Sales', 'HR'][i % 4],
      salary: 50000 + i * 1000,
      startDate: new Date(2020 + (i % 4), i % 12, (i % 28) + 1)
        .toISOString()
        .split('T')[0],
      status: i % 10 === 0 ? 'Inactive' : 'Active',
      tags:
        ['Senior', 'Lead', 'Manager', 'Junior'][i % 4] === 'Senior'
          ? ['Senior', 'Full-stack']
          : ['Lead', 'Digital'],
    })),
    columns: sortableColumns,
    gridOptions: {
      pagination: true,
      paginationPageSize: 20,
      paginationPageSizeSelector: [10, 20, 50, 100],
    },
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table optimized for large datasets with pagination, sorting, and filtering.',
      },
    },
  },
};

// Bordered Table
export const Bordered: Story = {
  name: 'Bordered',
  args: {
    data: sampleData,
    columns: basicColumns,
    variant: 'bordered',
  },
  parameters: {
    docs: {
      description: {
        story:
          "Table with borders enabled using AG Grid's theme system. This shows borders around the wrapper, header rows, and between all rows and columns.",
      },
    },
  },
};

// Borderless Table
export const Borderless: Story = {
  name: 'Borderless',
  args: {
    data: sampleData,
    columns: basicColumns,
    variant: 'borderless',
  },
  parameters: {
    docs: {
      description: {
        story:
          "Table with borders disabled using AG Grid's theme system. This removes all borders for a cleaner, minimal look.",
      },
    },
  },
};

// Resizable Columns
export const ResizableColumns: Story = {
  name: 'Resizable Columns',
  args: {
    data: sampleData,
    columns: basicColumns,
    resizable: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Table with resizable columns enabled. Drag the column borders to resize columns. The table maintains proper layout and handles column width changes gracefully.',
      },
    },
  },
};
