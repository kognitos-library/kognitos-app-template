import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Item,
  ItemActions,
  ItemContent,
  ItemDescription,
  ItemFooter,
  ItemGroup,
  ItemHeader,
  ItemMedia,
  ItemSeparator,
  ItemTitle,
} from './item';
import { Button } from './button';
import { Avatar, AvatarFallback, AvatarImage } from './avatar';
import { Badge } from './badge';
import { Icon } from '../icons';

const meta: Meta<typeof Item> = {
  title: 'Design System/Primitives/Data Display/Item',
  component: Item,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A versatile component that you can use to display any content. The Item component is a straightforward flex container that can house nearly any type of content. Use it to display a title, description, and actions. Group it with the ItemGroup component to create a list of items.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['default', 'outline', 'muted'],
      description: 'Visual variant of the item',
      table: {
        type: { summary: 'default | outline | muted' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    size: {
      control: { type: 'select' },
      options: ['default', 'sm'],
      description: 'Size of the item',
      table: {
        type: { summary: 'default | sm' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    asChild: {
      control: { type: 'boolean' },
      description: 'Render as a custom component (e.g., anchor tag)',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'Behavior',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Item>;

// Main Demo
export const Demo: Story = {
  render: () => (
    <div className="flex w-full max-w-md flex-col gap-6">
      <Item variant="outline">
        <ItemContent>
          <ItemTitle>Basic Item</ItemTitle>
          <ItemDescription>
            A simple item with title and description.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button variant="outline" size="sm">
            Action
          </Button>
        </ItemActions>
      </Item>
      <Item variant="outline" size="sm" asChild>
        <a href="#">
          <ItemMedia>
            <Icon type="BadgeCheck" className="size-5" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Your profile has been verified.</ItemTitle>
          </ItemContent>
          <ItemActions>
            <Icon type="ChevronRight" className="size-4" />
          </ItemActions>
        </a>
      </Item>
    </div>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'Basic examples showing an item with actions and a compact item rendered as a link.',
      },
    },
  },
};

// Variants
export const Variants: Story = {
  render: () => (
    <div className="flex flex-col gap-6">
      <Item>
        <ItemContent>
          <ItemTitle>Default Variant</ItemTitle>
          <ItemDescription>
            Standard styling with subtle background and borders.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button variant="outline" size="sm">
            Open
          </Button>
        </ItemActions>
      </Item>
      <Item variant="outline">
        <ItemContent>
          <ItemTitle>Outline Variant</ItemTitle>
          <ItemDescription>
            Outlined style with clear borders and transparent background.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button variant="outline" size="sm">
            Open
          </Button>
        </ItemActions>
      </Item>
      <Item variant="muted">
        <ItemContent>
          <ItemTitle>Muted Variant</ItemTitle>
          <ItemDescription>
            Subdued appearance with muted colors for secondary content.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button variant="outline" size="sm">
            Open
          </Button>
        </ItemActions>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Three visual variants: default (transparent), outline (bordered), and muted (subtle background).',
      },
    },
  },
};

// Sizes
export const Sizes: Story = {
  render: () => (
    <div className="flex w-full max-w-md flex-col gap-6">
      <Item variant="outline">
        <ItemContent>
          <ItemTitle>Default Size</ItemTitle>
          <ItemDescription>
            Standard size with comfortable padding for general use.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button variant="outline" size="sm">
            Action
          </Button>
        </ItemActions>
      </Item>
      <Item variant="outline" size="sm" asChild>
        <a href="#">
          <ItemMedia>
            <Icon type="BadgeCheck" className="size-5" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Small Size</ItemTitle>
          </ItemContent>
          <ItemActions>
            <Icon type="ChevronRight" className="size-4" />
          </ItemActions>
        </a>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Two size variants: default for standard items and sm for compact items.',
      },
    },
  },
};

// Icon Example
export const IconExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <Item variant="outline">
        <ItemMedia variant="icon">
          <Icon type="ShieldAlert" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Security Alert</ItemTitle>
          <ItemDescription>
            New login detected from unknown device.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button size="sm" variant="outline">
            Review
          </Button>
        </ItemActions>
      </Item>
      <Item variant="outline">
        <ItemMedia variant="icon">
          <Icon type="Mail" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>New Message</ItemTitle>
          <ItemDescription>
            You have a new message from support.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button size="sm" variant="outline">
            Read
          </Button>
        </ItemActions>
      </Item>
      <Item variant="outline">
        <ItemMedia variant="icon">
          <Icon type="Bell" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Notification Settings</ItemTitle>
          <ItemDescription>
            Manage your notification preferences.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Icon type="ChevronRight" className="size-4" />
        </ItemActions>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Items with icon media variant showing different types of notifications and actions.',
      },
    },
  },
};

// Avatar Example
export const AvatarExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <Item variant="outline">
        <ItemMedia>
          <Avatar>
            <AvatarImage src="https://github.com/shadcn.png" />
            <AvatarFallback>ER</AvatarFallback>
          </Avatar>
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Evil Rabbit</ItemTitle>
          <ItemDescription>Last seen 5 months ago</ItemDescription>
        </ItemContent>
        <ItemActions>
          <Icon type="ChevronRight" className="size-4" />
        </ItemActions>
      </Item>
      <Item variant="outline">
        <ItemMedia variant="icon">
          <Icon type="UserPlus" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>No Team Members</ItemTitle>
          <ItemDescription>
            Invite your team to collaborate on this project.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button size="sm" variant="outline">
            Invite
          </Button>
        </ItemActions>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Items with avatar media showing user profiles and team member invitations.',
      },
    },
  },
};

// Image Example
export const ImageExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <Item variant="outline">
        <ItemMedia variant="image">
          <img
            src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=100&h=100&fit=crop"
            alt="Abstract art"
          />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Abstract Painting</ItemTitle>
          <ItemDescription>
            Modern art collection piece from 2024
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button size="sm" variant="outline">
            View
          </Button>
        </ItemActions>
      </Item>
      <Item variant="outline">
        <ItemMedia variant="image">
          <img
            src="https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?w=100&h=100&fit=crop"
            alt="Geometric pattern"
          />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Geometric Design</ItemTitle>
          <ItemDescription>Contemporary digital artwork</ItemDescription>
        </ItemContent>
        <ItemActions>
          <Icon type="ChevronRight" className="size-4" />
        </ItemActions>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Items with image media variant displaying artwork with descriptions.',
      },
    },
  },
};

// Group Example
export const GroupExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <ItemGroup>
        <Item variant="outline">
          <ItemMedia variant="icon">
            <Icon type="User" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Profile Settings</ItemTitle>
            <ItemDescription>Manage your profile information</ItemDescription>
          </ItemContent>
          <ItemActions>
            <Icon type="ChevronRight" className="size-4" />
          </ItemActions>
        </Item>
        <ItemSeparator />
        <Item variant="outline">
          <ItemMedia variant="icon">
            <Icon type="Bell" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Notifications</ItemTitle>
            <ItemDescription>
              Configure notification preferences
            </ItemDescription>
          </ItemContent>
          <ItemActions>
            <Icon type="ChevronRight" className="size-4" />
          </ItemActions>
        </Item>
        <ItemSeparator />
        <Item variant="outline">
          <ItemMedia variant="icon">
            <Icon type="Lock" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Security</ItemTitle>
            <ItemDescription>Update security settings</ItemDescription>
          </ItemContent>
          <ItemActions>
            <Icon type="ChevronRight" className="size-4" />
          </ItemActions>
        </Item>
      </ItemGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'ItemGroup with separators creates a cohesive list of related settings.',
      },
    },
  },
};

// Header and Footer Example
export const HeaderFooterExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <Item variant="outline">
        <ItemHeader>
          <Badge variant="secondary">New</Badge>
          <Icon type="MoreHorizontal" className="size-4" />
        </ItemHeader>
        <ItemMedia variant="icon">
          <Icon type="Package" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Product Update Available</ItemTitle>
          <ItemDescription>
            A new version of the application is ready to install.
          </ItemDescription>
        </ItemContent>
        <ItemFooter>
          <span className="text-xs text-muted-foreground">2 hours ago</span>
          <Button size="sm" variant="outline">
            Update Now
          </Button>
        </ItemFooter>
      </Item>
      <Item variant="outline">
        <ItemHeader>
          <Badge>Featured</Badge>
        </ItemHeader>
        <ItemMedia variant="icon">
          <Icon type="Sparkles" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Premium Feature</ItemTitle>
          <ItemDescription>
            Unlock advanced features with our premium plan.
          </ItemDescription>
        </ItemContent>
        <ItemFooter>
          <Button size="sm">Learn More</Button>
        </ItemFooter>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Items with header and footer sections for additional context and actions.',
      },
    },
  },
};

// Link Example
export const LinkExample: Story = {
  render: () => (
    <div className="flex w-full max-w-md flex-col gap-4">
      <Item asChild>
        <a href="#">
          <ItemContent>
            <ItemTitle>Visit our documentation</ItemTitle>
            <ItemDescription>
              Learn how to get started with our components.
            </ItemDescription>
          </ItemContent>
          <ItemActions>
            <Icon type="ChevronRight" className="size-4" />
          </ItemActions>
        </a>
      </Item>
      <Item variant="outline" asChild>
        <a href="#" target="_blank" rel="noopener noreferrer">
          <ItemContent>
            <ItemTitle>External resource</ItemTitle>
            <ItemDescription>
              Opens in a new tab with security attributes.
            </ItemDescription>
          </ItemContent>
          <ItemActions>
            <Icon type="ExternalLink" className="size-4" />
          </ItemActions>
        </a>
      </Item>
      <Item variant="muted" asChild>
        <a href="#">
          <ItemMedia variant="icon">
            <Icon type="Home" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Dashboard</ItemTitle>
            <ItemDescription>
              Overview of your account and activity.
            </ItemDescription>
          </ItemContent>
          <ItemActions>
            <Icon type="ChevronRight" className="size-4" />
          </ItemActions>
        </a>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Items rendered as links using asChild prop. Hover and focus states are applied to the anchor element.',
      },
    },
  },
};

// Notification List Example
export const NotificationListExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <ItemGroup>
        <Item>
          <ItemMedia variant="icon">
            <Icon type="MessageSquare" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>New comment on your post</ItemTitle>
            <ItemDescription>
              John Doe replied to your comment: "Great insight!"
            </ItemDescription>
          </ItemContent>
          <ItemActions>
            <Badge variant="secondary">3</Badge>
          </ItemActions>
        </Item>
        <ItemSeparator />
        <Item>
          <ItemMedia variant="icon">
            <Icon type="Heart" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>Someone liked your post</ItemTitle>
            <ItemDescription>
              Your post received 5 new likes in the last hour.
            </ItemDescription>
          </ItemContent>
        </Item>
        <ItemSeparator />
        <Item>
          <ItemMedia variant="icon">
            <Icon type="UserPlus" />
          </ItemMedia>
          <ItemContent>
            <ItemTitle>New follower</ItemTitle>
            <ItemDescription>Jane Smith started following you.</ItemDescription>
          </ItemContent>
          <ItemActions>
            <Button size="sm" variant="outline">
              Follow Back
            </Button>
          </ItemActions>
        </Item>
      </ItemGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'A notification list demonstrating various types of social interactions.',
      },
    },
  },
};

// Settings Menu Example
export const SettingsMenuExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <ItemGroup>
        <Item variant="outline" asChild>
          <a href="#">
            <ItemMedia variant="icon">
              <Icon type="User" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Account</ItemTitle>
              <ItemDescription>
                Manage your account settings and preferences
              </ItemDescription>
            </ItemContent>
            <ItemActions>
              <Icon type="ChevronRight" className="size-4" />
            </ItemActions>
          </a>
        </Item>
        <ItemSeparator />
        <Item variant="outline" asChild>
          <a href="#">
            <ItemMedia variant="icon">
              <Icon type="Palette" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Appearance</ItemTitle>
              <ItemDescription>
                Customize the look and feel of your interface
              </ItemDescription>
            </ItemContent>
            <ItemActions>
              <Icon type="ChevronRight" className="size-4" />
            </ItemActions>
          </a>
        </Item>
        <ItemSeparator />
        <Item variant="outline" asChild>
          <a href="#">
            <ItemMedia variant="icon">
              <Icon type="Shield" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Privacy & Security</ItemTitle>
              <ItemDescription>
                Control your privacy and security settings
              </ItemDescription>
            </ItemContent>
            <ItemActions>
              <Icon type="ChevronRight" className="size-4" />
            </ItemActions>
          </a>
        </Item>
        <ItemSeparator />
        <Item variant="outline" asChild>
          <a href="#">
            <ItemMedia variant="icon">
              <Icon type="CreditCard" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Billing</ItemTitle>
              <ItemDescription>
                Manage your subscription and payment methods
              </ItemDescription>
            </ItemContent>
            <ItemActions>
              <Icon type="ChevronRight" className="size-4" />
            </ItemActions>
          </a>
        </Item>
      </ItemGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'A settings menu using ItemGroup with clickable navigation items.',
      },
    },
  },
};

// Team Members Example
export const TeamMembersExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <ItemGroup>
        <Item variant="outline">
          <ItemMedia>
            <Avatar>
              <AvatarImage src="https://github.com/shadcn.png" />
              <AvatarFallback>SC</AvatarFallback>
            </Avatar>
          </ItemMedia>
          <ItemContent>
            <ItemTitle>shadcn</ItemTitle>
            <ItemDescription>shadcn@vercel.com</ItemDescription>
          </ItemContent>
          <ItemActions>
            <Badge variant="secondary">Admin</Badge>
          </ItemActions>
        </Item>
        <ItemSeparator />
        <Item variant="outline">
          <ItemMedia>
            <Avatar>
              <AvatarFallback>ML</AvatarFallback>
            </Avatar>
          </ItemMedia>
          <ItemContent>
            <ItemTitle>maxleiter</ItemTitle>
            <ItemDescription>maxleiter@vercel.com</ItemDescription>
          </ItemContent>
          <ItemActions>
            <Badge variant="outline">Member</Badge>
          </ItemActions>
        </Item>
        <ItemSeparator />
        <Item variant="outline">
          <ItemMedia>
            <Avatar>
              <AvatarFallback>ER</AvatarFallback>
            </Avatar>
          </ItemMedia>
          <ItemContent>
            <ItemTitle>evilrabbit</ItemTitle>
            <ItemDescription>evilrabbit@vercel.com</ItemDescription>
          </ItemContent>
          <ItemActions>
            <Badge variant="outline">Member</Badge>
          </ItemActions>
        </Item>
      </ItemGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Team member list with avatars, roles, and member information.',
      },
    },
  },
};

// With Multiple Actions
export const MultipleActionsExample: Story = {
  render: () => (
    <div className="flex w-full max-w-lg flex-col gap-6">
      <Item variant="outline">
        <ItemMedia variant="icon">
          <Icon type="FileText" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Project Documentation</ItemTitle>
          <ItemDescription>
            Complete guide to getting started with the project.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button size="sm" variant="outline">
            Edit
          </Button>
          <Button size="sm" variant="outline">
            Share
          </Button>
        </ItemActions>
      </Item>
      <Item variant="outline">
        <ItemMedia variant="icon">
          <Icon type="Image" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Design Assets</ItemTitle>
          <ItemDescription>
            Brand guidelines and design resources.
          </ItemDescription>
        </ItemContent>
        <ItemActions>
          <Button size="sm" variant="outline">
            Download
          </Button>
          <Button size="sm" variant="outline">
            Preview
          </Button>
          <Button size="sm" variant="outline">
            <Icon type="MoreHorizontal" className="size-4" />
          </Button>
        </ItemActions>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Items with multiple action buttons in the ItemActions slot.',
      },
    },
  },
};

// Compact List Example
export const CompactListExample: Story = {
  render: () => (
    <div className="flex w-full max-w-md flex-col gap-6">
      <ItemGroup>
        <Item size="sm" variant="outline" asChild>
          <a href="#">
            <ItemMedia>
              <Icon type="Home" className="size-4" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Dashboard</ItemTitle>
            </ItemContent>
            <ItemActions>
              <Icon type="ChevronRight" className="size-4" />
            </ItemActions>
          </a>
        </Item>
        <ItemSeparator />
        <Item size="sm" variant="outline" asChild>
          <a href="#">
            <ItemMedia>
              <Icon type="Users" className="size-4" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Team</ItemTitle>
            </ItemContent>
            <ItemActions>
              <Badge variant="secondary" className="text-xs">
                5
              </Badge>
            </ItemActions>
          </a>
        </Item>
        <ItemSeparator />
        <Item size="sm" variant="outline" asChild>
          <a href="#">
            <ItemMedia>
              <Icon type="Settings" className="size-4" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Settings</ItemTitle>
            </ItemContent>
            <ItemActions>
              <Icon type="ChevronRight" className="size-4" />
            </ItemActions>
          </a>
        </Item>
        <ItemSeparator />
        <Item size="sm" variant="outline" asChild>
          <a href="#">
            <ItemMedia>
              <Icon type="HelpCircle" className="size-4" />
            </ItemMedia>
            <ItemContent>
              <ItemTitle>Help & Support</ItemTitle>
            </ItemContent>
            <ItemActions>
              <Icon type="ChevronRight" className="size-4" />
            </ItemActions>
          </a>
        </Item>
      </ItemGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Compact navigation menu using small size variant for space-efficient layouts.',
      },
    },
  },
};

// Complex Item Example
export const ComplexItemExample: Story = {
  render: () => (
    <div className="flex w-full max-w-2xl flex-col gap-6">
      <Item variant="outline">
        <ItemHeader>
          <Badge>Active Project</Badge>
          <span className="text-xs text-muted-foreground">Due in 3 days</span>
        </ItemHeader>
        <ItemMedia variant="icon">
          <Icon type="Folder" />
        </ItemMedia>
        <ItemContent>
          <ItemTitle>Website Redesign Q4 2024</ItemTitle>
          <ItemDescription>
            Complete overhaul of the company website including new branding,
            improved UX, and mobile optimization. This is a high-priority
            project with multiple stakeholders.
          </ItemDescription>
        </ItemContent>
        <ItemFooter>
          <div className="flex items-center gap-2">
            <Avatar className="size-6">
              <AvatarFallback className="text-xs">JD</AvatarFallback>
            </Avatar>
            <Avatar className="size-6">
              <AvatarFallback className="text-xs">SM</AvatarFallback>
            </Avatar>
            <span className="text-xs text-muted-foreground">+3</span>
          </div>
          <div className="flex gap-2">
            <Button size="sm" variant="outline">
              View Details
            </Button>
            <Button size="sm">Update Status</Button>
          </div>
        </ItemFooter>
      </Item>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Complex item showcasing all available slots: header, media, content, and footer.',
      },
    },
  },
};

// Accessibility Example
export const AccessibilityExample: Story = {
  render: () => (
    <div className="w-full max-w-md space-y-6">
      <div className="bg-muted p-4 rounded-lg space-y-4">
        <div>
          <h4 className="font-medium text-foreground mb-2 text-sm">
            Semantic List Structure
          </h4>
          <p className="text-xs text-muted-foreground mb-3">
            ItemGroup uses role="list" for proper screen reader announcement.
          </p>
          <ItemGroup>
            <Item variant="outline">
              <ItemContent>
                <ItemTitle>First Item</ItemTitle>
                <ItemDescription>
                  Screen readers announce this as a list
                </ItemDescription>
              </ItemContent>
            </Item>
            <ItemSeparator />
            <Item variant="outline">
              <ItemContent>
                <ItemTitle>Second Item</ItemTitle>
                <ItemDescription>With proper list semantics</ItemDescription>
              </ItemContent>
            </Item>
          </ItemGroup>
        </div>
        <div>
          <h4 className="font-medium text-foreground mb-2 text-sm">
            Keyboard Navigation
          </h4>
          <p className="text-xs text-muted-foreground mb-3">
            Items rendered as links are fully keyboard accessible.
          </p>
          <Item variant="outline" asChild>
            <a href="#">
              <ItemContent>
                <ItemTitle>Keyboard Accessible Link</ItemTitle>
                <ItemDescription>
                  Tab to focus, Enter to activate
                </ItemDescription>
              </ItemContent>
              <ItemActions>
                <Icon type="ChevronRight" className="size-4" />
              </ItemActions>
            </a>
          </Item>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Items are built with accessibility in mind, using semantic HTML and proper ARIA attributes.',
      },
    },
  },
};
