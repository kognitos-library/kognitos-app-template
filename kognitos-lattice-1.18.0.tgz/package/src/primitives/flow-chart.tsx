import {
  ReactFlow,
  ReactFlowProvider,
  useInternalNode,
  type Node,
  type Edge,
  Handle,
  Position,
  BaseEdge,
  getStraightPath,
  type EdgeProps,
  EdgeLabelRenderer,
} from '@xyflow/react';
import {
  Flex,
  Text,
  Icon,
  Skeleton,
  EmptyState,
  type IconType,
} from '@/design-system';
import {
  useMemo,
  useState,
  useCallback,
  useEffect,
  memo,
  type FC,
} from 'react';
import {
  skeletonNodes,
  skeletonEdges,
  useNodeHeightMeasurement,
  getLayoutNodes,
  getEdgePositions,
  NODE_WIDTH_LINEAR,
  NODE_WIDTH_BRANCHING,
} from './flow-chart.utils';
import '@xyflow/react/dist/style.css';
import { useI18n } from '@/design-system/lib/utils';

const INITIAL_NODES: Node[] = [];
const INITIAL_EDGES: Edge[] = [];

const edgeStyle = {
  strokeDasharray: '6 6', // Dash pattern for the edge: 6px dash, 6px gap, to match design
  strokeWidth: 1,
  stroke: 'var(--muted-foreground)',
  strokeOpacity: 0.4,
} as const;

interface ICustomNodeData {
  label: string;
  onHeightMeasured?: (id: string, height: number) => void;
}

/**
 * Skeleton node for loading state
 */
const SkeletonNode = memo(({ data }: { data: { width: number } }) => (
  <Flex className="cursor-default">
    <Handle
      type="target"
      position={Position.Top}
      isConnectable={false}
      className="opacity-0"
    />
    <Skeleton
      className="h-12 rounded-md bg-muted-foreground/20"
      style={{ width: data.width }}
    />
    <Handle
      type="source"
      position={Position.Bottom}
      isConnectable={false}
      className="opacity-0"
    />
  </Flex>
));

/**
 * Custom node.
 */
const createCustomNode = (isLinear: boolean) => {
  return memo(
    ({ data, id }: { data: ICustomNodeData; id: string }) => {
      const nodeRef = useNodeHeightMeasurement(id, data.onHeightMeasured);

      return (
        <Flex
          paddingX={5}
          paddingY={2.5}
          ref={nodeRef}
          className="bg-muted-foreground/20 rounded-sm cursor-default"
          style={{
            maxWidth: isLinear ? NODE_WIDTH_LINEAR : NODE_WIDTH_BRANCHING,
          }}
        >
          <Handle
            type="target"
            position={Position.Top}
            isConnectable={false}
            className="opacity-0"
          />
          <Text
            weight="medium"
            level="large"
            className="text-accent-foreground"
          >
            {data.label}
          </Text>
          <Handle
            type="source"
            position={Position.Bottom}
            isConnectable={false}
            className="opacity-0"
          />
        </Flex>
      );
    },
    (prev, next) => prev.id === next.id && prev.data.label === next.data.label,
  );
};

/**
 * Custom edge - calculates positions from node bounds, waits for measurement
 */
const CustomEdge: FC<EdgeProps<Edge<{ label: string }>>> = ({
  id,
  source,
  target,
  data,
}) => {
  const sourceNode = useInternalNode(source);
  const targetNode = useInternalNode(target);

  const positions = getEdgePositions(sourceNode, targetNode);
  if (!positions) return null;

  const { sourceX, sourceY, targetX, targetY, labelX, labelY } = positions;
  const [edgePath] = getStraightPath({ sourceX, sourceY, targetX, targetY });
  const label = data?.label;

  return (
    <>
      <BaseEdge id={id} path={edgePath} style={edgeStyle} />
      {label && (
        <EdgeLabelRenderer>
          <Flex
            position="absolute"
            paddingX={1.5}
            paddingY={1}
            className="bg-muted-foreground rounded-sm nodrag nopan"
            style={{
              transform: `translate(-50%, -50%) translate(${labelX}px,${labelY}px)`,
            }}
          >
            <Text color="accent" className="text-xs">
              {String(label)}
            </Text>
          </Flex>
        </EdgeLabelRenderer>
      )}
    </>
  );
};

const edgeTypes = { default: CustomEdge };
const skeletonNodeTypes = { skeleton: SkeletonNode };

export interface IFlowChartProps {
  initialNodes?: Node[];
  initialEdges?: Edge[];
  width?: string | number;
  height?: string | number;
  fitView?: boolean;
  linear?: boolean;
  error?: {
    show?: boolean;
    title?: string;
    description?: string;
    actionLabel?: string;
    onAction?: () => void;
    actionLoading?: boolean;
  };
  loading?: boolean;
  loadingText?: string;
  minZoom?: number;
  maxZoom?: number;
  overlay?: {
    show?: boolean;
    text?: string;
    icon?: IconType;
    onDismiss?: () => void;
    autoHideDelay?: number;
  };
}

// Render flow chart
function FlowChartInner({
  initialNodes = INITIAL_NODES,
  initialEdges = INITIAL_EDGES,
  fitView = true,
  linear = true,
  error,
  loading = false,
  loadingText = 'Loading...',
  minZoom = 0.4,
  maxZoom = 2,
  overlay,
}: IFlowChartProps) {
  const { t } = useI18n();
  const showError = error?.show ?? false;
  const errorTitle = error?.title ?? t('flowChart.errorTitle');
  const errorDescription =
    error?.description ?? t('flowChart.errorDescription');
  const errorActionLabel =
    error?.actionLabel ?? t('flowChart.errorActionLabel');
  const errorOnAction = error?.onAction;
  const errorActionLoading = error?.actionLoading ?? false;
  const [nodeHeights, setNodeHeights] = useState<Record<string, number>>({});
  const [isFading, setIsFading] = useState(false);

  // Overlay configuration, use props or default to values below
  const showOverlay = overlay?.show && !loading && !showError;
  const overlayText =
    overlay?.text ??
    'Click and drag to move around. Use pinch or scroll wheel to zoom in and out.';
  const autoHideDelay = overlay?.autoHideDelay ?? 3000;
  const overlayIcon = overlay?.icon ?? 'SquareMousePointer';

  /**
   * Handles dismissing the instructional overlay with fade-out animation.
   */
  const handleDismissOverlay = useCallback(() => {
    if (isFading) return;
    setIsFading(true);
  }, [isFading]);

  /**
   * Auto-fade timer: dismisses the overlay after autoHideDelay if not already dismissed.
   */

  useEffect(() => {
    if (!showOverlay || isFading) return;

    const timerId = setTimeout(() => {
      setIsFading(true);
    }, autoHideDelay);

    return () => clearTimeout(timerId);
  }, [showOverlay, isFading, autoHideDelay]);

  /**
   * Removes overlay from DOM after fade animation completes
   */
  const handleFadeComplete = useCallback(() => {
    overlay?.onDismiss?.();
  }, [overlay]);

  const handleHeightMeasured = useCallback((nodeId: string, h: number) => {
    setNodeHeights(prev =>
      prev[nodeId] === h ? prev : { ...prev, [nodeId]: h },
    );
  }, []);

  const nodeTypes = useMemo(
    () => ({ custom: createCustomNode(linear) }),
    [linear],
  );

  /**
   * Calculates and positions nodes using the dagre layout algorithm.
   *
   * Applies layout positioning to initial nodes based on their measured heights
   * and adds the height measurement callback to each node's data for dynamic
   * height tracking.
   *
   * @returns {Node[]} Array of nodes with calculated positions and height measurement callbacks
   */
  const positionedNodes = useMemo(() => {
    if (initialNodes.length === 0) return [];
    return getLayoutNodes(initialNodes, initialEdges, nodeHeights, linear).map(
      node => ({
        ...node,
        data: { ...node.data, onHeightMeasured: handleHeightMeasured },
      }),
    );
  }, [initialNodes, initialEdges, nodeHeights, handleHeightMeasured, linear]);

  const positionedSkeletonNodes = useMemo(
    () => getLayoutNodes(skeletonNodes, skeletonEdges, {}, true),
    [],
  );

  return (
    <Flex
      position={loading || showOverlay ? 'relative' : undefined}
      width="full"
      height="full"
      justify={showError ? 'center' : undefined}
      align={showError ? 'center' : undefined}
      paddingX={showError ? 4 : undefined}
      paddingY={showError ? 3 : undefined}
      className="bg-secondary/50 rounded-md"
    >
      {loading && (
        <>
          <ReactFlow
            nodes={positionedSkeletonNodes}
            edges={skeletonEdges}
            fitView
            nodeTypes={skeletonNodeTypes}
            edgeTypes={edgeTypes}
            nodeOrigin={[0.5, 0]}
            nodesDraggable={false}
            fitViewOptions={{ maxZoom: 1.0, minZoom: 0.1, padding: 0.1 }}
            minZoom={0.1}
            maxZoom={maxZoom}
            panOnDrag={false}
            zoomOnScroll={false}
            zoomOnPinch={false}
            zoomOnDoubleClick={false}
          />
          <Text
            color="muted"
            className="absolute text-xs whitespace-nowrap pointer-events-none"
            style={{
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
            }}
          >
            {loadingText}
          </Text>
        </>
      )}

      {showError && (
        <EmptyState
          icon="CircleAlert"
          title={errorTitle}
          description={errorDescription}
          actionLabel={errorOnAction ? errorActionLabel : undefined}
          actionIcon="RefreshCw"
          onAction={errorOnAction}
          actionLoading={errorActionLoading}
          bordered
          className="max-w-sm"
        />
      )}

      {!loading && !showError && (
        <ReactFlow
          nodes={positionedNodes}
          edges={initialEdges}
          fitView={fitView}
          nodeTypes={nodeTypes}
          edgeTypes={edgeTypes}
          nodeOrigin={[0.5, 0]}
          nodesDraggable={false}
          fitViewOptions={{ maxZoom: 0.8, minZoom: 0.1, padding: 0.2 }}
          minZoom={minZoom}
          maxZoom={maxZoom}
          proOptions={{ hideAttribution: true }}
        />
      )}

      {/* Instructional overlay - fades out on mouse movement or after timeout */}
      {showOverlay && (
        <Flex
          position="absolute"
          direction="column"
          gap={2}
          className={`inset-0 bg-black/60 rounded-md z-10 transition-opacity duration-700 ${
            isFading ? 'opacity-0 pointer-events-none' : 'opacity-100'
          }`}
          align="center"
          justify="center"
          onMouseMove={handleDismissOverlay}
          onTransitionEnd={handleFadeComplete}
          data-testid="flowchart-overlay"
        >
          <Icon type={overlayIcon} size="xl" className="text-white" />
          <Text level="small" className="text-center max-w-[200px] text-white">
            {overlayText}
          </Text>
        </Flex>
      )}
    </Flex>
  );
}

function FlowChart(props: IFlowChartProps) {
  return (
    <ReactFlowProvider>
      <FlowChartInner {...props} />
    </ReactFlowProvider>
  );
}

export default FlowChart;
