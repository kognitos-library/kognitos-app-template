import type { Meta, StoryObj } from '@storybook/react';
import { Flex } from '@/design-system';

import { ShimmeringText } from './shimmering-text';

const meta: Meta<typeof ShimmeringText> = {
  title: 'Design System/Primitives/General/ShimmeringText',
  component: ShimmeringText,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'An animated text component that creates a shimmering effect across characters. Can optionally include a wave animation for a more dynamic effect. Perfect for loading states, attention-grabbing text, or decorative elements.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    text: {
      control: { type: 'text' },
      description: 'The text to animate',
    },
    duration: {
      control: { type: 'number', min: 0.1, max: 5, step: 0.1 },
      description: 'Duration of the animation cycle in seconds',
    },
    wave: {
      control: { type: 'boolean' },
      description: 'Enable wave animation (movement and rotation)',
    },
    color: {
      control: { type: 'text' },
      description: 'Base color of the text (CSS variable or color value)',
    },
    shimmeringColor: {
      control: { type: 'text' },
      description: 'Color when shimmering (CSS variable or color value)',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    text: 'Shimmering Text',
    duration: 1,
    wave: false,
    color: 'var(--color-muted-foreground)',
    shimmeringColor: 'var(--color-muted)',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Default shimmering text with basic color animation. Adjust the controls to see real-time changes.',
      },
    },
  },
};

export const WithWave: Story = {
  args: {
    text: 'Wave Animation',
    duration: 1,
    wave: true,
    color: 'var(--color-muted-foreground)',
    shimmeringColor: 'var(--color-muted)',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Shimmering text with wave animation enabled. Characters move and rotate as they shimmer.',
      },
    },
  },
};

export const DifferentDurations: Story = {
  render: () => (
    <Flex direction="column" gap={4} align="start">
      <div>
        <div className="text-sm text-muted-foreground mb-2">Fast (0.5s)</div>
        <ShimmeringText
          text="Fast Animation"
          duration={0.5}
          color="var(--color-muted-foreground)"
          shimmeringColor="var(--color-muted)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Default (1s)</div>
        <ShimmeringText
          text="Default Speed"
          duration={1}
          color="var(--color-muted-foreground)"
          shimmeringColor="var(--color-muted)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Slow (2s)</div>
        <ShimmeringText
          text="Slow Animation"
          duration={2}
          color="var(--color-muted-foreground)"
          shimmeringColor="var(--color-muted)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Very Slow (3s)</div>
        <ShimmeringText
          text="Very Slow Animation"
          duration={3}
          color="var(--color-muted-foreground)"
          shimmeringColor="var(--color-muted)"
        />
      </div>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Different animation durations from fast to very slow.',
      },
    },
  },
};

export const ColorVariants: Story = {
  render: () => (
    <Flex direction="column" gap={4} align="start">
      <div>
        <div className="text-sm text-muted-foreground mb-2">Muted</div>
        <ShimmeringText
          text="Muted Colors"
          color="var(--color-muted-foreground)"
          shimmeringColor="var(--color-muted)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Primary</div>
        <ShimmeringText
          text="Primary Colors"
          color="var(--color-primary)"
          shimmeringColor="var(--color-primary-foreground)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Accent</div>
        <ShimmeringText
          text="Accent Colors"
          color="var(--color-accent)"
          shimmeringColor="var(--color-accent-foreground)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Destructive</div>
        <ShimmeringText
          text="Destructive Colors"
          color="var(--color-destructive)"
          shimmeringColor="color-mix(in oklch, var(--color-destructive) 60%, white)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Success</div>
        <ShimmeringText
          text="Success Colors"
          color="var(--color-success)"
          shimmeringColor="color-mix(in oklch, var(--color-success) 60%, white)"
        />
      </div>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Different color combinations for the shimmering effect using design system colors.',
      },
    },
  },
};

export const TextLengths: Story = {
  render: () => (
    <Flex direction="column" gap={4} align="start">
      <div>
        <div className="text-sm text-muted-foreground mb-2">Short</div>
        <ShimmeringText text="Hi" duration={1} />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Medium</div>
        <ShimmeringText text="Hello World" duration={1} />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Long</div>
        <ShimmeringText
          text="This is a longer sentence with more characters"
          duration={1}
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">Very Long</div>
        <ShimmeringText
          text="This is a very long sentence that demonstrates how the shimmering effect works across many characters in a single string"
          duration={1}
        />
      </div>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Shimmering effect with different text lengths.',
      },
    },
  },
};

export const WaveVariants: Story = {
  render: () => (
    <Flex direction="column" gap={4} align="start">
      <div>
        <div className="text-sm text-muted-foreground mb-2">Without Wave</div>
        <ShimmeringText
          text="Standard Shimmer"
          wave={false}
          duration={1}
          color="var(--color-muted-foreground)"
          shimmeringColor="var(--color-muted)"
        />
      </div>
      <div>
        <div className="text-sm text-muted-foreground mb-2">With Wave</div>
        <ShimmeringText
          text="Wave Shimmer"
          wave
          duration={1}
          color="var(--color-muted-foreground)"
          shimmeringColor="var(--color-muted)"
        />
      </div>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Comparison between standard shimmer and wave animation.',
      },
    },
  },
};
