import type { Meta, StoryObj } from '@storybook/react-vite';
import { Flex } from './flex';
import { Button } from './button';
import { Card, CardContent } from './card';

const meta: Meta<typeof Flex> = {
  title: 'Design System/Primitives/Layout/Flex',
  component: Flex,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Flexible layout components for creating responsive layouts with ease. Flex provides horizontal layouts while Col provides vertical layouts.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    direction: {
      control: { type: 'select' },
      options: ['row', 'row-reverse', 'column', 'column-reverse'],
      description: 'The direction of the flex container',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'row' },
        category: 'Layout',
      },
    },
    align: {
      control: { type: 'select' },
      options: ['start', 'center', 'end', 'stretch', 'baseline'],
      description: 'Alignment of items along the cross axis',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'start' },
        category: 'Layout',
      },
    },
    justify: {
      control: { type: 'select' },
      options: ['start', 'center', 'end', 'between', 'around', 'evenly'],
      description: 'Justification of items along the main axis',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'start' },
        category: 'Layout',
      },
    },
    wrap: {
      control: { type: 'select' },
      options: ['nowrap', 'wrap', 'wrap-reverse'],
      description: 'How items wrap when they overflow',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'nowrap' },
        category: 'Layout',
      },
    },
    gap: {
      control: { type: 'select' },
      options: [0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32],
      description: 'Gap between flex items',
      table: {
        type: { summary: 'number' },
        defaultValue: { summary: '0' },
        category: 'Spacing',
      },
    },
    width: {
      control: { type: 'select' },
      options: ['auto', 'full', 'fit'],
      description: 'Width of the flex container',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'auto' },
        category: 'Layout',
      },
    },
  },
  args: {
    direction: 'row',
    align: 'start',
    justify: 'start',
    wrap: 'nowrap',
    gap: 4,
    width: 'auto',
  },
};

export default meta;
type Story = StoryObj<typeof Flex>;

// Basic Flex examples
export const Basic: Story = {
  render: args => (
    <Flex {...args} className="p-4 border rounded-lg">
      <div className="w-20 h-20 bg-primary rounded flex items-center justify-center text-primary-foreground">
        1
      </div>
      <div className="w-20 h-20 bg-secondary rounded flex items-center justify-center text-secondary-foreground">
        2
      </div>
      <div className="w-20 h-20 bg-accent rounded flex items-center justify-center text-accent-foreground">
        3
      </div>
    </Flex>
  ),
};

export const Centered: Story = {
  render: () => (
    <Flex align="center" justify="center" className="h-32 border rounded-lg">
      <div className="w-20 h-20 bg-primary rounded flex items-center justify-center text-primary-foreground">
        Centered
      </div>
    </Flex>
  ),
};

export const SpaceBetween: Story = {
  render: () => (
    <Flex justify="between" className="p-4 border rounded-lg">
      <Button variant="outline">Left</Button>
      <Button variant="outline">Center</Button>
      <Button variant="outline">Right</Button>
    </Flex>
  ),
};

export const Wrapped: Story = {
  render: () => (
    <Flex wrap="wrap" gap={2} className="p-4 border rounded-lg max-w-md">
      {Array.from({ length: 8 }, (_, i) => (
        <div
          key={i}
          className="w-16 h-16 bg-primary/20 rounded flex items-center justify-center text-sm"
        >
          {i + 1}
        </div>
      ))}
    </Flex>
  ),
};

export const Responsive: Story = {
  render: () => (
    <Flex
      direction="column"
      gap={4}
      className="p-4 border rounded-lg md:flex-row"
    >
      <Card className="flex-1">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-2">Card 1</h3>
          <p className="text-sm text-muted-foreground">
            This card will stack vertically on mobile and horizontally on
            desktop.
          </p>
        </CardContent>
      </Card>
      <Card className="flex-1">
        <CardContent className="p-4">
          <h3 className="font-semibold mb-2">Card 2</h3>
          <p className="text-sm text-muted-foreground">
            Responsive layout using Flex component.
          </p>
        </CardContent>
      </Card>
    </Flex>
  ),
};
