import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import {
  StepperCardItem,
  StepperCardIcon,
  StepperCardContent,
  StepperCardTitle,
  StepperCardDescription,
} from './stepper-card-items';
import { Flex } from './flex';

const meta = {
  title: 'Design System/Primitives/Navigation/StepperCardItem',
  component: StepperCardItem,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A composable stepper card item component that displays a step in a multi-step process. Use StepperCardIcon, StepperCardContent, StepperCardTitle, and StepperCardDescription as children.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    state: {
      control: { type: 'select' },
      options: ['default', 'completed', 'disabled', 'loading'],
      description:
        'The state of the step (affects opacity for disabled/loading)',
    },
    variant: {
      control: { type: 'select' },
      options: ['default', 'selected'],
      description:
        'The variant - default shows step number, selected highlights the current step',
    },
  },
} satisfies Meta<typeof StepperCardItem>;

export default meta;
type Story = StoryObj<typeof meta>;

// Placeholder args for stories using render function
const placeholderArgs = { children: null as unknown as React.ReactNode };

// Default variant states
export const DefaultState: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'default'} variant={'default'}>
      <StepperCardIcon stepNumber={1} state={'default'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

export const CompletedState: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'completed'} variant={'default'}>
      <StepperCardIcon state={'completed'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

export const DisabledState: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'disabled'} variant={'default'}>
      <StepperCardIcon stepNumber={1} state={'disabled'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

export const LoadingState: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'loading'} variant={'default'}>
      <StepperCardIcon stepNumber={1} state={'loading'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

// Selected variant states
export const SelectedDefault: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'default'} variant={'selected'}>
      <StepperCardIcon stepNumber={1} state={'default'} variant={'selected'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

export const SelectedCompleted: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'completed'} variant={'selected'}>
      <StepperCardIcon state={'completed'} variant={'selected'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

export const SelectedDisabled: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'disabled'} variant={'selected'}>
      <StepperCardIcon stepNumber={1} state={'disabled'} variant={'selected'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

export const SelectedLoading: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'loading'} variant={'selected'}>
      <StepperCardIcon stepNumber={1} state={'loading'} variant={'selected'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
        <StepperCardDescription>Description</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

// Without description
export const WithoutDescription: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'default'} variant={'default'}>
      <StepperCardIcon stepNumber={1} state={'default'} />
      <StepperCardContent>
        <StepperCardTitle>Title</StepperCardTitle>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

// With custom icon
export const WithIcon: Story = {
  args: placeholderArgs,
  render: () => (
    <StepperCardItem state={'default'} variant={'default'}>
      <StepperCardIcon icon="User" state={'default'} />
      <StepperCardContent>
        <StepperCardTitle>Account</StepperCardTitle>
        <StepperCardDescription>Set up your account</StepperCardDescription>
      </StepperCardContent>
    </StepperCardItem>
  ),
};

// All variants matrix (matching Figma design)
export const AllVariants: Story = {
  args: placeholderArgs,
  render: () => (
    <Flex direction="column" gap={4} className="w-[800px]">
      {/* Row 1: Default variant */}
      <Flex gap={4} width="full">
        <StepperCardItem state={'default'} variant={'default'}>
          <StepperCardIcon stepNumber={1} state={'default'} />
          <StepperCardContent>
            <StepperCardTitle>Default</StepperCardTitle>
            <StepperCardDescription>
              This is a long description of the step. It can be long and will be
              truncated if it exceeds the width of the container.
            </StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
        <StepperCardItem state={'completed'} variant={'default'}>
          <StepperCardIcon state={'completed'} />
          <StepperCardContent>
            <StepperCardTitle>Completed</StepperCardTitle>
            <StepperCardDescription>Description</StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
        <StepperCardItem state={'disabled'} variant={'default'}>
          <StepperCardIcon stepNumber={3} state={'disabled'} />
          <StepperCardContent>
            <StepperCardTitle>Disabled</StepperCardTitle>
            <StepperCardDescription>Description</StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
        <StepperCardItem state={'loading'} variant={'default'}>
          <StepperCardIcon stepNumber={4} state={'loading'} />
          <StepperCardContent>
            <StepperCardTitle>Loading</StepperCardTitle>
            <StepperCardDescription>Description</StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
      </Flex>

      {/* Row 2: Selected variant */}
      <Flex gap={4} width="full">
        <StepperCardItem state={'default'} variant={'selected'}>
          <StepperCardIcon
            stepNumber={1}
            state={'default'}
            variant={'selected'}
          />
          <StepperCardContent>
            <StepperCardTitle>Selected Default</StepperCardTitle>
            <StepperCardDescription>Description</StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
        <StepperCardItem state={'completed'} variant={'selected'}>
          <StepperCardIcon state={'completed'} variant={'selected'} />
          <StepperCardContent>
            <StepperCardTitle>Selected Completed</StepperCardTitle>
            <StepperCardDescription>Description</StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
        <StepperCardItem state={'disabled'} variant={'selected'}>
          <StepperCardIcon
            stepNumber={3}
            state={'disabled'}
            variant={'selected'}
          />
          <StepperCardContent>
            <StepperCardTitle>Selected Disabled</StepperCardTitle>
            <StepperCardDescription>Description</StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
        <StepperCardItem state={'loading'} variant={'selected'}>
          <StepperCardIcon
            stepNumber={4}
            state={'loading'}
            variant={'selected'}
          />
          <StepperCardContent>
            <StepperCardTitle>Selected Loading</StepperCardTitle>
            <StepperCardDescription>Description</StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>
      </Flex>
    </Flex>
  ),
};
