import React from 'react';
import { cva } from 'class-variance-authority';
import { cn } from '@/design-system/lib/utils';

// Title component variants - fixed weights for headings
const titleVariants = cva('text-foreground', {
  variants: {
    level: {
      h1: 'text-5xl font-semibold md:text-4xl',
      h2: 'text-3xl font-medium',
      h3: 'text-2xl font-medium',
      h4: 'text-xl font-medium',
    },
    color: {
      default: '',
      muted: 'text-muted-foreground',
      primary: 'text-primary',
      secondary: 'text-secondary',
      accent: 'text-accent',
      destructive: 'text-destructive',
      card: 'text-card-foreground',
    },
    align: {
      left: 'text-left',
      center: 'text-center',
      right: 'text-right',
      justify: 'text-justify',
    },
  },
  defaultVariants: {
    level: 'h1',
    color: 'default',
    align: 'left',
  },
});

// Text component variants - separated level and type
const textVariants = cva('text-foreground', {
  variants: {
    level: {
      xSmall: 'text-xs font-normal',
      small: 'text-sm font-medium',
      base: 'text-base font-normal',
      large: 'text-lg font-semibold',
    },
    type: {
      paragraph: '',
      blockquote: 'italic border-l-2 border-border pl-6',
      lead: 'font-normal text-lg text-muted-foreground',
      inlineCode:
        'font-mono text-[0.75em] bg-muted px-2 py-1 rounded-md break-anywhere',
      code: 'font-mono text-[0.875em] bg-muted px-4 py-4 rounded-md block w-full whitespace-pre-wrap break-words',
    },
    color: {
      default: '',
      muted: 'text-muted-foreground',
      primary: 'text-primary',
      secondary: 'text-secondary',
      accent: 'text-accent',
      destructive: 'text-destructive',
      card: 'text-card-foreground',
    },
    align: {
      left: 'text-left',
      center: 'text-center',
      right: 'text-right',
      justify: 'text-justify',
    },
    weight: {
      normal: 'font-normal',
      medium: 'font-medium',
      semibold: 'font-semibold',
      bold: 'font-bold',
    },
  },
  defaultVariants: {
    level: 'base',
    type: 'paragraph',
    color: 'default',
    align: 'left',
    weight: 'normal',
  },
});

// Title component interface
interface ITitleProps extends React.HTMLAttributes<HTMLHeadingElement> {
  level?: 'h1' | 'h2' | 'h3' | 'h4';
  color?:
    | 'default'
    | 'muted'
    | 'primary'
    | 'secondary'
    | 'accent'
    | 'destructive'
    | 'card';
  align?: 'left' | 'center' | 'right' | 'justify';
  children: React.ReactNode;
}

// Text component interface
interface ITextProps {
  level?: 'xSmall' | 'small' | 'base' | 'large';
  type?: 'paragraph' | 'lead' | 'inlineCode' | 'code' | 'blockquote';
  color?:
    | 'default'
    | 'muted'
    | 'primary'
    | 'secondary'
    | 'accent'
    | 'destructive'
    | 'card';
  align?: 'left' | 'center' | 'right' | 'justify';
  weight?: 'normal' | 'medium' | 'semibold' | 'bold';
  as?: 'p' | 'span' | 'div' | 'code' | 'blockquote';
  children: React.ReactNode;
  className?: string;
}

// Title component
function Title({
  className,
  level = 'h1',
  color = 'default',
  align = 'left',
  children,
  ...props
}: ITitleProps) {
  const Component = level;

  return (
    <Component
      className={cn(titleVariants({ level, color, align }), className)}
      {...props}
    >
      {children}
    </Component>
  );
}

// Text component
function Text({
  className,
  level = 'base',
  type = 'paragraph',
  color = 'default',
  align = 'left',
  weight = 'normal',
  as,
  children,
  ...props
}: ITextProps & React.HTMLAttributes<HTMLElement>) {
  // Determine the appropriate element based on type
  const getElement = () => {
    if (as) return as;
    switch (type) {
      case 'code':
      case 'inlineCode':
        return 'code';
      case 'blockquote':
        return 'blockquote';
      default:
        return 'p';
    }
  };

  const Component = getElement();

  return (
    <Component
      className={cn(
        textVariants({ level, type, color, align, weight, className }),
      )}
      {...props}
    >
      {children}
    </Component>
  );
}

// Export components and types
export { Title, Text, titleVariants, textVariants };
export type { ITitleProps, ITextProps };

// Export individual prop types for reuse
export type TextLevel = ITextProps['level'];
export type TextType = ITextProps['type'];
export type TextColor = ITextProps['color'];
export type TextAlign = ITextProps['align'];
export type TextWeight = ITextProps['weight'];
export type TitleLevel = ITitleProps['level'];
export type TitleColor = ITitleProps['color'];
export type TitleAlign = ITitleProps['align'];
