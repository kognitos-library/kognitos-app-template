import { render, screen } from '@testing-library/react';
import { Input } from './input';
import { describe, it, expect } from 'vitest';

describe('Input', () => {
  describe('Rendering', () => {
    it('should render input element', () => {
      render(<Input data-testid="input" placeholder="Test input" />);

      const input = screen.getByTestId('input');
      expect(input).toBeInTheDocument();
      expect(input).toHaveAttribute('placeholder', 'Test input');
    });

    it('should have data-slot attribute', () => {
      render(<Input data-testid="input" placeholder="Test input" />);

      const input = screen.getByTestId('input');
      expect(input).toHaveAttribute('data-slot', 'input');
    });
  });

  describe('Variants', () => {
    it('should render with default variant', () => {
      render(<Input data-testid="input" placeholder="Test input" />);

      const input = screen.getByTestId('input');
      expect(input).toHaveClass('border-input');
      expect(input).toHaveClass('rounded-md');
      expect(input).toHaveClass('border');
      expect(input).toHaveClass('shadow-xs');
      expect(input).toHaveClass('focus-visible:border-ring');
      expect(input).toHaveClass('focus-visible:ring-ring/50');
    });

    it('should render with ghost variant', () => {
      render(
        <Input data-testid="input" variant="ghost" placeholder="Test input" />,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveClass('border-transparent');
      expect(input).not.toHaveClass('border-input');
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      render(
        <Input
          data-testid="input"
          className="custom-class"
          placeholder="Test input"
        />,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveClass('custom-class');
    });
  });

  describe('Props', () => {
    it('should accept standard input props', () => {
      render(
        <Input
          data-testid="input"
          type="email"
          placeholder="Enter email"
          disabled
        />,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveAttribute('type', 'email');
      expect(input).toHaveAttribute('placeholder', 'Enter email');
      expect(input).toBeDisabled();
    });

    it('should forward additional props', () => {
      render(
        <Input
          data-testid="input"
          placeholder="Test"
          maxLength={100}
          autoComplete="off"
        />,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveAttribute('maxLength', '100');
      expect(input).toHaveAttribute('autoComplete', 'off');
    });

    it('should forward ref correctly', () => {
      const ref = { current: null as HTMLInputElement | null };
      render(<Input ref={ref} data-testid="input" placeholder="Test input" />);

      const input = screen.getByTestId('input');
      expect(ref.current).toBe(input);
    });
  });

  describe('States', () => {
    it('should handle disabled state', () => {
      render(<Input data-testid="input" placeholder="Test input" disabled />);

      const input = screen.getByTestId('input');
      expect(input).toBeDisabled();
      expect(input).toHaveClass('disabled:cursor-not-allowed');
      expect(input).toHaveClass('disabled:opacity-50');
    });

    it('should handle aria-invalid styling for default variant', () => {
      render(
        <Input data-testid="input" aria-invalid placeholder="Test input" />,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveClass('aria-invalid:ring-destructive/20');
      expect(input).toHaveClass('aria-invalid:border-destructive');
    });

    it('should handle aria-invalid styling for ghost variant', () => {
      render(
        <Input
          data-testid="input"
          variant="ghost"
          aria-invalid
          placeholder="Test input"
        />,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveClass('aria-invalid:border-transparent');
      expect(input).not.toHaveClass('aria-invalid:border-destructive');
    });
  });

  describe('Accessibility', () => {
    it('should have proper structure', () => {
      render(<Input data-testid="input" placeholder="Test input" />);

      const input = screen.getByTestId('input');
      expect(input).toHaveClass('w-full');
      expect(input).toHaveClass('outline-none');
    });

    it('should support aria attributes', () => {
      render(
        <Input
          data-testid="input"
          placeholder="Test input"
          aria-label="Test label"
          aria-describedby="help-text"
        />,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveAttribute('aria-label', 'Test label');
      expect(input).toHaveAttribute('aria-describedby', 'help-text');
    });
  });
});
