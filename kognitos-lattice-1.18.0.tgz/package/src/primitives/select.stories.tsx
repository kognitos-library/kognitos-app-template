import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
} from './select';
import { Icon } from '../icons';

const meta: Meta<typeof Select> = {
  title: 'Design System/Primitives/Data Entry/Select',
  component: Select,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A select component that allows users to choose from a list of options. Built on top of Radix UI primitives with full keyboard navigation and accessibility support.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the select is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'State',
      },
    },
    required: {
      control: { type: 'boolean' },
      description: 'Whether the select is required',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'Validation',
      },
    },
    name: {
      control: { type: 'text' },
      description: 'The name attribute for form submission',
      table: {
        type: { summary: 'string' },
        category: 'Form',
      },
    },
    value: {
      control: { type: 'text' },
      description: 'The controlled value of the select',
      table: {
        type: { summary: 'string' },
        category: 'Form',
      },
    },
    defaultValue: {
      control: { type: 'text' },
      description: 'The default value of the select',
      table: {
        type: { summary: 'string' },
        category: 'Form',
      },
    },
    onValueChange: {
      description: 'Callback when the value changes',
      table: {
        type: { summary: '(value: string) => void' },
        category: 'Events',
      },
    },
    open: {
      control: { type: 'boolean' },
      description: 'Whether the select is open',
      table: {
        type: { summary: 'boolean' },
        category: 'State',
      },
    },
    onOpenChange: {
      description: 'Callback when the open state changes',
      table: {
        type: { summary: '(open: boolean) => void' },
        category: 'Events',
      },
    },
  },
  args: {
    disabled: false,
    required: false,
  },
};

export default meta;
type Story = StoryObj<typeof Select>;

// Primary story - This will be the main showcase in autodocs
export const Primary: Story = {
  render: () => (
    <Select defaultValue="option1">
      <SelectTrigger>
        <SelectValue placeholder="Select an option" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="option1">Option 1</SelectItem>
        <SelectItem value="option2">Option 2</SelectItem>
        <SelectItem value="option3">Option 3</SelectItem>
      </SelectContent>
    </Select>
  ),
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'A basic select component with a placeholder and three options. Use the controls below to experiment with different states and behaviors.',
      },
    },
  },
};

// Basic Select Story
export const Default: Story = {
  render: () => (
    <Select defaultValue="apple">
      <SelectTrigger>
        <SelectValue placeholder="Choose a fruit" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="apple">Apple</SelectItem>
        <SelectItem value="banana">Banana</SelectItem>
        <SelectItem value="orange">Orange</SelectItem>
        <SelectItem value="grape">Grape</SelectItem>
      </SelectContent>
    </Select>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'The default select component with standard styling and behavior.',
      },
    },
  },
};

// With Icons Story
export const WithIcons: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Select with Icons
        </h3>
        <Select defaultValue="download">
          <SelectTrigger>
            <SelectValue placeholder="Choose an action" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="download">
              <Icon type="Download" className="mr-2" />
              Download
            </SelectItem>
            <SelectItem value="upload">
              <Icon type="Upload" className="mr-2" />
              Upload
            </SelectItem>
            <SelectItem value="edit">
              <Icon type="Edit" className="mr-2" />
              Edit
            </SelectItem>
            <SelectItem value="delete">
              <Icon type="Trash" className="mr-2" />
              Delete
            </SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  ),
};

// Different Sizes Story
export const Sizes: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Select Sizes
        </h3>
        <div className="flex flex-col gap-3">
          <Select defaultValue="small">
            <SelectTrigger size="sm">
              <SelectValue placeholder="Small select" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="small">Small Option</SelectItem>
              <SelectItem value="medium">Medium Option</SelectItem>
              <SelectItem value="large">Large Option</SelectItem>
            </SelectContent>
          </Select>

          <Select defaultValue="default">
            <SelectTrigger size="default">
              <SelectValue placeholder="Default select" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="small">Small Option</SelectItem>
              <SelectItem value="medium">Medium Option</SelectItem>
              <SelectItem value="large">Large Option</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  ),
};

// With Groups Story
export const WithGroups: Story = {
  render: () => (
    <Select defaultValue="react">
      <SelectTrigger>
        <SelectValue placeholder="Choose a framework" />
      </SelectTrigger>
      <SelectContent>
        <SelectGroup>
          <SelectLabel>Frontend Frameworks</SelectLabel>
          <SelectItem value="react">React</SelectItem>
          <SelectItem value="vue">Vue</SelectItem>
          <SelectItem value="angular">Angular</SelectItem>
        </SelectGroup>
        <SelectSeparator />
        <SelectGroup>
          <SelectLabel>Backend Frameworks</SelectLabel>
          <SelectItem value="node">Node.js</SelectItem>
          <SelectItem value="python">Python</SelectItem>
          <SelectItem value="java">Java</SelectItem>
        </SelectGroup>
      </SelectContent>
    </Select>
  ),
};

// States Story
export const States: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Select States
        </h3>
        <div className="flex flex-col gap-3">
          <Select defaultValue="normal">
            <SelectTrigger>
              <SelectValue placeholder="Normal state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal Option</SelectItem>
              <SelectItem value="another">Another Option</SelectItem>
            </SelectContent>
          </Select>

          <Select defaultValue="disabled" disabled>
            <SelectTrigger>
              <SelectValue placeholder="Disabled state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="disabled">Disabled Option</SelectItem>
              <SelectItem value="another">Another Option</SelectItem>
            </SelectContent>
          </Select>

          <Select defaultValue="required" required>
            <SelectTrigger>
              <SelectValue placeholder="Required field" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="required">Required Option</SelectItem>
              <SelectItem value="another">Another Option</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  ),
};

// Compact Variant Story
export const CompactVariant: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-4">
          Compact Select - Minimal styling without borders or background
        </h3>
        <div className="flex flex-col gap-4">
          {/* Compact variant example */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Sort by:</span>
            <Select defaultValue="newest">
              <SelectTrigger compact>
                <SelectValue placeholder="Select option" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="rating">Highest Rated</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Comparison: Compact vs Default */}
          <div className="mt-6 p-4 border rounded-lg space-y-4">
            <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Comparison
            </h4>

            <div className="space-y-3">
              <div className="flex items-center gap-4">
                <span className="text-sm w-20">Default:</span>
                <Select defaultValue="option1">
                  <SelectTrigger>
                    <SelectValue placeholder="Select option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="option1">Option 1</SelectItem>
                    <SelectItem value="option2">Option 2</SelectItem>
                    <SelectItem value="option3">Option 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center gap-4">
                <span className="text-sm w-20">Compact:</span>
                <Select defaultValue="option1">
                  <SelectTrigger compact>
                    <SelectValue placeholder="Select option" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="option1">Option 1</SelectItem>
                    <SelectItem value="option2">Option 2</SelectItem>
                    <SelectItem value="option3">Option 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Use cases */}
          <div className="mt-6 p-4 bg-muted/30 rounded-lg">
            <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-3">
              Use Cases
            </h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Inline selects within text or headers</li>
              <li>• Table column headers with sorting options</li>
              <li>• Toolbar or action bar controls</li>
              <li>
                • Minimalist UI designs where borders would add visual clutter
              </li>
            </ul>
          </div>

          {/* Disabled compact variant */}
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Disabled:</span>
            <Select defaultValue="disabled" disabled>
              <SelectTrigger compact>
                <SelectValue placeholder="Disabled compact" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="disabled">Disabled Option</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  ),
};

// Form Integration Story
export const FormIntegration: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Form Integration
        </h3>
        <form className="space-y-3">
          <div>
            <label
              htmlFor="country"
              className="text-sm font-medium text-foreground"
            >
              Country
            </label>
            <Select name="country" defaultValue="us">
              <SelectTrigger id="country">
                <SelectValue placeholder="Select your country" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="us">United States</SelectItem>
                <SelectItem value="ca">Canada</SelectItem>
                <SelectItem value="uk">United Kingdom</SelectItem>
                <SelectItem value="au">Australia</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label
              htmlFor="language"
              className="text-sm font-medium text-foreground"
            >
              Language
            </label>
            <Select name="language" defaultValue="en" required>
              <SelectTrigger id="language">
                <SelectValue placeholder="Select your language" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">English</SelectItem>
                <SelectItem value="es">Spanish</SelectItem>
                <SelectItem value="fr">French</SelectItem>
                <SelectItem value="de">German</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </form>
      </div>
    </div>
  ),
};

// Complex Options Story
export const ComplexOptions: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Complex Options with Descriptions
        </h3>
        <Select defaultValue="pro">
          <SelectTrigger>
            <SelectValue placeholder="Choose a plan" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="free">
              <div className="flex flex-col">
                <span className="font-medium">Free Plan</span>
                <span className="text-xs text-muted-foreground">
                  Basic features included
                </span>
              </div>
            </SelectItem>
            <SelectItem value="pro">
              <div className="flex flex-col">
                <span className="font-medium">Pro Plan</span>
                <span className="text-xs text-muted-foreground">
                  Advanced features + priority support
                </span>
              </div>
            </SelectItem>
            <SelectItem value="enterprise">
              <div className="flex flex-col">
                <span className="font-medium">Enterprise</span>
                <span className="text-xs text-muted-foreground">
                  Custom solutions + dedicated support
                </span>
              </div>
            </SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  ),
};

// Multiple Selects Story
export const MultipleSelects: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Multiple Selects in a Form
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium text-foreground">
              Category
            </label>
            <Select defaultValue="technology">
              <SelectTrigger>
                <SelectValue placeholder="Select category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="design">Design</SelectItem>
                <SelectItem value="business">Business</SelectItem>
                <SelectItem value="marketing">Marketing</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              Priority
            </label>
            <Select defaultValue="medium">
              <SelectTrigger>
                <SelectValue placeholder="Select priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="urgent">Urgent</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              Status
            </label>
            <Select defaultValue="in-progress">
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="todo">To Do</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="review">Review</SelectItem>
                <SelectItem value="done">Done</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              Assignee
            </label>
            <Select defaultValue="john">
              <SelectTrigger>
                <SelectValue placeholder="Select assignee" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="john">John Doe</SelectItem>
                <SelectItem value="jane">Jane Smith</SelectItem>
                <SelectItem value="bob">Bob Johnson</SelectItem>
                <SelectItem value="alice">Alice Brown</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  ),
};

// Accessibility Story
export const Accessibility: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Accessibility Features
        </h3>
        <div className="space-y-3">
          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Keyboard Navigation
            </h4>
            <p className="text-xs text-muted-foreground mb-2">
              All selects are keyboard accessible. Use Tab to navigate,
              Space/Enter to open, and arrow keys to navigate options.
            </p>
            <Select defaultValue="keyboard">
              <SelectTrigger>
                <SelectValue placeholder="Try keyboard navigation" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="keyboard">Keyboard Option</SelectItem>
                <SelectItem value="accessible">Accessible Option</SelectItem>
                <SelectItem value="navigable">Navigable Option</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Screen Reader Support
            </h4>
            <p className="text-xs text-muted-foreground mb-2">
              Selects include proper ARIA attributes and semantic HTML for
              screen readers.
            </p>
            <Select defaultValue="screen-reader">
              <SelectTrigger aria-label="Choose an accessibility option">
                <SelectValue placeholder="Screen reader friendly" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="screen-reader">
                  Screen Reader Option
                </SelectItem>
                <SelectItem value="aria">ARIA Support</SelectItem>
                <SelectItem value="semantic">Semantic HTML</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Focus Management
            </h4>
            <p className="text-xs text-muted-foreground mb-2">
              Focus is properly managed when opening and closing the select
              dropdown.
            </p>
            <Select defaultValue="focus">
              <SelectTrigger>
                <SelectValue placeholder="Focus management demo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="focus">Focus Option</SelectItem>
                <SelectItem value="management">Management Option</SelectItem>
                <SelectItem value="demo">Demo Option</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>
    </div>
  ),
};

// All Selects Story - Comprehensive showcase
export const AllSelects: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">Basic Select</h2>
        <Select defaultValue="basic">
          <SelectTrigger>
            <SelectValue placeholder="Basic select" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="basic">Basic Option</SelectItem>
            <SelectItem value="another">Another Option</SelectItem>
            <SelectItem value="third">Third Option</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Select with Icons
        </h2>
        <Select defaultValue="download">
          <SelectTrigger>
            <SelectValue placeholder="Choose an action" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="download">
              <Icon type="Download" className="mr-2" />
              Download
            </SelectItem>
            <SelectItem value="upload">
              <Icon type="Upload" className="mr-2" />
              Upload
            </SelectItem>
            <SelectItem value="edit">
              <Icon type="Edit" className="mr-2" />
              Edit
            </SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Select with Groups
        </h2>
        <Select defaultValue="react">
          <SelectTrigger>
            <SelectValue placeholder="Choose a framework" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectLabel>Frontend</SelectLabel>
              <SelectItem value="react">React</SelectItem>
              <SelectItem value="vue">Vue</SelectItem>
            </SelectGroup>
            <SelectSeparator />
            <SelectGroup>
              <SelectLabel>Backend</SelectLabel>
              <SelectItem value="node">Node.js</SelectItem>
              <SelectItem value="python">Python</SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Select States
        </h2>
        <div className="flex flex-col gap-3">
          <Select defaultValue="normal">
            <SelectTrigger>
              <SelectValue placeholder="Normal state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="normal">Normal</SelectItem>
            </SelectContent>
          </Select>

          <Select defaultValue="disabled" disabled>
            <SelectTrigger>
              <SelectValue placeholder="Disabled state" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="disabled">Disabled</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Form Integration
        </h2>
        <form className="space-y-3">
          <div>
            <label className="text-sm font-medium text-foreground">
              Country
            </label>
            <Select name="country" defaultValue="us">
              <SelectTrigger>
                <SelectValue placeholder="Select your country" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="us">United States</SelectItem>
                <SelectItem value="ca">Canada</SelectItem>
                <SelectItem value="uk">United Kingdom</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </form>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Accessibility
        </h2>
        <Select defaultValue="accessible">
          <SelectTrigger aria-label="Choose an accessibility option">
            <SelectValue placeholder="Accessible select" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="accessible">Accessible Option</SelectItem>
            <SelectItem value="keyboard">Keyboard Navigation</SelectItem>
            <SelectItem value="screen-reader">Screen Reader Support</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </div>
  ),
};
