import type { Meta, StoryObj } from '@storybook/react';

import { Asset, AssetType, EAssetTypeVariant } from './asset';
import { Flex } from './flex';
import { Text } from './typography';

const meta: Meta<typeof Asset> = {
  title: 'Design System/Primitives/Asset',
  component: Asset,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'An asset component for displaying file uploads with progress and actions.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['default', 'uploading', 'error'],
      description: 'The state of the asset',
    },
    name: {
      control: 'text',
      description: 'The name of the asset',
    },
    type: {
      control: { type: 'select' },
      options: Object.values(EAssetTypeVariant),
      description: 'The type of the asset',
    },
    description: {
      control: 'text',
      description: 'Description shown in default variant',
    },
    progressValue: {
      control: { type: 'range', min: 0, max: 100 },
      description: 'Progress value for uploading variant',
    },
    errorText: {
      control: 'text',
      description: 'Error text shown in error variant',
    },
    actionIcon: {
      control: { type: 'select' },
      options: ['CircleStop', 'X', 'Trash', 'Download', 'Eye'],
      description: 'Icon to show in the action button',
    },
    showActionIcon: {
      control: 'boolean',
      description: 'Whether to show the action icon button',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    variant: 'default',
    name: 'Sample Folder',
    type: 'folder',
    description: 'Complete',
  },
  decorators: [
    Story => (
      <div style={{ width: 400 }}>
        <Story />
      </div>
    ),
  ],
};

export const Variants: Story = {
  render: () => (
    <Flex direction="column" gap={4} style={{ width: 400 }}>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Default
        </Text>
        <Asset
          variant="default"
          name="Sample Folder"
          type="folder"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Uploading
        </Text>
        <Asset
          variant="uploading"
          name="LargeFile.zip"
          type="folder"
          progressValue={45}
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Error
        </Text>
        <Asset
          variant="error"
          name="Failed To Load"
          type="folder"
          errorText="Error uploading"
        />
      </Flex>
    </Flex>
  ),
};

export const SizeComparison: Story = {
  render: () => (
    <Flex direction="column" gap={4} style={{ width: 400 }}>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Default Size
        </Text>
        <Asset
          size="default"
          variant="default"
          name="Document.pdf"
          type="pdf"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Small Size
        </Text>
        <Asset
          size="sm"
          variant="default"
          name="Document.pdf"
          type="pdf"
          description="Complete"
        />
      </Flex>
    </Flex>
  ),
};

export const WithoutSubtext: Story = {
  args: {
    variant: 'default',
    name: 'Document.pdf',
    type: 'pdf',
  },
  decorators: [
    Story => (
      <div style={{ width: 400 }}>
        <Story />
      </div>
    ),
  ],
};

export const WithoutActionIcon: Story = {
  args: {
    variant: 'default',
    name: 'Spreadsheet.xlsx',
    type: 'spreadsheet',
    description: 'Complete',
    showActionIcon: false,
  },
  decorators: [
    Story => (
      <div style={{ width: 400 }}>
        <Story />
      </div>
    ),
  ],
};

export const WithCustomActionIcon: Story = {
  args: {
    variant: 'default',
    name: 'Document.pdf',
    type: 'pdf',
    description: 'Complete',
    actionIcon: 'ArrowRight',
  },
  decorators: [
    Story => (
      <div style={{ width: 400 }}>
        <Story />
      </div>
    ),
  ],
};

export const LongFileName: Story = {
  args: {
    variant: 'default',
    name: 'ThisIsAVeryLongFileNameThatShouldBeTruncatedProperly.tsx',
    type: 'document',
    description: 'Complete',
  },
  decorators: [
    Story => (
      <div style={{ width: 400 }}>
        <Story />
      </div>
    ),
  ],
};

export const WithDifferentAssetTypes: Story = {
  render: () => (
    <Flex direction="column" gap={4} style={{ width: 400 }}>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Folder (default)
        </Text>
        <Asset
          variant="default"
          name="Folder.folder"
          type="folder"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Document
        </Text>
        <Asset
          variant="default"
          name="Document.pdf"
          type="document"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Spreadsheet
        </Text>
        <Asset
          variant="default"
          name="Spreadsheet.xlsx"
          type="spreadsheet"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          PDF
        </Text>
        <Asset
          variant="default"
          name="PDF.pdf"
          type="pdf"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Image
        </Text>
        <Asset
          variant="default"
          name="Image.png"
          type="image"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          JSON
        </Text>
        <Asset
          variant="default"
          name="JSON.json"
          type="json"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Collection
        </Text>
        <Asset
          variant="default"
          name="Collection.txt"
          type="collection"
          description="Complete"
        />
      </Flex>
      <Flex direction="column" gap={2} width="full">
        <Text level="small" color="muted">
          Unknown
        </Text>
        <Asset
          variant="default"
          name="Unknown.unknown"
          type="unknown"
          description="Complete"
        />
      </Flex>
    </Flex>
  ),
};

export const AssetTypes: Story = {
  render: () => (
    <Flex direction="column" gap={4}>
      <Text level="small" color="muted">
        All Asset Types
      </Text>
      <Flex gap={2} wrap="wrap">
        <AssetType type="folder" />
        <AssetType type="document" />
        <AssetType type="spreadsheet" />
        <AssetType type="pdf" />
        <AssetType type="image" />
        <AssetType type="json" />
        <AssetType type="collection" />
        <AssetType type="unknown" />
      </Flex>

      <Text level="small" color="muted">
        Sizes
      </Text>
      <Flex gap={2} align="center">
        <AssetType type="document" iconSize="xs" />
        <AssetType type="document" iconSize="sm" />
        <AssetType type="document" iconSize="md" />
        <AssetType type="document" iconSize="lg" />
        <AssetType type="document" iconSize="xl" />
      </Flex>
    </Flex>
  ),
};
