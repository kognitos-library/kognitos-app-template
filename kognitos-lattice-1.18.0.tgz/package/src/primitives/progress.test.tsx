import { render, screen } from '@testing-library/react';
import { Progress } from './progress';
import { describe, it, expect } from 'vitest';

describe('Progress', () => {
  describe('Rendering', () => {
    it('should render progress bar with default props', () => {
      render(<Progress value={50} />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toBeInTheDocument();
      expect(progress).toHaveAttribute('data-slot', 'progress');
    });

    it('should render progress indicator', () => {
      const { container } = render(<Progress value={50} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toBeInTheDocument();
    });

    it('should apply correct width style based on value', () => {
      const { container } = render(<Progress value={75} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveStyle({ width: 'max(0.225rem, calc(75%))' });
    });

    it('should handle undefined value', () => {
      render(<Progress value={undefined} />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toBeInTheDocument();
    });

    it('should handle zero value', () => {
      const { container } = render(<Progress value={0} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveStyle({ width: 'max(0.225rem, calc(0%))' });
    });

    it('should handle 100% value', () => {
      const { container } = render(<Progress value={100} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveStyle({ width: 'max(0.225rem, calc(100%))' });
    });
  });

  describe('Variants', () => {
    it('should render with default variant', () => {
      const { container } = render(<Progress value={50} variant="default" />);

      const progress = container.querySelector('[data-slot="progress"]');
      expect(progress).toHaveClass('bg-primary/20');
    });

    it('should render with secondary variant', () => {
      const { container } = render(<Progress value={50} variant="secondary" />);

      const progress = container.querySelector('[data-slot="progress"]');
      expect(progress).toHaveClass('bg-ring/20');
    });

    it('should apply correct indicator variant for default', () => {
      const { container } = render(<Progress value={50} variant="default" />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveClass('bg-primary');
    });

    it('should apply correct indicator variant for secondary', () => {
      const { container } = render(<Progress value={50} variant="secondary" />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveClass('bg-ring');
    });

    it('should default to default variant when variant is not specified', () => {
      const { container } = render(<Progress value={50} />);

      const progress = container.querySelector('[data-slot="progress"]');
      expect(progress).toHaveClass('bg-primary/20');
    });
  });

  describe('Show Info', () => {
    it('should not show info by default', () => {
      render(<Progress value={50} />);

      expect(screen.queryByText('50%')).not.toBeInTheDocument();
    });

    it('should show percentage when showInfo is true', () => {
      render(<Progress value={50} showInfo />);

      expect(screen.getByText('50%')).toBeInTheDocument();
    });

    it('should show 0% when value is 0 and showInfo is true', () => {
      render(<Progress value={0} showInfo />);

      expect(screen.getByText('0%')).toBeInTheDocument();
    });

    it('should show 100% when value is 100 and showInfo is true', () => {
      render(<Progress value={100} showInfo />);

      expect(screen.getByText('100%')).toBeInTheDocument();
    });

    it('should show 0% when value is undefined and showInfo is true', () => {
      render(<Progress value={undefined} showInfo />);

      expect(screen.getByText('0%')).toBeInTheDocument();
    });

    it('should render info text with correct styling', () => {
      render(<Progress value={50} showInfo />);

      const infoText = screen.getByText('50%');
      expect(infoText).toBeInTheDocument();
    });
  });

  describe('Format Info', () => {
    it('should use formatInfo function when provided', () => {
      const formatInfo = (value: number) => `${value} out of 100`;
      render(<Progress value={50} showInfo formatInfo={formatInfo} />);

      expect(screen.getByText('50 out of 100')).toBeInTheDocument();
      expect(screen.queryByText('50%')).not.toBeInTheDocument();
    });

    it('should use formatInfo with 0 value', () => {
      const formatInfo = (value: number) => `Progress: ${value}%`;
      render(<Progress value={0} showInfo formatInfo={formatInfo} />);

      expect(screen.getByText('Progress: 0%')).toBeInTheDocument();
    });

    it('should use formatInfo with 100 value', () => {
      const formatInfo = (value: number) =>
        value === 100 ? 'Complete' : `${value}%`;
      render(<Progress value={100} showInfo formatInfo={formatInfo} />);

      expect(screen.getByText('Complete')).toBeInTheDocument();
    });

    it('should use formatInfo with undefined value (defaults to 0)', () => {
      const formatInfo = (value: number) => `Loading: ${value}%`;
      render(<Progress value={undefined} showInfo formatInfo={formatInfo} />);

      expect(screen.getByText('Loading: 0%')).toBeInTheDocument();
    });

    it('should fall back to percentage when formatInfo is not provided', () => {
      render(<Progress value={75} showInfo />);

      expect(screen.getByText('75%')).toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    it('should have default aria-label when showInfo is false', () => {
      render(<Progress value={50} />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toHaveAttribute('aria-label', '50% complete');
    });

    it('should use custom aria-label when provided', () => {
      render(<Progress value={50} aria-label="Upload progress" />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toHaveAttribute('aria-label', 'Upload progress');
    });

    it('should not have default aria-label when showInfo is true', () => {
      render(<Progress value={50} showInfo />);

      const progress = screen.getByRole('progressbar');
      expect(progress).not.toHaveAttribute('aria-label', '50% complete');
    });

    it('should use custom aria-label even when showInfo is true', () => {
      render(<Progress value={50} showInfo aria-label="Custom label" />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toHaveAttribute('aria-label', 'Custom label');
    });

    it('should have correct aria-label for 0%', () => {
      render(<Progress value={0} />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toHaveAttribute('aria-label', '0% complete');
    });

    it('should have correct aria-label for 100%', () => {
      render(<Progress value={100} />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toHaveAttribute('aria-label', '100% complete');
    });

    it('should have correct aria-label for undefined value', () => {
      render(<Progress value={undefined} />);

      const progress = screen.getByRole('progressbar');
      // When value is undefined, it becomes "undefined% complete" in the template literal
      expect(progress).toHaveAttribute('aria-label', 'undefined% complete');
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      const { container } = render(
        <Progress value={50} className="custom-progress-class" />,
      );

      const progress = container.querySelector('[data-slot="progress"]');
      expect(progress).toHaveClass('custom-progress-class');
    });

    it('should apply base progress classes', () => {
      const { container } = render(<Progress value={50} />);

      const progress = container.querySelector('[data-slot="progress"]');
      expect(progress).toHaveClass('relative');
      expect(progress).toHaveClass('h-1.5');
      expect(progress).toHaveClass('w-full');
      expect(progress).toHaveClass('overflow-hidden');
      expect(progress).toHaveClass('rounded-full');
    });

    it('should apply indicator base classes', () => {
      const { container } = render(<Progress value={50} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveClass('h-full');
      expect(indicator).toHaveClass('flex-1');
      expect(indicator).toHaveClass('transition-all');
      expect(indicator).toHaveClass('rounded-full');
    });
  });

  describe('Edge Cases', () => {
    it('should handle negative values gracefully', () => {
      const { container } = render(<Progress value={-10} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveStyle({ width: 'max(0.225rem, calc(-10%))' });
    });

    it('should handle values over 100', () => {
      const { container } = render(<Progress value={150} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveStyle({ width: 'max(0.225rem, calc(150%))' });
    });

    it('should handle decimal values', () => {
      const { container } = render(<Progress value={33.33} />);

      const indicator = container.querySelector(
        '[data-slot="progress-indicator"]',
      );
      expect(indicator).toHaveStyle({ width: 'max(0.225rem, calc(33.33%))' });
    });

    it('should display decimal values in info when showInfo is true', () => {
      render(<Progress value={33.33} showInfo />);

      expect(screen.getByText('33.33%')).toBeInTheDocument();
    });

    it('should handle formatInfo with decimal values', () => {
      const formatInfo = (value: number) => `${value.toFixed(1)}%`;
      render(<Progress value={33.33} showInfo formatInfo={formatInfo} />);

      expect(screen.getByText('33.3%')).toBeInTheDocument();
    });
  });

  describe('Props', () => {
    it('should forward additional props to progress element', () => {
      render(<Progress value={50} data-testid="custom-progress" />);

      const progress = screen.getByTestId('custom-progress');
      expect(progress).toBeInTheDocument();
    });

    it('should forward additional Radix UI props', () => {
      render(<Progress value={50} data-custom="test-value" />);

      const progress = screen.getByRole('progressbar');
      expect(progress).toHaveAttribute('data-custom', 'test-value');
    });

    it('should work with all props combined', () => {
      const formatInfo = (value: number) => `Step ${value}/100`;
      render(
        <Progress
          value={75}
          variant="secondary"
          showInfo
          formatInfo={formatInfo}
          aria-label="Installation progress"
          className="custom-class"
        />,
      );

      const progress = screen.getByRole('progressbar');
      expect(progress).toBeInTheDocument();
      expect(progress).toHaveAttribute('aria-label', 'Installation progress');
      expect(progress).toHaveClass('custom-class');

      expect(screen.getByText('Step 75/100')).toBeInTheDocument();
    });
  });
});
