import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from './accordion';

const meta: Meta<typeof Accordion> = {
  title: 'Design System/Primitives/Data Display/Accordion',
  component: Accordion,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A collapsible content component that allows users to expand and collapse sections. Uses Radix UI primitives for accessibility.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    type: {
      control: { type: 'select' },
      options: ['single', 'multiple'],
      description: 'The type of accordion behavior',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'single' },
        category: 'Behavior',
      },
    },
    collapsible: {
      control: { type: 'boolean' },
      description: 'Whether all items can be collapsed',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'Behavior',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
  args: {
    type: 'single',
    collapsible: false,
    className: '',
  },
};

export default meta;
type Story = StoryObj<typeof Accordion>;

// Basic Accordion
export const Basic: Story = {
  render: args => (
    <Accordion {...args}>
      <AccordionItem value="item-1">
        <AccordionTrigger>Is it accessible?</AccordionTrigger>
        <AccordionContent>
          Yes. It adheres to the WAI-ARIA design pattern.
        </AccordionContent>
      </AccordionItem>
      <AccordionItem value="item-2">
        <AccordionTrigger>Is it styled?</AccordionTrigger>
        <AccordionContent>
          Yes. It comes with default styles that matches the other
          components&apos; aesthetic.
        </AccordionContent>
      </AccordionItem>
      <AccordionItem value="item-3">
        <AccordionTrigger>Is it animated?</AccordionTrigger>
        <AccordionContent>
          Yes. It&apos;s animated by default, but you can disable it if you
          prefer.
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  ),
};

// Multiple Accordion
export const Multiple: Story = {
  render: args => {
    // Filter out props that conflict between single/multiple accordion modes
    // Storybook automatically includes all component props in args, but these
    // have different types for single vs multiple accordions
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { value, defaultValue, onValueChange, ...restArgs } = args;
    return (
      <Accordion {...restArgs} type="multiple" defaultValue={['item-1']}>
        <AccordionItem value="item-1">
          <AccordionTrigger>What is React?</AccordionTrigger>
          <AccordionContent>
            React is a JavaScript library for building user interfaces. It lets
            you create reusable UI components.
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-2">
          <AccordionTrigger>What is TypeScript?</AccordionTrigger>
          <AccordionContent>
            TypeScript is a superset of JavaScript that adds static typing to
            the language.
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-3">
          <AccordionTrigger>What is Tailwind CSS?</AccordionTrigger>
          <AccordionContent>
            Tailwind CSS is a utility-first CSS framework for rapidly building
            custom user interfaces.
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    );
  },
};

// Collapsible Accordion
export const Collapsible: Story = {
  render: args => {
    // Filter out props that conflict between single/multiple accordion modes
    // Storybook automatically includes all component props in args, but these
    // have different types for single vs multiple accordions
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    const { value, defaultValue, onValueChange, ...restArgs } = args;
    return (
      <Accordion {...restArgs} type="single" collapsible>
        <AccordionItem value="item-1">
          <AccordionTrigger>Can I collapse all items?</AccordionTrigger>
          <AccordionContent>
            Yes! When the collapsible prop is set to true, all items can be
            collapsed.
          </AccordionContent>
        </AccordionItem>
        <AccordionItem value="item-2">
          <AccordionTrigger>How does it work?</AccordionTrigger>
          <AccordionContent>
            The accordion uses Radix UI primitives under the hood for
            accessibility and behavior.
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    );
  },
};

// FAQ Style
export const FAQ: Story = {
  render: args => (
    <Accordion {...args} className="w-full max-w-2xl">
      <AccordionItem value="faq-1">
        <AccordionTrigger>How do I get started?</AccordionTrigger>
        <AccordionContent>
          Getting started is easy! Simply install the package and import the
          components you need. Check out our documentation for detailed setup
          instructions.
        </AccordionContent>
      </AccordionItem>
      <AccordionItem value="faq-2">
        <AccordionTrigger>Is there a free trial?</AccordionTrigger>
        <AccordionContent>
          Yes, we offer a 30-day free trial for all new users. No credit card
          required to get started.
        </AccordionContent>
      </AccordionItem>
      <AccordionItem value="faq-3">
        <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
        <AccordionContent>
          We accept all major credit cards, PayPal, and bank transfers for
          annual plans.
        </AccordionContent>
      </AccordionItem>
      <AccordionItem value="faq-4">
        <AccordionTrigger>Can I cancel anytime?</AccordionTrigger>
        <AccordionContent>
          Absolutely! You can cancel your subscription at any time from your
          account settings.
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  ),
};

// Nested Content
export const NestedContent: Story = {
  render: args => (
    <Accordion {...args}>
      <AccordionItem value="item-1">
        <AccordionTrigger>Advanced Configuration</AccordionTrigger>
        <AccordionContent>
          <div className="space-y-4">
            <p>This accordion item contains more complex content.</p>
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Configuration Options</h4>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Custom styling options</li>
                <li>Animation controls</li>
                <li>Accessibility features</li>
                <li>Keyboard navigation</li>
              </ul>
            </div>
            <p className="text-sm text-muted-foreground">
              You can include any content inside accordion items, including
              other components.
            </p>
          </div>
        </AccordionContent>
      </AccordionItem>
      <AccordionItem value="item-2">
        <AccordionTrigger>Code Examples</AccordionTrigger>
        <AccordionContent>
          <div className="space-y-4">
            <p>Here are some code examples:</p>
            <pre className="bg-muted p-4 rounded-lg text-sm overflow-x-auto">
              <code>{`<Accordion>
  <AccordionItem value="item-1">
    <AccordionTrigger>Title</AccordionTrigger>
    <AccordionContent>Content</AccordionContent>
  </AccordionItem>
</Accordion>`}</code>
            </pre>
          </div>
        </AccordionContent>
      </AccordionItem>
    </Accordion>
  ),
};
