import { type ComponentProps, useMemo, useRef } from 'react';
import { AgGridReact } from 'ag-grid-react';
import {
  type ColDef,
  type GridOptions,
  type ICellRendererParams,
  type ValueFormatterParams,
  type ITextFilterParams,
  type RowClickedEvent,
  AllCommunityModule,
  ModuleRegistry,
  themeQuartz,
  iconSetQuartzBold,
} from 'ag-grid-community';

import { cn } from '../lib/utils';
import { cva, type VariantProps } from 'class-variance-authority';

// Register all Community features
ModuleRegistry.registerModules([AllCommunityModule]);

type TDataTableSize = 'default' | 'md' | 'lg';

type TDataTableVariant = 'bordered' | 'borderless';

/**
 * Size variants for the table with corresponding row heights
 */
const dataTableVariants = cva('', {
  variants: {
    size: {
      default: '',
      md: '',
      lg: '',
    },
  },
  defaultVariants: {
    size: 'default',
  },
});

/**
 * Get row height based on size variant
 */
function getRowHeight(size: TDataTableSize): number {
  switch (size) {
    case 'md':
      return 72;
    case 'lg':
      return 96;
    case 'default':
    default:
      return 52;
  }
}

/**
 * Creates a themed AG Grid configuration using design system tokens
 * This ensures the grid matches your application's theme and supports light/dark mode switching
 * Refer to the AG Grid Theme Builder for more details: https://www.ag-grid.com/theme-builder/
 */
function createThemedGridConfig(
  size: TDataTableSize,
  variant: TDataTableVariant = 'borderless',
  background?: string,
) {
  const rowHeight = getRowHeight(size);

  // Get theme values from CSS variables
  const foregroundColor = 'var(--foreground)';
  const mutedForegroundColor = 'var(--muted-foreground)';
  const borderColor = 'var(--border)';
  const mutedBackgroundColor = 'var(--muted)';
  const backgroundColor = 'var(--background)';
  const cardBackgroundColor = 'var(--card)';

  // Get additional theme values for checkbox styling
  const primaryColor = 'var(--primary)';
  const primaryForegroundColor = 'var(--primary-foreground)';
  const inputColor = 'var(--input)';
  const radiusValue = 2; // the token value is a string, so use a number

  // Configure borders based on variant
  const borderConfig = (() => {
    switch (variant) {
      case 'bordered':
        return {
          wrapperBorder: true,
          /**
           * Control other border styles here if needed
           *
           * For example:
           *
           * headerRowBorder: true,
           * rowBorder: { style: 'solid', width: 1, color: borderColor },
           * columnBorder: { style: 'solid', width: 1, color: borderColor },
           */
        };
      case 'borderless':
      default:
        return {
          wrapperBorder: false,
        };
    }
  })();

  // Use custom background if provided, otherwise use default
  const tableBackgroundColor = background || backgroundColor;

  // Create the themed configuration
  const themedConfig = themeQuartz.withPart(iconSetQuartzBold).withParams({
    // Background colors
    backgroundColor: tableBackgroundColor,
    oddRowBackgroundColor: tableBackgroundColor,
    headerBackgroundColor: tableBackgroundColor,
    filterPanelApplyButtonBackgroundColor: primaryColor,

    // Text colors
    foregroundColor: foregroundColor,
    cellTextColor: foregroundColor,
    headerTextColor: mutedForegroundColor,

    // Accent color (controls hover state)
    accentColor: mutedBackgroundColor,

    // Border color
    borderColor: borderColor,

    // Border configuration based on variant
    ...borderConfig,

    // Icon button colors
    iconButtonActiveColor: foregroundColor, // controls the active filter icon color
    iconButtonActiveIndicatorColor: primaryColor, // controls the active filter badge indicator color

    // Menu styling - using design system tokens
    menuBackgroundColor: cardBackgroundColor,

    // Typography - using design system fonts
    fontFamily: 'var(--font-sans)',
    headerFontFamily: 'var(--font-sans)',

    // Font sizes
    fontSize: 14,
    headerFontSize: 14,

    // Spacing and padding
    cellHorizontalPaddingScale: 1.2,
    rowVerticalPaddingScale: 1.1,
    headerVerticalPaddingScale: 1.2,

    // Icon size
    iconSize: 14,

    // Browser color scheme detection
    browserColorScheme: 'auto',

    // Control heights
    headerHeight: 40,
    rowHeight: rowHeight,
    inputHeight: 36, // Set input and select box height to 36px
    listItemHeight: 36, // Set filter select box and list item height to 36px

    // Checkbox styling to match design system
    checkboxBorderRadius: radiusValue,
    checkboxBorderWidth: 1,
    checkboxCheckedBackgroundColor: primaryColor, // matches data-[state=checked]:bg-primary
    checkboxCheckedBorderColor: primaryColor, // matches data-[state=checked]:border-primary
    checkboxCheckedShapeColor: primaryForegroundColor, // matches data-[state=checked]:text-primary-foreground
    checkboxIndeterminateBackgroundColor: primaryColor, // matches data-[state=checked]:bg-primary for indeterminate
    checkboxIndeterminateBorderColor: primaryColor, // matches data-[state=checked]:border-primary for indeterminate
    checkboxIndeterminateShapeColor: primaryForegroundColor, // matches data-[state=checked]:text-primary-foreground for indeterminate
    checkboxUncheckedBackgroundColor: 'transparent', // matches transparent in light mode
    checkboxUncheckedBorderColor: inputColor, // matches border-input
  });

  return themedConfig;
}

/**
 * Extends the AgGridReact props with DataTable props
 */
interface IDataTableProps<TData = unknown>
  extends
    Omit<ComponentProps<typeof AgGridReact<TData>>, 'rowData' | 'columnDefs'>,
    VariantProps<typeof dataTableVariants> {
  /**
   * The data to display in the table
   * Equivalent to rowData in AG Grid
   */
  data: TData[];

  /**
   * Column definitions for the table
   * Equivalent to columnDefs in AG Grid
   */
  columns: ColDef<TData>[];

  /**
   * Default column definitions for the table
   * Equivalent to gridOptions.defaultColDef in AG Grid
   */
  defaultColDef?: ColDef<TData>;

  /**
   * Custom CSS class name
   */
  className?: string;

  /**
   * Whether to enable resizable columns
   * @default false
   */
  resizable?: boolean;

  /**
   * Size variant of the table
   * @default 'default'
   */
  size?: TDataTableSize;

  /**
   * Visual variant of the table
   * @default 'borderless'
   */
  variant?: TDataTableVariant;

  /**
   * Custom background color for the table
   * When provided, overrides the default background color
   */
  background?: string;
}

/**
 * A powerful data table component built on AG Grid React
 *
 * @example
 * ```tsx
 * const columns = [
 *   { field: 'name', headerName: 'Name', sortable: true, filter: true },
 *   { field: 'age', headerName: 'Age', sortable: true, filter: 'agNumberColumnFilter' },
 *   { field: 'email', headerName: 'Email', sortable: true, filter: true }
 * ];
 *
 * const data = [
 *   { name: 'John Doe', age: 30, email: 'john@example.com' },
 *   { name: 'Jane Smith', age: 25, email: 'jane@example.com' }
 * ];
 *
 * <DataTable
 *   data={data}
 *   columns={columns}
 * />
 * ```
 */
function DataTable<TData = unknown>({
  data,
  columns,
  defaultColDef,
  gridOptions,
  className,
  size = 'default',
  variant = 'borderless',
  resizable = false,
  background,
  ...props
}: IDataTableProps<TData>) {
  const gridRef = useRef<AgGridReact<TData>>(null);

  // Create themed configuration - always applied
  const themedConfig = useMemo(
    () => createThemedGridConfig(size, variant, background),
    [size, variant, background],
  );

  // Get row height based on size

  // Merge default grid options with provided options
  const mergedGridOptions: GridOptions<TData> = useMemo(
    () => ({
      // Apply design system theme configuration
      theme: themedConfig,

      // Default options
      animateRows: true,
      // Default column definitions
      defaultColDef: {
        resizable: resizable,
        flex: 1,
        ...defaultColDef,
      },

      // Merge with user-provided options
      ...(gridOptions || {}),
    }),
    [themedConfig, gridOptions, resizable, defaultColDef],
  );

  return (
    <AgGridReact<TData>
      ref={gridRef}
      rowData={data}
      columnDefs={columns}
      gridOptions={mergedGridOptions}
      {...props}
      className={cn('w-full h-full', dataTableVariants({ size }), className)}
    />
  );
}

export type {
  IDataTableProps,
  ColDef as IDataTableColDef,
  ICellRendererParams as IDataTableCellRendererParams,
  ValueFormatterParams as IDataTableValueFormatterParams,
  GridOptions as IDataTableGridOptions,
  ITextFilterParams as IDataTableTextFilterParams,
  RowClickedEvent as IDataTableRowClickedEvent,
};

export { DataTable };
