import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Toolbar,
  ToolbarGroup,
  ToolbarButton,
  ToolbarBadge,
  ToolbarSeparator,
} from './toolbar';
import { Icon } from '../icons';

const meta: Meta<typeof Toolbar> = {
  title: 'Design System/Primitives/General/Toolbar',
  component: Toolbar,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A toolbar component with backdrop blur effect, designed for contextual actions. Typically used as a floating action bar at the bottom center of a canvas or workspace. Based on Radix UI Toolbar primitive.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    size: {
      control: { type: 'select' },
      options: ['default', 'sm', 'lg'],
      description: 'The size of the toolbar',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
  args: {
    size: 'default',
  },
};

export default meta;
type Story = StoryObj<typeof Toolbar>;

// Primary story - This will be the main showcase in autodocs
export const Primary: Story = {
  render: () => (
    <div className="flex items-center justify-center p-8">
      <Toolbar>
        <ToolbarGroup>
          <ToolbarButton variant="default">Action</ToolbarButton>
          <ToolbarButton variant="text">Text</ToolbarButton>
        </ToolbarGroup>
      </Toolbar>
    </div>
  ),
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'The primary toolbar example. Use the controls below to experiment with different sizes and configurations.',
      },
    },
  },
};

// Basic Toolbar Story
export const Default: Story = {
  render: () => (
    <div className="flex items-center justify-center p-8">
      <Toolbar>
        <ToolbarGroup>
          <ToolbarButton variant="default">Draft</ToolbarButton>
          <ToolbarButton variant="text">Outputs</ToolbarButton>
        </ToolbarGroup>
      </Toolbar>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'A basic toolbar with two buttons in a group.',
      },
    },
  },
};

// Toolbar Sizes Story
export const Sizes: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar Sizes
        </h3>
        <div className="flex flex-col items-center gap-6">
          <div>
            <p className="text-xs text-muted-foreground mb-2">Small</p>
            <Toolbar size="sm">
              <ToolbarGroup>
                <ToolbarButton variant="default">Small</ToolbarButton>
                <ToolbarButton variant="text">Action</ToolbarButton>
              </ToolbarGroup>
            </Toolbar>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-2">Default</p>
            <Toolbar size="default">
              <ToolbarGroup>
                <ToolbarButton variant="default">Default</ToolbarButton>
                <ToolbarButton variant="text">Action</ToolbarButton>
              </ToolbarGroup>
            </Toolbar>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-2">Large</p>
            <Toolbar size="lg">
              <ToolbarGroup>
                <ToolbarButton variant="default">Large</ToolbarButton>
                <ToolbarButton variant="text">Action</ToolbarButton>
              </ToolbarGroup>
            </Toolbar>
          </div>
        </div>
      </div>
    </div>
  ),
};

// Button Variants Story
export const ButtonVariants: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar Button Variants
        </h3>
        <div className="flex flex-col items-center gap-6">
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default">Default</ToolbarButton>
              <ToolbarButton variant="ghost">Ghost</ToolbarButton>
              <ToolbarButton variant="text">Text</ToolbarButton>
              <ToolbarButton variant="icon">
                <Icon type="Settings" />
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
        </div>
      </div>
    </div>
  ),
};

// With Badges Story
export const WithBadges: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar with Badges
        </h3>
        <div className="flex flex-col items-center gap-6">
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default">Draft</ToolbarButton>
              <ToolbarButton variant="text">
                Outputs <ToolbarBadge count={5} />
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default">
                Messages <ToolbarBadge count={12} />
              </ToolbarButton>
              <ToolbarButton variant="text">
                Notifications <ToolbarBadge count={99} />
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
        </div>
      </div>
    </div>
  ),
};

// With Separators Story
export const WithSeparators: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar with Separators
        </h3>
        <div className="flex flex-col items-center gap-6">
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default">Action 1</ToolbarButton>
              <ToolbarButton variant="default">Action 2</ToolbarButton>
            </ToolbarGroup>
            <ToolbarSeparator />
            <ToolbarGroup>
              <ToolbarButton variant="ghost">Action 3</ToolbarButton>
              <ToolbarButton variant="ghost">Action 4</ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
        </div>
      </div>
    </div>
  ),
};

// With Icons Story
export const WithIcons: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar with Icons
        </h3>
        <div className="flex flex-col items-center gap-6">
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default">
                <Icon type="Save" />
                Save
              </ToolbarButton>
              <ToolbarButton variant="default">
                <Icon type="Download" />
                Download
              </ToolbarButton>
              <ToolbarButton variant="icon">
                <Icon type="Settings" />
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="ghost">
                <Icon type="Heart" />
                Like
              </ToolbarButton>
              <ToolbarButton variant="ghost">
                <Icon type="Share" />
                Share
              </ToolbarButton>
              <ToolbarButton variant="icon">
                <Icon type="MoreVertical" />
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
        </div>
      </div>
    </div>
  ),
};

// Multiple Groups Story
export const MultipleGroups: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar with Multiple Groups
        </h3>
        <div className="flex flex-col items-center gap-6">
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default">
                Group 1 - Action 1
              </ToolbarButton>
              <ToolbarButton variant="text">Group 1 - Action 2</ToolbarButton>
            </ToolbarGroup>
            <ToolbarSeparator />
            <ToolbarGroup>
              <ToolbarButton variant="ghost">Group 2 - Action 1</ToolbarButton>
              <ToolbarButton variant="ghost">Group 2 - Action 2</ToolbarButton>
            </ToolbarGroup>
            <ToolbarSeparator />
            <ToolbarGroup>
              <ToolbarButton variant="icon">
                <Icon type="Settings" />
              </ToolbarButton>
              <ToolbarButton variant="icon">
                <Icon type="MoreVertical" />
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
        </div>
      </div>
    </div>
  ),
};

// Real-World Example Story
export const RealWorldExample: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Real-World Example: Run Toolbar
        </h3>
        <p className="text-xs text-muted-foreground mb-4">
          Example of how the toolbar is used in the automation run page.
        </p>
        <div className="flex flex-col items-center gap-6">
          <div className="relative w-full h-64 bg-muted/20 rounded-lg flex items-end justify-center pb-8">
            <Toolbar>
              <ToolbarGroup>
                <ToolbarButton variant="default">Draft</ToolbarButton>
                <ToolbarButton variant="text">
                  Outputs <ToolbarBadge count={3} />
                </ToolbarButton>
              </ToolbarGroup>
            </Toolbar>
          </div>
        </div>
      </div>
    </div>
  ),
};

// States Story
export const States: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar Button States
        </h3>
        <div className="flex flex-col items-center gap-6">
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default">Normal</ToolbarButton>
              <ToolbarButton variant="default" disabled>
                Disabled
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="ghost">Normal</ToolbarButton>
              <ToolbarButton variant="ghost" disabled>
                Disabled
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
        </div>
      </div>
    </div>
  ),
};

// Group Sizes Story
export const GroupSizes: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar Group Sizes
        </h3>
        <div className="flex flex-col items-center gap-6">
          <div>
            <p className="text-xs text-muted-foreground mb-2">Default Height</p>
            <Toolbar>
              <ToolbarGroup size="default">
                <ToolbarButton variant="default">Default</ToolbarButton>
                <ToolbarButton variant="text">Action</ToolbarButton>
              </ToolbarGroup>
            </Toolbar>
          </div>
          <div>
            <p className="text-xs text-muted-foreground mb-2">Large Height</p>
            <Toolbar>
              <ToolbarGroup size="lg">
                <ToolbarButton variant="default">Large</ToolbarButton>
                <ToolbarButton variant="text">Action</ToolbarButton>
              </ToolbarGroup>
            </Toolbar>
          </div>
        </div>
      </div>
    </div>
  ),
};

// Button Sizes Story
export const ButtonSizes: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Toolbar Button Sizes
        </h3>
        <div className="flex flex-col items-center gap-6">
          <Toolbar>
            <ToolbarGroup>
              <ToolbarButton variant="default" size="sm">
                Small
              </ToolbarButton>
              <ToolbarButton variant="default" size="default">
                Default
              </ToolbarButton>
              <ToolbarButton variant="default" size="lg">
                Large
              </ToolbarButton>
            </ToolbarGroup>
          </Toolbar>
        </div>
      </div>
    </div>
  ),
};

// Accessibility Story
export const Accessibility: Story = {
  render: () => (
    <div className="space-y-6 p-8">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-3">
          Accessibility Features
        </h3>
        <div className="space-y-4">
          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-medium text-foreground mb-2 text-sm">
              Keyboard Navigation
            </h4>
            <p className="text-xs text-muted-foreground mb-3">
              All toolbar buttons are keyboard accessible. Use Tab to navigate
              between buttons and Enter/Space to activate them.
            </p>
            <div className="flex items-center justify-center">
              <Toolbar>
                <ToolbarGroup>
                  <ToolbarButton variant="default">
                    Focus me (Tab)
                  </ToolbarButton>
                  <ToolbarButton variant="text">Then me</ToolbarButton>
                </ToolbarGroup>
              </Toolbar>
            </div>
          </div>

          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-medium text-foreground mb-2 text-sm">
              Focus Indicators
            </h4>
            <p className="text-xs text-muted-foreground mb-3">
              Toolbar buttons have visible focus indicators that work with the
              current theme.
            </p>
            <div className="flex items-center justify-center">
              <Toolbar>
                <ToolbarGroup>
                  <ToolbarButton
                    variant="default"
                    className="focus:ring-2 focus:ring-ring"
                  >
                    Focus me
                  </ToolbarButton>
                </ToolbarGroup>
              </Toolbar>
            </div>
          </div>

          <div className="bg-muted p-4 rounded-lg">
            <h4 className="font-medium text-foreground mb-2 text-sm">
              Screen Reader Support
            </h4>
            <p className="text-xs text-muted-foreground mb-3">
              Toolbar buttons include proper ARIA attributes and semantic HTML.
              Use aria-label for icon-only buttons.
            </p>
            <div className="flex items-center justify-center">
              <Toolbar>
                <ToolbarGroup>
                  <ToolbarButton variant="icon" aria-label="Settings">
                    <Icon type="Settings" />
                  </ToolbarButton>
                  <ToolbarButton variant="icon" aria-label="More options">
                    <Icon type="MoreVertical" />
                  </ToolbarButton>
                </ToolbarGroup>
              </Toolbar>
            </div>
          </div>
        </div>
      </div>
    </div>
  ),
};
