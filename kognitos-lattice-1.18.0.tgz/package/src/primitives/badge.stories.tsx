import type { Meta, StoryObj } from '@storybook/react-vite';
import { Badge } from './badge';
import { Icon } from '../icons';

const meta: Meta<typeof Badge> = {
  title: 'Design System/Primitives/Data Display/Badge',
  component: Badge,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A status badge component with multiple variants for displaying labels, tags, and status indicators.\n\n<a href="https://www.figma.com/design/CzPeHQcKj6bNvk4EBMQQRD/Kognitos-Design-System---shadcn?node-id=17083-177430&t=PP08vMqqCwCZtlRX-4" target="_blank" rel="noopener noreferrer">View in Figma ↗</a>',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: [
        'default',
        'secondary',
        'outline',
        'destructive',
        'success',
        'warning',
        'verified',
      ],
      description: 'The visual style variant of the badge',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    asChild: {
      control: { type: 'boolean' },
      description: 'Render as a child component using Radix Slot',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'Behavior',
      },
    },
    children: {
      control: { type: 'text' },
      description: 'The content to display inside the badge',
      table: {
        type: { summary: 'ReactNode' },
        category: 'Content',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
  args: {
    children: 'Badge',
    variant: 'default',
  },
};

export default meta;
type Story = StoryObj<typeof Badge>;

// Primary story - This will be the main showcase in autodocs
export const Primary: Story = {
  args: {
    children: 'Badge',
    variant: 'default',
  },
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'The primary badge variant. Use the controls below to experiment with different variants.',
      },
    },
  },
};

// Default Badge Story
export const Default: Story = {
  args: {
    children: 'Badge',
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story: 'The default badge variant with primary styling.',
      },
    },
  },
};

// All Variants Story
export const Variants: Story = {
  render: () => (
    <div className="flex flex-wrap gap-3">
      <Badge variant="default">Default</Badge>
      <Badge variant="secondary">Secondary</Badge>
      <Badge variant="outline">Outline</Badge>
      <Badge variant="destructive">Destructive</Badge>
      <Badge variant="success">Success</Badge>
      <Badge variant="warning">Warning</Badge>
      <Badge variant="verified">Verified</Badge>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'All available badge variants: default (primary), secondary, outline, destructive, success, warning, and verified.',
      },
      source: {
        code: `<Badge variant="default">Default</Badge>
<Badge variant="secondary">Secondary</Badge>
<Badge variant="outline">Outline</Badge>
<Badge variant="destructive">Destructive</Badge>
<Badge variant="success">Success</Badge>
<Badge variant="warning">Warning</Badge>
<Badge variant="verified">Verified</Badge>`,
      },
    },
  },
};

// Status Badges Story
export const StatusBadges: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Status Indicators
        </h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="success">Completed</Badge>
          <Badge variant="warning">Pending</Badge>
          <Badge variant="destructive">Failed</Badge>
          <Badge variant="verified">Verified</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Workflow States
        </h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="secondary">Draft</Badge>
          <Badge variant="warning">In Review</Badge>
          <Badge variant="default">Active</Badge>
          <Badge variant="success">Published</Badge>
          <Badge variant="destructive">Archived</Badge>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Examples of using badges for status indicators and workflow states.',
      },
      source: {
        code: `// Status Indicators
<Badge variant="success">Completed</Badge>
<Badge variant="warning">Pending</Badge>
<Badge variant="destructive">Failed</Badge>
<Badge variant="verified">Verified</Badge>

// Workflow States
<Badge variant="secondary">Draft</Badge>
<Badge variant="warning">In Review</Badge>
<Badge variant="default">Active</Badge>
<Badge variant="success">Published</Badge>`,
      },
    },
  },
};

// With Icons Story
export const WithIcons: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Badges with Icons
        </h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="success">
            <Icon type="Check" />
            Approved
          </Badge>
          <Badge variant="warning">
            <Icon type="AlertTriangle" />
            Warning
          </Badge>
          <Badge variant="destructive">
            <Icon type="CircleX" />
            Error
          </Badge>
          <Badge variant="verified">
            <Icon type="BadgeCheck" />
            Verified
          </Badge>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Information Badges
        </h3>
        <div className="flex flex-wrap gap-3">
          <Badge variant="default">
            <Icon type="Star" />
            Featured
          </Badge>
          <Badge variant="secondary">
            <Icon type="Clock" />
            Scheduled
          </Badge>
          <Badge variant="outline">
            <Icon type="Tag" />
            Label
          </Badge>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Badges can include icons to enhance visual communication. Icons automatically size to match the badge text.',
      },
      source: {
        code: `<Badge variant="success">
  <Icon type="Check" />
  Approved
</Badge>

<Badge variant="warning">
  <Icon type="AlertTriangle" />
  Warning
</Badge>

<Badge variant="destructive">
  <Icon type="CircleX" />
  Error
</Badge>

<Badge variant="verified">
  <Icon type="BadgeCheck" />
  Verified
</Badge>`,
      },
    },
  },
};

// Link Badges Story
export const LinkBadges: Story = {
  render: () => (
    <div className="flex flex-wrap gap-3">
      <Badge asChild variant="default">
        <a href="#">Default Link</a>
      </Badge>
      <Badge asChild variant="secondary">
        <a href="#">Secondary Link</a>
      </Badge>
      <Badge asChild variant="success">
        <a href="#">Success Link</a>
      </Badge>
      <Badge asChild variant="warning">
        <a href="#">Warning Link</a>
      </Badge>
      <Badge asChild variant="destructive">
        <a href="#">Destructive Link</a>
      </Badge>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Badges can be rendered as links using the `asChild` prop. Link badges have hover states.',
      },
      source: {
        code: `<Badge asChild variant="default">
  <a href="/link">Clickable Badge</a>
</Badge>

<Badge asChild variant="success">
  <a href="/success">Success Link</a>
</Badge>`,
      },
    },
  },
};

// Use Cases Story
export const UseCases: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Category Tags
        </h3>
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline">Technology</Badge>
          <Badge variant="outline">Design</Badge>
          <Badge variant="outline">Marketing</Badge>
          <Badge variant="outline">Development</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Priority Levels
        </h3>
        <div className="flex flex-wrap gap-2">
          <Badge variant="destructive">High Priority</Badge>
          <Badge variant="warning">Medium Priority</Badge>
          <Badge variant="secondary">Low Priority</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          User Roles
        </h3>
        <div className="flex flex-wrap gap-2">
          <Badge variant="default">Admin</Badge>
          <Badge variant="verified">
            <Icon type="BadgeCheck" />
            Pro User
          </Badge>
          <Badge variant="secondary">Member</Badge>
          <Badge variant="outline">Guest</Badge>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Item Counts
        </h3>
        <div className="flex flex-wrap gap-2">
          <Badge variant="secondary">12 items</Badge>
          <Badge variant="default">New</Badge>
          <Badge variant="warning">3 pending</Badge>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Common use cases for badges including category tags, priority levels, user roles, and item counts.',
      },
      source: {
        code: `// Category Tags
<Badge variant="outline">Technology</Badge>
<Badge variant="outline">Design</Badge>

// Priority Levels
<Badge variant="destructive">High Priority</Badge>
<Badge variant="warning">Medium Priority</Badge>
<Badge variant="secondary">Low Priority</Badge>

// User Roles
<Badge variant="default">Admin</Badge>
<Badge variant="verified">
  <Icon type="BadgeCheck" />
  Pro User
</Badge>

// Item Counts
<Badge variant="secondary">12 items</Badge>
<Badge variant="warning">3 pending</Badge>`,
      },
    },
  },
};

// All Badges Story
export const AllBadges: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          All Badge Variants
        </h2>
        <div className="flex flex-wrap gap-3">
          <Badge variant="default">Default</Badge>
          <Badge variant="secondary">Secondary</Badge>
          <Badge variant="outline">Outline</Badge>
          <Badge variant="destructive">Destructive</Badge>
          <Badge variant="success">Success</Badge>
          <Badge variant="warning">Warning</Badge>
          <Badge variant="verified">Verified</Badge>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Badges with Icons
        </h2>
        <div className="flex flex-wrap gap-3">
          <Badge variant="success">
            <Icon type="Check" />
            Approved
          </Badge>
          <Badge variant="warning">
            <Icon type="AlertTriangle" />
            Warning
          </Badge>
          <Badge variant="destructive">
            <Icon type="CircleX" />
            Error
          </Badge>
          <Badge variant="verified">
            <Icon type="BadgeCheck" />
            Verified
          </Badge>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Status Indicators
        </h2>
        <div className="flex flex-wrap gap-3">
          <Badge variant="success">Completed</Badge>
          <Badge variant="warning">Pending</Badge>
          <Badge variant="destructive">Failed</Badge>
          <Badge variant="secondary">Draft</Badge>
          <Badge variant="default">Active</Badge>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">Link Badges</h2>
        <div className="flex flex-wrap gap-3">
          <Badge asChild variant="default">
            <a href="#">Clickable</a>
          </Badge>
          <Badge asChild variant="success">
            <a href="#">Success Link</a>
          </Badge>
          <Badge asChild variant="warning">
            <a href="#">Warning Link</a>
          </Badge>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'A comprehensive overview of all badge variants and features in a single story.',
      },
      source: {
        code: `// Basic variants
<Badge variant="default">Default</Badge>
<Badge variant="secondary">Secondary</Badge>
<Badge variant="outline">Outline</Badge>
<Badge variant="destructive">Destructive</Badge>
<Badge variant="success">Success</Badge>
<Badge variant="warning">Warning</Badge>
<Badge variant="verified">Verified</Badge>

// With icons
<Badge variant="success">
  <Icon type="Check" />
  Approved
</Badge>

// As link
<Badge asChild variant="default">
  <a href="#">Clickable</a>
</Badge>`,
      },
    },
  },
};
