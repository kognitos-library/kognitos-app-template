import { Flex } from './flex';
import { Icon, IconSize, IconType } from '@/icons';
import { Progress } from './progress';
import { Text } from './typography';
import { Button } from './button';
import { cn } from '@/design-system/lib/utils';

enum EAssetTypeVariant {
  Folder = 'folder',
  Spreadsheet = 'spreadsheet',
  Document = 'document',
  PDF = 'pdf',
  Image = 'image',
  Collection = 'collection',
  JSON = 'json',
  Unknown = 'unknown',
}

type TAssetTypeVariant = `${EAssetTypeVariant}`;

type TAssetTypeConfig = {
  icon: IconType;
  iconColor: string;
  backgroundColor: string;
};

interface IAssetProps {
  variant?: 'default' | 'uploading' | 'error';
  size?: 'default' | 'sm';
  type?: TAssetTypeVariant;
  iconSize?: IconSize;
  name: string;
  progressValue?: number;
  description?: string;
  errorText?: string;
  showActionIcon?: boolean;
  actionIcon?: IconType;
}

interface IAssetTypeProps {
  type: TAssetTypeVariant;
  iconSize?: IconSize;
  className?: string;
}

const assetTypeConfig: Record<EAssetTypeVariant, TAssetTypeConfig> = {
  [EAssetTypeVariant.Folder]: {
    icon: 'Folder',
    iconColor: 'text-foreground',
    backgroundColor: 'bg-muted',
  },
  [EAssetTypeVariant.Document]: {
    icon: 'FileType',
    iconColor: 'text-alternate-7',
    backgroundColor: 'bg-alternate-7/5',
  },
  [EAssetTypeVariant.Spreadsheet]: {
    icon: 'FileX',
    iconColor: 'text-alternate-5',
    backgroundColor: 'bg-alternate-5/5',
  },
  [EAssetTypeVariant.PDF]: {
    icon: 'File',
    iconColor: 'text-alternate-2',
    backgroundColor: 'bg-alternate-2/5',
  },
  [EAssetTypeVariant.Image]: {
    icon: 'Image',
    iconColor: 'text-alternate-4',
    backgroundColor: 'bg-alternate-4/5',
  },
  [EAssetTypeVariant.JSON]: {
    icon: 'FileJson',
    iconColor: 'text-alternate-6',
    backgroundColor: 'bg-alternate-6/5',
  },
  [EAssetTypeVariant.Collection]: {
    icon: 'Database',
    iconColor: 'text-alternate-1',
    backgroundColor: 'bg-alternate-1/5',
  },
  [EAssetTypeVariant.Unknown]: {
    icon: 'File',
    iconColor: 'text-alternate-1',
    backgroundColor: 'bg-alternate-1/5',
  },
};

function AssetType({ type, iconSize = 'sm', className }: IAssetTypeProps) {
  const { icon, backgroundColor, iconColor } = assetTypeConfig[type];

  return (
    <Flex
      align="center"
      justify="center"
      padding={2}
      className={cn('rounded-md', backgroundColor, className)}
    >
      <Icon
        type={icon}
        size={iconSize}
        className={iconColor}
        inheritColor={false}
      />
    </Flex>
  );
}

function Asset({
  variant = 'default',
  size = 'default',
  type = 'folder',
  iconSize = 'sm',
  name,
  progressValue = 0,
  description,
  errorText,
  actionIcon = 'X',
  showActionIcon = true,
}: IAssetProps) {
  return (
    <Flex
      width="full"
      gap={2}
      align="center"
      paddingX={size === 'sm' ? 2 : 3}
      paddingY={size === 'sm' ? 1 : 2}
      className="border border-border shadow-xs rounded-md bg-transparent hover:bg-accent/20 hover:cursor-pointer"
    >
      <AssetType type={type} iconSize={iconSize} />

      <Flex gap={3} align="center" className="flex-1 min-w-0">
        <Flex direction="column" overflow="hidden" width="full">
          {/* Asset name */}
          <Text
            level={size === 'sm' ? 'small' : 'base'}
            color="muted"
            className="truncate max-w-full"
          >
            {name}
          </Text>

          {/* Progress bar / status text */}
          {variant === 'uploading' && (
            <Flex width="full" className="pt-1.5 pb-1">
              <Progress variant="secondary" value={progressValue} />
            </Flex>
          )}
          {variant === 'default' && description && (
            <Text level="xSmall" color="muted" className="opacity-70">
              {description}
            </Text>
          )}
          {variant === 'error' && errorText && (
            <Text level="xSmall" color="destructive">
              {errorText}
            </Text>
          )}
        </Flex>

        {/* Action button */}
        {showActionIcon && (
          <Flex className="shrink-0">
            <Button variant="ghost" size="icon">
              <Icon
                type={actionIcon}
                size="sm"
                className="text-muted-foreground"
              />
            </Button>
          </Flex>
        )}
      </Flex>
    </Flex>
  );
}

export {
  Asset,
  AssetType,
  EAssetTypeVariant,
  type TAssetTypeVariant,
  type IAssetProps,
  type IAssetTypeProps,
};
