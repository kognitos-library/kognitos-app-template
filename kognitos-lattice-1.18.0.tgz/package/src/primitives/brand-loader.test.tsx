import { render, screen } from '@testing-library/react';
import { describe, expect, it, vi } from 'vitest';

vi.mock('@/design-system/icons/assets/svg/logo-animated.svg?react', () => ({
  default: (props: React.SVGProps<SVGSVGElement>) => (
    <svg data-testid="mock-svg" {...props} />
  ),
}));

import { BrandLoader } from './brand-loader';

describe('BrandLoader', () => {
  it('renders with default props', () => {
    render(<BrandLoader />);
    const loader = screen.getByRole('status');
    expect(loader).toBeInTheDocument();
    expect(loader).toHaveAttribute('aria-label', 'Loading');
  });

  it('renders with default size (xl)', () => {
    render(<BrandLoader />);
    const loader = screen.getByRole('status');
    expect(loader).toHaveClass('size-24');
  });

  it('renders with custom size', () => {
    render(<BrandLoader size="sm" />);
    const loader = screen.getByRole('status');
    expect(loader).toHaveClass('size-12');
  });

  it('renders with custom className', () => {
    render(<BrandLoader className="custom-class" />);
    const loader = screen.getByRole('status');
    expect(loader).toHaveClass('custom-class');
  });

  it('renders all size variants', () => {
    const { rerender } = render(<BrandLoader size="sm" />);
    expect(screen.getByRole('status')).toHaveClass('size-12');

    rerender(<BrandLoader size="md" />);
    expect(screen.getByRole('status')).toHaveClass('size-16');

    rerender(<BrandLoader size="lg" />);
    expect(screen.getByRole('status')).toHaveClass('size-20');

    rerender(<BrandLoader size="xl" />);
    expect(screen.getByRole('status')).toHaveClass('size-24');
  });

  it('has proper accessibility attributes', () => {
    render(<BrandLoader />);
    const loader = screen.getByRole('status');
    expect(loader).toHaveAttribute('aria-label', 'Loading');
  });

  it('renders the SVG element', () => {
    render(<BrandLoader />);
    const svg = screen.getByTestId('mock-svg');
    expect(svg).toBeInTheDocument();
  });
});
