import type { Node, Edge, InternalNode } from '@xyflow/react';
import { useRef, useLayoutEffect } from 'react';
import dagre from 'dagre';

/**
 * FlowNodeType defines the different types of nodes in an automation flow.
 */
export const FlowNodeType = {
  /** Unspecified node type */
  UNSPECIFIED: 'FLOW_NODE_TYPE_UNSPECIFIED',
  /** Start node - represents the beginning of the flow */
  START: 'FLOW_NODE_TYPE_START',
  /** End node - represents the end of the flow */
  END: 'FLOW_NODE_TYPE_END',
  /** Process node - represents a processing step */
  PROCESS: 'FLOW_NODE_TYPE_PROCESS',
  /** Decision node - represents a branching point (if-else conditions) */
  DECISION: 'FLOW_NODE_TYPE_DECISION',
  /** Input node - represents an input action */
  INPUT: 'FLOW_NODE_TYPE_INPUT',
  /** Output node - represents an output action */
  OUTPUT: 'FLOW_NODE_TYPE_OUTPUT',
} as const;

export type TFlowNodeType = (typeof FlowNodeType)[keyof typeof FlowNodeType];

/**
 * Represents a node in the flow graph.
 */
export interface IFlowNode {
  /** Unique identifier for the node */
  id?: string;
  /** Display label for the node */
  label?: string;
  /** Type of the node */
  type?: TFlowNodeType | string;
}

/**
 * Represents an edge (connection) between nodes in the flow graph.
 */
export interface IFlowEdge {
  /** Source node ID */
  source?: string;
  /** Target node ID */
  target?: string;
  /** Optional condition label for the edge (e.g., for decision branches) */
  condition?: string;
}

/**
 * Represents the complete flow graph structure.
 */
export interface IFlowGraph {
  /** Array of nodes in the graph */
  nodes?: IFlowNode[];
  /** Array of edges connecting the nodes */
  edges?: IFlowEdge[];
}

const DEFAULT_NODE_HEIGHT = 48; // Default height of a node, assuming single line of text
const HORIZONTAL_SPACING = 48; // Horizontal spacing between nodes at the same level
const VERTICAL_SPACING = 60; // Distance between levels
export const NODE_WIDTH_LINEAR = 600; // Max width of a node in a linear flow
export const NODE_WIDTH_BRANCHING = 200; // Max width of a node in a branching flow
export const EDGE_OFFSET = 10; // Gap between node and edge

export interface IEdgePositions {
  sourceX: number;
  sourceY: number;
  targetX: number;
  targetY: number;
  labelX: number;
  labelY: number;
}

/**
 * Calculates edge and label positions from source and target nodes.
 *
 * Returns null if nodes are not yet measured (positions/dimensions unavailable).
 * Used by custom edge components to position edges and labels accurately.
 *
 * @param sourceNode - The source node from useInternalNode
 * @param targetNode - The target node from useInternalNode
 * @returns Edge positions or null if nodes are not ready
 */
export const getEdgePositions = (
  sourceNode: InternalNode | undefined,
  targetNode: InternalNode | undefined,
): IEdgePositions | null => {
  if (
    !sourceNode?.internals.positionAbsolute ||
    !targetNode?.internals.positionAbsolute ||
    !sourceNode.measured?.width ||
    !sourceNode.measured?.height ||
    !targetNode.measured?.width
  ) {
    return null;
  }

  const sourcePos = sourceNode.internals.positionAbsolute;
  const targetPos = targetNode.internals.positionAbsolute;

  const sourceX = sourcePos.x + sourceNode.measured.width / 2;
  const targetX = targetPos.x + targetNode.measured.width / 2;
  const sourceY = sourcePos.y + sourceNode.measured.height + EDGE_OFFSET;
  const targetY = targetPos.y - EDGE_OFFSET;

  const labelX = (sourceX + targetX) / 2;
  const labelY = (sourceY + targetY) / 2;

  return { sourceX, sourceY, targetX, targetY, labelX, labelY };
};

/**
 * Custom hook to measure and report node height for layout calculations.
 *
 * Measures the node's height using a ref and reports it via the onHeightMeasured
 * callback whenever the height changes. This enables dynamic layout positioning
 * based on actual rendered node dimensions.
 *
 * @param {string} id - Unique identifier for the node
 * @param {(id: string, height: number) => void} [onHeightMeasured] - Callback to report height changes
 * @returns {React.RefObject<HTMLDivElement>} Ref to attach to the node element
 */
export const useNodeHeightMeasurement = (
  id: string,
  onHeightMeasured?: (id: string, height: number) => void,
) => {
  const nodeRef = useRef<HTMLDivElement>(null);
  const lastReportedHeight = useRef<number | undefined>(undefined);

  useLayoutEffect(() => {
    if (!nodeRef.current || !onHeightMeasured) return;
    const height = nodeRef.current.offsetHeight;
    if (lastReportedHeight.current !== height) {
      lastReportedHeight.current = height;
      onHeightMeasured(id, height);
    }
  }, [id, onHeightMeasured]);

  return nodeRef;
};

/**
 * Calculates node positions using dagre layout algorithm.
 *
 * Supports both linear and branching layouts with node spacing and
 * width constraints. Node positions are adjusted based on their measured heights
 * for accurate vertical alignment.
 *
 * @param {Node[]} nodes - Array of nodes to position
 * @param {Edge[]} edges - Array of edges connecting the nodes
 * @param {Record<string, number>} nodeHeights - Map of node IDs to their measured heights
 * @param {boolean} isLinear - Whether the flow is linear (true) or branching (false)
 * @returns {Node[]} Array of nodes with calculated positions
 */
export const getLayoutNodes = (
  nodes: Node[],
  edges: Edge[],
  nodeHeights: Record<string, number>,
  isLinear: boolean,
): Node[] => {
  const g = new dagre.graphlib.Graph(); // Create a dagre graph instance
  g.setDefaultEdgeLabel(() => ({}));
  g.setGraph({
    rankdir: 'TB', // Top to Bottom layout
    nodesep: isLinear ? 0 : HORIZONTAL_SPACING, // horizontal spacing between nodes at the same level (applicable for branching flows)
    ranksep: VERTICAL_SPACING, // vertical spacing between levels
  });

  // Max width of a node
  const nodeWidth = isLinear ? NODE_WIDTH_LINEAR : NODE_WIDTH_BRANCHING;

  // Set the width and calculated height of each node
  nodes.forEach(node => {
    g.setNode(node.id, {
      width: nodeWidth,
      height: nodeHeights[node.id] ?? DEFAULT_NODE_HEIGHT,
    });
  });

  // Set the edges between the nodes
  edges.forEach(edge => g.setEdge(edge.source, edge.target));
  // Layout the graph
  dagre.layout(g);

  // Return the nodes with the calculated positions
  return nodes.map(node => {
    const pos = g.node(node.id);
    const height = nodeHeights[node.id] ?? DEFAULT_NODE_HEIGHT;
    return { ...node, position: { x: pos.x, y: pos.y - height / 2 } };
  });
};

/**
 * Skeleton nodes for loading state in flow chart.
 */
export const skeletonNodes: Node[] = [
  {
    id: 's1',
    type: 'skeleton',
    position: { x: 0, y: 0 },
    data: { width: 200 },
  },
  {
    id: 's2',
    type: 'skeleton',
    position: { x: 0, y: 0 },
    data: { width: 240 },
  },
  {
    id: 's3',
    type: 'skeleton',
    position: { x: 0, y: 0 },
    data: { width: 200 },
  },
  {
    id: 's4',
    type: 'skeleton',
    position: { x: 0, y: 0 },
    data: { width: 240 },
  },
  {
    id: 's5',
    type: 'skeleton',
    position: { x: 0, y: 0 },
    data: { width: 340 },
  },
  {
    id: 's6',
    type: 'skeleton',
    position: { x: 0, y: 0 },
    data: { width: 200 },
  },
];

/**
 * Skeleton edges for loading state in flow chart.
 */
export const skeletonEdges: Edge[] = [
  { id: 's1-s2', source: 's1', target: 's2' },
  { id: 's2-s3', source: 's2', target: 's3' },
  { id: 's3-s4', source: 's3', target: 's4' },
  { id: 's4-s5', source: 's4', target: 's5' },
  { id: 's5-s6', source: 's5', target: 's6' },
];

/**
 * Transforms a FlowGraph into ReactFlow Node and Edge arrays
 * compatible with the FlowChart component.
 */
export const transformFlowGraphToFlowChart = (
  graph: IFlowGraph | undefined,
): { nodes: Node[]; edges: Edge[]; isLinear: boolean } => {
  // if no nodes, return empty arrays and linear true
  if (!graph?.nodes?.length) {
    return { nodes: [], edges: [], isLinear: true };
  }

  // transform nodes
  const nodes: Node[] = graph.nodes.map(node => ({
    id: node.id ?? '',
    type: 'custom',
    position: { x: 0, y: 0 }, // placeholder position coordinates, dagre will auto-calculate positions at render
    data: { label: node.label ?? '' },
  }));

  // transform edges
  const edges: Edge[] = (graph.edges ?? []).map(edge => {
    const source = edge.source ?? '';
    const target = edge.target ?? '';
    const edgeData: Edge['data'] = edge.condition
      ? { label: edge.condition }
      : undefined;
    return {
      id: `${source}-${target}`,
      source,
      target,
      ...(edgeData && { data: edgeData, type: 'default' }),
    };
  });

  // Graph is non-linear if it contains decision nodes (if-else flow exists)
  const hasDecisionNodes = graph.nodes.some(
    node => node.type === FlowNodeType.DECISION,
  );

  return { nodes, edges, isLinear: !hasDecisionNodes };
};
