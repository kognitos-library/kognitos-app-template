import {
  render,
  screen,
  renderHook,
  fireEvent,
  act,
} from '@testing-library/react';
import type { Node, Edge } from '@xyflow/react';
import {
  getLayoutNodes,
  getEdgePositions,
  useNodeHeightMeasurement,
  skeletonNodes,
  skeletonEdges,
  NODE_WIDTH_LINEAR,
  NODE_WIDTH_BRANCHING,
  EDGE_OFFSET,
  transformFlowGraphToFlowChart,
  FlowNodeType,
  type IFlowGraph,
} from './flow-chart.utils';
import FlowChart from './flow-chart';
import { vi, describe, it, expect, beforeEach, afterEach } from 'vitest';

// Mock @xyflow/react
vi.mock('@xyflow/react', async () => {
  const actual = await vi.importActual('@xyflow/react');
  return {
    ...actual,
    ReactFlow: vi.fn(({ nodes, edges }) => (
      <div data-testid="react-flow">
        <div data-testid="nodes-count">{nodes?.length ?? 0}</div>
        <div data-testid="edges-count">{edges?.length ?? 0}</div>
        {nodes?.map((node: Node) => (
          <div key={node.id} data-testid={`node-${node.id}`}>
            {String(node.data?.label ?? node.data?.width ?? 'node')}
          </div>
        ))}
      </div>
    )),
    ReactFlowProvider: ({ children }: { children: React.ReactNode }) => (
      <div data-testid="react-flow-provider">{children}</div>
    ),
    useInternalNode: vi.fn(),
    Handle: () => null,
    Position: { Top: 'top', Bottom: 'bottom' },
    BaseEdge: () => null,
    getStraightPath: vi.fn(() => ['M0,0 L100,100']),
    EdgeLabelRenderer: ({ children }: { children: React.ReactNode }) => (
      <div>{children}</div>
    ),
  };
});

describe('flow-chart.utils', () => {
  describe('getLayoutNodes', () => {
    // Empty input
    it('returns empty array for empty nodes', () => {
      expect(getLayoutNodes([], [], {}, true)).toEqual([]);
    });

    // Single node positioning
    it('positions a single node', () => {
      const nodes = [{ id: '1', position: { x: 0, y: 0 }, data: {} }];
      const result = getLayoutNodes(nodes, [], {}, true);
      expect(result[0].position).toBeDefined();
      expect(typeof result[0].position.x).toBe('number');
      expect(typeof result[0].position.y).toBe('number');
    });

    // Linear vs branching uses correct width
    it('uses NODE_WIDTH_LINEAR for linear layout', () => {
      // Verify nodes are spaced assuming 600px width
    });

    it('uses NODE_WIDTH_BRANCHING for branching layout', () => {
      // Verify nodes are spaced assuming 200px width
    });

    // Measured heights are respected
    it('uses measured height when provided', () => {
      const nodes = [{ id: '1', position: { x: 0, y: 0 }, data: {} }];
      const heights = { '1': 100 };
      const result = getLayoutNodes(nodes, [], heights, true);
      // Dagre calculates center position, then we adjust by -height/2
      // For a single node, dagre places it at center (height/2), so final y ≈ 0
      expect(result[0].position.y).toBe(0);
    });

    // Falls back to default height
    it('uses DEFAULT_NODE_HEIGHT when height not measured', () => {
      const nodes = [{ id: '1', position: { x: 0, y: 0 }, data: {} }];
      const result = getLayoutNodes(nodes, [], {}, true);
      // Dagre calculates center position with DEFAULT_NODE_HEIGHT (48)
      // Final y position adjusts by -height/2
      expect(result[0].position.y).toBe(0);
    });

    // Vertical ordering from edges
    it('positions connected nodes top-to-bottom', () => {
      const nodes = [
        { id: 'a', position: { x: 0, y: 0 }, data: {} },
        { id: 'b', position: { x: 0, y: 0 }, data: {} },
      ];
      const edges = [{ id: 'e1', source: 'a', target: 'b' }];
      const result = getLayoutNodes(nodes, edges, {}, true);
      expect(result.find(n => n.id === 'a')!.position.y).toBeLessThan(
        result.find(n => n.id === 'b')!.position.y,
      );
    });

    // Branching layout spreads nodes horizontally
    it('spreads sibling nodes horizontally in branching layout', () => {
      const nodes = [
        { id: 'root', position: { x: 0, y: 0 }, data: {} },
        { id: 'child1', position: { x: 0, y: 0 }, data: {} },
        { id: 'child2', position: { x: 0, y: 0 }, data: {} },
      ];
      const edges = [
        { id: 'e1', source: 'root', target: 'child1' },
        { id: 'e2', source: 'root', target: 'child2' },
      ];
      const result = getLayoutNodes(nodes, edges, {}, false);
      const c1 = result.find(n => n.id === 'child1')!;
      const c2 = result.find(n => n.id === 'child2')!;
      expect(c1.position.x).not.toEqual(c2.position.x); // Spread apart
    });

    // Preserves node data/properties
    it('preserves original node data', () => {
      const nodes = [
        {
          id: '1',
          position: { x: 0, y: 0 },
          data: { label: 'Test' },
          type: 'custom',
        },
      ];
      const result = getLayoutNodes(nodes, [], {}, true);
      expect(result[0].data.label).toBe('Test');
      expect(result[0].type).toBe('custom');
    });
  });

  describe('getEdgePositions', () => {
    const createMockNode = (
      x: number,
      y: number,
      width: number,
      height: number,
    ) => ({
      internals: { positionAbsolute: { x, y } },
      measured: { width, height },
    });

    it('returns null when sourceNode is undefined', () => {
      const targetNode = createMockNode(0, 100, 200, 50);
      expect(getEdgePositions(undefined, targetNode as never)).toBeNull();
    });

    it('returns null when targetNode is undefined', () => {
      const sourceNode = createMockNode(0, 0, 200, 50);
      expect(getEdgePositions(sourceNode as never, undefined)).toBeNull();
    });

    it('returns null when sourceNode position is not measured', () => {
      const sourceNode = {
        internals: {},
        measured: { width: 200, height: 50 },
      };
      const targetNode = createMockNode(0, 100, 200, 50);
      expect(
        getEdgePositions(sourceNode as never, targetNode as never),
      ).toBeNull();
    });

    it('returns null when sourceNode dimensions are not measured', () => {
      const sourceNode = {
        internals: { positionAbsolute: { x: 0, y: 0 } },
        measured: {},
      };
      const targetNode = createMockNode(0, 100, 200, 50);
      expect(
        getEdgePositions(sourceNode as never, targetNode as never),
      ).toBeNull();
    });

    it('calculates correct edge positions', () => {
      const sourceNode = createMockNode(0, 0, 200, 50);
      const targetNode = createMockNode(0, 100, 200, 50);

      const result = getEdgePositions(sourceNode as never, targetNode as never);

      expect(result).not.toBeNull();
      expect(result!.sourceX).toBe(100); // x + width/2 = 0 + 100
      expect(result!.targetX).toBe(100); // x + width/2 = 0 + 100
      expect(result!.sourceY).toBe(50 + EDGE_OFFSET); // y + height + offset
      expect(result!.targetY).toBe(100 - EDGE_OFFSET); // y - offset
    });

    it('calculates correct label positions at midpoint', () => {
      const sourceNode = createMockNode(0, 0, 200, 50);
      const targetNode = createMockNode(0, 100, 200, 50);

      const result = getEdgePositions(sourceNode as never, targetNode as never);

      expect(result).not.toBeNull();
      expect(result!.labelX).toBe(100); // midpoint of sourceX and targetX
      expect(result!.labelY).toBe((60 + 90) / 2); // midpoint of sourceY and targetY
    });
  });

  describe('useNodeHeightMeasurement', () => {
    it('returns a ref object', () => {
      const { result } = renderHook(() => useNodeHeightMeasurement('test-id'));
      expect(result.current).toBeDefined();
      expect(result.current.current).toBeNull();
    });

    it('works without callback provided', () => {
      const { result } = renderHook(() =>
        useNodeHeightMeasurement('test-id', undefined),
      );
      expect(result.current).toBeDefined();
    });

    it('calls onHeightMeasured when element is mounted', () => {
      const mockCallback = vi.fn();

      const TestComponent = () => {
        const ref = useNodeHeightMeasurement('test-node', mockCallback);
        return (
          <div ref={ref} style={{ height: '100px' }}>
            Test content
          </div>
        );
      };

      render(<TestComponent />);
      expect(mockCallback).toHaveBeenCalledWith(
        'test-node',
        expect.any(Number),
      );
    });

    it('does not call callback when ref is null', () => {
      const mockCallback = vi.fn();
      renderHook(() => useNodeHeightMeasurement('test-id', mockCallback));
      expect(mockCallback).not.toHaveBeenCalled();
    });

    it('passes correct node id to callback', () => {
      const mockCallback = vi.fn();

      const TestComponent = () => {
        const ref = useNodeHeightMeasurement('my-unique-node-id', mockCallback);
        return <div ref={ref}>Content</div>;
      };

      render(<TestComponent />);
      expect(mockCallback).toHaveBeenCalledWith(
        'my-unique-node-id',
        expect.any(Number),
      );
    });
  });

  describe('skeletonNodes', () => {
    it('should have 6 skeleton nodes', () => {
      expect(skeletonNodes).toHaveLength(6);
    });

    it('should have correct node type for all skeleton nodes', () => {
      skeletonNodes.forEach(node => {
        expect(node.type).toBe('skeleton');
      });
    });
  });

  describe('skeletonEdges', () => {
    it('should have 5 skeleton edges', () => {
      expect(skeletonEdges).toHaveLength(5);
    });

    it('should have source and target for all skeleton edges', () => {
      skeletonEdges.forEach(edge => {
        expect(edge.source).toBeDefined();
        expect(edge.target).toBeDefined();
        expect(typeof edge.source).toBe('string');
        expect(typeof edge.target).toBe('string');
      });
    });

    it('should connect skeleton nodes in sequence', () => {
      const connections = skeletonEdges.map(edge => ({
        source: edge.source,
        target: edge.target,
      }));

      expect(connections[0]).toEqual({ source: 's1', target: 's2' });
      expect(connections[1]).toEqual({ source: 's2', target: 's3' });
      expect(connections[2]).toEqual({ source: 's3', target: 's4' });
      expect(connections[3]).toEqual({ source: 's4', target: 's5' });
      expect(connections[4]).toEqual({ source: 's5', target: 's6' });
    });
  });

  describe('constants', () => {
    it('should export NODE_WIDTH_LINEAR with correct value', () => {
      expect(NODE_WIDTH_LINEAR).toBe(600);
    });

    it('should export NODE_WIDTH_BRANCHING with correct value', () => {
      expect(NODE_WIDTH_BRANCHING).toBe(200);
    });
  });

  describe('transformFlowGraphToFlowChart', () => {
    it('returns empty arrays and linear=true when graph is undefined', () => {
      const result = transformFlowGraphToFlowChart(undefined);

      expect(result.nodes).toEqual([]);
      expect(result.edges).toEqual([]);
      expect(result.isLinear).toBe(true);
    });

    it('returns empty arrays and linear=true when nodes array is empty', () => {
      const graph: IFlowGraph = { nodes: [], edges: [] };
      const result = transformFlowGraphToFlowChart(graph);

      expect(result.nodes).toEqual([]);
      expect(result.edges).toEqual([]);
      expect(result.isLinear).toBe(true);
    });

    it('transforms nodes correctly with proper id, type, and label', () => {
      const graph: IFlowGraph = {
        nodes: [
          {
            id: 'node-1',
            label: 'Start Process',
            type: FlowNodeType.START,
          },
          {
            id: 'node-2',
            label: 'Do Something',
            type: FlowNodeType.PROCESS,
          },
        ],
        edges: [],
      };

      const result = transformFlowGraphToFlowChart(graph);

      expect(result.nodes).toHaveLength(2);
      expect(result.nodes[0]).toEqual({
        id: 'node-1',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: 'Start Process' },
      });
      expect(result.nodes[1]).toEqual({
        id: 'node-2',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: 'Do Something' },
      });
    });

    it('transforms edges correctly without conditions', () => {
      const graph: IFlowGraph = {
        nodes: [
          { id: 'a', label: 'A', type: FlowNodeType.START },
          { id: 'b', label: 'B', type: FlowNodeType.END },
        ],
        edges: [{ source: 'a', target: 'b' }],
      };

      const result = transformFlowGraphToFlowChart(graph);

      expect(result.edges).toHaveLength(1);
      expect(result.edges[0]).toEqual({
        id: 'a-b',
        source: 'a',
        target: 'b',
      });
    });

    it('transforms edges correctly with condition labels', () => {
      const graph: IFlowGraph = {
        nodes: [
          {
            id: 'decision',
            label: 'Is Valid?',
            type: FlowNodeType.DECISION,
          },
          {
            id: 'yes-branch',
            label: 'Yes Branch',
            type: FlowNodeType.PROCESS,
          },
          {
            id: 'no-branch',
            label: 'No Branch',
            type: FlowNodeType.PROCESS,
          },
        ],
        edges: [
          { source: 'decision', target: 'yes-branch', condition: 'Yes' },
          { source: 'decision', target: 'no-branch', condition: 'No' },
        ],
      };

      const result = transformFlowGraphToFlowChart(graph);

      expect(result.edges).toHaveLength(2);
      expect(result.edges[0]).toEqual({
        id: 'decision-yes-branch',
        source: 'decision',
        target: 'yes-branch',
        data: { label: 'Yes' },
        type: 'default',
      });
      expect(result.edges[1]).toEqual({
        id: 'decision-no-branch',
        source: 'decision',
        target: 'no-branch',
        data: { label: 'No' },
        type: 'default',
      });
    });

    it('sets isLinear=false when DECISION nodes are present', () => {
      const graph: IFlowGraph = {
        nodes: [
          {
            id: 'start',
            label: 'Start',
            type: FlowNodeType.START,
          },
          {
            id: 'decision',
            label: 'Decision',
            type: FlowNodeType.DECISION,
          },
          { id: 'end', label: 'End', type: FlowNodeType.END },
        ],
        edges: [],
      };

      const result = transformFlowGraphToFlowChart(graph);

      expect(result.isLinear).toBe(false);
    });

    it('sets isLinear=true when no DECISION nodes exist', () => {
      const graph: IFlowGraph = {
        nodes: [
          {
            id: 'start',
            label: 'Start',
            type: FlowNodeType.START,
          },
          {
            id: 'process',
            label: 'Process',
            type: FlowNodeType.PROCESS,
          },
          { id: 'end', label: 'End', type: FlowNodeType.END },
        ],
        edges: [],
      };

      const result = transformFlowGraphToFlowChart(graph);

      expect(result.isLinear).toBe(true);
    });

    it('handles edges with missing source/target gracefully', () => {
      const graph: IFlowGraph = {
        nodes: [{ id: 'a', label: 'A', type: FlowNodeType.START }],
        edges: [
          { source: undefined, target: 'a' },
          { source: 'a', target: undefined },
          { source: undefined, target: undefined },
        ],
      };

      const result = transformFlowGraphToFlowChart(graph);

      expect(result.edges).toHaveLength(3);
      expect(result.edges[0]).toEqual({ id: '-a', source: '', target: 'a' });
      expect(result.edges[1]).toEqual({ id: 'a-', source: 'a', target: '' });
      expect(result.edges[2]).toEqual({ id: '-', source: '', target: '' });
    });

    it('handles nodes with missing id/label gracefully', () => {
      const graph: IFlowGraph = {
        nodes: [
          {
            id: undefined,
            label: 'No ID',
            type: FlowNodeType.START,
          },
          {
            id: 'has-id',
            label: undefined,
            type: FlowNodeType.PROCESS,
          },
          {
            id: undefined,
            label: undefined,
            type: FlowNodeType.END,
          },
        ],
        edges: [],
      };

      const result = transformFlowGraphToFlowChart(graph);

      expect(result.nodes).toHaveLength(3);
      expect(result.nodes[0]).toEqual({
        id: '',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: 'No ID' },
      });
      expect(result.nodes[1]).toEqual({
        id: 'has-id',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: '' },
      });
      expect(result.nodes[2]).toEqual({
        id: '',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: '' },
      });
    });
  });
});

describe('FlowChart', () => {
  const testNodes: Node[] = [
    {
      id: 'node1',
      type: 'custom',
      position: { x: 0, y: 0 },
      data: { label: 'Node 1' },
    },
    {
      id: 'node2',
      type: 'custom',
      position: { x: 0, y: 0 },
      data: { label: 'Node 2' },
    },
  ];

  const testEdges: Edge[] = [{ id: 'e1-2', source: 'node1', target: 'node2' }];

  describe('basic rendering', () => {
    it('should render within ReactFlowProvider', () => {
      render(<FlowChart />);

      expect(screen.getByTestId('react-flow-provider')).toBeInTheDocument();
    });

    it('should render ReactFlow component', () => {
      render(<FlowChart initialNodes={testNodes} initialEdges={testEdges} />);

      expect(screen.getByTestId('react-flow')).toBeInTheDocument();
    });

    it('should render with provided nodes', () => {
      render(<FlowChart initialNodes={testNodes} initialEdges={testEdges} />);

      expect(screen.getByTestId('nodes-count').textContent).toBe('2');
    });

    it('should render with provided edges', () => {
      render(<FlowChart initialNodes={testNodes} initialEdges={testEdges} />);

      expect(screen.getByTestId('edges-count').textContent).toBe('1');
    });

    it('should render with empty nodes when none provided', () => {
      render(<FlowChart />);

      expect(screen.getByTestId('nodes-count').textContent).toBe('0');
    });
  });

  describe('loading state', () => {
    it('should render loading state when loading is true', () => {
      render(<FlowChart loading />);

      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('should render custom loading text', () => {
      render(<FlowChart loading loadingText="Generating diagram..." />);

      expect(screen.getByText('Generating diagram...')).toBeInTheDocument();
    });

    it('should render skeleton nodes when loading', () => {
      render(<FlowChart loading />);

      expect(screen.getByTestId('nodes-count').textContent).toBe('6');
    });

    it('should not render loading state when loading is false', () => {
      render(<FlowChart loading={false} />);

      expect(screen.queryByText('Loading...')).not.toBeInTheDocument();
    });
  });

  describe('error state', () => {
    it('should render error state when error.show is true', () => {
      render(<FlowChart error={{ show: true }} />);

      expect(screen.getByText("Couldn't load the diagram")).toBeInTheDocument();
    });

    it('should render error description', () => {
      render(<FlowChart error={{ show: true }} />);

      expect(
        screen.getByText(
          /There was an issue displaying this workflow. Please try refreshing the page or try again later./,
        ),
      ).toBeInTheDocument();
    });

    it('should render custom error title and description', () => {
      render(
        <FlowChart
          error={{
            show: true,
            title: 'Custom Error',
            description: 'Custom description',
          }}
        />,
      );

      expect(screen.getByText('Custom Error')).toBeInTheDocument();
      expect(screen.getByText('Custom description')).toBeInTheDocument();
    });

    it('should not render ReactFlow when error.show is true', () => {
      render(<FlowChart error={{ show: true }} />);

      expect(screen.queryByTestId('react-flow')).not.toBeInTheDocument();
    });

    it('should not render error state when error.show is false', () => {
      render(<FlowChart error={{ show: false }} />);

      expect(
        screen.queryByText("Couldn't load the diagram"),
      ).not.toBeInTheDocument();
    });

    it('should not render error state when error is undefined', () => {
      render(<FlowChart />);

      expect(
        screen.queryByText("Couldn't load the diagram"),
      ).not.toBeInTheDocument();
    });

    it('should render action button when onAction is provided', () => {
      const onAction = vi.fn();
      render(<FlowChart error={{ show: true, onAction }} />);

      const refreshButton = screen.getByRole('button', { name: /refresh/i });
      expect(refreshButton).toBeInTheDocument();
    });

    it('should not render action button when onAction is not provided', () => {
      render(<FlowChart error={{ show: true }} />);

      expect(
        screen.queryByRole('button', { name: /refresh/i }),
      ).not.toBeInTheDocument();
    });

    it('should call onAction when action button is clicked', () => {
      const onAction = vi.fn();
      render(<FlowChart error={{ show: true, onAction }} />);

      const refreshButton = screen.getByRole('button', { name: /refresh/i });
      fireEvent.click(refreshButton);

      expect(onAction).toHaveBeenCalledTimes(1);
    });

    it('should render custom action label', () => {
      const onAction = vi.fn();
      render(
        <FlowChart
          error={{ show: true, onAction, actionLabel: 'Try Again' }}
        />,
      );

      expect(
        screen.getByRole('button', { name: /try again/i }),
      ).toBeInTheDocument();
    });

    it('should show loading state on action button when actionLoading is true', () => {
      const onAction = vi.fn();
      render(
        <FlowChart error={{ show: true, onAction, actionLoading: true }} />,
      );

      const refreshButton = screen.getByRole('button', { name: /refresh/i });
      expect(refreshButton).toBeDisabled();
    });
  });

  describe('props', () => {
    it('should use default fitView value of true', () => {
      render(<FlowChart initialNodes={testNodes} />);

      expect(screen.getByTestId('react-flow')).toBeInTheDocument();
    });

    it('should accept minZoom and maxZoom props', () => {
      render(<FlowChart minZoom={0.2} maxZoom={3} />);

      expect(screen.getByTestId('react-flow-provider')).toBeInTheDocument();
    });

    it('should use linear layout by default', () => {
      render(<FlowChart initialNodes={testNodes} initialEdges={testEdges} />);

      // Default linear prop is true
      expect(screen.getByTestId('react-flow')).toBeInTheDocument();
    });

    it('should support branching layout', () => {
      render(
        <FlowChart
          initialNodes={testNodes}
          initialEdges={testEdges}
          linear={false}
        />,
      );

      expect(screen.getByTestId('react-flow')).toBeInTheDocument();
    });
  });

  describe('state priority', () => {
    it('should prioritize loading state over normal rendering', () => {
      render(
        <FlowChart loading initialNodes={testNodes} initialEdges={testEdges} />,
      );

      // Should show loading text, not the actual nodes
      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    it('should prioritize error state over normal rendering', () => {
      render(
        <FlowChart
          error={{ show: true }}
          initialNodes={testNodes}
          initialEdges={testEdges}
        />,
      );

      // Should show error message, not the actual nodes
      expect(screen.getByText("Couldn't load the diagram")).toBeInTheDocument();
    });

    it('should show both loading and error when both are active', () => {
      render(<FlowChart loading error={{ show: true }} />);

      // Both states render - loading shows skeleton in background, error shows on top
      expect(screen.getByText('Loading...')).toBeInTheDocument();
      expect(screen.getByText("Couldn't load the diagram")).toBeInTheDocument();
    });
  });

  describe('overlay', () => {
    beforeEach(() => {
      vi.useFakeTimers();
    });

    afterEach(() => {
      vi.useRealTimers();
    });

    it('should render overlay when overlay.show is true', () => {
      render(
        <FlowChart
          initialNodes={testNodes}
          initialEdges={testEdges}
          overlay={{ show: true }}
        />,
      );

      expect(screen.getByTestId('flowchart-overlay')).toBeInTheDocument();
    });

    it('should not render overlay when overlay.show is false', () => {
      render(
        <FlowChart
          initialNodes={testNodes}
          initialEdges={testEdges}
          overlay={{ show: false }}
        />,
      );

      expect(screen.queryByTestId('flowchart-overlay')).not.toBeInTheDocument();
    });

    it('should not render overlay when overlay is undefined', () => {
      render(<FlowChart initialNodes={testNodes} initialEdges={testEdges} />);

      expect(screen.queryByTestId('flowchart-overlay')).not.toBeInTheDocument();
    });

    it('should not render overlay when loading is true', () => {
      render(<FlowChart loading overlay={{ show: true }} />);

      expect(screen.queryByTestId('flowchart-overlay')).not.toBeInTheDocument();
    });

    it('should not render overlay when error.show is true', () => {
      render(<FlowChart error={{ show: true }} overlay={{ show: true }} />);

      expect(screen.queryByTestId('flowchart-overlay')).not.toBeInTheDocument();
    });

    it('should render custom overlay text', () => {
      render(
        <FlowChart
          initialNodes={testNodes}
          overlay={{ show: true, text: 'Custom instruction text' }}
        />,
      );

      expect(screen.getByText('Custom instruction text')).toBeInTheDocument();
    });

    it('should fade out overlay on mouse movement', () => {
      render(<FlowChart initialNodes={testNodes} overlay={{ show: true }} />);

      const overlay = screen.getByTestId('flowchart-overlay');
      expect(overlay).toHaveClass('opacity-100');

      fireEvent.mouseMove(overlay);

      expect(overlay).toHaveClass('opacity-0');
    });

    it('should auto-fade overlay after default delay (3 seconds)', () => {
      render(<FlowChart initialNodes={testNodes} overlay={{ show: true }} />);

      const overlay = screen.getByTestId('flowchart-overlay');
      expect(overlay).toHaveClass('opacity-100');

      act(() => {
        vi.advanceTimersByTime(3000);
      });

      expect(overlay).toHaveClass('opacity-0');
    });

    it('should auto-fade overlay after custom delay', () => {
      render(
        <FlowChart
          initialNodes={testNodes}
          overlay={{ show: true, autoHideDelay: 5000 }}
        />,
      );

      const overlay = screen.getByTestId('flowchart-overlay');
      expect(overlay).toHaveClass('opacity-100');

      // Should not fade after 3 seconds
      act(() => {
        vi.advanceTimersByTime(3000);
      });
      expect(overlay).toHaveClass('opacity-100');

      // Should fade after 5 seconds total
      act(() => {
        vi.advanceTimersByTime(2000);
      });
      expect(overlay).toHaveClass('opacity-0');
    });

    it('should call onDismiss callback after fade animation completes', () => {
      const onDismiss = vi.fn();
      render(
        <FlowChart
          initialNodes={testNodes}
          overlay={{ show: true, onDismiss }}
        />,
      );

      const overlay = screen.getByTestId('flowchart-overlay');

      // Trigger mouse movement to start fading
      fireEvent.mouseMove(overlay);

      // onDismiss should not be called yet (still animating)
      expect(onDismiss).not.toHaveBeenCalled();

      // Trigger transition end
      fireEvent.transitionEnd(overlay);

      // onDismiss should now be called
      expect(onDismiss).toHaveBeenCalledTimes(1);
    });

    it('should not call onDismiss multiple times for multiple mouse movements', () => {
      const onDismiss = vi.fn();
      render(
        <FlowChart
          initialNodes={testNodes}
          overlay={{ show: true, onDismiss }}
        />,
      );

      const overlay = screen.getByTestId('flowchart-overlay');

      // Multiple mouse movements
      fireEvent.mouseMove(overlay);
      fireEvent.mouseMove(overlay);
      fireEvent.mouseMove(overlay);

      // Trigger transition end
      fireEvent.transitionEnd(overlay);

      // onDismiss should only be called once
      expect(onDismiss).toHaveBeenCalledTimes(1);
    });
  });
});
