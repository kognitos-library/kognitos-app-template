import type { Meta, StoryObj } from '@storybook/react';
import { useState } from 'react';

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  Button,
  Input,
  Label,
  Text,
  Flex,
} from '@/design-system';

const meta: Meta<typeof Dialog> = {
  title: 'Design System/Primitives/Feedback/Dialog',
  component: Dialog,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A window overlaid on either the primary window or another dialog window.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    open: {
      control: 'boolean',
      description: 'The controlled open state of the dialog',
    },
    onOpenChange: {
      action: 'onOpenChange',
      description:
        'Event handler called when the open state of the dialog changes',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Dialog>;

// Basic Dialog Story
const DefaultDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Open Dialog</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Are you absolutely sure?</DialogTitle>
          <DialogDescription>
            This action cannot be undone. This will permanently delete your
            account and remove your data from our servers.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button variant="destructive">Delete Account</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const Default: Story = {
  render: DefaultDialog,
};

// Dialog with Form
const FormDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Edit Profile</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Edit Profile</DialogTitle>
          <DialogDescription>
            Make changes to your profile here. Click save when you're done.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="name" className="text-right">
              Name
            </Label>
            <Input
              id="name"
              defaultValue="Pedro Duarte"
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="username" className="text-right">
              Username
            </Label>
            <Input
              id="username"
              defaultValue="@peduarte"
              className="col-span-3"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={() => setOpen(false)}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const WithForm: Story = {
  render: FormDialog,
};

// Dialog without Close Button
const NoCloseDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Open Dialog</Button>
      </DialogTrigger>
      <DialogContent showCloseButton={false}>
        <DialogHeader>
          <DialogTitle>Important Notice</DialogTitle>
          <DialogDescription>
            This dialog cannot be closed by clicking the X button. You must use
            the action buttons below.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={() => setOpen(false)}>Confirm</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const WithoutCloseButton: Story = {
  render: NoCloseDialog,
};

// Dialog with Custom Content
const CustomContentDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>View Details</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Project Details</DialogTitle>
          <DialogDescription>
            Here are the details for your selected project.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Text className="font-medium">Project Name</Text>
              <Text className="text-muted-foreground">Bumblebee Dashboard</Text>
            </div>
            <div>
              <Text className="font-medium">Status</Text>
              <Text className="text-muted-foreground">In Progress</Text>
            </div>
            <div>
              <Text className="font-medium">Created</Text>
              <Text className="text-muted-foreground">January 15, 2024</Text>
            </div>
            <div>
              <Text className="font-medium">Last Updated</Text>
              <Text className="text-muted-foreground">March 10, 2024</Text>
            </div>
          </div>
          <div>
            <Text className="font-medium">Description</Text>
            <Text className="text-muted-foreground">
              A comprehensive dashboard application built with React and
              TypeScript. Features include real-time data visualization, user
              management, and advanced analytics capabilities.
            </Text>
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Close
          </Button>
          <Button onClick={() => setOpen(false)}>Edit Project</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const WithCustomContent: Story = {
  render: CustomContentDialog,
};

// Dialog with Alert Content
const AlertDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="destructive">Delete Item</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Delete Confirmation</DialogTitle>
          <DialogDescription>
            Are you sure you want to delete this item? This action cannot be
            undone and will permanently remove the item from your account.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={() => setOpen(false)}>
            Delete
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const WithAlert: Story = {
  render: AlertDialog,
};

// Dialog with Long Content
const LongContentDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>View Terms</Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Terms of Service</DialogTitle>
          <DialogDescription>
            Please read our terms of service carefully before proceeding.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <ol className="space-y-4">
            {Array.from({ length: 15 }, (_, index) => (
              <li key={index}>
                <Text className="font-medium">{index + 1}. Terms Section</Text>
                <Text className="text-muted-foreground">
                  This is a sample terms section with placeholder text that
                  demonstrates how the dialog handles long content with proper
                  scrolling and formatting.
                </Text>
              </li>
            ))}
          </ol>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Decline
          </Button>
          <Button onClick={() => setOpen(false)}>Accept</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const WithLongContent: Story = {
  render: LongContentDialog,
};

// Dialog with Different Backdrop Blur Values
export const BackdropBlurVariants: Story = {
  render: () => {
    const BlurVariantsDialog = () => {
      const [open, setOpen] = useState(false);
      const [blurValue, setBlurValue] = useState<'sm' | 'md' | 'lg'>('lg');

      const blurOptions: Array<{
        value: 'sm' | 'md' | 'lg';
        label: string;
      }> = [
        { value: 'sm', label: 'Small' },
        { value: 'md', label: 'Medium' },
        { value: 'lg', label: 'Large' },
      ];

      return (
        <div className="space-y-4">
          <Flex gap={2} wrap="wrap">
            {blurOptions.map(option => (
              <Button
                key={option.value}
                variant={blurValue === option.value ? 'secondary' : 'outline'}
                onClick={() => setBlurValue(option.value)}
              >
                {option.label}
              </Button>
            ))}
          </Flex>

          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button className="mt-4">
                Open Dialog with {blurValue} Blur
              </Button>
            </DialogTrigger>
            <DialogContent backdropBlur={blurValue}>
              <DialogHeader>
                <DialogTitle>Backdrop Blur: {blurValue}</DialogTitle>
                <DialogDescription>
                  This dialog demonstrates the {blurValue} backdrop blur effect.
                  Try different blur values using the buttons above.
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="secondary" onClick={() => setOpen(false)}>
                  Close
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      );
    };

    return <BlurVariantsDialog />;
  },
};

// Dialog Accessibility Demo
const AccessibilityDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Accessibility Demo</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Accessibility Features</DialogTitle>
          <DialogDescription>
            This dialog demonstrates various accessibility features:
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Text className="font-medium">Keyboard Navigation</Text>
            <Text className="text-muted-foreground">
              • Press Tab to navigate between focusable elements • Press Escape
              to close the dialog • Press Enter or Space to activate buttons
            </Text>
          </div>
          <div>
            <Text className="font-medium">Screen Reader Support</Text>
            <Text className="text-muted-foreground">
              • Dialog title and description are announced • Focus is trapped
              within the dialog • Close button has proper ARIA labels
            </Text>
          </div>
          <div>
            <Text className="font-medium">Focus Management</Text>
            <Text className="text-muted-foreground">
              • Focus moves to the first focusable element when opened • Focus
              returns to the trigger when closed • Focus is trapped within the
              dialog content
            </Text>
          </div>
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Close
          </Button>
          <Button onClick={() => setOpen(false)}>Learn More</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const AccessibilityDemo: Story = {
  render: AccessibilityDialog,
};

const ScrollableBodyDialog = (args: React.ComponentProps<typeof Dialog>) => {
  const [open, setOpen] = useState(false);

  return (
    <Dialog {...args} open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>Open Scrollable Dialog</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg overflow-hidden">
        <DialogHeader>
          <DialogTitle>Scrollable Content Demo</DialogTitle>
          <DialogDescription>
            This dialog has content that exceeds the viewport height, triggering
            the scroll behavior.
          </DialogDescription>
        </DialogHeader>
        <div className="max-h-[50vh] space-y-4 overflow-y-auto">
          {Array.from({ length: 20 }, (_, index) => (
            <div key={index} className="rounded-md border p-4">
              <Text className="font-medium">Section {index + 1}</Text>
              <Text className="text-muted-foreground">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do
                eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                enim ad minim veniam, quis nostrud exercitation ullamco laboris.
              </Text>
            </div>
          ))}
        </div>
        <DialogFooter>
          <Button variant="secondary" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={() => setOpen(false)}>Confirm</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export const ScrollableBody: Story = {
  render: ScrollableBodyDialog,
  parameters: {
    docs: {
      description: {
        story:
          'Demonstrates the dialog scroll behavior when content exceeds the max height. Max height in component should set the max height of the dialog content. Add overflow to content container to allow scrolling.',
      },
    },
  },
};
