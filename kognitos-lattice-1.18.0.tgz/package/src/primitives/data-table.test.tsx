import * as React from 'react';
import { render, screen } from '@testing-library/react';
import { DataTable, type IDataTableColDef } from './data-table';
import { vi, describe, beforeEach, it, expect } from 'vitest';

// Mock AG Grid React to avoid DOM issues in tests
vi.mock('ag-grid-react', () => ({
  AgGridReact: ({
    rowData,
    columnDefs,
    onGridReady,
    className,
  }: {
    rowData: unknown[];
    columnDefs: IDataTableColDef[];
    onGridReady?: (event: { api: { sizeColumnsToFit: () => void } }) => void;
    className?: string;
  }) => {
    // Simulate grid ready event
    React.useEffect(() => {
      if (onGridReady) {
        onGridReady({
          api: {
            sizeColumnsToFit: vi.fn(),
          },
        });
      }
    }, [onGridReady]);

    return (
      <div className={className} data-testid="ds-table">
        <div data-testid="grid-header">
          {columnDefs.map((col: IDataTableColDef) => (
            <div key={col.field} data-testid={`header-${col.field}`}>
              {col.headerName || col.field}
            </div>
          ))}
        </div>
        <div data-testid="grid-body">
          {rowData?.map((row: unknown, rowIndex: number) => {
            const rowData = row as Record<string, unknown>;
            const rowId = rowData.id || rowIndex; // Use id if available, fallback to index
            return (
              <div key={`row-${rowId}`} data-testid={`row-${rowIndex}`}>
                {columnDefs.map((col: IDataTableColDef) => (
                  <div
                    key={`${rowId}-${col.field}`}
                    data-testid={`cell-${rowIndex}-${col.field}`}
                  >
                    {String(rowData[col.field as string])}
                  </div>
                ))}
              </div>
            );
          })}
        </div>
      </div>
    );
  },
}));

// Mock AG Grid styles
vi.mock('ag-grid-community/styles/ag-grid.css', () => ({}));
vi.mock('ag-grid-community/styles/ag-theme-alpine.css', () => ({}));

describe('DataTable', () => {
  const mockData = [
    { id: 1, name: 'John Doe', age: 30, email: 'john@example.com' },
    { id: 2, name: 'Jane Smith', age: 25, email: 'jane@example.com' },
  ];

  const mockColumns: IDataTableColDef[] = [
    { field: 'id', headerName: 'ID' },
    { field: 'name', headerName: 'Name' },
    { field: 'age', headerName: 'Age' },
    { field: 'email', headerName: 'Email' },
  ];

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should render with basic props', () => {
    render(<DataTable data={mockData} columns={mockColumns} />);

    expect(screen.getByTestId('ds-table')).toBeInTheDocument();
    expect(screen.getByTestId('grid-header')).toBeInTheDocument();
    expect(screen.getByTestId('grid-body')).toBeInTheDocument();
  });

  it('should render column headers correctly', () => {
    render(<DataTable data={mockData} columns={mockColumns} />);

    expect(screen.getByTestId('header-id')).toHaveTextContent('ID');
    expect(screen.getByTestId('header-name')).toHaveTextContent('Name');
    expect(screen.getByTestId('header-age')).toHaveTextContent('Age');
    expect(screen.getByTestId('header-email')).toHaveTextContent('Email');
  });

  it('should render data rows correctly', () => {
    render(<DataTable data={mockData} columns={mockColumns} />);

    // Check first row
    expect(screen.getByTestId('cell-0-id')).toHaveTextContent('1');
    expect(screen.getByTestId('cell-0-name')).toHaveTextContent('John Doe');
    expect(screen.getByTestId('cell-0-age')).toHaveTextContent('30');
    expect(screen.getByTestId('cell-0-email')).toHaveTextContent(
      'john@example.com',
    );

    // Check second row
    expect(screen.getByTestId('cell-1-id')).toHaveTextContent('2');
    expect(screen.getByTestId('cell-1-name')).toHaveTextContent('Jane Smith');
    expect(screen.getByTestId('cell-1-age')).toHaveTextContent('25');
    expect(screen.getByTestId('cell-1-email')).toHaveTextContent(
      'jane@example.com',
    );
  });

  it('should apply custom className', () => {
    render(
      <DataTable
        data={mockData}
        columns={mockColumns}
        className="custom-class"
      />,
    );

    const tableElement = screen.getByTestId('ds-table');
    expect(tableElement).toHaveClass('custom-class');
  });

  it('should apply default styling', () => {
    render(<DataTable data={mockData} columns={mockColumns} />);

    const tableElement = screen.getByTestId('ds-table');
    expect(tableElement).toHaveClass('w-full', 'h-full');
  });

  it('should handle empty data', () => {
    render(<DataTable data={[]} columns={mockColumns} />);

    expect(screen.getByTestId('ds-table')).toBeInTheDocument();
    expect(screen.getByTestId('grid-header')).toBeInTheDocument();
    expect(screen.getByTestId('grid-body')).toBeInTheDocument();
  });

  it('should call onGridReady when provided', () => {
    const mockOnGridReady = vi.fn();

    render(
      <DataTable
        data={mockData}
        columns={mockColumns}
        onGridReady={mockOnGridReady}
      />,
    );

    expect(mockOnGridReady).toHaveBeenCalledWith(
      expect.objectContaining({
        api: expect.objectContaining({
          sizeColumnsToFit: expect.any(Function),
        }),
      }),
    );
  });

  it('should handle loading state', () => {
    render(<DataTable data={mockData} columns={mockColumns} loading />);

    expect(screen.getByTestId('ds-table')).toBeInTheDocument();
  });

  it('should enable row selection when specified', () => {
    render(
      <DataTable
        data={mockData}
        columns={mockColumns}
        rowSelection={{
          mode: 'multiRow',
        }}
      />,
    );

    expect(screen.getByTestId('ds-table')).toBeInTheDocument();
  });

  it('should handle grid options when specified', () => {
    render(
      <DataTable
        data={mockData}
        columns={mockColumns}
        gridOptions={{ animateRows: false }}
      />,
    );

    expect(screen.getByTestId('ds-table')).toBeInTheDocument();
  });

  it('should enable pagination when specified', () => {
    render(
      <DataTable
        data={mockData}
        columns={mockColumns}
        gridOptions={{ pagination: true, paginationPageSize: 1 }}
      />,
    );

    expect(screen.getByTestId('ds-table')).toBeInTheDocument();
  });

  it('should apply design system theme', () => {
    render(<DataTable data={mockData} columns={mockColumns} />);

    expect(screen.getByTestId('ds-table')).toBeInTheDocument();
    // The theme is applied internally via the createThemedGridConfig function
    // We can't easily test the theme application without mocking AG Grid internals
  });

  describe('size variants', () => {
    it('should apply default size (52px row height)', () => {
      render(
        <DataTable data={mockData} columns={mockColumns} size="default" />,
      );

      const table = screen.getByTestId('ds-table');
      expect(table).toBeInTheDocument();
    });

    it('should apply md size (72px row height)', () => {
      render(<DataTable data={mockData} columns={mockColumns} size="md" />);

      const table = screen.getByTestId('ds-table');
      expect(table).toBeInTheDocument();
    });

    it('should apply lg size (96px row height)', () => {
      render(<DataTable data={mockData} columns={mockColumns} size="lg" />);

      const table = screen.getByTestId('ds-table');
      expect(table).toBeInTheDocument();
    });

    it('should default to default size when no size is provided', () => {
      render(<DataTable data={mockData} columns={mockColumns} />);

      const table = screen.getByTestId('ds-table');
      expect(table).toBeInTheDocument();
    });
  });

  describe('variant prop', () => {
    it('should render with borderless variant', () => {
      render(
        <DataTable
          data={mockData}
          columns={mockColumns}
          variant="borderless"
        />,
      );

      const table = screen.getByTestId('ds-table');
      expect(table).toBeInTheDocument();
      // Border styling is now handled by AG Grid's theme system, not CSS classes
    });

    it('should render with bordered variant', () => {
      render(
        <DataTable data={mockData} columns={mockColumns} variant="bordered" />,
      );

      const table = screen.getByTestId('ds-table');
      expect(table).toBeInTheDocument();
      // Border styling is now handled by AG Grid's theme system, not CSS classes
    });

    it('should default to borderless when variant prop is not provided', () => {
      render(<DataTable data={mockData} columns={mockColumns} />);

      const table = screen.getByTestId('ds-table');
      expect(table).toBeInTheDocument();
      // Border styling is now handled by AG Grid's theme system, not CSS classes
    });
  });
});
