import { type ComponentProps, type ReactNode, isValidElement } from 'react';
import { Slot, Slottable } from '@radix-ui/react-slot';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '../lib/utils';
import Icon from '../icons';

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-all disabled:cursor-not-allowed disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive not-disabled:hover:cursor-pointer",
  {
    variants: {
      variant: {
        default:
          'bg-button-primary text-primary-foreground not-disabled:hover:bg-button-primary/90',
        destructive:
          'bg-destructive text-white not-disabled:hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:focus-visible:ring-destructive/40 dark:bg-destructive/60',
        outline:
          'border bg-background shadow-xs not-disabled:hover:bg-accent not-disabled:hover:text-accent-foreground dark:bg-input/30 dark:border-input dark:not-disabled:hover:bg-input/50',
        secondary:
          'bg-secondary text-secondary-foreground not-disabled:hover:bg-secondary/80',
        ghost:
          'not-disabled:hover:bg-accent not-disabled:hover:text-accent-foreground dark:not-disabled:hover:bg-accent',
        link: 'text-link underline-offset-4 not-disabled:hover:underline', // custom link color
      },
      size: {
        default: 'h-9 px-4 py-2 has-[>svg]:px-3',
        sm: 'h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5 text-xs',
        lg: 'h-10 rounded-md px-6 has-[>svg]:px-4',
        icon: 'size-9',
        'icon-xs': 'size-6 rounded-sm',
        'icon-sm': 'size-8',
        'icon-lg': 'size-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  },
);

interface IButtonProps
  extends ComponentProps<'button'>, VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  // custom prop for loading state
  isLoading?: boolean;
}

/**
 * Filters out Icon components from children when loading
 */
function filterIconsFromChildren(children: ReactNode): ReactNode {
  if (!children) return children;

  // Handle array of children
  if (Array.isArray(children)) {
    return children.filter(child => {
      return !(isValidElement(child) && child.type === Icon);
    });
  }

  // Handle single child
  if (isValidElement(children) && children.type === Icon) {
    return null;
  }

  return children;
}

function Button({
  className,
  variant,
  size,
  children,
  asChild = false,
  isLoading,
  disabled,
  ...props
}: IButtonProps) {
  const Comp = asChild ? Slot : 'button';

  // Determine what content to show
  let content: ReactNode;
  if (size && ['icon', 'icon-sm', 'icon-lg'].includes(size) && isLoading) {
    // Icon-only button: hide all children when loading
    content = null;
  } else if (isLoading) {
    // Regular button with icon: filter out Icon components when loading
    content = filterIconsFromChildren(children);
  } else {
    // Normal state: show all children
    content = children;
  }

  return (
    <Comp
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading && <Icon type="Loader2" className="animate-spin" />}
      <Slottable>{content}</Slottable>
    </Comp>
  );
}

export { Button, buttonVariants, type IButtonProps };
