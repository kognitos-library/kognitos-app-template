import { render, screen } from '@testing-library/react';
import { Textarea } from './textarea';
import { describe, expect, it } from 'vitest';

describe('Textarea', () => {
  describe('Variants', () => {
    it('should render with default variant', () => {
      render(<Textarea placeholder="Default textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('border-input');
      expect(textarea).toHaveClass('shadow-xs');
      expect(textarea).toHaveClass('focus-visible:border-ring');
      expect(textarea).toHaveClass('focus-visible:ring-ring/50');
    });

    it('should render with ghost variant', () => {
      render(<Textarea variant="ghost" placeholder="Ghost textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('border-transparent');
      expect(textarea).not.toHaveClass('shadow-xs');
    });

    it('should render with inline variant', () => {
      render(<Textarea variant="inline" placeholder="Inline textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('flex-1');
      expect(textarea).toHaveClass('min-w-0');
      expect(textarea).toHaveClass('bg-transparent');
      expect(textarea).toHaveClass('border-0');
      expect(textarea).toHaveClass('resize-none');
      expect(textarea).toHaveClass('rounded-none');
    });
  });

  describe('States', () => {
    it('should handle disabled state', () => {
      render(<Textarea disabled placeholder="Disabled textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toBeDisabled();
      expect(textarea).toHaveClass('disabled:cursor-not-allowed');
      expect(textarea).toHaveClass('disabled:opacity-50');
    });

    it('should handle invalid state for default variant', () => {
      render(
        <Textarea
          variant="default"
          aria-invalid
          placeholder="Invalid textarea"
        />,
      );

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('border-destructive');
      expect(textarea).toHaveClass('ring-destructive/20');
    });

    it('should handle invalid state for ghost variant', () => {
      render(
        <Textarea
          variant="ghost"
          aria-invalid
          placeholder="Invalid ghost textarea"
        />,
      );

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('border-transparent');
      expect(textarea).not.toHaveClass('border-destructive');
    });

    it('should still set aria-invalid attribute for inline variant when invalid', () => {
      render(
        <Textarea
          variant="inline"
          aria-invalid
          placeholder="Invalid inline textarea"
        />,
      );

      const textarea = screen.getByRole('textbox');
      // aria-invalid should still be set for accessibility, even if visual styles aren't applied
      expect(textarea).toHaveAttribute('aria-invalid', 'true');
    });
  });

  describe('Styling', () => {
    it('should have auto-sizing classes', () => {
      render(<Textarea placeholder="Auto-sizing textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('field-sizing-content');
      expect(textarea).toHaveClass('min-h-16');
    });

    it('should render with custom className', () => {
      render(
        <Textarea className="custom-class" placeholder="Custom textarea" />,
      );

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('custom-class');
    });

    it('should have proper rounded corners', () => {
      render(<Textarea placeholder="Rounded textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('rounded-md');
    });

    it('should have proper padding for default variant', () => {
      render(<Textarea placeholder="Padded textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('px-3');
      expect(textarea).toHaveClass('py-2');
    });

    it('should have no horizontal padding nor rounded corners for inline variant', () => {
      render(<Textarea variant="inline" placeholder="Inline textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveClass('px-0');
      expect(textarea).toHaveClass('py-2');
      expect(textarea).toHaveClass('rounded-none');
      expect(textarea).not.toHaveClass('rounded-md');
    });

    it('should not have max-height restrictions for inline variant', () => {
      const longText = 'Line 1\n'.repeat(100); // Create a long multi-line text
      render(<Textarea variant="inline" defaultValue={longText} />);

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;

      // Inline variant should not have max-height classes
      expect(textarea).not.toHaveClass('max-h-');
      expect(textarea.style.maxHeight).toBe('');

      // Should be able to contain long content without height restrictions
      expect(textarea.value).toBe(longText);
    });

    it('should allow inline variant to grow with long messages', () => {
      const longMessage = 'This is a very long message. '.repeat(50);
      render(
        <Textarea
          variant="inline"
          defaultValue={longMessage}
          placeholder="Type a long message"
        />,
      );

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;

      // Should contain the long message
      expect(textarea.value).toBe(longMessage);

      // Should not have overflow restrictions that limit height
      expect(textarea).not.toHaveClass('overflow-hidden');
      expect(textarea.style.maxHeight).toBe('');
    });
  });

  describe('Attributes', () => {
    it('should have data-slot attribute', () => {
      render(<Textarea placeholder="Slot textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveAttribute('data-slot', 'textarea');
    });

    it('should render with placeholder', () => {
      const placeholder = 'Enter your text here';
      render(<Textarea placeholder={placeholder} />);

      const textarea = screen.getByPlaceholderText(placeholder);
      expect(textarea).toBeInTheDocument();
    });

    it('should render with default value', () => {
      const defaultValue = 'Initial content';
      render(<Textarea defaultValue={defaultValue} />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveValue(defaultValue);
    });

    it('should forward all props to textarea element', () => {
      render(
        <Textarea
          placeholder="Test"
          rows={5}
          maxLength={100}
          data-testid="custom-textarea"
        />,
      );

      const textarea = screen.getByTestId('custom-textarea');
      expect(textarea).toHaveAttribute('rows', '5');
      expect(textarea).toHaveAttribute('maxLength', '100');
    });
  });

  describe('Accessibility', () => {
    it('should be accessible by role', () => {
      render(<Textarea placeholder="Accessible textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toBeInTheDocument();
    });

    it('should support aria-invalid', () => {
      render(<Textarea aria-invalid placeholder="Invalid textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveAttribute('aria-invalid', 'true');
    });

    it('should support aria-describedby', () => {
      render(
        <Textarea
          aria-describedby="error-message"
          placeholder="Described textarea"
        />,
      );

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveAttribute('aria-describedby', 'error-message');
    });

    it('should support aria-label', () => {
      render(<Textarea aria-label="Custom label" />);

      const textarea = screen.getByLabelText('Custom label');
      expect(textarea).toBeInTheDocument();
    });

    it('should support aria-required', () => {
      render(<Textarea aria-required placeholder="Required textarea" />);

      const textarea = screen.getByRole('textbox');
      expect(textarea).toHaveAttribute('aria-required', 'true');
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty value', () => {
      render(<Textarea defaultValue="" />);

      const textarea = screen.getByRole('textbox') as HTMLTextAreaElement;
      expect(textarea.value).toBe('');
    });
  });
});
