import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState, useEffect } from 'react';
import { Progress, Flex, Text, Button } from '@/design-system';

const meta: Meta<typeof Progress> = {
  title: 'Design System/Primitives/Feedback/Progress',
  component: Progress,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Progress component that displays a visual indicator of progress or completion status. Built on Radix UI Progress primitive with smooth animations and accessibility support.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
  argTypes: {
    value: {
      control: { type: 'number', min: 0, max: 100, step: 1 },
      description: 'The progress value as a percentage (0-100)',
    },
    variant: {
      control: { type: 'select' },
      options: ['default', 'secondary'],
      description: 'Visual variant of the progress bar',
    },
    showInfo: {
      control: { type: 'boolean' },
      description:
        'Whether to display the progress text next to the progress bar',
    },
    className: {
      control: { type: 'text' },
      description: 'Additional className for the progress bar',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Progress>;

// Primary default progress component
export const PrimaryDefault: Story = {
  args: {
    value: 50,
  },
  parameters: {
    docs: {
      description: {
        story:
          'This is the primary default Progress component. It has different information display options and has a secondary color variant. Adjust the value using the controls panel above to see real-time changes.',
      },
    },
  },
};

// Secondary default progress component
export const SecondaryDefault: Story = {
  args: {
    value: 50,
    variant: 'secondary',
  },
  parameters: {
    docs: {
      description: {
        story:
          'This is the secondary default Progress component. It has a different color variant than the primary default.',
      },
    },
  },
};

// Different progress values from 0% to 100%.
export const ProgressStages: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Progress component at different completion stages without any information display.',
      },
    },
  },
  render: () => (
    <Flex direction="column" gap={4} className="w-full">
      {(['default', 'secondary'] as const).map(variant =>
        [0, 25, 50, 75, 100].map(value => (
          <Progress
            key={`${variant}-${value}`}
            value={value}
            variant={variant}
          />
        )),
      )}
    </Flex>
  ),
};

// Progress with percentages showing current value.
export const WithPercentages: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Progress component with labels showing the current progress value using showInfo prop = true.',
      },
    },
  },
  render: () => (
    <Flex direction="column" gap={4} className="w-full">
      {(['default', 'secondary'] as const).map(variant =>
        [45, 78, 100].map(value => (
          <Progress
            key={`${variant}-${value}`}
            value={value}
            variant={variant}
            showInfo
          />
        )),
      )}
    </Flex>
  ),
};

// Variants with showInfo enabled and formatInfo prop set to a custom function.
export const WithCustomFormat: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Progress component variants with showInfo enabled and formatInfo prop set to a custom function will show custom text instead of the percentage.',
      },
    },
  },
  render: () => {
    const totalNumber = 10;
    const formatInfo = (value: number): string => {
      const currentNumber = Math.round((value / 100) * totalNumber);
      return `${currentNumber} out of ${totalNumber}`;
    };

    return (
      <Flex direction="column" gap={4} className="w-full">
        {(['default', 'secondary'] as const).map(variant =>
          [25, 50, 75, 100].map(value => (
            <Progress
              key={`${variant}-${value}`}
              value={value}
              variant={variant}
              showInfo
              formatInfo={formatInfo}
            />
          )),
        )}
      </Flex>
    );
  },
};

// Other examples of Progress component usage in different contexts, including various formats for the info text.
export const OtherExamples: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Other examples of Progress component usage in different contexts, including various formats for the info text.',
      },
    },
  },
  render: () => {
    // File Upload: 48% = 2.4 MB / 5.0 MB
    const fileUploadFormat = (value: number): string => {
      const totalMB = 5.0;
      const currentMB = (value / 100) * totalMB;
      return `${currentMB.toFixed(1)} MB / ${totalMB} MB`;
    };

    // Data Processing: 49% = 1,234 / 2,500
    const dataProcessingFormat = (value: number): string => {
      const total = 2500;
      const current = Math.round((value / 100) * total);
      return `${current.toLocaleString()} / ${total.toLocaleString()}`;
    };

    // Installation: Show "Complete" at 100%, otherwise percentage
    const installationFormat = (value: number): string => {
      return value === 100 ? 'Complete' : `${value}%`;
    };

    // Loading: Show "Loading..." for indeterminate
    const loadingFormat = (_value: number): string => {
      return 'Loading...';
    };

    return (
      <Flex direction="column" gap={6} className="w-full">
        {/* File Upload Example */}
        <Progress
          value={48}
          showInfo
          formatInfo={fileUploadFormat}
          className="w-full"
        />

        {/* Data Processing Example */}
        <Progress
          value={49}
          variant="secondary"
          showInfo
          formatInfo={dataProcessingFormat}
          className="w-full"
        />

        {/* Installation Example */}
        <Progress
          value={100}
          showInfo
          formatInfo={installationFormat}
          className="w-full"
        />

        {/* Loading State Example */}
        <Progress
          value={undefined}
          variant="secondary"
          showInfo
          formatInfo={loadingFormat}
          className="w-full"
        />

        {/* Multiple Progress Bars */}
        <Flex direction="column" gap={4} className="w-full">
          <Progress value={75} showInfo className="w-full" />
          <Progress
            value={32}
            variant="secondary"
            showInfo
            className="w-full"
          />
          <Progress value={100} showInfo className="w-full" />
        </Flex>
      </Flex>
    );
  },
};

// Animated progress bar that loads from 0 to 100.
function AnimatedProgress() {
  const [progress, setProgress] = useState(0);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsRunning(false);
          return 100;
        }
        return prev + 1;
      });
    }, 50);

    return () => clearInterval(interval);
  }, [isRunning]);

  const handleStart = () => {
    setProgress(0);
    setIsRunning(true);
  };

  return (
    <Flex direction="column" gap={6} className="w-full">
      <div className="space-y-2 w-full">
        <Flex justify="between" align="center">
          <Text level="base" weight="medium">
            Loading Progress
          </Text>
          <Button onClick={handleStart} disabled={isRunning}>
            Run Progress
          </Button>
        </Flex>
        <Progress value={progress} showInfo />
        <Text level="small" color="muted">
          Click "Run Progress" to start the animation.
        </Text>
      </div>
    </Flex>
  );
}

export const Animated: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Progress component that animates from 0% to 100% to demonstrate loading behavior.',
      },
    },
  },
  render: () => <AnimatedProgress />,
};
