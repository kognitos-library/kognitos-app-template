import { type VariantProps, cva } from 'class-variance-authority';

import { cn } from '@/design-system/lib/utils/index';
import { Loader2Icon, Loader } from 'lucide-react';

const spinnerVariants = cva('animate-spin', {
  variants: {
    size: {
      sm: 'size-3.5',
      default: 'size-4',
      lg: 'size-8',
      xl: 'size-12',
    },
    variant: {
      default: 'text-primary',
      secondary: 'text-secondary',
      muted: 'text-muted-foreground',
      destructive: 'text-destructive',
      accent: 'text-accent',
    },
  },
  defaultVariants: {
    size: 'default',
    variant: 'default',
  },
});

interface SpinnerType {
  iconType?: 'spoked' | 'circular';
}

export interface ISpinnerProps
  extends
    React.ComponentProps<'svg'>,
    VariantProps<typeof spinnerVariants>,
    SpinnerType {}

function Spinner({
  className,
  size,
  variant,
  iconType = 'circular',
  ...props
}: ISpinnerProps) {
  const Icon = iconType === 'spoked' ? Loader : Loader2Icon;
  return (
    <Icon
      role="status"
      aria-label="Loading"
      data-slot="spinner"
      className={cn(spinnerVariants({ size, variant }), className)}
      {...props}
    />
  );
}

export { Spinner };
