import type { Meta, StoryObj } from '@storybook/react';
import { useState, useEffect } from 'react';
import {
  Calculator,
  Calendar,
  CreditCard,
  Settings,
  Smile,
  User,
  Moon,
  Sun,
  Laptop,
  Mail,
  MessageSquare,
  PlusCircle,
  UserPlus,
  FileText,
  Search,
} from 'lucide-react';

import {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
  Button,
} from '@/design-system';

const meta: Meta<typeof Command> = {
  title: 'Design System/Primitives/Data Entry/Command',
  component: Command,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A fast, composable command menu component. Built on top of cmdk, it provides keyboard-navigable menus for searching, filtering, and selecting items.',
      },
    },
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof Command>;

// Basic Command Menu
export const Default: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Basic command menu with search input and grouped items.',
      },
    },
  },
  render: () => (
    <Command className="rounded-lg border shadow-md md:min-w-[450px]">
      <CommandInput placeholder="Type a command or search..." />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Suggestions">
          <CommandItem>
            <Calendar />
            <span>Calendar</span>
          </CommandItem>
          <CommandItem>
            <Smile />
            <span>Search Emoji</span>
          </CommandItem>
          <CommandItem>
            <Calculator />
            <span>Calculator</span>
          </CommandItem>
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Settings">
          <CommandItem>
            <User />
            <span>Profile</span>
            <CommandShortcut>⌘P</CommandShortcut>
          </CommandItem>
          <CommandItem>
            <CreditCard />
            <span>Billing</span>
            <CommandShortcut>⌘B</CommandShortcut>
          </CommandItem>
          <CommandItem>
            <Settings />
            <span>Settings</span>
            <CommandShortcut>⌘S</CommandShortcut>
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </Command>
  ),
};

// Command Dialog with keyboard shortcut
export const Dialog: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Command menu in a dialog. Press ⌘K (or Ctrl+K on Windows) to open.',
      },
    },
  },
  render: () => {
    const DialogDemo = () => {
      const [open, setOpen] = useState(false);

      useEffect(() => {
        const down = (e: KeyboardEvent) => {
          if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
            e.preventDefault();
            setOpen(open => !open);
          }
        };

        document.addEventListener('keydown', down);
        return () => document.removeEventListener('keydown', down);
      }, []);

      return (
        <div className="flex flex-col items-center gap-4">
          <p className="text-sm text-muted-foreground">
            Press ⌘K to open the command menu
          </p>
          <Button onClick={() => setOpen(true)} variant="outline">
            Open Command Menu
          </Button>
          <CommandDialog open={open} onOpenChange={setOpen}>
            <CommandInput placeholder="Type a command or search..." />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Suggestions">
                <CommandItem onSelect={() => setOpen(false)}>
                  <Calendar />
                  <span>Calendar</span>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <Smile />
                  <span>Search Emoji</span>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <Calculator />
                  <span>Calculator</span>
                </CommandItem>
              </CommandGroup>
              <CommandSeparator />
              <CommandGroup heading="Settings">
                <CommandItem onSelect={() => setOpen(false)}>
                  <User />
                  <span>Profile</span>
                  <CommandShortcut>⌘P</CommandShortcut>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <CreditCard />
                  <span>Billing</span>
                  <CommandShortcut>⌘B</CommandShortcut>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <Settings />
                  <span>Settings</span>
                  <CommandShortcut>⌘S</CommandShortcut>
                </CommandItem>
              </CommandGroup>
            </CommandList>
          </CommandDialog>
        </div>
      );
    };

    return <DialogDemo />;
  },
};

// Dialog without close button
export const DialogWithoutCloseButton: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Command dialog without the close button in the corner.',
      },
    },
  },
  render: () => {
    const DialogDemo = () => {
      const [open, setOpen] = useState(false);

      return (
        <div className="flex flex-col items-center gap-4">
          <Button onClick={() => setOpen(true)} variant="outline">
            Open Dialog (No Close Button)
          </Button>
          <CommandDialog
            open={open}
            onOpenChange={setOpen}
            showCloseButton={false}
          >
            <CommandInput placeholder="Type a command or search..." />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Actions">
                <CommandItem onSelect={() => setOpen(false)}>
                  <Search />
                  <span>Search</span>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <Settings />
                  <span>Settings</span>
                </CommandItem>
              </CommandGroup>
            </CommandList>
          </CommandDialog>
        </div>
      );
    };

    return <DialogDemo />;
  },
};

// Theme Switcher Command
export const ThemeSwitcher: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Command menu as a theme switcher.',
      },
    },
  },
  render: () => {
    const ThemeDemo = () => {
      const [theme, setTheme] = useState('system');

      return (
        <div className="flex flex-col items-center gap-4">
          <Command className="rounded-lg border shadow-md w-[200px]">
            <CommandInput placeholder="Set theme..." />
            <CommandList>
              <CommandEmpty>No theme found.</CommandEmpty>
              <CommandGroup>
                <CommandItem
                  onSelect={() => setTheme('light')}
                  className={theme === 'light' ? 'bg-accent' : ''}
                >
                  <Sun />
                  <span>Light</span>
                </CommandItem>
                <CommandItem
                  onSelect={() => setTheme('dark')}
                  className={theme === 'dark' ? 'bg-accent' : ''}
                >
                  <Moon />
                  <span>Dark</span>
                </CommandItem>
                <CommandItem
                  onSelect={() => setTheme('system')}
                  className={theme === 'system' ? 'bg-accent' : ''}
                >
                  <Laptop />
                  <span>System</span>
                </CommandItem>
              </CommandGroup>
            </CommandList>
          </Command>
          <p className="text-sm text-muted-foreground">
            Current theme: <span className="font-medium">{theme}</span>
          </p>
        </div>
      );
    };

    return <ThemeDemo />;
  },
};

// Multiple Groups
export const MultipleGroups: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Command menu with multiple groups and separators.',
      },
    },
  },
  render: () => (
    <Command className="rounded-lg border shadow-md md:min-w-[450px]">
      <CommandInput placeholder="Search all..." />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Mail">
          <CommandItem>
            <Mail />
            <span>Inbox</span>
            <CommandShortcut>⌘I</CommandShortcut>
          </CommandItem>
          <CommandItem>
            <MessageSquare />
            <span>Messages</span>
            <CommandShortcut>⌘M</CommandShortcut>
          </CommandItem>
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Team">
          <CommandItem>
            <User />
            <span>View Team</span>
          </CommandItem>
          <CommandItem>
            <UserPlus />
            <span>Invite Member</span>
          </CommandItem>
          <CommandItem>
            <PlusCircle />
            <span>Create Team</span>
          </CommandItem>
        </CommandGroup>
        <CommandSeparator />
        <CommandGroup heading="Documents">
          <CommandItem>
            <FileText />
            <span>New Document</span>
            <CommandShortcut>⌘N</CommandShortcut>
          </CommandItem>
          <CommandItem>
            <Search />
            <span>Search Documents</span>
            <CommandShortcut>⌘F</CommandShortcut>
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </Command>
  ),
};

// With Disabled Items
export const WithDisabledItems: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Command menu with some disabled items.',
      },
    },
  },
  render: () => (
    <Command className="rounded-lg border shadow-md md:min-w-[450px]">
      <CommandInput placeholder="Type a command..." />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Actions">
          <CommandItem>
            <Calendar />
            <span>Schedule Meeting</span>
          </CommandItem>
          <CommandItem disabled>
            <Mail />
            <span>Send Email (Disabled)</span>
          </CommandItem>
          <CommandItem>
            <MessageSquare />
            <span>Send Message</span>
          </CommandItem>
          <CommandItem disabled>
            <CreditCard />
            <span>Make Payment (Disabled)</span>
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </Command>
  ),
};

// Spotlight-style Command
export const SpotlightStyle: Story = {
  parameters: {
    docs: {
      description: {
        story: 'A spotlight-style command menu similar to macOS Spotlight.',
      },
    },
  },
  render: () => {
    const SpotlightDemo = () => {
      const [open, setOpen] = useState(false);

      return (
        <div className="flex flex-col items-center gap-4">
          <Button onClick={() => setOpen(true)} variant="outline">
            <Search />
            Search...
          </Button>
          <CommandDialog
            open={open}
            onOpenChange={setOpen}
            showCloseButton={false}
          >
            <CommandInput placeholder="What are you looking for?" />
            <CommandList>
              <CommandEmpty>No results found.</CommandEmpty>
              <CommandGroup heading="Quick Actions">
                <CommandItem onSelect={() => setOpen(false)}>
                  <PlusCircle />
                  <span>New File</span>
                  <CommandShortcut>⌘N</CommandShortcut>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <Search />
                  <span>Find in Files</span>
                  <CommandShortcut>⌘⇧F</CommandShortcut>
                </CommandItem>
              </CommandGroup>
              <CommandSeparator />
              <CommandGroup heading="Recent Files">
                <CommandItem onSelect={() => setOpen(false)}>
                  <FileText />
                  <span>README.md</span>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <FileText />
                  <span>package.json</span>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <FileText />
                  <span>tsconfig.json</span>
                </CommandItem>
              </CommandGroup>
              <CommandSeparator />
              <CommandGroup heading="Settings">
                <CommandItem onSelect={() => setOpen(false)}>
                  <Settings />
                  <span>Preferences</span>
                  <CommandShortcut>⌘,</CommandShortcut>
                </CommandItem>
                <CommandItem onSelect={() => setOpen(false)}>
                  <User />
                  <span>Account</span>
                </CommandItem>
              </CommandGroup>
            </CommandList>
          </CommandDialog>
        </div>
      );
    };

    return <SpotlightDemo />;
  },
};
