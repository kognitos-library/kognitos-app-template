import { render, screen, fireEvent } from '@testing-library/react';
import {
  StepperCardItem,
  StepperCardIcon,
  StepperCardContent,
  StepperCardTitle,
  StepperCardDescription,
} from './stepper-card-items';
import { describe, expect, it, vi } from 'vitest';

describe('StepperCardItem', () => {
  describe('rendering', () => {
    it('should render with title, description, and step number', () => {
      render(
        <StepperCardItem>
          <StepperCardIcon stepNumber={1} />
          <StepperCardContent>
            <StepperCardTitle>Account Details</StepperCardTitle>
            <StepperCardDescription>
              Enter your information
            </StepperCardDescription>
          </StepperCardContent>
        </StepperCardItem>,
      );

      expect(screen.getByText('Account Details')).toBeInTheDocument();
      expect(screen.getByText('Enter your information')).toBeInTheDocument();
      expect(screen.getByText('1')).toBeInTheDocument();
    });

    it('should render without description when not provided', () => {
      render(
        <StepperCardItem>
          <StepperCardIcon stepNumber={1} />
          <StepperCardContent>
            <StepperCardTitle>Step Title</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      expect(
        screen.queryByTestId('stepper-card-description'),
      ).not.toBeInTheDocument();
    });

    it('should render with custom step number', () => {
      render(
        <StepperCardItem>
          <StepperCardIcon stepNumber={5} />
          <StepperCardContent>
            <StepperCardTitle>Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      expect(screen.getByText('5')).toBeInTheDocument();
    });

    it('should accept string step numbers', () => {
      render(
        <StepperCardItem>
          <StepperCardIcon stepNumber="2A" />
          <StepperCardContent>
            <StepperCardTitle>Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      expect(screen.getByText('2A')).toBeInTheDocument();
    });
  });

  describe('states', () => {
    it('should render loading state with loader icon', () => {
      render(
        <StepperCardItem>
          <StepperCardIcon stepNumber={1} state={'loading'} />
          <StepperCardContent>
            <StepperCardTitle>Loading Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Loading Step')
        .closest('[data-slot="stepper-card-item"]');
      // Loading icon should be visible
      expect(
        stepperCard?.querySelector('.lucide-loader-circle'),
      ).toBeInTheDocument();
      expect(screen.queryByText('1')).not.toBeInTheDocument();
    });

    it('should handle completed state with checkmark', () => {
      render(
        <StepperCardItem>
          <StepperCardIcon state={'completed'} />
          <StepperCardContent>
            <StepperCardTitle>Completed Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Completed Step')
        .closest('[data-slot="stepper-card-item"]');
      // Checkmark icon should be visible
      expect(stepperCard?.querySelector('.lucide-check')).toBeInTheDocument();
    });
  });

  describe('variants', () => {
    it('should render selected variant with highlighted styling', () => {
      render(
        <StepperCardItem variant={'selected'}>
          <StepperCardIcon stepNumber={1} variant={'selected'} />
          <StepperCardContent>
            <StepperCardTitle>Selected Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Selected Step')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard).toHaveAttribute('data-variant', 'selected');
      // Selected variant should have aria-current
      expect(stepperCard).toHaveAttribute('aria-current', 'true');
      expect(screen.getByText('1')).toBeInTheDocument();
    });

    it('should render default variant without highlighted styling', () => {
      render(
        <StepperCardItem variant={'default'}>
          <StepperCardIcon stepNumber={2} />
          <StepperCardContent>
            <StepperCardTitle>Default Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Default Step')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard).toHaveAttribute('data-variant', 'default');
      // Default variant should not have aria-current
      expect(stepperCard).not.toHaveAttribute('aria-current');
      expect(screen.getByText('2')).toBeInTheDocument();
    });
  });

  describe('combined state and variant', () => {
    it('should render completed state with selected variant', () => {
      render(
        <StepperCardItem variant={'selected'}>
          <StepperCardIcon state={'completed'} variant={'selected'} />
          <StepperCardContent>
            <StepperCardTitle>Completed Selected</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Completed Selected')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard).toHaveAttribute('data-variant', 'selected');
      expect(stepperCard).toHaveAttribute('aria-current', 'true');
      // Checkmark should be visible for completed state
      expect(stepperCard?.querySelector('.lucide-check')).toBeInTheDocument();
    });
  });

  describe('click handling', () => {
    it('should call onClick when clicked', () => {
      const onClick = vi.fn();
      render(
        <StepperCardItem onClick={onClick}>
          <StepperCardIcon stepNumber={1} />
          <StepperCardContent>
            <StepperCardTitle>Clickable Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Clickable Step')
        .closest('[data-slot="stepper-card-item"]');
      fireEvent.click(stepperCard!);

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('should not call onClick when disabled', () => {
      const onClick = vi.fn();
      render(
        <StepperCardItem state={'disabled'} onClick={onClick}>
          <StepperCardIcon stepNumber={1} state={'disabled'} />
          <StepperCardContent>
            <StepperCardTitle>Disabled Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Disabled Step')
        .closest('[data-slot="stepper-card-item"]');
      fireEvent.click(stepperCard!);

      expect(onClick).not.toHaveBeenCalled();
    });

    it('should have button role when onClick is provided', () => {
      const onClick = vi.fn();
      render(
        <StepperCardItem onClick={onClick}>
          <StepperCardIcon stepNumber={1} />
          <StepperCardContent>
            <StepperCardTitle>Clickable Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Clickable Step')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard).toHaveAttribute('role', 'button');
      expect(stepperCard).toHaveAttribute('tabIndex', '0');
    });

    it('should not have button role when onClick is not provided', () => {
      render(
        <StepperCardItem>
          <StepperCardIcon stepNumber={1} />
          <StepperCardContent>
            <StepperCardTitle>Non-clickable Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Non-clickable Step')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard).not.toHaveAttribute('role');
      expect(stepperCard).not.toHaveAttribute('tabIndex');
    });

    it('should have aria-disabled when disabled with onClick', () => {
      const onClick = vi.fn();
      render(
        <StepperCardItem state={'disabled'} onClick={onClick}>
          <StepperCardIcon stepNumber={1} state={'disabled'} />
          <StepperCardContent>
            <StepperCardTitle>Disabled Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Disabled Step')
        .closest('[data-slot="stepper-card-item"]');
      expect(stepperCard).toHaveAttribute('aria-disabled', 'true');
    });

    it('should call onClick when pressing Enter key', () => {
      const onClick = vi.fn();
      render(
        <StepperCardItem onClick={onClick}>
          <StepperCardIcon stepNumber={1} />
          <StepperCardContent>
            <StepperCardTitle>Clickable Step</StepperCardTitle>
          </StepperCardContent>
        </StepperCardItem>,
      );

      const stepperCard = screen
        .getByText('Clickable Step')
        .closest('[data-slot="stepper-card-item"]');
      fireEvent.keyDown(stepperCard!, { key: 'Enter' });

      expect(onClick).toHaveBeenCalledTimes(1);
    });
  });
});
