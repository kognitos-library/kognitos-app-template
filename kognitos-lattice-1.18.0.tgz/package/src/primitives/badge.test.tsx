import { render, screen } from '@testing-library/react';

import { Badge } from './badge';
import { describe, it, expect } from 'vitest';

describe('Badge', () => {
  describe('basic rendering', () => {
    it('should render badge with text content', () => {
      render(<Badge>Test Badge</Badge>);

      expect(screen.getByText('Test Badge')).toBeInTheDocument();
    });

    it('should render as a span element by default', () => {
      render(<Badge>Test Badge</Badge>);

      const badge = screen.getByText('Test Badge');
      expect(badge.tagName).toBe('SPAN');
    });
  });

  describe('border radius', () => {
    it('should have rounded-sm border radius class', () => {
      render(<Badge>Test Badge</Badge>);

      const badge = screen.getByText('Test Badge');
      expect(badge).toHaveClass('rounded-sm');
    });
  });

  describe('variants', () => {
    it('should apply default variant styles', () => {
      render(<Badge variant="default">Default Badge</Badge>);

      const badge = screen.getByText('Default Badge');
      expect(badge).toHaveClass('bg-primary', 'text-primary-foreground');
    });

    it('should apply secondary variant styles', () => {
      render(<Badge variant="secondary">Secondary Badge</Badge>);

      const badge = screen.getByText('Secondary Badge');
      expect(badge).toHaveClass('bg-secondary', 'text-secondary-foreground');
    });

    it('should apply destructive variant styles', () => {
      render(<Badge variant="destructive">Destructive Badge</Badge>);

      const badge = screen.getByText('Destructive Badge');
      expect(badge).toHaveClass('bg-destructive/5', 'text-destructive');
    });

    it('should apply verified variant styles', () => {
      render(<Badge variant="verified">Verified Badge</Badge>);

      const badge = screen.getByText('Verified Badge');
      expect(badge).toHaveClass('bg-blue-500', 'text-white');
    });

    it('should apply success variant styles', () => {
      render(<Badge variant="success">Success Badge</Badge>);

      const badge = screen.getByText('Success Badge');
      expect(badge).toHaveClass('bg-success/5', 'text-success');
    });

    it('should apply warning variant styles', () => {
      render(<Badge variant="warning">Warning Badge</Badge>);

      const badge = screen.getByText('Warning Badge');
      expect(badge).toHaveClass('bg-warning/5', 'text-warning');
    });

    it('should apply outline variant styles', () => {
      render(<Badge variant="outline">Outline Badge</Badge>);

      const badge = screen.getByText('Outline Badge');
      expect(badge).toHaveClass('text-foreground');
    });

    it('should use default variant when no variant is specified', () => {
      render(<Badge>Default Badge</Badge>);

      const badge = screen.getByText('Default Badge');
      expect(badge).toHaveClass('bg-primary', 'text-primary-foreground');
    });
  });

  describe('asChild prop', () => {
    it('should render as child element when asChild is true', () => {
      render(
        <Badge asChild>
          <a href="/test">Link Badge</a>
        </Badge>,
      );

      const badge = screen.getByText('Link Badge');
      expect(badge.tagName).toBe('A');
      expect(badge).toHaveAttribute('href', '/test');
    });
  });
});
