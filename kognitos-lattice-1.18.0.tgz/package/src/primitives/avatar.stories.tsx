import type { Meta, StoryObj } from '@storybook/react-vite';
import { Avatar, AvatarImage, AvatarFallback } from './avatar';
import { Flex } from './flex';

const meta: Meta<typeof Avatar> = {
  title: 'Design System/Primitives/Data Display/Avatar',
  component: Avatar,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'An avatar component that displays user profile images with fallback support. Uses Radix UI primitives for accessibility.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
  args: {
    className: '',
  },
};

export default meta;
type Story = StoryObj<typeof Avatar>;

// Basic Avatar with Image
export const WithImage: Story = {
  render: args => (
    <Avatar {...args}>
      <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
      <AvatarFallback>CN</AvatarFallback>
    </Avatar>
  ),
};

// Avatar with Fallback
export const WithFallback: Story = {
  render: args => (
    <Avatar {...args}>
      <AvatarImage src="/broken-image.jpg" alt="@user" />
      <AvatarFallback>JD</AvatarFallback>
    </Avatar>
  ),
};

// Avatar with Custom Fallback
export const CustomFallback: Story = {
  render: args => (
    <Avatar {...args}>
      <AvatarFallback className="bg-primary text-primary-foreground">
        <span className="text-sm font-medium">JD</span>
      </AvatarFallback>
    </Avatar>
  ),
};

// Multiple Avatars
export const MultipleAvatars: Story = {
  render: args => (
    <Flex align="center" gap={4}>
      <Avatar {...args}>
        <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        <AvatarFallback>CN</AvatarFallback>
      </Avatar>
      <Avatar {...args}>
        <AvatarImage src="https://github.com/vercel.png" alt="@vercel" />
        <AvatarFallback>VR</AvatarFallback>
      </Avatar>
      <Avatar {...args}>
        <AvatarImage src="https://github.com/nextui.png" alt="@nextui" />
        <AvatarFallback>NU</AvatarFallback>
      </Avatar>
      <Avatar {...args}>
        <AvatarFallback>JD</AvatarFallback>
      </Avatar>
    </Flex>
  ),
};

// Different Sizes
export const DifferentSizes: Story = {
  render: args => (
    <Flex align="center" gap={4}>
      <Avatar {...args} className="h-6 w-6">
        <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        <AvatarFallback className="text-xs">CN</AvatarFallback>
      </Avatar>
      <Avatar {...args} className="h-8 w-8">
        <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        <AvatarFallback className="text-xs">CN</AvatarFallback>
      </Avatar>
      <Avatar {...args} className="h-10 w-10">
        <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        <AvatarFallback>CN</AvatarFallback>
      </Avatar>
      <Avatar {...args} className="h-12 w-12">
        <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        <AvatarFallback className="text-sm">CN</AvatarFallback>
      </Avatar>
      <Avatar {...args} className="h-16 w-16">
        <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        <AvatarFallback className="text-lg">CN</AvatarFallback>
      </Avatar>
    </Flex>
  ),
};

// Avatar Group
export const AvatarGroup: Story = {
  render: args => (
    <Flex className="-space-x-2">
      <Avatar {...args} className="border-2 border-background">
        <AvatarImage src="https://github.com/shadcn.png" alt="@shadcn" />
        <AvatarFallback>CN</AvatarFallback>
      </Avatar>
      <Avatar {...args} className="border-2 border-background">
        <AvatarImage src="https://github.com/vercel.png" alt="@vercel" />
        <AvatarFallback>VR</AvatarFallback>
      </Avatar>
      <Avatar {...args} className="border-2 border-background">
        <AvatarImage src="https://github.com/nextui.png" alt="@nextui" />
        <AvatarFallback>NU</AvatarFallback>
      </Avatar>
      <Avatar {...args} className="border-2 border-background">
        <AvatarFallback>+2</AvatarFallback>
      </Avatar>
    </Flex>
  ),
};
