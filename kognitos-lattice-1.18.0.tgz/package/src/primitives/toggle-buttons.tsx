import * as React from 'react';

import { cn } from '@/design-system/lib/utils';
import {
  ToggleGroup,
  ToggleGroupItem,
} from '@/design-system/primitives/toggle-group';

// Omit props to enforce single selection
type IToggleButtonsProps = Omit<
  React.ComponentProps<typeof ToggleGroup>,
  'type' | 'value' | 'defaultValue' | 'onValueChange'
> & {
  value?: string;
  defaultValue?: string;
  onValueChange?: (value: string) => void;
};

function ToggleButtons({
  className,
  children,
  value,
  defaultValue,
  onValueChange,
  ...props
}: IToggleButtonsProps) {
  return (
    <ToggleGroup
      data-slot="toggle-buttons"
      type="single"
      value={value}
      defaultValue={defaultValue}
      onValueChange={onValueChange}
      className={cn('gap-0.5 rounded-lg bg-background p-0.5', className)}
      {...props}
    >
      {children}
    </ToggleGroup>
  );
}

type IToggleButtonItemProps = React.ComponentProps<typeof ToggleGroupItem>;

function ToggleButtonItem({
  className,
  children,
  ...props
}: IToggleButtonItemProps) {
  return (
    <ToggleGroupItem
      data-slot="toggle-button-item"
      className={cn('rounded-md border-0', className)}
      {...props}
    >
      {children}
    </ToggleGroupItem>
  );
}

export {
  ToggleButtons,
  ToggleButtonItem,
  type IToggleButtonsProps,
  type IToggleButtonItemProps,
};
