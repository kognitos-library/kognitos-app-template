import type { Meta, StoryObj } from '@storybook/react-vite';
import { Tooltip, TooltipTrigger, TooltipContent } from './tooltip';
import { Button } from './button';
import { Icon } from '../icons';

const meta: Meta<typeof Tooltip> = {
  title: 'Design System/Primitives/Overlay/Tooltip',
  component: Tooltip,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A tooltip component that displays informative text when users hover over or focus on an element. Supports multiple variants for different use cases.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['default', 'primary'],
      description: 'The visual style variant of the tooltip',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    open: {
      control: { type: 'boolean' },
      description: 'Controlled open state of the tooltip',
      table: {
        type: { summary: 'boolean' },
        category: 'State',
      },
    },
    defaultOpen: {
      control: { type: 'boolean' },
      description: 'Default open state for uncontrolled tooltip',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'State',
      },
    },
    onOpenChange: {
      description: 'Callback when the open state changes',
      table: {
        type: { summary: '(open: boolean) => void' },
        category: 'Events',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Tooltip>;

// Primary story - This will be the main showcase in autodocs
export const Primary: Story = {
  render: args => (
    <div className="flex justify-center p-8">
      <Tooltip {...args}>
        <TooltipTrigger asChild>
          <Button variant="outline">Hover me</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>This is a helpful tooltip</p>
        </TooltipContent>
      </Tooltip>
    </div>
  ),
  args: {
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story:
          'The primary tooltip component. Use the controls below to experiment with different variants.',
      },
    },
  },
};

// Variants Story
export const Variants: Story = {
  render: () => (
    <div className="flex gap-4 p-8">
      <Tooltip variant="default">
        <TooltipTrigger asChild>
          <Button variant="outline">Default Variant</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Default tooltip with accent colors</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip variant="primary">
        <TooltipTrigger asChild>
          <Button variant="outline">Primary Variant</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Primary tooltip with brand colors</p>
        </TooltipContent>
      </Tooltip>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Tooltips come in two variants: default (accent colors) and primary (brand colors).',
      },
    },
  },
};

// With Different Triggers
export const DifferentTriggers: Story = {
  render: () => (
    <div className="flex flex-wrap gap-4 p-8">
      <Tooltip>
        <TooltipTrigger asChild>
          <Button>Button with Tooltip</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Tooltip on a button</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip variant="primary">
        <TooltipTrigger asChild>
          <Button variant="outline">
            <Icon type={'Info'} />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Important information</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="ghost">
            <Icon type={'HelpCircle'} />
            Help
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Get help with this feature</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip variant="primary">
        <TooltipTrigger asChild>
          <Button size="icon" variant="secondary">
            <Icon type={'Settings'} />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Settings</p>
        </TooltipContent>
      </Tooltip>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Tooltips can be attached to any interactive element like buttons, icons, or text.',
      },
    },
  },
};

// Positioning
export const Positioning: Story = {
  render: () => (
    <div className="flex flex-col items-center justify-center gap-16 p-16">
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="outline">Top (default)</Button>
        </TooltipTrigger>
        <TooltipContent side="top">
          <p>Positioned on top</p>
        </TooltipContent>
      </Tooltip>

      <div className="flex gap-16">
        <Tooltip variant="primary">
          <TooltipTrigger asChild>
            <Button variant="outline">Left</Button>
          </TooltipTrigger>
          <TooltipContent side="left">
            <p>Positioned on left</p>
          </TooltipContent>
        </Tooltip>

        <Tooltip>
          <TooltipTrigger asChild>
            <Button variant="outline">Right</Button>
          </TooltipTrigger>
          <TooltipContent side="right">
            <p>Positioned on right</p>
          </TooltipContent>
        </Tooltip>
      </div>

      <Tooltip variant="primary">
        <TooltipTrigger asChild>
          <Button variant="outline">Bottom</Button>
        </TooltipTrigger>
        <TooltipContent side="bottom">
          <p>Positioned on bottom</p>
        </TooltipContent>
      </Tooltip>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Tooltips can be positioned on any side of the trigger element: top (default), right, bottom, or left.',
      },
    },
  },
};

// Different Content
export const DifferentContent: Story = {
  render: () => (
    <div className="flex flex-wrap gap-4 p-8">
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="outline">Simple Text</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Simple tooltip text</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip variant="primary">
        <TooltipTrigger asChild>
          <Button variant="outline">Multi-line</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>
            This is a longer tooltip
            <br />
            with multiple lines
          </p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="outline">Keyboard Shortcut</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>
            Save <kbd className="text-xs">⌘S</kbd>
          </p>
        </TooltipContent>
      </Tooltip>

      <Tooltip variant="primary">
        <TooltipTrigger asChild>
          <Button variant="outline">With Icon</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>
            <Icon type={'Info'} className="inline-block mr-1" />
            Tooltip with icon
          </p>
        </TooltipContent>
      </Tooltip>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Tooltips support different content types including simple text, multi-line text, keyboard shortcuts, and rich content.',
      },
    },
  },
};

// Accessibility
export const Accessibility: Story = {
  render: () => (
    <div className="flex flex-wrap gap-4 p-8">
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="outline">Tab to focus me</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Tooltip shown on hover and focus</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip variant="primary">
        <TooltipTrigger asChild>
          <Button variant="outline">Then tab here</Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Keyboard navigation works seamlessly</p>
        </TooltipContent>
      </Tooltip>

      <Tooltip>
        <TooltipTrigger asChild>
          <Button size="icon" variant="outline">
            <Icon type={'HelpCircle'} />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Screen reader support included</p>
        </TooltipContent>
      </Tooltip>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Tooltips are fully accessible with keyboard navigation (Tab key), focus management, and screen reader support.',
      },
    },
  },
};
