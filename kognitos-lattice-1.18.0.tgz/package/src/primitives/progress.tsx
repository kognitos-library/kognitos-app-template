import * as React from 'react';
import * as ProgressPrimitive from '@radix-ui/react-progress';
import { cva } from 'class-variance-authority';

import { cn } from '@/design-system/lib/utils';
import { Flex } from './flex';
import { Text } from './typography';

// Shared variant type - both track and indicator use the same variant values
type TProgressVariant = 'default' | 'secondary';

// Progress track (background) variants
const progressVariants = cva(
  'relative h-1.5 w-full overflow-hidden rounded-full p-[1px]',
  {
    variants: {
      variant: {
        default: 'bg-primary/20',
        secondary: 'bg-ring/20',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

// Progress indicator (foreground) variants
const progressIndicatorVariants = cva(
  'h-full flex-1 transition-all rounded-full',
  {
    variants: {
      variant: {
        default: 'bg-primary',
        secondary: 'bg-ring',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

interface IProgressProps extends React.ComponentProps<
  typeof ProgressPrimitive.Root
> {
  variant?: TProgressVariant;
  showInfo?: boolean;
  formatInfo?: (value: number) => string;
  'aria-label'?: string;
}

function Progress({
  className,
  value,
  variant = 'default',
  showInfo = false,
  formatInfo,
  'aria-label': ariaLabel,
  ...props
}: IProgressProps) {
  const progressBar = (
    <ProgressPrimitive.Root
      data-slot="progress"
      className={cn(progressVariants({ variant }), className)}
      aria-label={ariaLabel || (showInfo ? undefined : `${value}% complete`)}
      {...props}
    >
      <ProgressPrimitive.Indicator
        data-slot="progress-indicator"
        className={progressIndicatorVariants({ variant })}
        style={{ width: `max(0.225rem, calc(${value}%))` }}
      />
    </ProgressPrimitive.Root>
  );

  if (showInfo) {
    return (
      <Flex gap={2} align="center" className="w-full">
        <div className="flex-1 min-w-0">{progressBar}</div>
        <Text
          level="small"
          color="muted"
          className="shrink-0 whitespace-nowrap"
        >
          {formatInfo ? formatInfo(value ?? 0) : `${value ?? 0}%`}
        </Text>
      </Flex>
    );
  }

  return progressBar;
}

export { Progress };
export type { IProgressProps };
