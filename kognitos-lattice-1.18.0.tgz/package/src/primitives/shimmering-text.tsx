import * as React from 'react';
import { motion, type HTMLMotionProps } from 'motion/react';

const WAVE_ANIMATION = {
  x: [0, 5, 0],
  y: [0, -5, 0],
  scale: [1, 1.1, 1],
  rotateY: [0, 15, 0],
};

type TShimmeringTextProps = Omit<HTMLMotionProps<'span'>, 'children'> & {
  text: string;
  duration?: number;
  wave?: boolean;
  color?: string;
  shimmeringColor?: string;
  'data-testid'?: string;
};

function ShimmeringText({
  text,
  duration = 1,
  transition,
  wave = false,
  color = 'var(--muted-foreground)',
  shimmeringColor = 'var(--foreground)',
  'data-testid': testId = 'shimmering-text',
  ...props
}: TShimmeringTextProps) {
  return (
    <motion.span
      data-testid={testId}
      style={
        {
          '--shimmering-color': shimmeringColor,
          '--color': color,
          color: 'var(--color)',
          position: 'relative',
          display: 'inline-block',
          perspective: '500px',
        } as React.CSSProperties
      }
      {...props}
    >
      {text.split('').map((char, i) => (
        <motion.span
          // eslint-disable-next-line react-x/no-array-index-key -- static text content, index is stable
          key={`${text}-char-${i}`}
          data-testid={`${testId}-char-${i}`}
          style={{
            display: 'inline-block',
            whiteSpace: 'pre',
            transformStyle: 'preserve-3d',
          }}
          initial={{
            ...(wave
              ? {
                  scale: 1,
                  rotateY: 0,
                }
              : {}),
            color: 'var(--color)',
          }}
          animate={{
            ...(wave ? WAVE_ANIMATION : {}),
            color: ['var(--color)', 'var(--shimmering-color)', 'var(--color)'],
          }}
          transition={{
            duration,
            repeat: Infinity,
            repeatType: 'loop',
            repeatDelay: text.length * 0.05,
            delay: (i * duration) / text.length,
            ease: 'easeInOut',
            ...transition,
          }}
        >
          {char}
        </motion.span>
      ))}
    </motion.span>
  );
}

export { ShimmeringText, type TShimmeringTextProps };
