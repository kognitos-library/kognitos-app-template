import * as React from 'react';
import * as ToolbarPrimitive from '@radix-ui/react-toolbar';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/design-system/lib/utils';
import { Flex } from './flex';
import { type IconType } from '../icons';

/**
 * Toolbar Component
 *
 * A toolbar with backdrop blur effect, designed for contextual actions.
 * Typically used as a floating action bar at the bottom center of a canvas or workspace.
 *
 * Based on Radix UI Toolbar primitive.
 */

const toolbarVariants = cva(
  'backdrop-blur-md border border-border rounded-xl p-1 flex gap-1 items-start shadow-md bg-background/48 dark:bg-card dark:border-border',
  {
    variants: {
      size: {
        default: 'p-1',
        sm: 'p-0.5',
        lg: 'p-1.5',
      },
    },
    defaultVariants: {
      size: 'default',
    },
  },
);

const toolbarGroupVariants = cva(
  'backdrop-blur-md rounded-xl p-0.5 flex items-center gap-1 bg-muted',
  {
    variants: {
      size: {
        default: 'h-9',
        lg: 'h-10',
      },
    },
    defaultVariants: {
      size: 'default',
    },
  },
);

const toolbarButtonVariants = cva(
  'cursor-pointer inline-flex items-center justify-center gap-1 rounded-xl text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 whitespace-nowrap',
  {
    variants: {
      variant: {
        default:
          'bg-background/95 shadow-xs text-foreground hover:text-foreground dark:bg-card dark:text-foreground px-2.5 py-1.5',
        ghost: 'text-muted-foreground hover:text-foreground px-2.5 py-1.5',
        icon: 'bg-transparent text-muted-foreground hover:text-foreground p-0 w-9 h-9',
        text: 'text-muted-foreground hover:text-foreground px-2.5 py-1.5',
      },
      size: {
        default: 'h-full',
        sm: 'h-7',
        lg: 'h-10',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'default',
    },
  },
);

export interface IToolbarProps
  extends
    React.ComponentPropsWithoutRef<typeof ToolbarPrimitive.Root>,
    VariantProps<typeof toolbarVariants> {
  /** Optional icon to display on the right side of the toolbar */
  rightIcon?: IconType;
}

export interface IToolbarGroupProps
  extends
    React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof toolbarGroupVariants> {}

export interface IToolbarButtonProps
  extends
    React.ComponentPropsWithoutRef<typeof ToolbarPrimitive.Button>,
    VariantProps<typeof toolbarButtonVariants> {}

export interface IToolbarBadgeProps extends React.HTMLAttributes<HTMLDivElement> {
  count?: number;
}

function Toolbar({ className, size, children, ...props }: IToolbarProps) {
  return (
    <ToolbarPrimitive.Root
      className={cn(toolbarVariants({ size }), className)}
      {...props}
    >
      <Flex direction="row" align="center" justify="center" gap={1}>
        {children}
      </Flex>
    </ToolbarPrimitive.Root>
  );
}

function ToolbarGroup({ className, size, ...props }: IToolbarGroupProps) {
  return (
    <div className={cn(toolbarGroupVariants({ size }), className)} {...props} />
  );
}

function ToolbarButton({
  className,
  variant,
  size,
  children,
  ...props
}: IToolbarButtonProps) {
  return (
    <ToolbarPrimitive.Button
      className={cn(toolbarButtonVariants({ variant, size }), className)}
      type="button"
      {...props}
    >
      {children}
    </ToolbarPrimitive.Button>
  );
}

function ToolbarBadge({
  className,
  count,
  children,
  ...props
}: IToolbarBadgeProps) {
  const displayCount = count !== undefined ? count : children;

  return (
    <div
      className={cn(
        'bg-background/50 dark:bg-primary border border-transparent rounded-full min-w-5 h-4 flex items-center justify-center px-1',
        className,
      )}
      {...props}
    >
      <span className="text-xs font-normal text-secondary-foreground dark:text-primary-foreground leading-none">
        {displayCount}
      </span>
    </div>
  );
}

function ToolbarSeparator({
  className,
  ...props
}: React.ComponentPropsWithoutRef<typeof ToolbarPrimitive.Separator>) {
  return (
    <ToolbarPrimitive.Separator
      className={cn('w-px h-6 bg-border mx-1', className)}
      {...props}
    />
  );
}

export { Toolbar, ToolbarGroup, ToolbarButton, ToolbarBadge, ToolbarSeparator };
