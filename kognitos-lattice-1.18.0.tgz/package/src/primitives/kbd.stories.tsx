import type { Meta, StoryObj } from '@storybook/react-vite';
import { Kbd, KbdGroup } from './kbd';
import { Button } from './button';
import { ButtonGroup } from './button-group';
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
  TooltipProvider,
} from './tooltip';

const meta: Meta<typeof Kbd> = {
  title: 'Design System/Primitives/General/Kbd',
  component: Kbd,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Use the Kbd component to display textual user input from keyboard. The component can be used standalone or grouped with KbdGroup to show keyboard combinations.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Kbd>;

// Primary story - Main demo from shadcn
export const Demo: Story = {
  render: () => (
    <div className="flex flex-col items-center gap-4">
      <KbdGroup>
        <Kbd>⌘</Kbd>
        <Kbd>⇧</Kbd>
        <Kbd>⌥</Kbd>
        <Kbd>⌃</Kbd>
      </KbdGroup>
      <KbdGroup>
        <Kbd>Ctrl</Kbd>
        <span>+</span>
        <Kbd>B</Kbd>
      </KbdGroup>
    </div>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'The main demo showing keyboard keys and combinations. Use Kbd for individual keys and KbdGroup to combine them.',
      },
    },
  },
};

// Basic usage
export const Basic: Story = {
  render: () => <Kbd>Ctrl</Kbd>,
  parameters: {
    docs: {
      description: {
        story: 'A single keyboard key displayed with the Kbd component.',
      },
    },
  },
};

// Group example
export const Group: Story = {
  render: () => (
    <div className="flex flex-col items-center gap-4">
      <p className="text-muted-foreground text-sm">
        Use{' '}
        <KbdGroup>
          <Kbd>Ctrl + B</Kbd>
          <Kbd>Ctrl + K</Kbd>
        </KbdGroup>{' '}
        to open the command palette
      </p>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Use the KbdGroup component to group keyboard keys together in text.',
      },
    },
  },
};

// Button with Kbd
export const WithButton: Story = {
  render: () => (
    <div className="flex flex-wrap items-center gap-4">
      <Button variant="outline" size="sm" className="pr-2">
        Accept <Kbd>⏎</Kbd>
      </Button>
      <Button variant="outline" size="sm" className="pr-2">
        Cancel <Kbd>Esc</Kbd>
      </Button>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Use the Kbd component inside a Button component to display a keyboard key inside a button.',
      },
    },
  },
};

// Tooltip with Kbd
export const WithTooltip: Story = {
  render: () => (
    <TooltipProvider>
      <div className="flex flex-wrap gap-4">
        <ButtonGroup>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button size="sm" variant="outline">
                Save
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <div className="flex items-center gap-2">
                Save Changes <Kbd>S</Kbd>
              </div>
            </TooltipContent>
          </Tooltip>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button size="sm" variant="outline">
                Print
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <div className="flex items-center gap-2">
                Print Document{' '}
                <KbdGroup>
                  <Kbd>Ctrl</Kbd>
                  <Kbd>P</Kbd>
                </KbdGroup>
              </div>
            </TooltipContent>
          </Tooltip>
        </ButtonGroup>
      </div>
    </TooltipProvider>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Use the Kbd component inside a Tooltip component to display keyboard shortcuts in tooltips.',
      },
    },
  },
};

// Various key symbols
export const KeySymbols: Story = {
  render: () => (
    <div className="flex flex-wrap items-center gap-4">
      <Kbd>⌘</Kbd>
      <Kbd>⌥</Kbd>
      <Kbd>⇧</Kbd>
      <Kbd>⌃</Kbd>
      <Kbd>⏎</Kbd>
      <Kbd>⌫</Kbd>
      <Kbd>⌦</Kbd>
      <Kbd>⇥</Kbd>
      <Kbd>⎋</Kbd>
      <Kbd>↑</Kbd>
      <Kbd>↓</Kbd>
      <Kbd>←</Kbd>
      <Kbd>→</Kbd>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Various keyboard symbols that can be used with the Kbd component. Includes Command (⌘), Option (⌥), Shift (⇧), Control (⌃), Return (⏎), Delete (⌫), Forward Delete (⌦), Tab (⇥), Escape (⎋), and arrow keys.',
      },
    },
  },
};

// Text keys
export const TextKeys: Story = {
  render: () => (
    <div className="flex flex-wrap items-center gap-4">
      <Kbd>Ctrl</Kbd>
      <Kbd>Alt</Kbd>
      <Kbd>Shift</Kbd>
      <Kbd>Enter</Kbd>
      <Kbd>Esc</Kbd>
      <Kbd>Tab</Kbd>
      <Kbd>Space</Kbd>
      <Kbd>Delete</Kbd>
      <Kbd>Backspace</Kbd>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Common text-based keyboard keys. Use these for better readability on Windows or cross-platform applications.',
      },
    },
  },
};

// Keyboard combinations
export const Combinations: Story = {
  render: () => (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-center gap-4">
        <KbdGroup>
          <Kbd>Ctrl</Kbd>
          <span>+</span>
          <Kbd>C</Kbd>
        </KbdGroup>
        <KbdGroup>
          <Kbd>Ctrl</Kbd>
          <span>+</span>
          <Kbd>V</Kbd>
        </KbdGroup>
        <KbdGroup>
          <Kbd>Ctrl</Kbd>
          <span>+</span>
          <Kbd>Z</Kbd>
        </KbdGroup>
      </div>
      <div className="flex flex-wrap items-center gap-4">
        <KbdGroup>
          <Kbd>⌘</Kbd>
          <Kbd>K</Kbd>
        </KbdGroup>
        <KbdGroup>
          <Kbd>⌘</Kbd>
          <Kbd>⇧</Kbd>
          <Kbd>P</Kbd>
        </KbdGroup>
        <KbdGroup>
          <Kbd>Ctrl</Kbd>
          <Kbd>Alt</Kbd>
          <Kbd>Delete</Kbd>
        </KbdGroup>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Common keyboard combinations using KbdGroup. You can use either symbols or text keys, and optionally add a "+" separator between keys.',
      },
    },
  },
};

// Inline usage in text
export const InlineText: Story = {
  render: () => (
    <div className="flex max-w-md flex-col gap-4">
      <p className="text-sm">
        Press <Kbd>Ctrl</Kbd> + <Kbd>S</Kbd> to save your work.
      </p>
      <p className="text-sm">
        Use{' '}
        <KbdGroup>
          <Kbd>⌘</Kbd>
          <Kbd>K</Kbd>
        </KbdGroup>{' '}
        to open the command palette.
      </p>
      <p className="text-muted-foreground text-sm">
        Navigate with{' '}
        <KbdGroup>
          <Kbd>↑</Kbd>
          <Kbd>↓</Kbd>
        </KbdGroup>{' '}
        and select with <Kbd>⏎</Kbd>.
      </p>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Examples of using Kbd components inline within text content. This is useful for documentation and help text.',
      },
    },
  },
};
