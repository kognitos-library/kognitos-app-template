import type { Meta, StoryObj } from '@storybook/react';
import { Flex } from '@/design-system';

import { BrandLoader } from './brand-loader';

const meta: Meta<typeof BrandLoader> = {
  title: 'Design System/Primitives/Feedback/BrandLoader',
  component: BrandLoader,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'An animated loading indicator with a drawing stroke effect. Uses currentColor for theming.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: { type: 'select' },
      options: ['sm', 'md', 'lg', 'xl'],
      description: 'The size of the loader',
    },
    color: {
      control: { type: 'text' },
      description:
        'Color class for the loader stroke (e.g., text-primary, text-destructive)',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Sizes: Story = {
  render: () => (
    <Flex gap={4} align="center">
      <BrandLoader size="sm" />
      <BrandLoader size="md" />
      <BrandLoader size="lg" />
      <BrandLoader size="xl" />
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'All available loader sizes from small to extra large.',
      },
    },
  },
};

export const CustomColors: Story = {
  render: () => (
    <Flex gap={4} align="center">
      <BrandLoader />
      <BrandLoader color="text-destructive" />
      <BrandLoader color="text-muted-foreground" />
      <BrandLoader color="text-success" />
      <BrandLoader color="text-warning" />
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Examples of different color variants using design system tokens.',
      },
    },
  },
};
