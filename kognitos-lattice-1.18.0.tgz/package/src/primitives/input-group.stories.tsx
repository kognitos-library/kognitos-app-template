import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupInput,
  InputGroupText,
  InputGroupTextarea,
} from './input-group';
import { Icon } from '../icons';
import { Text } from './typography';
import { Tooltip, TooltipContent, TooltipTrigger } from './tooltip';
import { Separator } from './separator';
import { Spinner } from './spinner';
import { Label } from './label';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './dropdown-menu';

const meta: Meta<typeof InputGroup> = {
  title: 'Design System/Primitives/Data Entry/Input Group',
  component: InputGroup,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Display additional information or actions to an input or textarea. Input Group allows you to combine inputs with icons, text, buttons, and other elements to create rich form controls.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof InputGroup>;

// Primary story - Main demo
export const Demo: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <InputGroup>
        <InputGroupInput placeholder="Search..." />
        <InputGroupAddon>
          <Icon type="Search" />
        </InputGroupAddon>
        <InputGroupAddon align="inline-end">12 results</InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="example.com" className="!pl-1" />
        <InputGroupAddon>
          <InputGroupText>https://</InputGroupText>
        </InputGroupAddon>
        <InputGroupAddon align="inline-end">
          <Tooltip>
            <TooltipTrigger asChild>
              <InputGroupButton className="rounded-full" size="icon-xs">
                <Icon type="Info" />
              </InputGroupButton>
            </TooltipTrigger>
            <TooltipContent>This is content in a tooltip.</TooltipContent>
          </Tooltip>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupTextarea placeholder="Ask, Search or Chat..." />
        <InputGroupAddon align="block-end">
          <InputGroupButton
            variant="outline"
            className="rounded-full"
            size="icon-xs"
          >
            <Icon type="Plus" />
          </InputGroupButton>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <InputGroupButton variant="ghost">Auto</InputGroupButton>
            </DropdownMenuTrigger>
            <DropdownMenuContent side="top" align="start">
              <DropdownMenuItem>Auto</DropdownMenuItem>
              <DropdownMenuItem>Agent</DropdownMenuItem>
              <DropdownMenuItem>Manual</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <InputGroupText className="ml-auto">52% used</InputGroupText>
          <Separator orientation="vertical" className="!h-4" />
          <InputGroupButton
            variant="default"
            className="rounded-full"
            size="icon-xs"
            disabled
          >
            <Icon type="ArrowUp" />
            <span className="sr-only">Send</span>
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="@shadcn" />
        <InputGroupAddon align="inline-end">
          <div className="bg-primary text-primary-foreground flex size-4 items-center justify-center rounded-full">
            <Icon type="Check" className="size-3" />
          </div>
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'The main demo showing various input group configurations with icons, text, buttons, and interactive elements.',
      },
    },
  },
};

// Icon Examples
export const WithIcon: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <InputGroup>
        <InputGroupInput placeholder="Search..." />
        <InputGroupAddon>
          <Icon type="Search" />
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput type="email" placeholder="Enter your email" />
        <InputGroupAddon>
          <Icon type="Mail" />
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="Card number" />
        <InputGroupAddon>
          <Icon type="CreditCard" />
        </InputGroupAddon>
        <InputGroupAddon align="inline-end">
          <Icon type="Check" />
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="Card number" />
        <InputGroupAddon align="inline-end">
          <Icon type="Star" />
          <Icon type="Info" />
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Input groups with icons. Icons can be placed at the start or end of the input using the align prop.',
      },
    },
  },
};

// Text Examples
export const WithText: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <InputGroup>
        <InputGroupAddon>
          <InputGroupText>$</InputGroupText>
        </InputGroupAddon>
        <InputGroupInput placeholder="0.00" />
        <InputGroupAddon align="inline-end">
          <InputGroupText>USD</InputGroupText>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupAddon>
          <InputGroupText>https://</InputGroupText>
        </InputGroupAddon>
        <InputGroupInput placeholder="example.com" className="!pl-0.5" />
        <InputGroupAddon align="inline-end">
          <InputGroupText>.com</InputGroupText>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="Enter your username" />
        <InputGroupAddon align="inline-end">
          <InputGroupText>@company.com</InputGroupText>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupTextarea placeholder="Enter your message" />
        <InputGroupAddon align="block-end">
          <InputGroupText className="text-muted-foreground text-xs">
            120 characters left
          </InputGroupText>
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Display additional text information alongside inputs. Useful for showing currency symbols, domain prefixes/suffixes, and character counts.',
      },
    },
  },
};

// Button Examples
export const WithButton: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <InputGroup>
        <InputGroupAddon>
          <InputGroupText>https://</InputGroupText>
        </InputGroupAddon>
        <InputGroupInput placeholder="example.com" />
        <InputGroupAddon align="inline-end">
          <InputGroupButton>Go</InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput type="search" placeholder="Search..." />
        <InputGroupAddon align="inline-end">
          <InputGroupButton>Search</InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="Enter your email" />
        <InputGroupAddon align="inline-end">
          <InputGroupButton variant="default" size="xs">
            Subscribe
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="Paste link here" />
        <InputGroupAddon align="inline-end">
          <InputGroupButton variant="outline" size="icon-xs">
            <Icon type="Copy" />
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Add buttons to perform actions within the input group. Supports different button variants and sizes.',
      },
    },
  },
};

// Tooltip Example
export const WithTooltip: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <InputGroup>
        <InputGroupInput placeholder="Enter API key" type="password" />
        <InputGroupAddon align="inline-end">
          <Tooltip>
            <TooltipTrigger asChild>
              <InputGroupButton className="rounded-full" size="icon-xs">
                <Icon type="Info" />
              </InputGroupButton>
            </TooltipTrigger>
            <TooltipContent>
              Your API key is used to authenticate requests
            </TooltipContent>
          </Tooltip>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="example.com" />
        <InputGroupAddon>
          <InputGroupText>https://</InputGroupText>
        </InputGroupAddon>
        <InputGroupAddon align="inline-end">
          <Tooltip>
            <TooltipTrigger asChild>
              <InputGroupButton
                variant="ghost"
                className="rounded-full"
                size="icon-xs"
              >
                <Icon type="HelpCircle" />
              </InputGroupButton>
            </TooltipTrigger>
            <TooltipContent>
              Enter your domain without the protocol
            </TooltipContent>
          </Tooltip>
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Input groups with tooltips for providing additional context or help text.',
      },
    },
  },
};

// Textarea Examples
export const WithTextarea: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <InputGroup>
        <InputGroupTextarea placeholder="Enter your message..." />
        <InputGroupAddon align="block-end">
          <InputGroupButton className="ml-auto" size="xs" variant="default">
            Send
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupTextarea placeholder="Ask, Search or Chat..." />
        <InputGroupAddon align="block-end">
          <InputGroupButton
            variant="outline"
            className="rounded-full"
            size="icon-xs"
          >
            <Icon type="Plus" />
          </InputGroupButton>
          <InputGroupText className="ml-auto text-xs">0/500</InputGroupText>
          <InputGroupButton
            variant="default"
            className="rounded-full"
            size="icon-xs"
          >
            <Icon type="SendHorizontal" />
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupAddon align="block-start">
          <InputGroupText className="text-xs">Comment</InputGroupText>
        </InputGroupAddon>
        <InputGroupTextarea placeholder="Write a comment..." />
        <InputGroupAddon align="block-end">
          <InputGroupButton variant="ghost" size="xs">
            Cancel
          </InputGroupButton>
          <InputGroupButton variant="default" size="xs" className="ml-auto">
            Post
          </InputGroupButton>
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Input groups with textarea elements. Use block-start and block-end alignment for vertical positioning of addons.',
      },
    },
  },
};

// Spinner Example
export const WithSpinner: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <InputGroup>
        <InputGroupInput placeholder="Loading..." />
        <InputGroupAddon align="inline-end">
          <Spinner />
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="Searching..." type="search" />
        <InputGroupAddon>
          <Icon type="Search" />
        </InputGroupAddon>
        <InputGroupAddon align="inline-end">
          <Spinner />
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Input groups with loading spinners to indicate ongoing operations.',
      },
    },
  },
};

// Label Example
export const WithLabel: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <div className="space-y-2">
        <Label htmlFor="email">Email Address</Label>
        <InputGroup>
          <InputGroupInput id="email" type="email" placeholder="Enter email" />
          <InputGroupAddon>
            <Icon type="Mail" />
          </InputGroupAddon>
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Label htmlFor="website">Website URL</Label>
        <InputGroup>
          <InputGroupAddon>
            <InputGroupText>https://</InputGroupText>
          </InputGroupAddon>
          <InputGroupInput id="website" placeholder="example.com" />
          <InputGroupAddon align="inline-end">
            <Icon type="ExternalLink" />
          </InputGroupAddon>
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Label htmlFor="price">Price</Label>
        <InputGroup>
          <InputGroupAddon>
            <InputGroupText>$</InputGroupText>
          </InputGroupAddon>
          <InputGroupInput id="price" type="number" placeholder="0.00" />
          <InputGroupAddon align="inline-end">
            <InputGroupText>USD</InputGroupText>
          </InputGroupAddon>
        </InputGroup>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Input groups with labels for better form accessibility.',
      },
    },
  },
};

// Dropdown Example
export const WithDropdown: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-4">
      <InputGroup>
        <InputGroupInput placeholder="Enter file name" />
        <InputGroupAddon align="inline-end">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <InputGroupButton
                variant="ghost"
                aria-label="More"
                size="icon-xs"
              >
                <Icon type="MoreHorizontal" />
              </InputGroupButton>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Settings</DropdownMenuItem>
              <DropdownMenuItem>Copy path</DropdownMenuItem>
              <DropdownMenuItem>Open location</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </InputGroupAddon>
      </InputGroup>
      <InputGroup>
        <InputGroupInput placeholder="Enter search query" />
        <InputGroupAddon align="inline-end">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <InputGroupButton variant="ghost" className="!pr-1.5 text-xs">
                Search In...
                <Icon type="ChevronDown" className="size-3" />
              </InputGroupButton>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Documentation</DropdownMenuItem>
              <DropdownMenuItem>Blog Posts</DropdownMenuItem>
              <DropdownMenuItem>Changelog</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </InputGroupAddon>
      </InputGroup>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Input groups with dropdown menus for additional actions and interactions.',
      },
    },
  },
};

// Alignment Examples
export const Alignment: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <div className="space-y-2">
        <Text level="small" className="block">
          Inline Start
        </Text>
        <InputGroup>
          <InputGroupAddon align="inline-start">
            <Icon type="Search" />
          </InputGroupAddon>
          <InputGroupInput placeholder="Search..." />
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Text level="small" className="block">
          Inline End
        </Text>
        <InputGroup>
          <InputGroupInput placeholder="Search..." />
          <InputGroupAddon align="inline-end">
            <Icon type="Search" />
          </InputGroupAddon>
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Text level="small" className="block">
          Block Start
        </Text>
        <InputGroup>
          <InputGroupAddon align="block-start">
            <InputGroupText className="text-xs">Title</InputGroupText>
          </InputGroupAddon>
          <InputGroupTextarea placeholder="Enter content..." />
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Text level="small" className="block">
          Block End
        </Text>
        <InputGroup>
          <InputGroupTextarea placeholder="Enter message..." />
          <InputGroupAddon align="block-end">
            <InputGroupButton size="xs">Submit</InputGroupButton>
          </InputGroupAddon>
        </InputGroup>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Different alignment options for addons: inline-start, inline-end (for inputs), block-start, block-end (for textareas).',
      },
    },
  },
};

// States
export const States: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <div className="space-y-2">
        <Text level="small" className="block">
          Normal
        </Text>
        <InputGroup>
          <InputGroupInput placeholder="Normal state" />
          <InputGroupAddon align="inline-end">
            <Icon type="Check" />
          </InputGroupAddon>
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Text level="small" className="block">
          Disabled
        </Text>
        <InputGroup data-disabled="true">
          <InputGroupInput placeholder="Disabled state" disabled />
          <InputGroupAddon align="inline-end">
            <Icon type="Lock" />
          </InputGroupAddon>
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Text level="small" className="block">
          Invalid
        </Text>
        <InputGroup>
          <InputGroupInput placeholder="Invalid state" aria-invalid="true" />
          <InputGroupAddon align="inline-end">
            <Icon type="AlertCircle" />
          </InputGroupAddon>
        </InputGroup>
        <Text level="small" color="muted" className="mt-1">
          This field has an error
        </Text>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Different states of input groups: normal, disabled, and invalid.',
      },
    },
  },
};

// Complex Examples
export const ComplexExamples: Story = {
  render: () => (
    <div className="grid w-full max-w-sm gap-6">
      <div className="space-y-2">
        <Label>Search with filters</Label>
        <InputGroup>
          <InputGroupInput type="search" placeholder="Search..." />
          <InputGroupAddon>
            <Icon type="Search" />
          </InputGroupAddon>
          <InputGroupAddon align="inline-end">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <InputGroupButton variant="ghost" size="xs">
                  All
                  <Icon type="ChevronDown" className="size-3" />
                </InputGroupButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem>All Items</DropdownMenuItem>
                <DropdownMenuItem>Active</DropdownMenuItem>
                <DropdownMenuItem>Archived</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <InputGroupButton variant="outline" size="icon-xs">
              <Icon type="Settings2" />
            </InputGroupButton>
          </InputGroupAddon>
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Label>Amount with currency</Label>
        <InputGroup>
          <InputGroupAddon>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <InputGroupButton variant="ghost" size="xs">
                  USD
                  <Icon type="ChevronDown" className="size-3" />
                </InputGroupButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem>USD</DropdownMenuItem>
                <DropdownMenuItem>EUR</DropdownMenuItem>
                <DropdownMenuItem>GBP</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </InputGroupAddon>
          <InputGroupInput type="number" placeholder="0.00" />
          <InputGroupAddon align="inline-end">
            <Tooltip>
              <TooltipTrigger asChild>
                <InputGroupButton
                  variant="ghost"
                  className="rounded-full"
                  size="icon-xs"
                >
                  <Icon type="Info" />
                </InputGroupButton>
              </TooltipTrigger>
              <TooltipContent>Enter amount in selected currency</TooltipContent>
            </Tooltip>
          </InputGroupAddon>
        </InputGroup>
      </div>
      <div className="space-y-2">
        <Label>Chat input</Label>
        <InputGroup>
          <InputGroupTextarea placeholder="Type your message..." />
          <InputGroupAddon align="block-end">
            <InputGroupButton
              variant="outline"
              className="rounded-full"
              size="icon-xs"
            >
              <Icon type="Plus" />
            </InputGroupButton>
            <InputGroupButton
              variant="outline"
              className="rounded-full"
              size="icon-xs"
            >
              <Icon type="Smile" />
            </InputGroupButton>
            <InputGroupText className="ml-auto text-xs">0/1000</InputGroupText>
            <Separator orientation="vertical" className="!h-4" />
            <InputGroupButton
              variant="default"
              className="rounded-full"
              size="icon-xs"
            >
              <Icon type="SendHorizontal" />
              <span className="sr-only">Send message</span>
            </InputGroupButton>
          </InputGroupAddon>
        </InputGroup>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Complex examples combining multiple features: dropdowns, tooltips, buttons, and various addons.',
      },
    },
  },
};

// Form Examples
export const FormExamples: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-4">
          Contact Form
        </h3>
        <div className="space-y-4 max-w-md">
          <div className="space-y-2">
            <Label htmlFor="name">Full Name</Label>
            <InputGroup>
              <InputGroupInput id="name" placeholder="Enter your full name" />
              <InputGroupAddon>
                <Icon type="User" />
              </InputGroupAddon>
            </InputGroup>
          </div>
          <div className="space-y-2">
            <Label htmlFor="contact-email">Email Address</Label>
            <InputGroup>
              <InputGroupInput
                id="contact-email"
                type="email"
                placeholder="Enter your email"
              />
              <InputGroupAddon>
                <Icon type="Mail" />
              </InputGroupAddon>
            </InputGroup>
          </div>
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <InputGroup>
              <InputGroupAddon>
                <InputGroupText>+1</InputGroupText>
              </InputGroupAddon>
              <InputGroupInput
                id="phone"
                type="tel"
                placeholder="(555) 000-0000"
              />
              <InputGroupAddon align="inline-end">
                <Icon type="Phone" />
              </InputGroupAddon>
            </InputGroup>
          </div>
          <div className="space-y-2">
            <Label htmlFor="message">Message</Label>
            <InputGroup>
              <InputGroupTextarea
                id="message"
                placeholder="Enter your message..."
              />
              <InputGroupAddon align="block-end">
                <InputGroupText className="ml-auto text-xs">
                  0/500
                </InputGroupText>
              </InputGroupAddon>
            </InputGroup>
          </div>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'A complete contact form example using various input groups.',
      },
    },
  },
};
