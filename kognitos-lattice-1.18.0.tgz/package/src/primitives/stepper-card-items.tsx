import { cva, type VariantProps } from 'class-variance-authority';
import { cn } from '@/design-system/lib/utils';
import { Icon, type IconType } from '@/design-system/icons';
import { Flex } from './flex';
import { Text } from './typography';

// ============================================================================
// ENUMS
// ============================================================================

/**
 * State of the StepperCard component
 */
export enum EStepperCardState {
  DEFAULT = 'default',
  COMPLETED = 'completed',
  DISABLED = 'disabled',
  LOADING = 'loading',
}

// Creates a union type of string literals from EStepperCardState enum values
// e.g., "default" | "completed" | "disabled" | "loading"
export type TStepperCardState = `${EStepperCardState}`;

/**
 * Variant of the StepperCard component
 * - default: no highlight
 * - selected: highlights the current step
 */
export enum EStepperCardVariant {
  DEFAULT = 'default',
  SELECTED = 'selected',
}

// Creates a union type of string literals from EStepperCardVariant enum values
// e.g., "default" | "selected"
export type TStepperCardVariant = `${EStepperCardVariant}`;

// ============================================================================
// VARIANTS
// ============================================================================

const stepperCardVariants = cva(
  'bg-card rounded-md border border-border transition-all duration-200 min-w-36',
  {
    variants: {
      state: {
        default: '',
        completed: '',
        disabled: 'opacity-50 hover:cursor-not-allowed',
        loading: 'opacity-50',
      },
      variant: {
        default: '',
        selected: 'border-primary bg-primary/10',
      },
    },
    defaultVariants: {
      state: 'default',
      variant: 'default',
    },
  },
);

const stepIndicatorVariants = cva(
  'size-6 shrink-0 rounded-full border border-border bg-transparent transition-colors text-foreground',
  {
    variants: {
      variant: {
        default: '',
        selected: 'border-primary bg-primary text-primary-foreground',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

// ============================================================================
// STEPPER CARD ICON (NUMBER, ICON, CHECKMARK, LOADING SPINNER, ETC)
// ============================================================================

interface IStepperCardIconProps {
  state?: TStepperCardState;
  variant?: TStepperCardVariant;
  stepNumber?: number | string;
  icon?: IconType;
}

/**
 * StepperCardIcon displays the stepper card number, icon, checkmark, or loading spinner.
 */
export function StepperCardIcon({
  state = 'default',
  variant = 'default',
  stepNumber = 1,
  icon,
}: IStepperCardIconProps) {
  const isLoading = state === 'loading';
  const isCompleted = state === 'completed';

  // Render the content inside the indicator based on state
  const renderContent = () => {
    if (isLoading) {
      return (
        <Icon type="LoaderCircle" size="xs" className={cn('animate-spin')} />
      );
    }

    if (isCompleted) {
      return <Icon type="Check" size="xs" />;
    }

    // If an icon is provided, use it
    if (icon) {
      return <Icon type={icon} size="xs" />;
    }

    // Inherits text color from parent, determined by variants above
    return (
      <Text level="small" weight="normal" className="text-inherit">
        {stepNumber}
      </Text>
    );
  };

  return (
    <Flex
      data-slot="stepper-card-icon"
      align="center"
      justify="center"
      className={cn(stepIndicatorVariants({ variant }))}
    >
      {renderContent()}
    </Flex>
  );
}

// ============================================================================
// STEPPER CARD TITLE
// ============================================================================

interface IStepperCardTitleProps {
  children: React.ReactNode;
}

/**
 * StepperCardTitle displays the stepper card title text.
 * TODO: Should we do anything with truncated text? Any way to show full text?
 */
export function StepperCardTitle({ children }: IStepperCardTitleProps) {
  return (
    <Text
      level="base"
      weight="medium"
      color="default"
      className="max-w-full leading-none truncate"
      data-slot="stepper-card-title"
    >
      {children}
    </Text>
  );
}

// ============================================================================
// STEPPER CARD DESCRIPTION
// ============================================================================

interface IStepperCardDescriptionProps {
  children: React.ReactNode;
}

/**
 * StepperCardDescription displays the stepper card description text.
 */
export function StepperCardDescription({
  children,
}: IStepperCardDescriptionProps) {
  return (
    <Text
      level="xSmall"
      color="muted"
      className="max-w-full leading-none truncate"
      data-slot="stepper-card-description"
    >
      {children}
    </Text>
  );
}

// ============================================================================
// STEPPER CARD CONTENT
// ============================================================================

interface IStepperCardContentProps {
  children: React.ReactNode;
}

/**
 * StepperCardContent displays the stepper card content (title and description).
 */
export function StepperCardContent({ children }: IStepperCardContentProps) {
  return (
    <Flex
      direction="column"
      gap={1.5}
      width="full"
      height="fit"
      align="start"
      justify="center"
      className="min-h-6 min-w-0 flex-1 overflow-hidden"
      data-slot="stepper-card-content"
    >
      {children}
    </Flex>
  );
}

// ============================================================================
// STEPPER CARD ITEM
// ============================================================================

interface IStepperCardItemProps extends VariantProps<
  typeof stepperCardVariants
> {
  state?: TStepperCardState;
  variant?: TStepperCardVariant;
  children: React.ReactNode;
  onClick?: () => void;
}

/**
 * StepperCardItem component displays a stepper card in a multi-step process.
 *
 * Supports different states: default, completed, disabled, and loading.
 * Supports different variants: default (no highlight) and selected (highlights the current step).
 *
 * @example
 * <StepperCardItem
 *   variant="selected"
 *   onClick={() => console.log('Step clicked')}
 * >
 *   <StepperCardIcon Icon />
 *   <StepperCardContent>
 *     <StepperCardTitle>Step 1</StepperCardTitle>
 *     <StepperCardDescription>Description of step 1</StepperCardDescription>
 *   </StepperCardContent>
 * />
 */
export function StepperCardItem({
  state = 'default',
  variant = 'default',
  children,
  onClick,
}: IStepperCardItemProps) {
  // StepperCardItem cannot be clicked if it is disabled
  const isDisabled = state === 'disabled';
  const isClickable = onClick && !isDisabled;

  const handleClick = () => {
    if (isClickable) {
      onClick();
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (isClickable && e.key === 'Enter') {
      e.preventDefault();
      onClick();
    }
  };

  return (
    <Flex
      data-slot="stepper-card-item"
      data-variant={variant}
      aria-current={variant === 'selected' || undefined}
      aria-disabled={isDisabled || undefined}
      role={onClick ? 'button' : undefined}
      tabIndex={isClickable ? 0 : undefined}
      gap={2}
      padding={3}
      width="full"
      className={cn(
        stepperCardVariants({ state, variant }),
        isClickable && 'cursor-pointer hover:bg-accent', // TODO: Need to sync on hover and focus design, might be a separate variant.
      )}
      onClick={handleClick}
      onKeyDown={handleKeyDown}
    >
      {children}
    </Flex>
  );
}
