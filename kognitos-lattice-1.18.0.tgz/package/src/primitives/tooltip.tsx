import { use, useMemo, createContext, type ComponentProps } from 'react';
import {
  TooltipProvider as TooltipProviderPrimitive,
  Root,
  Trigger,
  Content,
  Arrow,
  Portal,
} from '@radix-ui/react-tooltip';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/design-system/lib/utils';

const tooltipContentVariants = cva(
  'animate-in fade-in-0 zoom-in-95 data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=closed]:zoom-out-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 z-50 w-fit origin-(--radix-tooltip-content-transform-origin) rounded-md px-3 py-1.5 text-xs text-balance',
  {
    variants: {
      variant: {
        default: 'bg-accent text-accent-foreground',
        primary: 'bg-primary text-primary-foreground',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

const tooltipArrowVariants = cva(
  'z-50 size-2.5 translate-y-[calc(-50%_-_2px)] rotate-45 rounded-[2px]',
  {
    variants: {
      variant: {
        default: 'bg-accent fill-accent',
        primary: 'bg-primary fill-primary',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

type TooltipVariant = VariantProps<typeof tooltipContentVariants>['variant'];

const TooltipContext = createContext<{
  variant: TooltipVariant;
}>({
  variant: 'default',
});

function TooltipProvider({
  delayDuration = 0,
  ...props
}: ComponentProps<typeof TooltipProviderPrimitive>) {
  return (
    <TooltipProviderPrimitive
      data-slot="tooltip-provider"
      delayDuration={delayDuration}
      {...props}
    />
  );
}

interface TooltipProps extends ComponentProps<typeof Root> {
  variant?: TooltipVariant;
}

function Tooltip({ variant = 'default', ...props }: TooltipProps) {
  const contextValue = useMemo(() => ({ variant }), [variant]);

  return (
    <TooltipProvider>
      <TooltipContext value={contextValue}>
        <Root data-slot="tooltip" {...props} />
      </TooltipContext>
    </TooltipProvider>
  );
}

function TooltipTrigger({ ...props }: ComponentProps<typeof Trigger>) {
  return <Trigger data-slot="tooltip-trigger" {...props} />;
}

interface TooltipContentProps extends ComponentProps<typeof Content> {
  variant?: TooltipVariant;
}

function TooltipContent({
  className,
  sideOffset = 0,
  variant,
  children,
  ...props
}: TooltipContentProps) {
  const context = use(TooltipContext);
  const appliedVariant = variant ?? context.variant;

  return (
    <Portal>
      <Content
        data-slot="tooltip-content"
        sideOffset={sideOffset}
        className={cn(
          tooltipContentVariants({ variant: appliedVariant }),
          className,
        )}
        {...props}
      >
        {children}
        <Arrow
          className={cn(tooltipArrowVariants({ variant: appliedVariant }))}
        />
      </Content>
    </Portal>
  );
}

export { Tooltip, TooltipTrigger, TooltipContent, TooltipProvider };
