import type { Meta, StoryObj } from '@storybook/react-vite';
import { Alert, AlertTitle, AlertDescription } from './alert';
import { Icon, Button, Flex } from '@/design-system';

const meta: Meta<typeof Alert> = {
  title: 'Design System/Primitives/Feedback/Alert',
  component: Alert,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'An alert component for displaying important messages to users. Supports different variants and can include icons.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['default', 'destructive'],
      description: 'The visual style variant of the alert',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
  args: {
    variant: 'default',
    className: '',
  },
};

export default meta;
type Story = StoryObj<typeof Alert>;

// Default Alert
export const Default: Story = {
  render: args => (
    <Alert {...args}>
      <Icon type="Info" />
      <AlertTitle>Heads up!</AlertTitle>
      <AlertDescription>
        You can add components to your app using the cli.
      </AlertDescription>
    </Alert>
  ),
};

// Destructive Alert
export const Destructive: Story = {
  render: args => (
    <Alert {...args} variant="destructive">
      <Icon type="AlertCircle" />
      <AlertTitle>Error</AlertTitle>
      <AlertDescription>
        Your session has expired. Please log in again.
      </AlertDescription>
    </Alert>
  ),
};

// Alert with Icon
export const WithIcon: Story = {
  render: args => (
    <div className="space-y-4">
      <Alert {...args}>
        <Icon type="Check" />
        <AlertTitle>Success!</AlertTitle>
        <AlertDescription>
          Your changes have been saved successfully.
        </AlertDescription>
      </Alert>

      <Alert {...args}>
        <Icon type="AlertCircle" />
        <AlertTitle>Warning</AlertTitle>
        <AlertDescription>
          Please review your settings before proceeding.
        </AlertDescription>
      </Alert>

      <Alert {...args}>
        <Icon type="Info" />
        <AlertTitle>Information</AlertTitle>
        <AlertDescription>
          This is an informational message for your reference.
        </AlertDescription>
      </Alert>
    </div>
  ),
};

// Alert without Icon
export const WithoutIcon: Story = {
  render: args => (
    <Alert {...args}>
      <AlertTitle>No Icon Alert</AlertTitle>
      <AlertDescription>
        This alert doesn't have an icon. It still maintains proper spacing and
        layout.
      </AlertDescription>
    </Alert>
  ),
};

// Alert with Long Content
export const LongContent: Story = {
  render: args => (
    <Alert {...args}>
      <Icon type="FileText" />
      <AlertTitle>Documentation Update</AlertTitle>
      <AlertDescription>
        We've updated our documentation with new examples and best practices.
        The new guide includes detailed walkthroughs for common use cases,
        troubleshooting tips, and advanced configuration options. Please take a
        moment to review the changes.
      </AlertDescription>
    </Alert>
  ),
};

// Multiple Alerts
export const MultipleAlerts: Story = {
  render: args => (
    <div className="space-y-4">
      <Alert {...args}>
        <Icon type="Check" />
        <AlertTitle>Success</AlertTitle>
        <AlertDescription>
          Your profile has been updated successfully.
        </AlertDescription>
      </Alert>

      <Alert {...args} variant="destructive">
        <Icon type="AlertCircle" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>
          Failed to save changes. Please try again.
        </AlertDescription>
      </Alert>

      <Alert {...args}>
        <Icon type="Info" />
        <AlertTitle>Info</AlertTitle>
        <AlertDescription>
          New features are available in the latest update.
        </AlertDescription>
      </Alert>
    </div>
  ),
};

// Alert with Actions
export const WithActions: Story = {
  render: args => (
    <Alert {...args}>
      <Icon type="Shield" />
      <AlertTitle>Security Notice</AlertTitle>
      <AlertDescription>
        <Flex direction="column" gap={2} width="full">
          <p>Your account security settings need attention.</p>
          <Flex gap={2} justify="end" width="full">
            <Button variant="link" size="sm">
              Review Settings
            </Button>
            <Button variant="link" size="sm">
              Dismiss
            </Button>
          </Flex>
        </Flex>
      </AlertDescription>
    </Alert>
  ),
};
