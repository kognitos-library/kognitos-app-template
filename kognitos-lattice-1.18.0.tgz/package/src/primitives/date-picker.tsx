import * as React from 'react';
import { Calendar as CalendarIcon, ChevronDownIcon } from 'lucide-react';
import type { Matcher } from 'react-day-picker';

import { cn, formatDate, useI18n } from '@/design-system/lib/utils';
import { Button } from '@/design-system/primitives/button';
import { Calendar } from '@/design-system/primitives/calendar';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/design-system/primitives/popover';

export interface DatePickerProps {
  date?: Date;
  onDateChange?: (date: Date | undefined) => void;
  placeholder?: string;
  disabled?: boolean;
  disabledDates?: Matcher | Matcher[];
  className?: string;
  buttonClassName?: string;
  popoverClassName?: string;
  calendarClassName?: string;
  showIcon?: boolean;
  showChevron?: boolean;
  format?: string;
  align?: 'start' | 'center' | 'end';
  side?: 'top' | 'right' | 'bottom' | 'left';
  sideOffset?: number;
  alignOffset?: number;
  avoidCollisions?: boolean;
  collisionBoundary?: Element | null | Array<Element | null>;
  collisionPadding?:
    | number
    | Partial<Record<'top' | 'right' | 'bottom' | 'left', number>>;
  arrowPadding?: number;
  sticky?: 'partial' | 'always';
  hideWhenDetached?: boolean;
  updatePositionStrategy?: 'optimized' | 'always';
  onOpenChange?: (open: boolean) => void;
  open?: boolean;
  defaultOpen?: boolean;
  modal?: boolean;
  children?: React.ReactNode;
}

export function DatePicker({
  date,
  onDateChange,
  placeholder,
  disabled = false,
  disabledDates,
  className,
  buttonClassName,
  popoverClassName,
  calendarClassName,
  showIcon = true,
  showChevron = false,
  format: dateFormat = 'MMMM D, YYYY',
  align = 'start',
  side = 'bottom',
  sideOffset = 4,
  alignOffset = 0,
  avoidCollisions = true,
  collisionBoundary,
  collisionPadding = 0,
  arrowPadding = 0,
  sticky = 'partial',
  hideWhenDetached = false,
  updatePositionStrategy = 'optimized',
  onOpenChange,
  open,
  defaultOpen = false,
  modal = false,
  children,
  ...props
}: DatePickerProps) {
  const { t } = useI18n();
  const resolvedPlaceholder = placeholder ?? t('datePicker.placeholder');

  const [isOpen, setIsOpen] = React.useState(defaultOpen);
  const controlledOpen = open !== undefined ? open : isOpen;
  const setControlledOpen = onOpenChange || setIsOpen;

  const handleDateSelect = (selectedDate: Date | undefined) => {
    onDateChange?.(selectedDate);
    if (selectedDate) {
      setControlledOpen(false);
    }
  };

  const triggerContent = children || (
    <Button
      variant="outline"
      disabled={disabled}
      data-empty={!date}
      className={cn(
        'w-[280px] justify-start text-left font-normal',
        'data-[empty=true]:text-muted-foreground',
        buttonClassName,
      )}
    >
      {showIcon && <CalendarIcon className="mr-2 h-4 w-4" />}
      {date ? formatDate(date, dateFormat) : <span>{resolvedPlaceholder}</span>}
      {showChevron && <ChevronDownIcon className="ml-auto h-4 w-4" />}
    </Button>
  );

  return (
    <Popover
      open={controlledOpen}
      onOpenChange={setControlledOpen}
      modal={modal}
      {...props}
    >
      <PopoverTrigger asChild className={className}>
        {triggerContent}
      </PopoverTrigger>
      <PopoverContent
        className={cn('w-auto p-0', popoverClassName)}
        align={align}
        side={side}
        sideOffset={sideOffset}
        alignOffset={alignOffset}
        avoidCollisions={avoidCollisions}
        collisionBoundary={collisionBoundary}
        collisionPadding={collisionPadding}
        arrowPadding={arrowPadding}
        sticky={sticky}
        hideWhenDetached={hideWhenDetached}
        updatePositionStrategy={updatePositionStrategy}
      >
        <Calendar
          mode="single"
          selected={date}
          onSelect={handleDateSelect}
          className={calendarClassName}
          disabled={disabledDates}
        />
      </PopoverContent>
    </Popover>
  );
}

// Date Range Picker Component
export interface DateRangePickerProps {
  dateRange?: { from: Date | undefined; to?: Date | undefined };
  onDateRangeChange?: (
    range: { from: Date | undefined; to?: Date | undefined } | undefined,
  ) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  buttonClassName?: string;
  popoverClassName?: string;
  calendarClassName?: string;
  showIcon?: boolean;
  showChevron?: boolean;
  format?: string;
  align?: 'start' | 'center' | 'end';
  side?: 'top' | 'right' | 'bottom' | 'left';
  sideOffset?: number;
  alignOffset?: number;
  avoidCollisions?: boolean;
  collisionBoundary?: Element | null | Array<Element | null>;
  collisionPadding?:
    | number
    | Partial<Record<'top' | 'right' | 'bottom' | 'left', number>>;
  arrowPadding?: number;
  sticky?: 'partial' | 'always';
  hideWhenDetached?: boolean;
  updatePositionStrategy?: 'optimized' | 'always';
  onOpenChange?: (open: boolean) => void;
  open?: boolean;
  defaultOpen?: boolean;
  modal?: boolean;
  children?: React.ReactNode;
}

export function DateRangePicker({
  dateRange,
  onDateRangeChange,
  placeholder,
  disabled = false,
  className,
  buttonClassName,
  popoverClassName,
  calendarClassName,
  showIcon = true,
  showChevron = false,
  format: dateFormat = 'MMMM D, YYYY',
  align = 'start',
  side = 'bottom',
  sideOffset = 4,
  alignOffset = 0,
  avoidCollisions = true,
  collisionBoundary,
  collisionPadding = 0,
  arrowPadding = 0,
  sticky = 'partial',
  hideWhenDetached = false,
  updatePositionStrategy = 'optimized',
  onOpenChange,
  open,
  defaultOpen = false,
  modal = false,
  children,
  ...props
}: DateRangePickerProps) {
  const { t } = useI18n();
  const resolvedPlaceholder = placeholder ?? t('datePicker.placeholderRange');

  const [isOpen, setIsOpen] = React.useState(defaultOpen);
  const controlledOpen = open !== undefined ? open : isOpen;
  const setControlledOpen = onOpenChange || setIsOpen;

  const handleDateRangeSelect = (
    range: { from: Date | undefined; to?: Date | undefined } | undefined,
  ) => {
    onDateRangeChange?.(range);
    if (range?.to) {
      setControlledOpen(false);
    }
  };

  const formatDateRange = () => {
    if (!dateRange?.from) return resolvedPlaceholder;
    if (!dateRange.to) return formatDate(dateRange.from, dateFormat);
    return `${formatDate(dateRange.from, dateFormat)} - ${formatDate(dateRange.to, dateFormat)}`;
  };

  const triggerContent = children || (
    <Button
      variant="outline"
      disabled={disabled}
      data-empty={!dateRange?.from}
      className={cn(
        'w-[280px] justify-start text-left font-normal',
        'data-[empty=true]:text-muted-foreground',
        buttonClassName,
      )}
    >
      {showIcon && <CalendarIcon className="mr-2 h-4 w-4" />}
      <span>{formatDateRange()}</span>
      {showChevron && <ChevronDownIcon className="ml-auto h-4 w-4" />}
    </Button>
  );

  return (
    <Popover
      open={controlledOpen}
      onOpenChange={setControlledOpen}
      modal={modal}
      {...props}
    >
      <PopoverTrigger asChild className={className}>
        {triggerContent}
      </PopoverTrigger>
      <PopoverContent
        className={cn('w-auto p-0', popoverClassName)}
        align={align}
        side={side}
        sideOffset={sideOffset}
        alignOffset={alignOffset}
        avoidCollisions={avoidCollisions}
        collisionBoundary={collisionBoundary}
        collisionPadding={collisionPadding}
        arrowPadding={arrowPadding}
        sticky={sticky}
        hideWhenDetached={hideWhenDetached}
        updatePositionStrategy={updatePositionStrategy}
      >
        <Calendar
          mode="range"
          selected={dateRange}
          onSelect={handleDateRangeSelect}
          className={calendarClassName}
        />
      </PopoverContent>
    </Popover>
  );
}

// Date Picker with Input Component
export interface DatePickerInputProps {
  date?: Date;
  onDateChange?: (date: Date | undefined) => void;
  placeholder?: string;
  disabled?: boolean;
  className?: string;
  buttonClassName?: string;
  popoverClassName?: string;
  calendarClassName?: string;
  showIcon?: boolean;
  format?: string;
  align?: 'start' | 'center' | 'end';
  side?: 'top' | 'right' | 'bottom' | 'left';
  sideOffset?: number;
  alignOffset?: number;
  avoidCollisions?: boolean;
  collisionBoundary?: Element | null | Array<Element | null>;
  collisionPadding?:
    | number
    | Partial<Record<'top' | 'right' | 'bottom' | 'left', number>>;
  arrowPadding?: number;
  sticky?: 'partial' | 'always';
  hideWhenDetached?: boolean;
  updatePositionStrategy?: 'optimized' | 'always';
  onOpenChange?: (open: boolean) => void;
  open?: boolean;
  defaultOpen?: boolean;
  modal?: boolean;
  children?: React.ReactNode;
}

export function DatePickerInput({
  date,
  onDateChange,
  placeholder,
  disabled = false,
  className,
  buttonClassName,
  popoverClassName,
  calendarClassName,
  showIcon = true,
  format: dateFormat = 'MMMM D, YYYY',
  align = 'start',
  side = 'bottom',
  sideOffset = 4,
  alignOffset = 0,
  avoidCollisions = true,
  collisionBoundary,
  collisionPadding = 0,
  arrowPadding = 0,
  sticky = 'partial',
  hideWhenDetached = false,
  updatePositionStrategy = 'optimized',
  onOpenChange,
  open,
  defaultOpen = false,
  modal = false,
  children,
  ...props
}: DatePickerInputProps) {
  const { t } = useI18n();
  const resolvedPlaceholder = placeholder ?? t('datePicker.placeholderInput');

  const [isOpen, setIsOpen] = React.useState(defaultOpen);
  const controlledOpen = open !== undefined ? open : isOpen;
  const setControlledOpen = onOpenChange || setIsOpen;

  const handleDateSelect = (selectedDate: Date | undefined) => {
    onDateChange?.(selectedDate);
    if (selectedDate) {
      setControlledOpen(false);
    }
  };

  const triggerContent = children || (
    <Button
      variant="outline"
      disabled={disabled}
      className={cn('w-48 justify-between font-normal', buttonClassName)}
    >
      {date ? formatDate(date, dateFormat) : resolvedPlaceholder}
      {showIcon && <ChevronDownIcon className="h-4 w-4" />}
    </Button>
  );

  return (
    <Popover
      open={controlledOpen}
      onOpenChange={setControlledOpen}
      modal={modal}
      {...props}
    >
      <PopoverTrigger asChild className={className}>
        {triggerContent}
      </PopoverTrigger>
      <PopoverContent
        className={cn('w-auto overflow-hidden p-0', popoverClassName)}
        align={align}
        side={side}
        sideOffset={sideOffset}
        alignOffset={alignOffset}
        avoidCollisions={avoidCollisions}
        collisionBoundary={collisionBoundary}
        collisionPadding={collisionPadding}
        arrowPadding={arrowPadding}
        sticky={sticky}
        hideWhenDetached={hideWhenDetached}
        updatePositionStrategy={updatePositionStrategy}
      >
        <Calendar
          mode="single"
          selected={date}
          onSelect={handleDateSelect}
          captionLayout="dropdown"
          className={calendarClassName}
        />
      </PopoverContent>
    </Popover>
  );
}
