import * as React from 'react';
import { type VariantProps, cva } from 'class-variance-authority';

import { cn } from '@/design-system/lib/utils/index';

const inputVariants = cva(
  'file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input h-9 w-full min-w-0 rounded-md border bg-white px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:cursor-not-allowed disabled:opacity-50 md:text-sm',
  {
    variants: {
      variant: {
        default:
          'border-input rounded-md border focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive',
        // custom ghost variant
        ghost: 'border-transparent aria-invalid:border-transparent',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

interface IInputProps
  extends React.ComponentProps<'input'>, VariantProps<typeof inputVariants> {}

const Input = ({ className, variant, type, ...props }: IInputProps) => {
  return (
    <input
      type={type}
      data-slot="input"
      className={cn(
        inputVariants({ variant }),
        {
          // custom pointer cursor for file input
          'cursor-pointer': type === 'file' || type === 'date',
        },
        className,
      )}
      {...props}
    />
  );
};

Input.displayName = 'Input';

export { Input, inputVariants, type IInputProps };
