import { render, screen } from '@testing-library/react';
import { Button } from './button';
import { describe, it, expect } from 'vitest';

describe('Button', () => {
  describe('Rendering', () => {
    it('should render button element', () => {
      render(<Button data-testid="button">Click me</Button>);

      const button = screen.getByTestId('button');
      expect(button).toBeInTheDocument();
      expect(button).toHaveTextContent('Click me');
    });

    it('should have data-slot attribute', () => {
      render(<Button data-testid="button">Click me</Button>);

      const button = screen.getByTestId('button');
      expect(button).toHaveAttribute('data-slot', 'button');
    });
  });

  describe('Variants', () => {
    it('should render with default variant', () => {
      render(<Button data-testid="button">Click me</Button>);

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('bg-button-primary');
      expect(button).toHaveClass('text-primary-foreground');
    });

    it('should render with destructive variant', () => {
      render(
        <Button data-testid="button" variant="destructive">
          Delete
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('bg-destructive');
      expect(button).toHaveClass('text-white');
    });

    it('should render with outline variant', () => {
      render(
        <Button data-testid="button" variant="outline">
          Outline
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('border');
      expect(button).toHaveClass('bg-background');
    });

    it('should render with secondary variant', () => {
      render(
        <Button data-testid="button" variant="secondary">
          Secondary
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('bg-secondary');
      expect(button).toHaveClass('text-secondary-foreground');
    });

    it('should render with ghost variant', () => {
      render(
        <Button data-testid="button" variant="ghost">
          Ghost
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('not-disabled:hover:bg-accent');
    });

    it('should render with link variant', () => {
      render(
        <Button data-testid="button" variant="link">
          Link
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('text-link');
      expect(button).toHaveClass('underline-offset-4');
    });
  });

  describe('Sizes', () => {
    it('should render with default size', () => {
      render(<Button data-testid="button">Click me</Button>);

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('h-9');
      expect(button).toHaveClass('px-4');
    });

    it('should render with sm size', () => {
      render(
        <Button data-testid="button" size="sm">
          Small
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('h-8');
      expect(button).toHaveClass('text-xs');
    });

    it('should render with lg size', () => {
      render(
        <Button data-testid="button" size="lg">
          Large
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('h-10');
      expect(button).toHaveClass('px-6');
    });

    it('should render with icon size', () => {
      render(
        <Button data-testid="button" size="icon">
          X
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('size-9');
    });

    it('should render with icon-xs size', () => {
      render(
        <Button data-testid="button" size="icon-xs">
          X
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('size-6');
    });

    it('should render with icon-sm size', () => {
      render(
        <Button data-testid="button" size="icon-sm">
          X
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('size-8');
    });

    it('should render with icon-lg size', () => {
      render(
        <Button data-testid="button" size="icon-lg">
          X
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('size-10');
    });
  });

  describe('States', () => {
    it('should handle disabled state with cursor-not-allowed', () => {
      render(
        <Button data-testid="button" disabled>
          Disabled
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toBeDisabled();
      expect(button).toHaveClass('disabled:cursor-not-allowed');
      expect(button).toHaveClass('disabled:opacity-50');
    });

    it('should handle loading state', () => {
      render(
        <Button data-testid="button" isLoading>
          Loading
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toBeDisabled();
    });

    it('should be disabled when isLoading is true', () => {
      render(
        <Button data-testid="button" isLoading>
          Loading
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveAttribute('disabled');
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      render(
        <Button data-testid="button" className="custom-class">
          Click me
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('custom-class');
    });

    it('should have hover cursor pointer styling', () => {
      render(<Button data-testid="button">Click me</Button>);

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('not-disabled:hover:cursor-pointer');
    });
  });

  describe('Accessibility', () => {
    it('should support aria attributes', () => {
      render(
        <Button
          data-testid="button"
          aria-label="Test label"
          aria-describedby="help-text"
        >
          Click me
        </Button>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveAttribute('aria-label', 'Test label');
      expect(button).toHaveAttribute('aria-describedby', 'help-text');
    });

    it('should have focus-visible ring styling', () => {
      render(<Button data-testid="button">Click me</Button>);

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('focus-visible:ring-ring/50');
      expect(button).toHaveClass('focus-visible:ring-[3px]');
    });
  });
});
