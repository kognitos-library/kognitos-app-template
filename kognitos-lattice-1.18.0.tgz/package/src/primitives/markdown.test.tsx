import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Markdown } from './markdown';

describe('Markdown', () => {
  describe('Basic Markdown Rendering', () => {
    it('should render bold text', () => {
      render(<Markdown>**bold text**</Markdown>);

      const boldElement = screen.getByText('bold text');
      expect(boldElement).toBeInTheDocument();
      expect(boldElement.tagName).toBe('STRONG');
      expect(boldElement).toHaveClass('font-semibold');
    });

    it('should render italic text', () => {
      render(<Markdown>*italic text*</Markdown>);

      const italicElement = screen.getByText('italic text');
      expect(italicElement).toBeInTheDocument();
      expect(italicElement.tagName).toBe('EM');
      expect(italicElement).toHaveClass('italic');
    });

    it('should render headings', () => {
      render(
        <Markdown>
          {`# Heading 1
## Heading 2
### Heading 3
#### Heading 4`}
        </Markdown>,
      );

      expect(screen.getByText('Heading 1')).toBeInTheDocument();
      expect(screen.getByText('Heading 2')).toBeInTheDocument();
      expect(screen.getByText('Heading 3')).toBeInTheDocument();
      expect(screen.getByText('Heading 4')).toBeInTheDocument();
    });

    it('should render paragraphs', () => {
      render(
        <Markdown>
          {`First paragraph

Second paragraph`}
        </Markdown>,
      );

      expect(screen.getByText('First paragraph')).toBeInTheDocument();
      expect(screen.getByText('Second paragraph')).toBeInTheDocument();
    });

    it('should render unordered lists', () => {
      render(
        <Markdown>
          {`- Item 1
- Item 2
- Item 3`}
        </Markdown>,
      );

      const list = screen.getByRole('list');
      expect(list).toBeInTheDocument();
      expect(list.tagName).toBe('UL');
      expect(list).toHaveClass('list-disc', 'list-inside');

      expect(screen.getByText('Item 1')).toBeInTheDocument();
      expect(screen.getByText('Item 2')).toBeInTheDocument();
      expect(screen.getByText('Item 3')).toBeInTheDocument();
    });

    it('should render ordered lists', () => {
      render(
        <Markdown>
          {`1. First item
2. Second item
3. Third item`}
        </Markdown>,
      );

      const list = screen.getByRole('list');
      expect(list).toBeInTheDocument();
      expect(list.tagName).toBe('OL');
      expect(list).toHaveClass('list-decimal', 'list-inside');

      expect(screen.getByText('First item')).toBeInTheDocument();
      expect(screen.getByText('Second item')).toBeInTheDocument();
      expect(screen.getByText('Third item')).toBeInTheDocument();
    });

    it('should render inline code', () => {
      render(<Markdown>This is `inline code` example</Markdown>);

      const codeElement = screen.getByText('inline code');
      expect(codeElement).toBeInTheDocument();
      expect(codeElement.tagName).toBe('CODE');
    });

    it('should render code blocks', () => {
      render(
        <Markdown>
          {`\`\`\`javascript
const x = 1;
\`\`\``}
        </Markdown>,
      );

      const codeElement = screen.getByText('const x = 1;');
      expect(codeElement).toBeInTheDocument();
      expect(codeElement.tagName).toBe('CODE');
      expect(codeElement).toHaveClass('block');
    });

    it('should apply wrapping classes to code blocks to prevent overflow', () => {
      const longCodeLine =
        'const veryLongVariableNameThatShouldWrap = "This is a very long string that should cause the code block to wrap to multiple lines instead of overflowing horizontally"';

      render(
        <Markdown>
          {`\`\`\`javascript
${longCodeLine}
\`\`\``}
        </Markdown>,
      );

      // Find the code element containing the long line
      const codeElement = screen.getByText(longCodeLine);
      expect(codeElement).toBeInTheDocument();
      expect(codeElement.tagName).toBe('CODE');

      // Verify wrapping classes are applied (block code should have these)
      expect(codeElement).toHaveClass('whitespace-pre-wrap');
      expect(codeElement).toHaveClass('break-words');
      expect(codeElement).toHaveClass('block');
      expect(codeElement).toHaveClass('w-full');

      // Should not have horizontal scroll
      expect(codeElement).not.toHaveClass('overflow-x-auto');
    });

    it('should render blockquotes', () => {
      const { container } = render(<Markdown>{`> This is a quote`}</Markdown>);

      // react-markdown wraps blockquote content in paragraphs
      expect(screen.getByText('This is a quote')).toBeInTheDocument();

      // Check that blockquote element exists in the DOM
      const blockquote = container.querySelector('blockquote');
      expect(blockquote).toBeInTheDocument();
      expect(blockquote).toHaveClass('my-2');
    });

    it('should render horizontal rules', () => {
      const { container } = render(
        <Markdown>
          {`Content above

---

Content below`}
        </Markdown>,
      );

      const hr = container.querySelector('hr');
      expect(hr).toBeInTheDocument();
      expect(hr).toHaveClass('border-border');
      expect(hr).toHaveClass('my-4');
    });
  });

  describe('Table Rendering', () => {
    it('should render a basic table with headers and data', () => {
      const { container } = render(
        <Markdown>
          {`| Header 1 | Header 2 |
|---------|---------|
| Cell 1  | Cell 2  |`}
        </Markdown>,
      );

      const table = container.querySelector('table');
      expect(table).toBeInTheDocument();
      expect(table).toHaveClass(
        'border-collapse',
        'table-auto',
        'w-full',
        'border',
        'border-border',
      );

      expect(screen.getByText('Header 1')).toBeInTheDocument();
      expect(screen.getByText('Header 2')).toBeInTheDocument();
      expect(screen.getByText('Cell 1')).toBeInTheDocument();
      expect(screen.getByText('Cell 2')).toBeInTheDocument();
    });

    it('should render table with proper structure (thead, tbody, tr, th, td)', () => {
      const { container } = render(
        <Markdown>
          {`| Name | Age |
|------|-----|
| John | 25  |
| Jane | 30  |`}
        </Markdown>,
      );

      const table = container.querySelector('table');
      expect(table).toBeInTheDocument();

      const thead = container.querySelector('thead');
      expect(thead).toBeInTheDocument();
      expect(thead).toHaveClass('bg-muted');

      const tbody = container.querySelector('tbody');
      expect(tbody).toBeInTheDocument();

      const rows = container.querySelectorAll('tr');
      expect(rows.length).toBeGreaterThanOrEqual(3); // Header row + 2 data rows

      const headerCells = container.querySelectorAll('th');
      expect(headerCells.length).toBe(2);
      headerCells.forEach(th => {
        expect(th).toHaveClass(
          'border',
          'border-border',
          'p-3',
          'text-left',
          'font-semibold',
        );
      });

      const dataCells = container.querySelectorAll('td');
      expect(dataCells.length).toBe(4); // 2 rows × 2 columns
      dataCells.forEach(td => {
        expect(td).toHaveClass('border', 'border-border', 'p-3');
      });
    });

    it('should render table with multiple rows and columns', () => {
      render(
        <Markdown>
          {`| Service | Amount | Quantity |
|---------|--------|----------|
| Item A  | 100    | 5        |
| Item B  | 200    | 3        |
| Item C  | 150    | 2        |`}
        </Markdown>,
      );

      expect(screen.getByText('Service')).toBeInTheDocument();
      expect(screen.getByText('Amount')).toBeInTheDocument();
      expect(screen.getByText('Quantity')).toBeInTheDocument();
      expect(screen.getByText('Item A')).toBeInTheDocument();
      expect(screen.getByText('Item B')).toBeInTheDocument();
      expect(screen.getByText('Item C')).toBeInTheDocument();
      expect(screen.getByText('100')).toBeInTheDocument();
      expect(screen.getByText('200')).toBeInTheDocument();
      expect(screen.getByText('150')).toBeInTheDocument();
    });

    it('should wrap table in overflow container for horizontal scrolling', () => {
      const { container } = render(
        <Markdown>
          {`| Column 1 | Column 2 | Column 3 |
|---------|---------|---------|
| Data 1  | Data 2  | Data 3  |`}
        </Markdown>,
      );

      const table = container.querySelector('table');
      expect(table).toBeInTheDocument();

      const tableWrapper = table?.parentElement;
      expect(tableWrapper).toBeInTheDocument();
      expect(tableWrapper).toHaveClass('w-full', 'overflow-x-auto', 'my-4');
    });

    it('should render table with markdown content in cells', () => {
      render(
        <Markdown>
          {`| Header |
|-------|
| **Bold** text |
| *Italic* text |
| \`Code\` text |`}
        </Markdown>,
      );

      expect(screen.getByText('Header')).toBeInTheDocument();
      expect(screen.getByText('Bold')).toBeInTheDocument();
      expect(screen.getByText('Italic')).toBeInTheDocument();
      expect(screen.getByText('Code')).toBeInTheDocument();
    });

    it('should render table with empty cells', () => {
      const { container } = render(
        <Markdown>
          {`| Col 1 | Col 2 | Col 3 |
|-------|-------|-------|
| Data  |       | Data  |`}
        </Markdown>,
      );

      const table = container.querySelector('table');
      expect(table).toBeInTheDocument();

      const dataCells = container.querySelectorAll('td');
      expect(dataCells.length).toBe(3);
    });

    it('should render table with alignment in headers', () => {
      const { container } = render(
        <Markdown>
          {`| Left | Center | Right |
|:-----|:------:|------:|
| A    | B      | C     |`}
        </Markdown>,
      );

      const table = container.querySelector('table');
      expect(table).toBeInTheDocument();

      expect(screen.getByText('Left')).toBeInTheDocument();
      expect(screen.getByText('Center')).toBeInTheDocument();
      expect(screen.getByText('Right')).toBeInTheDocument();
      expect(screen.getByText('A')).toBeInTheDocument();
      expect(screen.getByText('B')).toBeInTheDocument();
      expect(screen.getByText('C')).toBeInTheDocument();
    });
  });

  describe('Link Security', () => {
    it('should sanitize dangerous javascript: links', () => {
      render(<Markdown>[Click me](javascript:alert(1))</Markdown>);

      const link = screen.queryByRole('link');
      expect(link).not.toBeInTheDocument();

      // Should render as plain text instead
      expect(screen.getByText('Click me')).toBeInTheDocument();
      const span = screen.getByText('Click me');
      expect(span.tagName).toBe('SPAN');
      expect(span).toHaveClass('text-link');
    });

    it('should sanitize dangerous data: links', () => {
      render(<Markdown>[Click](data:text/plain,test)</Markdown>);

      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.getByText('Click')).toBeInTheDocument();
    });

    it('should sanitize dangerous file: links', () => {
      render(<Markdown>[File](file:///etc/passwd)</Markdown>);

      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.getByText('File')).toBeInTheDocument();
    });

    it('should sanitize dangerous vbscript: links', () => {
      render(<Markdown>[Click](vbscript:msgbox("XSS"))</Markdown>);

      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.getByText('Click')).toBeInTheDocument();
    });

    it('should render valid HTTPS links with proper attributes', () => {
      render(<Markdown>[Example](https://example.com)</Markdown>);

      const link = screen.getByRole('link', { name: 'Example' });
      expect(link).toBeInTheDocument();
      expect(link).toHaveAttribute('href', 'https://example.com');
      expect(link).toHaveAttribute('target', '_blank');
      expect(link).toHaveAttribute('rel', 'noopener noreferrer');
    });

    it('should render valid HTTP links with proper attributes', () => {
      render(<Markdown>[Link](http://example.com)</Markdown>);

      const link = screen.getByRole('link', { name: 'Link' });
      expect(link).toBeInTheDocument();
      expect(link).toHaveAttribute('href', 'http://example.com');
      expect(link).toHaveAttribute('target', '_blank');
      expect(link).toHaveAttribute('rel', 'noopener noreferrer');
    });

    it('should handle links with query parameters and fragments', () => {
      render(
        <Markdown>
          [Link](https://example.com/path?query=value#fragment)
        </Markdown>,
      );

      const link = screen.getByRole('link', { name: 'Link' });
      expect(link).toBeInTheDocument();
      expect(link).toHaveAttribute(
        'href',
        'https://example.com/path?query=value#fragment',
      );
    });

    it('should sanitize invalid URLs', () => {
      render(<Markdown>[Link](not-a-url)</Markdown>);

      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.getByText('Link')).toBeInTheDocument();
    });

    it('should sanitize empty href', () => {
      render(<Markdown>[Link]()</Markdown>);

      expect(screen.queryByRole('link')).not.toBeInTheDocument();
      expect(screen.getByText('Link')).toBeInTheDocument();
    });
  });

  describe('Text Props Application', () => {
    it('should apply custom textProps to paragraphs', () => {
      render(
        <Markdown
          textProps={{ level: 'small', color: 'muted', weight: 'medium' }}
        >
          Test paragraph
        </Markdown>,
      );

      const paragraph = screen.getByText('Test paragraph');
      expect(paragraph).toBeInTheDocument();
      // The Text component should apply these props
      // We can verify by checking the rendered element exists with the content
    });

    it('should apply default textProps when not provided', () => {
      render(<Markdown>Default paragraph</Markdown>);

      const paragraph = screen.getByText('Default paragraph');
      expect(paragraph).toBeInTheDocument();
    });

    it('should apply textProps to list items', () => {
      render(
        <Markdown textProps={{ level: 'large', color: 'primary' }}>
          {`- Item 1
- Item 2`}
        </Markdown>,
      );

      expect(screen.getByText('Item 1')).toBeInTheDocument();
      expect(screen.getByText('Item 2')).toBeInTheDocument();
    });

    it('should apply textProps to inline code', () => {
      render(
        <Markdown textProps={{ level: 'base', color: 'default' }}>
          This has `code` in it
        </Markdown>,
      );

      const codeElement = screen.getByText('code');
      expect(codeElement).toBeInTheDocument();
      expect(codeElement.tagName).toBe('CODE');
    });

    it('should apply textProps to code blocks', () => {
      render(
        <Markdown textProps={{ level: 'small', color: 'muted' }}>
          {`\`\`\`
code block
\`\`\``}
        </Markdown>,
      );

      const codeElement = screen.getByText('code block');
      expect(codeElement).toBeInTheDocument();
      expect(codeElement.tagName).toBe('CODE');
    });

    it('should apply textProps to italic text', () => {
      render(
        <Markdown
          textProps={{ level: 'base', color: 'default', weight: 'normal' }}
        >
          *italic text*
        </Markdown>,
      );

      const italicElement = screen.getByText('italic text');
      expect(italicElement).toBeInTheDocument();
      expect(italicElement.tagName).toBe('EM');
      expect(italicElement).toHaveClass('italic');
    });
  });

  describe('Custom ClassName', () => {
    it('should apply custom className to wrapper', () => {
      const { container } = render(
        <Markdown className="custom-wrapper-class">Test content</Markdown>,
      );

      const wrapper = container.firstChild;
      expect(wrapper).toHaveClass('custom-wrapper-class');
    });

    it('should work without className prop', () => {
      const { container } = render(<Markdown>Test content</Markdown>);

      const wrapper = container.firstChild;
      expect(wrapper).toBeInTheDocument();
      expect(wrapper).toBeInstanceOf(HTMLDivElement);
    });
  });

  describe('Complex Markdown Content', () => {
    it('should render complex markdown with multiple elements', () => {
      const complexMarkdown = `# Main Heading

This is a paragraph with **bold** and *italic* text.

## Subheading

- List item 1
- List item 2

\`inline code\` example

> This is a blockquote

[Valid link](https://example.com)`;

      render(<Markdown>{complexMarkdown}</Markdown>);

      expect(screen.getByText('Main Heading')).toBeInTheDocument();
      expect(screen.getByText('Subheading')).toBeInTheDocument();
      expect(screen.getByText('bold')).toBeInTheDocument();
      expect(screen.getByText('italic')).toBeInTheDocument();
      expect(screen.getByText('List item 1')).toBeInTheDocument();
      expect(screen.getByText('inline code')).toBeInTheDocument();
      expect(screen.getByText('This is a blockquote')).toBeInTheDocument();
      expect(
        screen.getByRole('link', { name: 'Valid link' }),
      ).toBeInTheDocument();
    });

    it('should handle markdown with mixed safe and dangerous links', () => {
      const markdown = `[Safe link](https://example.com)
[Dangerous link](javascript:alert(1))`;

      render(<Markdown>{markdown}</Markdown>);

      const safeLink = screen.getByRole('link', { name: 'Safe link' });
      expect(safeLink).toBeInTheDocument();
      expect(safeLink).toHaveAttribute('href', 'https://example.com');

      // Dangerous link should be rendered as plain text
      expect(
        screen.queryByRole('link', { name: 'Dangerous link' }),
      ).not.toBeInTheDocument();
      expect(screen.getByText('Dangerous link')).toBeInTheDocument();
    });
  });

  describe('Edge Cases', () => {
    it('should handle empty markdown content', () => {
      const { container } = render(<Markdown>{''}</Markdown>);
      expect(container.firstChild).toBeInTheDocument();
    });

    it('should handle markdown with only whitespace', () => {
      const { container } = render(<Markdown>{'   \n\n   '}</Markdown>);
      expect(container.firstChild).toBeInTheDocument();
    });

    it('should handle nested markdown elements', () => {
      render(
        <Markdown>
          {`- **Bold item**
- *Italic item*
- \`Code item\``}
        </Markdown>,
      );

      expect(screen.getByText('Bold item')).toBeInTheDocument();
      expect(screen.getByText('Italic item')).toBeInTheDocument();
      expect(screen.getByText('Code item')).toBeInTheDocument();
    });

    it('should handle multiple paragraphs with spacing', () => {
      render(
        <Markdown>
          {`First paragraph

Second paragraph

Third paragraph`}
        </Markdown>,
      );

      expect(screen.getByText('First paragraph')).toBeInTheDocument();
      expect(screen.getByText('Second paragraph')).toBeInTheDocument();
      expect(screen.getByText('Third paragraph')).toBeInTheDocument();
    });
  });
});
