import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import {
  Combobox,
  MultiCombobox,
  type IComboboxOption,
  type IComboboxProps,
} from '@/design-system';
import { Clock, ChevronsUpDownIcon } from 'lucide-react';

const meta: Meta<typeof Combobox> = {
  title: 'Design System/Primitives/Data Entry/Combobox',
  component: Combobox,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Combobox component for autocomplete input and command palette with a list of suggestions. Supports both single and multi-select modes.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
  argTypes: {
    options: {
      control: { type: 'object' },
      description: 'Array of options to display',
    },
    value: {
      control: { type: 'text' },
      description: 'Selected value (for single select)',
    },
    placeholder: {
      control: { type: 'text' },
      description: 'Placeholder text when no option is selected',
    },
    searchPlaceholder: {
      control: { type: 'text' },
      description: 'Placeholder text for search input',
    },
    emptyMessage: {
      control: { type: 'text' },
      description: 'Message shown when no options match search',
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the combobox is disabled',
    },
    align: {
      control: { type: 'select' },
      options: ['start', 'center', 'end'],
      description: 'Alignment of the popover',
    },
    side: {
      control: { type: 'select' },
      options: ['top', 'right', 'bottom', 'left'],
      description: 'Side of the trigger to show popover',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Combobox>;

// Sample data
const frameworks: IComboboxOption[] = [
  { value: 'next.js', label: 'Next.js' },
  { value: 'sveltekit', label: 'SvelteKit' },
  { value: 'nuxt.js', label: 'Nuxt.js' },
  { value: 'remix', label: 'Remix' },
  { value: 'astro', label: 'Astro' },
  { value: 'gatsby', label: 'Gatsby' },
  { value: 'vite', label: 'Vite' },
  { value: 'webpack', label: 'Webpack' },
];

const countries: IComboboxOption[] = [
  { value: 'us', label: 'United States' },
  { value: 'ca', label: 'Canada' },
  { value: 'uk', label: 'United Kingdom' },
  { value: 'de', label: 'Germany' },
  { value: 'fr', label: 'France' },
  { value: 'jp', label: 'Japan' },
  { value: 'au', label: 'Australia' },
  { value: 'br', label: 'Brazil' },
  { value: 'in', label: 'India' },
  { value: 'cn', label: 'China' },
];

// User selection data (with avatars)
const users: IComboboxOption[] = [
  {
    value: 'shadcn',
    label: 'shadcn',
    avatar: {
      fallback: 'S',
      color: '#8b5cf6',
    },
  },
  {
    value: 'leerob',
    label: 'leerob',
    avatar: {
      fallback: 'L',
      color: '#6b7280',
    },
  },
  {
    value: 'evilrabbit',
    label: 'evilrabbit',
    avatar: {
      fallback: 'V',
      color: '#000000',
    },
  },
];

// Timezone data (with groups and descriptions)
const timezones: IComboboxOption[] = [
  // Americas
  { value: 'new-york', label: '(GMT-5) New York', group: 'Americas' },
  { value: 'los-angeles', label: '(GMT-8) Los Angeles', group: 'Americas' },
  { value: 'chicago', label: '(GMT-6) Chicago', group: 'Americas' },
  { value: 'toronto', label: '(GMT-5) Toronto', group: 'Americas' },
  { value: 'vancouver', label: '(GMT-8) Vancouver', group: 'Americas' },
  { value: 'sao-paulo', label: '(GMT-3) São Paulo', group: 'Americas' },
  // Europe
  { value: 'london', label: '(GMT+0) London', group: 'Europe' },
  { value: 'paris', label: '(GMT+1) Paris', group: 'Europe' },
  { value: 'berlin', label: '(GMT+1) Berlin', group: 'Europe' },
  { value: 'rome', label: '(GMT+1) Rome', group: 'Europe' },
  { value: 'madrid', label: '(GMT+1) Madrid', group: 'Europe' },
  { value: 'amsterdam', label: '(GMT+1) Amsterdam', group: 'Europe' },
];

// Interactive Single Select Combobox
export const Default: Story = {
  args: {
    options: frameworks,
    placeholder: 'Select framework...',
    searchPlaceholder: 'Search framework...',
    emptyMessage: 'No framework found.',
    disabled: false,
    align: 'start',
    side: 'bottom',
  },
  parameters: {
    docs: {
      description: {
        story: 'Interactive single-select combobox with search functionality.',
      },
    },
  },
  render: args => {
    const Component = (props: IComboboxProps) => {
      const [value, setValue] = useState<string>('');

      return (
        <div className="w-[300px]">
          <Combobox {...props} value={value} onValueChange={setValue} />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value || 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component {...args} />;
  },
};

// Multi-select Combobox
export const MultiSelect: Story = {
  args: {
    options: countries,
    placeholder: 'Select countries...',
    searchPlaceholder: 'Search countries...',
    emptyMessage: 'No countries found.',
    disabled: false,
    align: 'start',
    side: 'bottom',
  },
  parameters: {
    docs: {
      description: {
        story: 'Multi-select combobox allowing multiple selections.',
      },
    },
  },
  render: args => {
    const Component = (props: IComboboxProps) => {
      const [value, setValue] = useState<string[]>([]);

      return (
        <div className="w-[300px]">
          <MultiCombobox {...props} value={value} onValueChange={setValue} />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value.length > 0 ? value.join(', ') : 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component {...args} />;
  },
};

// Disabled State
export const Disabled: Story = {
  args: {
    options: frameworks,
    placeholder: 'Select framework...',
    disabled: true,
  },
  parameters: {
    docs: {
      description: {
        story: 'Disabled combobox state.',
      },
    },
  },
  render: args => {
    const Component = (props: IComboboxProps) => {
      return (
        <div className="w-[300px]">
          <Combobox {...props} />
        </div>
      );
    };

    return <Component {...args} />;
  },
};

// With Disabled Options
export const WithDisabledOptions: Story = {
  args: {
    options: [
      { value: 'next.js', label: 'Next.js' },
      { value: 'sveltekit', label: 'SvelteKit' },
      { value: 'nuxt.js', label: 'Nuxt.js', disabled: true },
      { value: 'remix', label: 'Remix' },
      { value: 'astro', label: 'Astro', disabled: true },
      { value: 'gatsby', label: 'Gatsby' },
    ],
    placeholder: 'Select framework...',
    searchPlaceholder: 'Search framework...',
    emptyMessage: 'No framework found.',
  },
  parameters: {
    docs: {
      description: {
        story: 'Combobox with some disabled options.',
      },
    },
  },
  render: args => {
    const Component = (props: IComboboxProps) => {
      const [value, setValue] = useState<string>('');

      return (
        <div className="w-[300px]">
          <Combobox {...props} value={value} onValueChange={setValue} />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value || 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component {...args} />;
  },
};

// Different Alignments
export const Alignments: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Combobox with different alignment options.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [value1, setValue1] = useState<string>('');
      const [value2, setValue2] = useState<string>('');
      const [value3, setValue3] = useState<string>('');

      return (
        <div className="space-y-8">
          <div className="flex justify-start">
            <div className="w-[200px]">
              <h3 className="text-sm font-medium mb-2">Start Aligned</h3>
              <Combobox
                options={frameworks}
                value={value1}
                onValueChange={setValue1}
                placeholder="Select framework..."
                align="start"
              />
            </div>
          </div>

          <div className="flex justify-center">
            <div className="w-[200px]">
              <h3 className="text-sm font-medium mb-2">Center Aligned</h3>
              <Combobox
                options={frameworks}
                value={value2}
                onValueChange={setValue2}
                placeholder="Select framework..."
                align="center"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <div className="w-[200px]">
              <h3 className="text-sm font-medium mb-2">End Aligned</h3>
              <Combobox
                options={frameworks}
                value={value3}
                onValueChange={setValue3}
                placeholder="Select framework..."
                align="end"
              />
            </div>
          </div>
        </div>
      );
    };

    return <Component />;
  },
};

// Different Sides
export const Sides: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Combobox with different side options.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [value1, setValue1] = useState<string>('');
      const [value2, setValue2] = useState<string>('');
      const [value3, setValue3] = useState<string>('');
      const [value4, setValue4] = useState<string>('');

      return (
        <div className="grid grid-cols-2 gap-8">
          <div className="w-[200px]">
            <h3 className="text-sm font-medium mb-2">Top Side</h3>
            <Combobox
              options={frameworks}
              value={value1}
              onValueChange={setValue1}
              placeholder="Select framework..."
              side="top"
            />
          </div>

          <div className="w-[200px]">
            <h3 className="text-sm font-medium mb-2">Right Side</h3>
            <Combobox
              options={frameworks}
              value={value2}
              onValueChange={setValue2}
              placeholder="Select framework..."
              side="right"
            />
          </div>

          <div className="w-[200px]">
            <h3 className="text-sm font-medium mb-2">Bottom Side</h3>
            <Combobox
              options={frameworks}
              value={value3}
              onValueChange={setValue3}
              placeholder="Select framework..."
              side="bottom"
            />
          </div>

          <div className="w-[200px]">
            <h3 className="text-sm font-medium mb-2">Left Side</h3>
            <Combobox
              options={frameworks}
              value={value4}
              onValueChange={setValue4}
              placeholder="Select framework..."
              side="left"
            />
          </div>
        </div>
      );
    };

    return <Component />;
  },
};

// Custom Trigger
export const CustomTrigger: Story = {
  args: {
    options: frameworks,
    placeholder: 'Select framework...',
    searchPlaceholder: 'Search framework...',
    emptyMessage: 'No framework found.',
  },
  parameters: {
    docs: {
      description: {
        story: 'Combobox with a custom trigger element.',
      },
    },
  },
  render: args => {
    const Component = (props: IComboboxProps) => {
      const [value, setValue] = useState<string>('');
      const selectedOption = frameworks.find(option => option.value === value);

      return (
        <div className="w-[300px]">
          <Combobox
            {...props}
            value={value}
            onValueChange={setValue}
            trigger={
              <div className="flex items-center justify-between w-full px-3 py-2 border border-input rounded-md bg-background hover:bg-accent hover:text-accent-foreground cursor-pointer">
                <span
                  className={
                    selectedOption ? 'text-foreground' : 'text-muted-foreground'
                  }
                >
                  {selectedOption ? selectedOption.label : 'Custom trigger...'}
                </span>
                <span className="text-xs text-muted-foreground">▼</span>
              </div>
            }
          />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value || 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component {...args} />;
  },
};

// Form Example
export const FormExample: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Combobox used in a form context.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [framework, setFramework] = useState<string>('');
      const [selectedCountries, setSelectedCountries] = useState<string[]>([]);

      return (
        <div className="w-[400px] space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Framework</label>
            <Combobox
              options={frameworks}
              value={framework}
              onValueChange={setFramework}
              placeholder="Select your framework..."
              searchPlaceholder="Search frameworks..."
            />
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">
              Target Countries
            </label>
            <MultiCombobox
              options={countries}
              value={selectedCountries}
              onValueChange={setSelectedCountries}
              placeholder="Select target countries..."
              searchPlaceholder="Search countries..."
            />
          </div>

          <div className="mt-6 p-4 bg-muted rounded">
            <h4 className="font-medium mb-2">Form Data:</h4>
            <div className="text-sm space-y-1">
              <div>Framework: {framework || 'Not selected'}</div>
              <div>
                Countries:{' '}
                {selectedCountries.length > 0
                  ? selectedCountries.join(', ')
                  : 'None selected'}
              </div>
            </div>
          </div>
        </div>
      );
    };

    return <Component />;
  },
};

// Responsive Example
export const Responsive: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Responsive combobox that adapts to different screen sizes.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [value, setValue] = useState<string>('');

      return (
        <div className="space-y-4">
          <div className="w-full max-w-sm">
            <h3 className="text-sm font-medium mb-2">Responsive Combobox</h3>
            <Combobox
              options={frameworks}
              value={value}
              onValueChange={setValue}
              placeholder="Select framework..."
              className="w-full"
              popoverClassName="w-full max-w-sm"
            />
          </div>

          <div className="text-sm text-muted-foreground">
            <p>
              This combobox will adapt its width based on the container size.
            </p>
            <p>
              Try resizing the browser window to see the responsive behavior.
            </p>
          </div>
        </div>
      );
    };

    return <Component />;
  },
};

// Shadcn Figma Variants

// 1. User Selection Combobox (with icons and create option)
export const UserSelection: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'This is a user selection combobox with a search placeholder, empty message, and create option.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [value, setValue] = useState<string>('shadcn');
      const selectedUser = users.find(user => user.value === value);
      console.log(selectedUser);

      return (
        <div className="w-[300px]">
          <Combobox
            options={users}
            value={value}
            onValueChange={setValue}
            placeholder="Select user..."
            searchPlaceholder="Search user..."
            emptyMessage="No user found."
            createOption={{
              label: 'Create user',
              onSelect: value => {
                console.log('Create user:', value);
              },
            }}
          />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value || 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component />;
  },
};

// 2. Single-Select Framework Combobox
export const SingleSelectFramework: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'This is a single-select combobox with a search placeholder, empty message, and create option.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [value, setValue] = useState<string>('');

      return (
        <div className="w-[300px]">
          <Combobox
            options={frameworks}
            value={value}
            onValueChange={setValue}
            placeholder="Select framework..."
            searchPlaceholder="Search framework..."
            emptyMessage="No framework found."
          />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value || 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component />;
  },
};

// 3. Timezone Selection Combobox (with groups)
export const TimezoneSelection: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'This is a timezone selection combobox with grouped options and create option.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [value, setValue] = useState<string>('new-york');
      const selectedTimezone = timezones.find(tz => tz.value === value);

      return (
        <div className="w-[300px]">
          <Combobox
            options={timezones}
            value={value}
            onValueChange={setValue}
            placeholder="Select timezone..."
            searchPlaceholder="Search timezone..."
            emptyMessage="No timezone found."
            showGroups
            createOption={{
              label: 'Create timezone',
              onSelect: value => {
                console.log('Create timezone:', value);
              },
            }}
            trigger={
              <div className="flex items-center justify-between w-full px-3 py-2 border border-input rounded-md bg-background hover:bg-accent hover:text-accent-foreground cursor-pointer">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  <span
                    className={
                      selectedTimezone
                        ? 'text-foreground'
                        : 'text-muted-foreground'
                    }
                  >
                    {selectedTimezone
                      ? selectedTimezone.label
                      : 'Select timezone...'}
                  </span>
                </div>
                <ChevronsUpDownIcon className="h-4 w-4 opacity-50" />
              </div>
            }
          />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value || 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component />;
  },
};

// 4. Multi-Select Framework Combobox
export const MultiSelectFramework: Story = {
  parameters: {
    docs: {
      description: {
        story: 'This is a multi-select framework combobox with checkboxes.',
      },
    },
  },
  render: () => {
    const Component = () => {
      const [value, setValue] = useState<string[]>(['next.js']);

      return (
        <div className="w-[300px]">
          <MultiCombobox
            options={frameworks}
            value={value}
            onValueChange={setValue}
            placeholder="Select frameworks (multi-select)..."
            searchPlaceholder="Search framework..."
            emptyMessage="No framework found."
          />
          <div className="mt-4 p-3 bg-muted rounded text-sm">
            <div>Selected: {value.length > 0 ? value.join(', ') : 'None'}</div>
          </div>
        </div>
      );
    };

    return <Component />;
  },
};
