import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { ToggleButtons, ToggleButtonItem } from './toggle-buttons';
import { Icon } from '../icons';

const meta: Meta<typeof ToggleButtons> = {
  title: 'Design System/Primitives/Data Entry/ToggleButtons',
  component: ToggleButtons,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A toggle button group component based on shadcn Pro Blocks. Features a pill-style container with individually rounded toggle items that highlight when selected. Only one item can be selected at a time. Built on top of ToggleGroup.',
      },
    },
  },
  argTypes: {
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the toggle group is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof ToggleButtons>;

// Helper component to use hooks in stories
function PrimaryExample() {
  const [value, setValue] = useState('today');
  return (
    <div className="p-6 bg-muted rounded-lg">
      <ToggleButtons value={value} onValueChange={setValue}>
        <ToggleButtonItem value="today">Today</ToggleButtonItem>
        <ToggleButtonItem value="this-week">This week</ToggleButtonItem>
        <ToggleButtonItem value="this-month">This month</ToggleButtonItem>
        <ToggleButtonItem value="this-year">This year</ToggleButtonItem>
      </ToggleButtons>
    </div>
  );
}

// Primary story - matches the Figma design
export const Primary: Story = {
  render: () => <PrimaryExample />,
  parameters: {
    layout: 'centered',
  },
};

function WithIconsExample() {
  const [value, setValue] = useState('table');
  return (
    <div className="p-6 bg-muted rounded-lg">
      <ToggleButtons value={value} onValueChange={setValue}>
        <ToggleButtonItem value="table">
          <Icon type="Table2" className="size-4" />
          Table
        </ToggleButtonItem>
        <ToggleButtonItem value="list">
          <Icon type="List" className="size-4" />
          List
        </ToggleButtonItem>
        <ToggleButtonItem value="menu">
          <Icon type="Menu" className="size-4" />
          Menu
        </ToggleButtonItem>
      </ToggleButtons>
    </div>
  );
}

// With Icons
export const WithIcons: Story = {
  render: () => <WithIconsExample />,
  parameters: {
    layout: 'centered',
  },
};

function IconOnlyExample() {
  const [value, setValue] = useState('table');
  return (
    <div className="p-6 bg-muted rounded-lg">
      <ToggleButtons value={value} onValueChange={setValue}>
        <ToggleButtonItem value="table" aria-label="Table view">
          <Icon type="Table2" className="size-4" />
        </ToggleButtonItem>
        <ToggleButtonItem value="list" aria-label="List view">
          <Icon type="List" className="size-4" />
        </ToggleButtonItem>
        <ToggleButtonItem value="menu" aria-label="Menu view">
          <Icon type="Menu" className="size-4" />
        </ToggleButtonItem>
      </ToggleButtons>
    </div>
  );
}

// Icon Only
export const IconOnly: Story = {
  render: () => <IconOnlyExample />,
  parameters: {
    layout: 'centered',
  },
};

// Disabled
export const Disabled: Story = {
  render: () => (
    <div className="p-6 bg-muted rounded-lg">
      <ToggleButtons defaultValue="today" disabled>
        <ToggleButtonItem value="today">Today</ToggleButtonItem>
        <ToggleButtonItem value="this-week">This week</ToggleButtonItem>
        <ToggleButtonItem value="this-month">This month</ToggleButtonItem>
      </ToggleButtons>
    </div>
  ),
  parameters: {
    layout: 'centered',
  },
};
