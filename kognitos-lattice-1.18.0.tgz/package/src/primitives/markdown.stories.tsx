import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Markdown,
  type TextLevel,
  type TextColor,
  type TextWeight,
} from '@/design-system';

const meta: Meta<typeof Markdown> = {
  title: 'Design System/Primitives/General/Markdown',
  component: Markdown,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          "Markdown component that renders markdown content using design system components. Provides consistent styling for markdown elements (headings, paragraphs, links, code blocks, etc.) using the design system's Text and Title components.",
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
  argTypes: {
    children: {
      control: { type: 'text' },
      description: 'The markdown content to render',
    },
    textProps: {
      control: { type: 'object' },
      description: 'Text styling properties to apply to markdown elements',
    },
    className: {
      control: { type: 'text' },
      description: 'Additional className for the wrapper element',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Markdown>;

/**
 * Interactive Markdown component with controls.
 * Adjust the props using the controls panel to see real-time changes.
 */
export const Default: Story = {
  args: {
    children: `# Welcome to Markdown

This is a **markdown** component that renders content using design system components.

You can use *italic* text, \`inline code\`, and [links](https://example.com).`,
    textProps: {
      level: 'base',
      color: 'default',
      weight: 'normal',
    },
  },
  parameters: {
    docs: {
      description: {
        story:
          'Interactive Markdown component with controls. Adjust the props using the controls panel to see real-time changes.',
      },
    },
  },
};

/**
 * Basic markdown example with common formatting.
 */
export const Basic: Story = {
  args: {
    children: `# Heading 1

This is a paragraph with **bold text** and *italic text*.

## Heading 2

You can also use \`inline code\` in your text.

### Heading 3

Here's a [link to example.com](https://example.com) that opens in a new tab.`,
  },
  parameters: {
    docs: {
      description: {
        story: 'Basic markdown example with common formatting features.',
      },
    },
  },
};

/**
 * All markdown features showcase.
 */
export const AllFeatures: Story = {
  args: {
    children: `# Welcome to Markdown Support

This message demonstrates **all** the markdown features supported in the Markdown component.

## Text Formatting

You can use **bold text**, *italic text*, and \`inline code\` in your messages.

## Code Blocks

Here's a code block example:

\`\`\`javascript
function greet(name) {
  return \`Hello, \${name}!\`;
}

const greeting = greet('World');
console.log(greeting);
\`\`\`

## Lists

### Unordered List

- First item
- Second item
- Third item with **bold** and *italic*
- Nested item
  - Sub-item one
  - Sub-item two

### Ordered List

1. First step
2. Second step
3. Third step
4. Fourth step with a [link](https://example.com)

## Links

Visit [our documentation](https://example.com/docs) for more information.

You can also use [links with custom text](https://example.com) that open in new tabs.

## Blockquotes

> This is a blockquote. It's useful for highlighting important information or quotes.
> 
> You can have multiple paragraphs in a blockquote.

## Headings

# Heading 1

## Heading 2

### Heading 3

#### Heading 4

## Horizontal Rule

---

That's all the markdown features!`,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Comprehensive example showcasing all supported markdown features including headings, text formatting, code blocks, lists, links, blockquotes, and horizontal rules.',
      },
    },
  },
};

/**
 * Text level variations.
 */
export const TextLevels: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Markdown rendered with different text level props.',
      },
    },
  },
  render: () => {
    const sampleMarkdown = `# Heading Example

This is a paragraph with **bold** and *italic* text.

- List item one
- List item two

\`inline code\` example`;

    return (
      <div className="space-y-6">
        <h3 className="text-lg font-semibold text-foreground">Text Levels</h3>
        {(['small', 'base', 'large'] as TextLevel[]).map(level => (
          <div key={level} className="space-y-2">
            <div className="text-sm font-mono text-muted-foreground">
              level="{level}"
            </div>
            <div className="p-4 border border-border rounded-lg">
              <Markdown
                textProps={{ level, color: 'default', weight: 'normal' }}
              >
                {sampleMarkdown}
              </Markdown>
            </div>
          </div>
        ))}
      </div>
    );
  },
};

/**
 * Text color variations.
 */
export const TextColors: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Markdown rendered with different text color props.',
      },
    },
  },
  render: () => {
    const sampleMarkdown = `# Colored Heading

This paragraph uses the specified color.

- List item
- Another item

\`code\` example`;

    return (
      <div className="space-y-6">
        <h3 className="text-lg font-semibold text-foreground">Text Colors</h3>
        {(
          [
            'default',
            'muted',
            'primary',
            'secondary',
            'accent',
            'destructive',
          ] as TextColor[]
        ).map(color => (
          <div key={color} className="space-y-2">
            <div className="text-sm font-mono text-muted-foreground">
              color="{color}"
            </div>
            <div className="p-4 border border-border rounded-lg">
              <Markdown textProps={{ level: 'base', color, weight: 'normal' }}>
                {sampleMarkdown}
              </Markdown>
            </div>
          </div>
        ))}
      </div>
    );
  },
};

/**
 * Text weight variations.
 */
export const TextWeights: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Markdown rendered with different text weight props.',
      },
    },
  },
  render: () => {
    const sampleMarkdown = `# Weighted Heading

This paragraph uses the specified weight.

- List item
- Another item

**Bold text** and *italic text*`;

    return (
      <div className="space-y-6">
        <h3 className="text-lg font-semibold text-foreground">Text Weights</h3>
        {(['normal', 'medium', 'semibold', 'bold'] as TextWeight[]).map(
          weight => (
            <div key={weight} className="space-y-2">
              <div className="text-sm font-mono text-muted-foreground">
                weight="{weight}"
              </div>
              <div className="p-4 border border-border rounded-lg">
                <Markdown
                  textProps={{ level: 'base', color: 'default', weight }}
                >
                  {sampleMarkdown}
                </Markdown>
              </div>
            </div>
          ),
        )}
      </div>
    );
  },
};

/**
 * Code examples with different languages.
 */
export const CodeExamples: Story = {
  args: {
    children: `# Code Examples

## JavaScript

\`\`\`javascript
function calculateTotal(items) {
  return items.reduce((sum, item) => sum + item.price, 0);
}
\`\`\`

## TypeScript

\`\`\`typescript
interface IUser {
  id: string;
  name: string;
  email: string;
}

const user: IUser = {
  id: '1',
  name: 'John Doe',
  email: 'john@example.com',
};
\`\`\`

## Inline Code

You can use \`inline code\` anywhere in your text, like \`const x = 42\` or \`function() {}\`.`,
  },
  parameters: {
    docs: {
      description: {
        story: 'Examples of code blocks and inline code rendering in markdown.',
      },
    },
  },
};

/**
 * List examples with nested items.
 */
export const Lists: Story = {
  args: {
    children: `# List Examples

## Unordered List

- First item
- Second item
- Third item
  - Nested item 1
  - Nested item 2
    - Deeply nested item
- Fourth item

## Ordered List

1. First step
2. Second step
3. Third step
   1. Sub-step A
   2. Sub-step B
4. Fourth step

## Mixed Content Lists

- Item with **bold text**
- Item with *italic text*
- Item with \`code\`
- Item with a [link](https://example.com)
- Item with multiple formats: **bold**, *italic*, and \`code\``,
  },
  parameters: {
    docs: {
      description: {
        story: 'Examples of ordered and unordered lists with nested items.',
      },
    },
  },
};

/**
 * Link examples including security validation.
 */
export const Links: Story = {
  args: {
    children: `# Link Examples

## Valid Links

- [HTTP link](http://example.com)
- [HTTPS link](https://example.com)
- [Link with custom text](https://example.com/docs/getting-started)

## Security

Dangerous protocols like \`javascript:\` and \`data:\` are automatically blocked for security.

Invalid or dangerous links will be rendered as plain text instead of clickable links.`,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Examples of links in markdown. Note that only HTTP and HTTPS protocols are allowed for security.',
      },
    },
  },
};

/**
 * Blockquote examples.
 */
export const Blockquotes: Story = {
  args: {
    children: `# Blockquote Examples

> This is a simple blockquote.

> This is a blockquote with **bold text** and *italic text*.

> This is a multi-paragraph blockquote.
> 
> It can contain multiple paragraphs.
> 
> Each paragraph is part of the same blockquote.

> You can also include lists in blockquotes:
> 
> - Item one
> - Item two
> - Item three`,
  },
  parameters: {
    docs: {
      description: {
        story: 'Examples of blockquotes with various content types.',
      },
    },
  },
};

/**
 * Real-world usage examples.
 */
export const RealWorldExamples: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Real-world examples of Markdown component usage in different contexts.',
      },
    },
  },
  render: () => (
    <div className="space-y-8">
      <h3 className="text-lg font-semibold text-foreground">
        Real-world Examples
      </h3>

      {/* Documentation Example */}
      <div className="space-y-2">
        <div className="text-sm font-mono text-muted-foreground">
          Documentation / Help Text
        </div>
        <div className="p-4 border border-border rounded-lg">
          <Markdown textProps={{ level: 'base', color: 'default' }}>
            {`# Getting Started

Follow these steps to get started:

1. Install the package
2. Configure your settings
3. Start using the component

For more information, visit our [documentation](https://example.com/docs).`}
          </Markdown>
        </div>
      </div>

      {/* Error Message Example */}
      <div className="space-y-2">
        <div className="text-sm font-mono text-muted-foreground">
          Error Message
        </div>
        <div className="p-4 border border-border rounded-lg bg-destructive/10">
          <Markdown textProps={{ level: 'small', color: 'destructive' }}>
            {`# Error: Validation Failed

The following issues were found:

- **Email**: Invalid format
- **Password**: Must be at least 8 characters
- **Username**: Already taken

Please fix these errors and try again.`}
          </Markdown>
        </div>
      </div>

      {/* Success Message Example */}
      <div className="space-y-2">
        <div className="text-sm font-mono text-muted-foreground">
          Success Message
        </div>
        <div className="p-4 border border-border rounded-lg bg-primary/10">
          <Markdown textProps={{ level: 'base', color: 'primary' }}>
            {`# Success!

Your changes have been saved successfully.

**Next steps:**
- Review your changes
- Share with your team
- Continue working

> Tip: You can always revert changes if needed.`}
          </Markdown>
        </div>
      </div>

      {/* Muted / Secondary Content */}
      <div className="space-y-2">
        <div className="text-sm font-mono text-muted-foreground">
          Muted / Secondary Content
        </div>
        <div className="p-4 border border-border rounded-lg">
          <Markdown textProps={{ level: 'small', color: 'muted' }}>
            {`## Additional Information

This is secondary content that provides context or additional details.

- Item one
- Item two
- Item three

For more details, see the [full documentation](https://example.com).`}
          </Markdown>
        </div>
      </div>

      {/* Code Documentation */}
      <div className="space-y-2">
        <div className="text-sm font-mono text-muted-foreground">
          Code Documentation
        </div>
        <div className="p-4 border border-border rounded-lg">
          <Markdown textProps={{ level: 'base', color: 'default' }}>
            {`# API Reference

## \`calculateTotal(items)\`

Calculates the total price of all items.

\`\`\`typescript
function calculateTotal(items: Item[]): number {
  return items.reduce((sum, item) => sum + item.price, 0);
}
\`\`\`

**Parameters:**
- \`items\`: Array of items with price property

**Returns:** Total price as a number`}
          </Markdown>
        </div>
      </div>
    </div>
  ),
};
