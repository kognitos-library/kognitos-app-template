import type { Meta, StoryObj } from '@storybook/react';
import React from 'react';
import { StepperCard, type IStepperCardItemData } from './stepper-card';
import { Flex } from './flex';
import { Button } from './button';

const meta = {
  title: 'Design System/Primitives/Navigation/StepperCard',
  component: StepperCard,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A stepper card component for multi-step processes. Supports both controlled and uncontrolled modes. Disabled steps cannot be selected.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    direction: {
      control: { type: 'select' },
      options: ['row', 'column'],
      description: 'Layout direction of the stepper card',
    },
    current: {
      control: { type: 'text' },
      description:
        'Controlled: Current selected step key (parent manages state)',
    },
    defaultCurrent: {
      control: { type: 'text' },
      description:
        'Uncontrolled: Initial selected step key (internal state management)',
    },
  },
} satisfies Meta<typeof StepperCard>;

export default meta;
type Story = StoryObj<typeof meta>;

const defaultSteps: IStepperCardItemData[] = [
  {
    key: '1',
    title: 'Account Details',
    description: 'Completed',
    state: 'completed',
  },
  { key: '2', title: 'Preferences', description: 'In progress' },
  {
    key: '3',
    title: 'Review & Submit',
    description: 'Pending',
    state: 'disabled',
  },
];

// Basic usage example
export const Default: Story = {
  args: {
    steps: defaultSteps,
    defaultCurrent: '1',
    direction: 'row',
    className: 'w-[600px]',
  },
};

// Column direction
export const ColumnDirection: Story = {
  args: {
    steps: defaultSteps,
    defaultCurrent: '1',
    direction: 'column',
    className: 'w-[400px]',
  },
};

// Without descriptions
export const WithoutDescriptions: Story = {
  args: {
    steps: [
      { key: '1', title: 'Step 1', state: 'completed' },
      { key: '2', title: 'Step 2' },
      { key: '3', title: 'Step 3', state: 'disabled' },
    ],
    defaultCurrent: '1',
    className: 'w-[600px]',
  },
};

// Loading state example
export const LoadingExample: Story = {
  args: {
    steps: [
      {
        key: '1',
        title: 'Upload',
        description: 'File uploaded',
        state: 'completed',
      },
      {
        key: '2',
        title: 'Processing',
        description: 'Analyzing data...',
        state: 'loading',
      },
      {
        key: '3',
        title: 'Complete',
        description: 'Waiting',
        state: 'disabled',
      },
    ],
    defaultCurrent: '2',
    className: 'w-[600px]',
  },
};

// Controlled mode example (parent manages state)
export const ControlledMode: Story = {
  args: {
    steps: [],
  },
  parameters: {
    docs: {
      description: {
        story:
          'In controlled mode, the parent manages selection state via `current` and `onStepClick` props. Useful for wizard flows where step progression is controlled externally.',
      },
    },
  },
  render: function ControlledStepperCard() {
    const [currentStep, setCurrentStep] = React.useState('1');

    const steps: IStepperCardItemData[] = [
      {
        key: '1',
        title: 'Test Environment',
        state: currentStep === '2' ? 'completed' : 'default',
      },
      {
        key: '2',
        title: 'Production Environment',
        state: currentStep === '1' ? 'disabled' : 'default',
      },
    ];

    return (
      <Flex direction="column" align="center" gap={4} className="w-[500px]">
        <StepperCard
          steps={steps}
          current={currentStep}
          onStepClick={setCurrentStep}
        />
        <Flex gap={2}>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setCurrentStep('1')}
            disabled={currentStep === '1'}
          >
            Back to Test
          </Button>
          <Button
            size="sm"
            onClick={() => setCurrentStep('2')}
            disabled={currentStep === '2'}
          >
            Go to Production
          </Button>
        </Flex>
      </Flex>
    );
  },
};

// Responsive grid layout example
export const ResponsiveGrid: Story = {
  args: {
    steps: [
      {
        key: '1',
        title: 'Step 1',
        description: 'First step',
        state: 'completed',
      },
      {
        key: '2',
        title: 'Step 2',
        description: 'Second step',
        state: 'completed',
      },
      { key: '3', title: 'Step 3', description: 'Third step' },
      {
        key: '4',
        title: 'Step 4',
        description: 'Fourth step',
        state: 'disabled',
      },
    ],
    defaultCurrent: '3',
    xs: 1,
    sm: 2,
    md: 4,
  },
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        story:
          'Use responsive breakpoint props (xs, sm, md, lg, xl, 2xl) to define the number of columns at each screen size. Resize the browser to see the layout change.',
      },
    },
  },
  render: args => (
    <div className="p-4 w-full">
      <StepperCard {...args} />
    </div>
  ),
};

// Responsive grid with more steps
export const ResponsiveGridManySteps: Story = {
  args: {
    steps: [
      {
        key: '1',
        title: 'Account',
        description: 'Create account',
        state: 'completed',
      },
      {
        key: '2',
        title: 'Profile',
        description: 'Setup profile',
        state: 'completed',
      },
      {
        key: '3',
        title: 'Preferences',
        description: 'Set preferences',
        state: 'completed',
      },
      { key: '4', title: 'Verification', description: 'Verify email' },
      {
        key: '5',
        title: 'Payment',
        description: 'Add payment',
        state: 'disabled',
      },
      {
        key: '6',
        title: 'Review',
        description: 'Final review',
        state: 'disabled',
      },
    ],
    defaultCurrent: '4',
    xs: 1,
    sm: 2,
    md: 3,
  },
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        story:
          'Example with 6 steps showing responsive behavior: 1 column on mobile, 2 on small screens, 3 on medium, and all 3 on large screens.',
      },
    },
  },
  render: args => (
    <div className="p-4 w-full">
      <StepperCard {...args} />
    </div>
  ),
};
