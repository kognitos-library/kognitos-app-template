import type { Meta, StoryObj } from '@storybook/react';
import { StepIndicator } from './step-indicator';

const meta = {
  title: 'Design System/Primitives/Navigation/StepIndicator',
  component: StepIndicator,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A step indicator component that displays progress through a multi-step process. Supports different sizes, variants, and is fully accessible.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    currentStep: {
      control: { type: 'number', min: 1, max: 10 },
      description: 'The current active step (1-based index)',
    },
    totalSteps: {
      control: { type: 'number', min: 1, max: 10 },
      description: 'Total number of steps',
    },
    size: {
      control: { type: 'select' },
      options: ['sm', 'md', 'lg'],
      description: 'Size of the step indicators',
    },
    variant: {
      control: { type: 'select' },
      options: ['default', 'outlined'],
      description: 'Visual variant of the step indicators',
    },
    gap: {
      control: { type: 'number', min: 1, max: 8 },
      description: 'Gap between step indicators',
    },
  },
} satisfies Meta<typeof StepIndicator>;

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {
    currentStep: 2,
    totalSteps: 4,
  },
};

export const FirstStep: Story = {
  args: {
    currentStep: 1,
    totalSteps: 5,
  },
};

export const LastStep: Story = {
  args: {
    currentStep: 4,
    totalSteps: 4,
  },
};

export const Small: Story = {
  args: {
    currentStep: 2,
    totalSteps: 3,
    size: 'sm',
  },
};

export const Large: Story = {
  args: {
    currentStep: 3,
    totalSteps: 5,
    size: 'lg',
  },
};

export const Outlined: Story = {
  args: {
    currentStep: 2,
    totalSteps: 4,
    variant: 'outlined',
  },
};

export const OutlinedLarge: Story = {
  args: {
    currentStep: 1,
    totalSteps: 3,
    size: 'lg',
    variant: 'outlined',
  },
};

export const ManySteps: Story = {
  args: {
    currentStep: 4,
    totalSteps: 8,
    size: 'sm',
  },
};

export const CustomGap: Story = {
  args: {
    currentStep: 2,
    totalSteps: 4,
    gap: 4,
  },
};

export const Interactive: Story = {
  args: {
    currentStep: 1,
    totalSteps: 5,
  },
  render: function InteractiveStepIndicator(args) {
    const [currentStep, setCurrentStep] = React.useState(args.currentStep);

    React.useEffect(() => {
      setCurrentStep(args.currentStep);
    }, [args.currentStep]);

    return (
      <div className="flex flex-col items-center gap-4">
        <StepIndicator {...args} currentStep={currentStep} />
        <div className="flex gap-2">
          <button
            className="px-3 py-1 bg-primary text-primary-foreground rounded disabled:opacity-50"
            onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
            disabled={currentStep <= 1}
          >
            Previous
          </button>
          <button
            className="px-3 py-1 bg-primary text-primary-foreground rounded disabled:opacity-50"
            onClick={() =>
              setCurrentStep(Math.min(args.totalSteps, currentStep + 1))
            }
            disabled={currentStep >= args.totalSteps}
          >
            Next
          </button>
        </div>
        <p className="text-sm text-muted-foreground">
          Step {currentStep} of {args.totalSteps}
        </p>
      </div>
    );
  },
};

// Import React for the Interactive story
import React from 'react';
