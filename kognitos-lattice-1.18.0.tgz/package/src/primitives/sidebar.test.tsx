import {
  render,
  screen,
  fireEvent,
  waitFor,
  act,
} from '@testing-library/react';
import { userEvent } from '@testing-library/user-event';
import {
  SidebarProvider,
  Sidebar,
  SidebarTrigger,
  SidebarRail,
  SidebarInset,
  SidebarInput,
  SidebarHeader,
  SidebarFooter,
  SidebarSeparator,
  SidebarContent,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubItem,
  SidebarMenuSubButton,
  useSidebar,
} from './sidebar';

// Mock the useIsMobile hook
vi.mock('@/design-system/hooks/use-mobile', () => ({
  useIsMobile: vi.fn(() => false),
}));

import { useIsMobile } from '@/design-system/hooks/use-mobile';
import { beforeEach, describe, expect, it, vi } from 'vitest';
const mockUseIsMobile = vi.mocked(useIsMobile);

// Test helper component to access the useSidebar hook
function SidebarHookTester({
  onContextValue,
}: {
  onContextValue: (value: ReturnType<typeof useSidebar>) => void;
}) {
  const context = useSidebar();
  onContextValue(context);
  return null;
}

describe('Sidebar', () => {
  beforeEach(() => {
    mockUseIsMobile.mockReturnValue(false);
    vi.clearAllMocks();
  });

  describe('SidebarProvider', () => {
    it('should render with correct structure and CSS variables', () => {
      render(
        <SidebarProvider className="custom-class">
          <div data-testid="child">Content</div>
        </SidebarProvider>,
      );

      const wrapper = screen.getByTestId('sidebar-wrapper');
      expect(wrapper).toBeInTheDocument();
      expect(wrapper).toHaveAttribute('data-slot', 'sidebar-wrapper');
      expect(wrapper).toHaveClass('custom-class');
      expect(wrapper).toHaveStyle({ '--sidebar-width': '16rem' });
      expect(wrapper).toHaveStyle({ '--sidebar-width-icon': '3rem' });
      expect(screen.getByTestId('child')).toBeInTheDocument();
    });

    it('should manage open state correctly', () => {
      let contextValue: ReturnType<typeof useSidebar> | undefined;

      // Test default open
      render(
        <SidebarProvider>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
        </SidebarProvider>,
      );

      expect(contextValue?.open).toBe(true);
      expect(contextValue?.state).toBe('expanded');
    });

    it('should respect defaultOpen=false', () => {
      let contextValue: ReturnType<typeof useSidebar> | undefined;

      render(
        <SidebarProvider defaultOpen={false}>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
        </SidebarProvider>,
      );

      expect(contextValue?.open).toBe(false);
      expect(contextValue?.state).toBe('collapsed');
    });

    it('should support controlled mode with onOpenChange', () => {
      const onOpenChange = vi.fn();
      let contextValue: ReturnType<typeof useSidebar> | undefined;

      render(
        <SidebarProvider open onOpenChange={onOpenChange}>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
        </SidebarProvider>,
      );

      contextValue?.setOpen(false);
      expect(onOpenChange).toHaveBeenCalledWith(false);
    });

    it('should handle keyboard shortcuts', async () => {
      let contextValue: ReturnType<typeof useSidebar> | undefined;

      render(
        <SidebarProvider>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
        </SidebarProvider>,
      );

      expect(contextValue?.open).toBe(true);

      // Test with metaKey
      fireEvent.keyDown(window, { key: 'b', metaKey: true });
      await waitFor(() => expect(contextValue?.open).toBe(false));

      // Test with ctrlKey
      fireEvent.keyDown(window, { key: 'b', ctrlKey: true });
      await waitFor(() => expect(contextValue?.open).toBe(true));

      // Without modifier - should not toggle
      fireEvent.keyDown(window, { key: 'b' });
      await waitFor(() => expect(contextValue?.open).toBe(true));
    });
  });

  describe('useSidebar hook', () => {
    it('should throw error when used outside SidebarProvider', () => {
      const consoleError = vi
        .spyOn(console, 'error')
        .mockImplementation(() => {});

      expect(() => {
        render(<SidebarHookTester onContextValue={() => {}} />);
      }).toThrow('useSidebar must be used within a SidebarProvider.');

      consoleError.mockRestore();
    });

    it('should provide toggle functionality for desktop and mobile', async () => {
      let contextValue: ReturnType<typeof useSidebar> | undefined;

      // Desktop toggle
      render(
        <SidebarProvider>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
        </SidebarProvider>,
      );

      expect(contextValue?.isMobile).toBe(false);
      expect(contextValue?.open).toBe(true);

      act(() => contextValue?.toggleSidebar());
      await waitFor(() => expect(contextValue?.open).toBe(false));

      // Mobile toggle
      mockUseIsMobile.mockReturnValue(true);
      const { unmount } = render(
        <SidebarProvider>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
        </SidebarProvider>,
      );

      expect(contextValue?.isMobile).toBe(true);
      expect(contextValue?.openMobile).toBe(false);

      act(() => contextValue?.toggleSidebar());
      await waitFor(() => expect(contextValue?.openMobile).toBe(true));

      unmount();
      mockUseIsMobile.mockReturnValue(false);
    });
  });

  describe('Sidebar Component', () => {
    it('should render with different variants and sides', () => {
      const { rerender } = render(
        <SidebarProvider>
          <Sidebar collapsible="none" data-testid="sidebar">
            <div>Content</div>
          </Sidebar>
        </SidebarProvider>,
      );

      expect(screen.getByTestId('sidebar')).toHaveAttribute(
        'data-slot',
        'sidebar',
      );

      // Test different props
      rerender(
        <SidebarProvider>
          <Sidebar side="right" variant="floating">
            <div>Content</div>
          </Sidebar>
        </SidebarProvider>,
      );

      expect(document.querySelector('[data-side="right"]')).toBeInTheDocument();
      expect(
        document.querySelector('[data-variant="floating"]'),
      ).toBeInTheDocument();
    });

    it('should render as Sheet on mobile', () => {
      mockUseIsMobile.mockReturnValue(true);

      render(
        <SidebarProvider>
          <Sidebar>
            <div data-testid="mobile-content">Mobile Content</div>
          </Sidebar>
        </SidebarProvider>,
      );

      // Content not visible when closed
      expect(screen.queryByTestId('mobile-content')).not.toBeInTheDocument();

      mockUseIsMobile.mockReturnValue(false);
    });
  });

  describe('SidebarTrigger', () => {
    it('should toggle sidebar and handle props correctly', async () => {
      const user = userEvent.setup();
      const handleClick = vi.fn();
      let contextValue: ReturnType<typeof useSidebar> | undefined;

      render(
        <SidebarProvider>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
          <SidebarTrigger
            data-testid="trigger"
            onClick={handleClick}
            className="custom-trigger"
          />
        </SidebarProvider>,
      );

      const trigger = screen.getByTestId('trigger');
      expect(trigger).toHaveClass('custom-trigger', 'size-7');
      expect(trigger).toHaveAttribute('aria-expanded', 'true');
      expect(screen.getByText('Toggle Sidebar')).toHaveClass('sr-only');

      await user.click(trigger);
      expect(handleClick).toHaveBeenCalled();
      await waitFor(() =>
        expect(trigger).toHaveAttribute('aria-expanded', 'false'),
      );

      // Test toggleOnClick=false
      render(
        <SidebarProvider>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
          <SidebarTrigger data-testid="trigger2" toggleOnClick={false} />
        </SidebarProvider>,
      );

      const initialOpen = contextValue?.open;
      await user.click(screen.getByTestId('trigger2'));
      expect(contextValue?.open).toBe(initialOpen);
    });
  });

  describe('SidebarRail', () => {
    it('should render with correct attributes and toggle on click', async () => {
      const user = userEvent.setup();
      let contextValue: ReturnType<typeof useSidebar> | undefined;

      render(
        <SidebarProvider>
          <SidebarHookTester onContextValue={v => (contextValue = v)} />
          <SidebarRail data-testid="rail" className="custom-rail" />
        </SidebarProvider>,
      );

      const rail = screen.getByTestId('rail');
      expect(rail).toHaveAttribute('data-sidebar', 'rail');
      expect(rail).toHaveAttribute('data-slot', 'sidebar-rail');
      expect(rail).toHaveAttribute('aria-label', 'Toggle sidebar');
      expect(rail).toHaveAttribute('tabIndex', '-1');
      expect(rail).toHaveClass('custom-rail');

      expect(contextValue?.open).toBe(true);
      await user.click(rail);
      await waitFor(() => expect(contextValue?.open).toBe(false));
    });
  });

  describe('Layout Components', () => {
    it('should render SidebarInset, Header, Footer, Content, and Separator', () => {
      render(
        <SidebarProvider>
          <SidebarInset data-testid="inset" className="custom-inset">
            <SidebarHeader data-testid="header" className="custom-header">
              Header
            </SidebarHeader>
            <SidebarContent data-testid="content" className="custom-content">
              Content
            </SidebarContent>
            <SidebarSeparator
              data-testid="separator"
              className="custom-separator"
            />
            <SidebarFooter data-testid="footer" className="custom-footer">
              Footer
            </SidebarFooter>
          </SidebarInset>
        </SidebarProvider>,
      );

      const inset = screen.getByTestId('inset');
      expect(inset.tagName).toBe('MAIN');
      expect(inset).toHaveAttribute('data-slot', 'sidebar-inset');
      expect(inset).toHaveClass('custom-inset');

      const header = screen.getByTestId('header');
      expect(header).toHaveAttribute('data-sidebar', 'header');
      expect(header).toHaveClass('custom-header');

      const content = screen.getByTestId('content');
      expect(content).toHaveAttribute('data-sidebar', 'content');
      expect(content).toHaveClass('custom-content');

      const separator = screen.getByTestId('separator');
      expect(separator).toHaveAttribute('data-sidebar', 'separator');
      expect(separator).toHaveClass('custom-separator');

      const footer = screen.getByTestId('footer');
      expect(footer).toHaveAttribute('data-sidebar', 'footer');
      expect(footer).toHaveClass('custom-footer');
    });

    it('should render SidebarInput with correct attributes', () => {
      render(
        <SidebarProvider>
          <SidebarInput
            data-testid="input"
            className="custom-input"
            placeholder="Search..."
          />
        </SidebarProvider>,
      );

      const input = screen.getByTestId('input');
      expect(input).toHaveAttribute('data-slot', 'sidebar-input');
      expect(input).toHaveAttribute('data-sidebar', 'input');
      expect(input).toHaveAttribute('placeholder', 'Search...');
      expect(input).toHaveClass('custom-input');
    });
  });

  describe('Group Components', () => {
    it('should render Group, Label, Action, and Content with asChild support', () => {
      render(
        <SidebarProvider>
          <SidebarGroup data-testid="group" className="custom-group">
            <SidebarGroupLabel data-testid="label" className="custom-label">
              Label
            </SidebarGroupLabel>
            <SidebarGroupAction data-testid="action" className="custom-action">
              Action
            </SidebarGroupAction>
            <SidebarGroupContent
              data-testid="group-content"
              className="custom-content"
            >
              Content
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarProvider>,
      );

      expect(screen.getByTestId('group')).toHaveAttribute(
        'data-sidebar',
        'group',
      );
      expect(screen.getByTestId('label')).toHaveAttribute(
        'data-sidebar',
        'group-label',
      );
      expect(screen.getByTestId('action')).toHaveAttribute(
        'data-sidebar',
        'group-action',
      );
      expect(screen.getByTestId('group-content')).toHaveAttribute(
        'data-sidebar',
        'group-content',
      );

      // Test asChild
      render(
        <SidebarProvider>
          <SidebarGroupLabel asChild>
            <span data-testid="child-label">Custom</span>
          </SidebarGroupLabel>
          <SidebarGroupAction asChild>
            <a data-testid="child-action" href="#">
              Link
            </a>
          </SidebarGroupAction>
        </SidebarProvider>,
      );

      expect(screen.getByTestId('child-label').tagName).toBe('SPAN');
      expect(screen.getByTestId('child-action').tagName).toBe('A');
    });
  });

  describe('Menu Components', () => {
    it('should render Menu and MenuItem correctly', () => {
      render(
        <SidebarProvider>
          <SidebarMenu data-testid="menu" className="custom-menu">
            <SidebarMenuItem data-testid="item" className="custom-item">
              Item
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarProvider>,
      );

      const menu = screen.getByTestId('menu');
      expect(menu.tagName).toBe('UL');
      expect(menu).toHaveAttribute('data-sidebar', 'menu');
      expect(menu).toHaveClass('custom-menu');

      const item = screen.getByTestId('item');
      expect(item.tagName).toBe('LI');
      expect(item).toHaveAttribute('data-sidebar', 'menu-item');
    });

    it('should render MenuButton with all variants and sizes', () => {
      const { rerender } = render(
        <SidebarProvider>
          <SidebarMenuButton
            data-testid="button"
            size="default"
            isActive
            className="custom-button"
          >
            Button
          </SidebarMenuButton>
        </SidebarProvider>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveAttribute('data-size', 'default');
      expect(button).toHaveAttribute('data-active', 'true');
      expect(button).toHaveClass('custom-button');

      // Test different sizes
      ['sm', 'md', 'lg'].forEach(size => {
        rerender(
          <SidebarProvider>
            <SidebarMenuButton
              data-testid="button"
              size={size as 'sm' | 'md' | 'lg'}
            >
              Button
            </SidebarMenuButton>
          </SidebarProvider>,
        );
        expect(screen.getByTestId('button')).toHaveAttribute('data-size', size);
      });

      // Test outline variant
      rerender(
        <SidebarProvider>
          <SidebarMenuButton data-testid="button" variant="outline">
            Button
          </SidebarMenuButton>
        </SidebarProvider>,
      );
      expect(screen.getByTestId('button')).toHaveClass('bg-background');

      // Test asChild
      rerender(
        <SidebarProvider>
          <SidebarMenuButton asChild>
            <a data-testid="link-button" href="#">
              Link
            </a>
          </SidebarMenuButton>
        </SidebarProvider>,
      );
      expect(screen.getByTestId('link-button').tagName).toBe('A');

      // Test tooltip
      rerender(
        <SidebarProvider defaultOpen={false}>
          <SidebarMenuButton data-testid="button" tooltip="Tooltip text">
            Button
          </SidebarMenuButton>
        </SidebarProvider>,
      );
      expect(screen.getByTestId('button')).toBeInTheDocument();
    });

    it('should render MenuAction with showOnHover', () => {
      const { rerender } = render(
        <SidebarProvider>
          <SidebarMenuAction data-testid="action" showOnHover>
            Action
          </SidebarMenuAction>
        </SidebarProvider>,
      );

      expect(screen.getByTestId('action')).toHaveClass('md:opacity-0');

      rerender(
        <SidebarProvider>
          <SidebarMenuAction data-testid="action" asChild>
            <a href="#">Link</a>
          </SidebarMenuAction>
        </SidebarProvider>,
      );
      expect(screen.getByRole('link')).toHaveAttribute(
        'data-sidebar',
        'menu-action',
      );
    });

    it('should render MenuBadge and MenuSkeleton', () => {
      const { container } = render(
        <SidebarProvider>
          <SidebarMenuBadge data-testid="badge" className="custom-badge">
            5
          </SidebarMenuBadge>
          <SidebarMenuSkeleton data-testid="skeleton" showIcon />
        </SidebarProvider>,
      );

      expect(screen.getByTestId('badge')).toHaveAttribute(
        'data-sidebar',
        'menu-badge',
      );
      expect(screen.getByText('5')).toBeInTheDocument();

      expect(screen.getByTestId('skeleton')).toHaveAttribute(
        'data-sidebar',
        'menu-skeleton',
      );
      expect(
        container.querySelector('[data-sidebar="menu-skeleton-icon"]'),
      ).toBeInTheDocument();
      expect(
        container.querySelector('[data-sidebar="menu-skeleton-text"]'),
      ).toBeInTheDocument();
    });
  });

  describe('SubMenu Components', () => {
    it('should render SubMenu, SubItem, and SubButton correctly', () => {
      render(
        <SidebarProvider>
          <SidebarMenuSub data-testid="sub-menu" className="custom-sub-menu">
            <SidebarMenuSubItem
              data-testid="sub-item"
              className="custom-sub-item"
            >
              <SidebarMenuSubButton
                data-testid="sub-button"
                size="sm"
                isActive
                className="custom-sub-button"
              >
                Sub Button
              </SidebarMenuSubButton>
            </SidebarMenuSubItem>
          </SidebarMenuSub>
        </SidebarProvider>,
      );

      const subMenu = screen.getByTestId('sub-menu');
      expect(subMenu.tagName).toBe('UL');
      expect(subMenu).toHaveAttribute('data-sidebar', 'menu-sub');
      expect(subMenu).toHaveClass('custom-sub-menu');

      const subItem = screen.getByTestId('sub-item');
      expect(subItem.tagName).toBe('LI');
      expect(subItem).toHaveAttribute('data-sidebar', 'menu-sub-item');

      const subButton = screen.getByTestId('sub-button');
      expect(subButton.tagName).toBe('A');
      expect(subButton).toHaveAttribute('data-size', 'sm');
      expect(subButton).toHaveAttribute('data-active', 'true');
      expect(subButton).toHaveClass('text-xs', 'custom-sub-button');

      // Test asChild
      render(
        <SidebarProvider>
          <SidebarMenuSubButton asChild>
            <button data-testid="child-sub-button">Button</button>
          </SidebarMenuSubButton>
        </SidebarProvider>,
      );
      expect(screen.getByTestId('child-sub-button').tagName).toBe('BUTTON');
    });
  });

  describe('Integration', () => {
    it('should render complete sidebar structure', () => {
      render(
        <SidebarProvider>
          <Sidebar collapsible="none">
            <SidebarHeader>Logo</SidebarHeader>
            <SidebarContent>
              <SidebarGroup>
                <SidebarGroupLabel>Navigation</SidebarGroupLabel>
                <SidebarGroupContent>
                  <SidebarMenu>
                    <SidebarMenuItem>
                      <SidebarMenuButton isActive>Dashboard</SidebarMenuButton>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton>Settings</SidebarMenuButton>
                      <SidebarMenuBadge>3</SidebarMenuBadge>
                    </SidebarMenuItem>
                    <SidebarMenuItem>
                      <SidebarMenuButton>Parent</SidebarMenuButton>
                      <SidebarMenuSub>
                        <SidebarMenuSubItem>
                          <SidebarMenuSubButton>Child</SidebarMenuSubButton>
                        </SidebarMenuSubItem>
                      </SidebarMenuSub>
                    </SidebarMenuItem>
                  </SidebarMenu>
                </SidebarGroupContent>
              </SidebarGroup>
            </SidebarContent>
            <SidebarFooter>Footer</SidebarFooter>
          </Sidebar>
          <SidebarInset>
            <SidebarTrigger data-testid="trigger" />
            <main>Main content</main>
          </SidebarInset>
        </SidebarProvider>,
      );

      expect(screen.getByText('Logo')).toBeInTheDocument();
      expect(screen.getByText('Navigation')).toBeInTheDocument();
      expect(screen.getByText('Dashboard')).toBeInTheDocument();
      expect(screen.getByText('Settings')).toBeInTheDocument();
      expect(screen.getByText('3')).toBeInTheDocument();
      expect(screen.getByText('Parent')).toBeInTheDocument();
      expect(screen.getByText('Child')).toBeInTheDocument();
      expect(screen.getByText('Footer')).toBeInTheDocument();
      expect(screen.getByText('Main content')).toBeInTheDocument();
    });
  });
});
