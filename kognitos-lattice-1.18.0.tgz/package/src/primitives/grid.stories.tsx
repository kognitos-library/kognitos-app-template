import type { Meta, StoryObj } from '@storybook/react-vite';
import { Grid } from './grid';
import { Card, CardContent } from './card';

const meta: Meta<typeof Grid> = {
  title: 'Design System/Primitives/Layout/Grid',
  component: Grid,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A flexible CSS Grid component with comprehensive layout options.',
      },
    },
  },
  argTypes: {
    cols: {
      control: { type: 'select' },
      options: [
        1,
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        10,
        11,
        12,
        'none',
        'auto',
        'auto-fit',
        'auto-fill',
      ],
      description: 'Number of columns in the grid',
    },
    rows: {
      control: { type: 'select' },
      options: [1, 2, 3, 4, 5, 6, 'none', 'auto', 'auto-fit', 'auto-fill'],
      description: 'Number of rows in the grid',
    },
    gap: {
      control: { type: 'select' },
      options: [0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32],
      description: 'Gap between grid items',
    },
    gapX: {
      control: { type: 'select' },
      options: [0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32],
      description: 'Horizontal gap between grid items',
    },
    gapY: {
      control: { type: 'select' },
      options: [0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24, 32],
      description: 'Vertical gap between grid items',
    },
    flow: {
      control: { type: 'select' },
      options: ['row', 'col', 'row-dense', 'col-dense'],
      description: 'Grid flow direction',
    },
    justify: {
      control: { type: 'select' },
      options: [
        'start',
        'center',
        'end',
        'between',
        'around',
        'evenly',
        'stretch',
      ],
      description: 'Justify content alignment',
    },
    align: {
      control: { type: 'select' },
      options: ['start', 'center', 'end', 'stretch', 'baseline'],
      description: 'Align items',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

// Sample grid items for demonstration
const GridItem = ({
  children,
  className = '',
}: {
  children: React.ReactNode;
  className?: string;
}) => (
  <Card className={`h-20 ${className}`}>
    <CardContent className="flex items-center justify-center h-full p-2">
      {children}
    </CardContent>
  </Card>
);

export const Default: Story = {
  args: {
    cols: 3,
    gap: 4,
    children: (
      <>
        <GridItem>Item 1</GridItem>
        <GridItem>Item 2</GridItem>
        <GridItem>Item 3</GridItem>
        <GridItem>Item 4</GridItem>
        <GridItem>Item 5</GridItem>
        <GridItem>Item 6</GridItem>
      </>
    ),
  },
};

export const ResponsiveGrid: Story = {
  args: {
    cols: 12,
    gap: 4,
    children: (
      <>
        <div className="col-span-12 md:col-span-6 lg:col-span-4">
          <GridItem>Full Width (Mobile)</GridItem>
        </div>
        <div className="col-span-12 md:col-span-6 lg:col-span-4">
          <GridItem>Half Width (Tablet)</GridItem>
        </div>
        <div className="col-span-12 md:col-span-12 lg:col-span-4">
          <GridItem>Third Width (Desktop)</GridItem>
        </div>
      </>
    ),
  },
};

export const AutoFitGrid: Story = {
  args: {
    cols: 'auto-fit',
    gap: 4,
    className: 'grid-cols-[repeat(auto-fit,minmax(200px,1fr))]',
    children: (
      <>
        <GridItem>Auto-fit Item 1</GridItem>
        <GridItem>Auto-fit Item 2</GridItem>
        <GridItem>Auto-fit Item 3</GridItem>
        <GridItem>Auto-fit Item 4</GridItem>
        <GridItem>Auto-fit Item 5</GridItem>
        <GridItem>Auto-fit Item 6</GridItem>
      </>
    ),
  },
};

export const DenseGrid: Story = {
  args: {
    cols: 4,
    gap: 2,
    flow: 'row-dense',
    children: (
      <>
        <div className="col-span-2 row-span-2">
          <GridItem className="h-40">Large Item</GridItem>
        </div>
        <GridItem>Small Item 1</GridItem>
        <GridItem>Small Item 2</GridItem>
        <GridItem>Small Item 3</GridItem>
        <GridItem>Small Item 4</GridItem>
        <GridItem>Small Item 5</GridItem>
      </>
    ),
  },
};

export const CenteredGrid: Story = {
  args: {
    cols: 3,
    gap: 6,
    justify: 'center',
    align: 'center',
    className: 'h-64',
    children: (
      <>
        <GridItem>Centered 1</GridItem>
        <GridItem>Centered 2</GridItem>
        <GridItem>Centered 3</GridItem>
      </>
    ),
  },
};

export const MasonryStyle: Story = {
  args: {
    cols: 4,
    gap: 4,
    children: (
      <>
        <div className="row-span-1">
          <GridItem className="h-16">Short</GridItem>
        </div>
        <div className="row-span-2">
          <GridItem className="h-32">Medium</GridItem>
        </div>
        <div className="row-span-3">
          <GridItem className="h-48">Tall</GridItem>
        </div>
        <div className="row-span-1">
          <GridItem className="h-16">Short</GridItem>
        </div>
        <div className="row-span-2">
          <GridItem className="h-32">Medium</GridItem>
        </div>
        <div className="row-span-1">
          <GridItem className="h-16">Short</GridItem>
        </div>
      </>
    ),
  },
};

export const Playground: Story = {
  args: {
    cols: 3,
    gap: 4,
    justify: 'start',
    align: 'start',
    children: (
      <>
        <GridItem>Item 1</GridItem>
        <GridItem>Item 2</GridItem>
        <GridItem>Item 3</GridItem>
        <GridItem>Item 4</GridItem>
        <GridItem>Item 5</GridItem>
        <GridItem>Item 6</GridItem>
      </>
    ),
  },
};
