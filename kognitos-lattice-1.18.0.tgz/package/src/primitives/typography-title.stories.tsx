import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Title,
  type TitleColor,
  type TitleAlign,
  type TitleLevel,
} from '@/design-system';

const meta: Meta<typeof Title> = {
  title: 'Design System/Primitives/General/Typography/Title',
  component: Title,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Title component for headings with semantic level configuration. Supports h1, h2, h3, h4 levels with consistent styling that matches the Figma design system.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
  argTypes: {
    level: {
      control: { type: 'select' },
      options: ['h1', 'h2', 'h3', 'h4'],
      description: 'Semantic heading level (h1=largest, h4=smallest)',
    },
    color: {
      control: { type: 'select' },
      options: [
        'default',
        'muted',
        'primary',
        'secondary',
        'accent',
        'destructive',
        'card',
      ],
      description: 'Text color variant',
    },
    align: {
      control: { type: 'select' },
      options: ['left', 'center', 'right', 'justify'],
      description: 'Text alignment',
    },
    children: {
      control: { type: 'text' },
      description: 'Content to display',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Title>;

// Interactive Title Component with Controls
export const Default: Story = {
  args: {
    level: 'h1',
    color: 'default',
    align: 'left',
    children: 'Sample Title',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Interactive Title component with controls. Adjust the props using the controls panel to see real-time changes.',
      },
    },
  },
  render: args => (
    <div className="space-y-4">
      <Title level={args.level} color={args.color} align={args.align}>
        {args.children}
      </Title>

      <div className="p-3 bg-muted rounded text-xs font-mono">
        <div>Level: {args.level}</div>
        <div>Color: {args.color}</div>
        <div>Align: {args.align}</div>
      </div>
    </div>
  ),
};

// All Title Levels
export const AllLevels: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'All available Title levels displayed in a clean format with semantic heading structure.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">
        Title Levels with Semantic Structure
      </h3>
      <div className="space-y-3">
        {[
          { level: 'h1', label: 'H1', desc: 'text-5xl font-extrabold' },
          { level: 'h2', label: 'H2', desc: 'text-3xl font-semibold' },
          { level: 'h3', label: 'H3', desc: 'text-2xl font-semibold' },
          { level: 'h4', label: 'H4', desc: 'text-xl font-semibold' },
        ].map(({ level, label, desc }) => (
          <div key={level} className="flex items-center gap-4">
            <div className="w-16 text-sm font-mono text-muted-foreground">
              {label}
            </div>
            <Title level={level as TitleLevel}>{label} Level Title</Title>
            <div className="text-xs text-muted-foreground">{desc}</div>
          </div>
        ))}
      </div>
    </div>
  ),
};

// Color Variants
export const ColorVariants: Story = {
  parameters: {
    docs: {
      description: {
        story: 'All available color variants for the Title component.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Color Variants</h3>
      <div className="space-y-3">
        {[
          'default',
          'muted',
          'primary',
          'secondary',
          'accent',
          'destructive',
          'card',
        ].map(color => (
          <div key={color} className="flex items-center gap-4">
            <div className="w-20 text-sm font-mono text-muted-foreground">
              {color}
            </div>
            <Title level="h2" color={color as TitleColor}>
              {color.charAt(0).toUpperCase() + color.slice(1)} Title
            </Title>
          </div>
        ))}
      </div>
    </div>
  ),
};

// Alignment Options
export const Alignment: Story = {
  parameters: {
    docs: {
      description: {
        story: 'All alignment options for the Title component.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">
        Alignment Options
      </h3>
      <div className="space-y-6">
        {['left', 'center', 'right', 'justify'].map(align => (
          <div key={align} className="space-y-2">
            <div className="text-sm font-mono text-muted-foreground">
              align="{align}"
            </div>
            <Title level="h2" align={align as TitleAlign}>
              {align.charAt(0).toUpperCase() + align.slice(1)} Aligned Title
            </Title>
          </div>
        ))}
      </div>
    </div>
  ),
};

// Real-world Examples
export const Examples: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Real-world examples of Title component usage.',
      },
    },
  },
  render: () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-foreground">
        Real-world Examples
      </h3>

      {/* Page Header */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Title level="h1" color="primary" align="center">
          Welcome to Our Platform
        </Title>
        <p className="text-sm text-muted-foreground text-center">
          Page header with primary color and center alignment
        </p>
      </div>

      {/* Section Header */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Title level="h2" color="default">
          Getting Started Guide
        </Title>
        <p className="text-sm text-muted-foreground">
          Section header with default styling
        </p>
      </div>

      {/* Card Title */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Title level="h3" color="secondary" align="center">
          Feature Card
        </Title>
        <p className="text-sm text-muted-foreground text-center">
          Card title with secondary color
        </p>
      </div>

      {/* Subsection */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Title level="h4" color="muted">
          Prerequisites
        </Title>
        <p className="text-sm text-muted-foreground">
          Subsection with muted color
        </p>
      </div>
    </div>
  ),
};
