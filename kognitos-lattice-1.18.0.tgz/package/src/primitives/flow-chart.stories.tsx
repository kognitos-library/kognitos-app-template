import type { Meta, StoryObj } from '@storybook/react';
import FlowChart from './flow-chart';
import { Flex } from '@/design-system';
import type { Node, Edge } from '@xyflow/react';
import {
  transformFlowGraphToFlowChart,
  FlowNodeType,
  type IFlowGraph,
} from './flow-chart.utils';

const meta: Meta<typeof FlowChart> = {
  title: 'Design System/Primitives/Data Display/FlowChart',
  component: FlowChart,
  parameters: {
    layout: 'fullscreen',
    docs: {
      description: {
        component:
          'An interactive flow chart component built with React Flow. Supports node and edge manipulation, drag-and-drop, and connection creation.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    width: {
      control: 'text',
      description: 'Width of the container',
    },
    height: {
      control: 'text',
      description: 'Height of the container',
    },
    fitView: {
      control: 'boolean',
      description: 'Whether to fit the view to show all nodes',
    },
  },
};

export default meta;
type Story = StoryObj<typeof FlowChart>;

/**
 * Default flow chart with two connected nodes.
 */
export const Default: Story = {
  render: () => {
    const defaultNodes: Node[] = [
      {
        id: 'n1',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: 'Node 1' },
      },
      {
        id: 'n2',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: 'Node 2' },
      },
    ];
    const defaultEdges: Edge[] = [{ id: 'n1-n2', source: 'n1', target: 'n2' }];

    return (
      <Flex justify="center" width="full">
        <div className="w-[400px] h-[300px]">
          <FlowChart
            initialNodes={defaultNodes}
            initialEdges={defaultEdges}
            linear
          />
        </div>
      </Flex>
    );
  },
};

/**
 * Flow chart with a more complex flow structure.
 * Demonstrates multiple nodes and connections in a workflow pattern.
 */
export const ComplexFlow: Story = {
  render: () => {
    const complexNodes: Node[] = [
      {
        id: 'start',
        type: 'custom',
        position: { x: 100, y: 0 },
        data: { label: 'Start' },
      },
      {
        id: 'process1',
        type: 'custom',
        position: { x: 0, y: 100 },
        data: {
          label:
            'This is a long label to test the flow chart layout. This should span multiple lines.',
        },
      },
      {
        id: 'process2',
        type: 'custom',
        position: { x: 200, y: 100 },
        data: { label: 'This is a long label to test the flow chart layout.' },
      },
      {
        id: 'decision',
        type: 'custom',
        position: { x: 100, y: 200 },
        data: { label: 'Decision' },
      },
      {
        id: 'end1',
        type: 'custom',
        position: { x: 0, y: 300 },
        data: { label: 'End 1' },
      },
      {
        id: 'end2',
        type: 'custom',
        position: { x: 200, y: 300 },
        data: { label: 'End 2' },
      },
    ];

    const complexEdges: Edge[] = [
      { id: 'e-start-1', source: 'start', target: 'process1' },
      { id: 'e-start-2', source: 'start', target: 'process2' },
      { id: 'e-1-decision', source: 'process1', target: 'decision' },
      { id: 'e-2-decision', source: 'process2', target: 'decision' },
      { id: 'e-decision-1', source: 'decision', target: 'end1' },
      { id: 'e-decision-2', source: 'decision', target: 'end2' },
    ];

    return (
      <Flex justify="center" width="full">
        <div className="w-[400px] h-[400px]">
          <FlowChart
            initialNodes={complexNodes}
            initialEdges={complexEdges}
            linear={false}
          />
        </div>
      </Flex>
    );
  },
  parameters: {
    docs: {
      description: {
        story:
          'A more complex flow chart with multiple nodes and connections. Users can drag nodes, create new connections, and interact with the flow.',
      },
    },
  },
};

/**
 * Flow chart with a single node.
 * Useful for starting a new flow from scratch.
 */
export const SingleNode: Story = {
  render: () => {
    const singleNode: Node[] = [
      {
        id: 'node1',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: 'Start Here' },
      },
    ];

    return (
      <Flex justify="center">
        <div className="w-[400px] h-[400px]">
          <FlowChart initialNodes={singleNode} initialEdges={[]} />
        </div>
      </Flex>
    );
  },
  parameters: {
    docs: {
      description: {
        story:
          'Flow chart with a single node. Users can add more nodes and create connections interactively.',
      },
    },
  },
};

/**
 * Automation flow chart example.
 */
export const AutomationFlow: Story = {
  render: () => {
    const automationNodes: Node[] = [
      {
        id: '1',
        type: 'custom',
        position: { x: 100, y: 0 },
        data: { label: '1. Upload PDF' },
      },
      {
        id: '2',
        type: 'custom',
        position: { x: 100, y: 100 },
        data: {
          label:
            '2. Extract invoice # and company name. This is a long label to test the flow chart layout. This should span multiple lines.',
        },
      },
      {
        id: '3',
        type: 'custom',
        position: { x: 100, y: 200 },
        data: { label: '3. Assign ticket priority' },
      },
      {
        id: '4',
        type: 'custom',
        position: { x: 100, y: 300 },
        data: { label: '4. Add a row to invoices.csv' },
      },
      {
        id: '5',
        type: 'custom',
        position: { x: 100, y: 400 },
        data: { label: '5. Add a row to invoices.pdf' },
      },
    ];

    const automationEdges: Edge[] = [
      { id: '1-2', source: '1', target: '2' },
      { id: '2-3', source: '2', target: '3' },
      { id: '3-4', source: '3', target: '4' },
      { id: '4-5', source: '4', target: '5' },
    ];

    return (
      <Flex justify="center" width="full">
        <div className="w-[400px] h-[600px]">
          <FlowChart
            initialNodes={automationNodes}
            initialEdges={automationEdges}
            linear
          />
        </div>
      </Flex>
    );
  },
};

/**
 * Flow chart error state.
 * Displays an error message when the flow chart cannot be loaded.
 */
export const ErrorStateDefault: Story = {
  render: () => (
    <Flex justify="center" width="full">
      <div className="w-[400px] h-[600px]">
        <FlowChart
          error={{
            show: true,
            onAction: () => alert('Refresh clicked'),
          }}
        />
      </div>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Error state displayed when the flow chart cannot be loaded. Shows an empty state with a refresh button.',
      },
    },
  },
};

/**
 * Flow chart error state with custom messages.
 */
export const ErrorStateCustom: Story = {
  render: () => (
    <Flex justify="center" width="full">
      <div className="w-[400px] h-[600px]">
        <FlowChart
          error={{
            show: true,
            title: 'Failed to generate diagram',
            description: 'The automation could not be visualized.',
            actionLabel: 'Try Again',
            onAction: () => alert('Try Again clicked'),
          }}
        />
      </div>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Error state with custom title, description, and action label.',
      },
    },
  },
};

/**
 * Flow chart loading state.
 * Displays skeleton loaders and dashed lines while the flow chart is being built.
 */
export const LoadingState: Story = {
  render: () => (
    <Flex justify="center" width="full">
      <div className="w-[400px] h-[700px]">
        <FlowChart loading />
      </div>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Loading state displayed while the flow chart is being built. Shows skeleton placeholders with dashed connecting lines and a loading message.',
      },
    },
  },
};

/**
 * Flow chart with edge labels (yes/no).
 * Demonstrates conditional branching with labeled edges.
 */
export const WithEdgeLabels: Story = {
  render: () => {
    const labeledNodes: Node[] = [
      {
        id: 'start',
        type: 'custom',
        position: { x: 0, y: 0 },
        data: { label: 'Start Process' },
      },
      {
        id: 'decision',
        type: 'custom',
        position: { x: 0, y: 100 },
        data: { label: 'Is condition met?' },
      },
      {
        id: 'yes-path',
        type: 'custom',
        position: { x: -150, y: 200 },
        data: { label: 'Continue' },
      },
      {
        id: 'no-path',
        type: 'custom',
        position: { x: 150, y: 200 },
        data: { label: 'Alternative' },
      },
      {
        id: 'end',
        type: 'custom',
        position: { x: 0, y: 300 },
        data: { label: 'End' },
      },
    ];

    const labeledEdges: Edge[] = [
      { id: 'e-start-decision', source: 'start', target: 'decision' },
      {
        id: 'e-decision-yes',
        source: 'decision',
        target: 'yes-path',
        data: { label: 'Yes' },
        type: 'default',
      },
      {
        id: 'e-decision-no',
        source: 'decision',
        target: 'no-path',
        data: { label: 'No' },
        type: 'default',
      },
      { id: 'e-yes-end', source: 'yes-path', target: 'end' },
      { id: 'e-no-end', source: 'no-path', target: 'end' },
    ];

    return (
      <Flex justify="center" width="full">
        <div className="w-[400px] h-[600px]">
          <FlowChart
            initialNodes={labeledNodes}
            initialEdges={labeledEdges}
            linear={false}
          />
        </div>
      </Flex>
    );
  },
  parameters: {
    docs: {
      description: {
        story:
          'Flow chart with edge labels showing conditional branching. Edges can display labels like "yes" and "no" to indicate decision paths.',
      },
    },
  },
};

/**
 * Flow chart from FlowGraph.
 * Demonstrates transforming a FlowGraph into FlowChart props.
 */
export const FromProtoFlowGraph: Story = {
  render: () => {
    // Simulated flow graph
    const protoGraph: IFlowGraph = {
      nodes: [
        {
          id: 'start',
          label: 'Start Process',
          type: FlowNodeType.START,
        },
        {
          id: 'validate',
          label: 'Validate Input Data',
          type: FlowNodeType.PROCESS,
        },
        {
          id: 'transform',
          label: 'Transform and Enrich',
          type: FlowNodeType.PROCESS,
        },
        {
          id: 'output',
          label: 'Send to Destination',
          type: FlowNodeType.OUTPUT,
        },
        {
          id: 'end',
          label: 'End Process',
          type: FlowNodeType.END,
        },
      ],
      edges: [
        { source: 'start', target: 'validate' },
        { source: 'validate', target: 'transform' },
        { source: 'transform', target: 'output' },
        { source: 'output', target: 'end' },
      ],
    };

    // Transform proto to FlowChart props
    const { nodes, edges, isLinear } =
      transformFlowGraphToFlowChart(protoGraph);

    return (
      <Flex justify="center" width="full">
        <div className="w-[400px] h-[500px]">
          <FlowChart
            initialNodes={nodes}
            initialEdges={edges}
            linear={isLinear}
          />
        </div>
      </Flex>
    );
  },
  parameters: {
    docs: {
      description: {
        story:
          'Demonstrates the transformFlowGraphToFlowChart utility that converts a FlowGraph into FlowChart-compatible nodes and edges.',
      },
    },
  },
};

/**
 * Flow chart from Proto with Decision Nodes (branching flow).
 */
export const FromProtoWithDecision: Story = {
  render: () => {
    const protoGraph: IFlowGraph = {
      nodes: [
        {
          id: 'start',
          label: 'Receive Invoice',
          type: FlowNodeType.START,
        },
        {
          id: 'check',
          label: 'Amount > $1000?',
          type: FlowNodeType.DECISION,
        },
        {
          id: 'approve',
          label: 'Auto-Approve',
          type: FlowNodeType.PROCESS,
        },
        {
          id: 'review',
          label: 'Manual Review',
          type: FlowNodeType.PROCESS,
        },
        {
          id: 'end',
          label: 'Complete',
          type: FlowNodeType.END,
        },
      ],
      edges: [
        { source: 'start', target: 'check' },
        { source: 'check', target: 'approve', condition: 'No' },
        { source: 'check', target: 'review', condition: 'Yes' },
        { source: 'approve', target: 'end' },
        { source: 'review', target: 'end' },
      ],
    };

    const { nodes, edges, isLinear } =
      transformFlowGraphToFlowChart(protoGraph);

    return (
      <Flex justify="center" width="full">
        <div className="w-[500px] h-[400px]">
          <FlowChart
            initialNodes={nodes}
            initialEdges={edges}
            linear={isLinear}
          />
        </div>
      </Flex>
    );
  },
  parameters: {
    docs: {
      description: {
        story:
          'A branching flow with decision nodes. The isLinear flag is automatically set to false when decision nodes are present.',
      },
    },
  },
};
