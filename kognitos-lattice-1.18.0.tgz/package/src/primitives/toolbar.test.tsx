import { render, screen } from '@testing-library/react';
import { userEvent } from '@testing-library/user-event';
import {
  Toolbar,
  ToolbarGroup,
  ToolbarButton,
  ToolbarBadge,
  ToolbarSeparator,
} from './toolbar';
import { Icon } from '../icons';
import { describe, it, expect, vi } from 'vitest';

describe('Toolbar', () => {
  describe('Rendering', () => {
    it('should render toolbar element', () => {
      render(
        <Toolbar data-testid="toolbar">
          <ToolbarGroup>
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const toolbar = screen.getByTestId('toolbar');
      expect(toolbar).toBeInTheDocument();
    });

    it('should render toolbar with children', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>Button 1</ToolbarButton>
            <ToolbarButton>Button 2</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      expect(screen.getByText('Button 1')).toBeInTheDocument();
      expect(screen.getByText('Button 2')).toBeInTheDocument();
    });
  });

  describe('Toolbar Sizes', () => {
    it('should render with default size', () => {
      render(
        <Toolbar data-testid="toolbar" size="default">
          <ToolbarGroup>
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const toolbar = screen.getByTestId('toolbar');
      expect(toolbar).toHaveClass('p-1');
    });

    it('should render with small size', () => {
      render(
        <Toolbar data-testid="toolbar" size="sm">
          <ToolbarGroup>
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const toolbar = screen.getByTestId('toolbar');
      expect(toolbar).toHaveClass('p-0.5');
    });

    it('should render with large size', () => {
      render(
        <Toolbar data-testid="toolbar" size="lg">
          <ToolbarGroup>
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const toolbar = screen.getByTestId('toolbar');
      expect(toolbar).toHaveClass('p-1.5');
    });
  });

  describe('Styling', () => {
    it('should apply custom className', () => {
      render(
        <Toolbar data-testid="toolbar" className="custom-class">
          <ToolbarGroup>
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const toolbar = screen.getByTestId('toolbar');
      expect(toolbar).toHaveClass('custom-class');
    });

    it('should have backdrop blur effect', () => {
      render(
        <Toolbar data-testid="toolbar">
          <ToolbarGroup>
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const toolbar = screen.getByTestId('toolbar');
      expect(toolbar).toHaveClass('backdrop-blur-md');
    });

    it('should have border and rounded corners', () => {
      render(
        <Toolbar data-testid="toolbar">
          <ToolbarGroup>
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const toolbar = screen.getByTestId('toolbar');
      expect(toolbar).toHaveClass('border');
      expect(toolbar).toHaveClass('border-border');
      expect(toolbar).toHaveClass('rounded-xl');
    });
  });

  describe('ToolbarGroup', () => {
    it('should render toolbar group', () => {
      render(
        <Toolbar>
          <ToolbarGroup data-testid="group">
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const group = screen.getByTestId('group');
      expect(group).toBeInTheDocument();
    });

    it('should render with default size', () => {
      render(
        <Toolbar>
          <ToolbarGroup data-testid="group" size="default">
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const group = screen.getByTestId('group');
      expect(group).toHaveClass('h-9');
    });

    it('should render with large size', () => {
      render(
        <Toolbar>
          <ToolbarGroup data-testid="group" size="lg">
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const group = screen.getByTestId('group');
      expect(group).toHaveClass('h-10');
    });

    it('should apply custom className', () => {
      render(
        <Toolbar>
          <ToolbarGroup data-testid="group" className="custom-group">
            <ToolbarButton>Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const group = screen.getByTestId('group');
      expect(group).toHaveClass('custom-group');
    });
  });

  describe('ToolbarButton', () => {
    it('should render toolbar button', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button">Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toBeInTheDocument();
      expect(button).toHaveTextContent('Action');
    });

    it('should render with default variant', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" variant="default">
              Action
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('bg-background/95');
      expect(button).toHaveClass('shadow-xs');
    });

    it('should render with ghost variant', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" variant="ghost">
              Action
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('text-muted-foreground');
    });

    it('should render with text variant', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" variant="text">
              Action
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('text-muted-foreground');
    });

    it('should render with icon variant', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" variant="icon">
              <Icon type="Settings" />
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('bg-transparent');
      expect(button).toHaveClass('w-9');
      expect(button).toHaveClass('h-full'); // Uses h-full when size is default
    });

    it('should render with different sizes', () => {
      const { rerender } = render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" size="sm">
              Small
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      let button = screen.getByTestId('button');
      expect(button).toHaveClass('h-7');

      rerender(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" size="lg">
              Large
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      button = screen.getByTestId('button');
      expect(button).toHaveClass('h-10');
    });

    it('should handle click events', async () => {
      const handleClick = vi.fn();
      const user = userEvent.setup();

      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" onClick={handleClick}>
              Click me
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      await user.click(button);

      expect(handleClick).toHaveBeenCalledTimes(1);
    });

    it('should handle disabled state', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" disabled>
              Disabled
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toBeDisabled();
      expect(button).toHaveClass('disabled:pointer-events-none');
      expect(button).toHaveClass('disabled:opacity-50');
    });

    it('should apply custom className', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button" className="custom-button">
              Action
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('custom-button');
    });

    it('should forward additional props', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton
              data-testid="button"
              aria-label="Custom action"
              data-custom="value"
            >
              Action
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveAttribute('aria-label', 'Custom action');
      expect(button).toHaveAttribute('data-custom', 'value');
    });
  });

  describe('ToolbarBadge', () => {
    it('should render toolbar badge with count', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>
              Outputs <ToolbarBadge count={5} data-testid="badge" />
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const badge = screen.getByTestId('badge');
      expect(badge).toBeInTheDocument();
      expect(badge).toHaveTextContent('5');
    });

    it('should render toolbar badge with children', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>
              Outputs <ToolbarBadge data-testid="badge">New</ToolbarBadge>
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const badge = screen.getByTestId('badge');
      expect(badge).toBeInTheDocument();
      expect(badge).toHaveTextContent('New');
    });

    it('should prioritize count over children', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>
              Outputs{' '}
              <ToolbarBadge count={10} data-testid="badge">
                New
              </ToolbarBadge>
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const badge = screen.getByTestId('badge');
      expect(badge).toHaveTextContent('10');
      expect(badge).not.toHaveTextContent('New');
    });

    it('should apply custom className', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>
              Outputs{' '}
              <ToolbarBadge
                count={5}
                data-testid="badge"
                className="custom-badge"
              />
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const badge = screen.getByTestId('badge');
      expect(badge).toHaveClass('custom-badge');
    });
  });

  describe('ToolbarSeparator', () => {
    it('should render toolbar separator', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>Action 1</ToolbarButton>
          </ToolbarGroup>
          <ToolbarSeparator data-testid="separator" />
          <ToolbarGroup>
            <ToolbarButton>Action 2</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const separator = screen.getByTestId('separator');
      expect(separator).toBeInTheDocument();
    });

    it('should have proper styling', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>Action 1</ToolbarButton>
          </ToolbarGroup>
          <ToolbarSeparator data-testid="separator" />
        </Toolbar>,
      );

      const separator = screen.getByTestId('separator');
      expect(separator).toHaveClass('w-px');
      expect(separator).toHaveClass('h-6');
      expect(separator).toHaveClass('bg-border');
    });

    it('should apply custom className', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>Action 1</ToolbarButton>
          </ToolbarGroup>
          <ToolbarSeparator
            data-testid="separator"
            className="custom-separator"
          />
        </Toolbar>,
      );

      const separator = screen.getByTestId('separator');
      expect(separator).toHaveClass('custom-separator');
    });
  });

  describe('Accessibility', () => {
    it('should support aria attributes on buttons', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton aria-label="Save document">Save</ToolbarButton>
            <ToolbarButton aria-label="Download file">
              <Icon type="Download" />
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      expect(screen.getByLabelText('Save document')).toBeInTheDocument();
      expect(screen.getByLabelText('Download file')).toBeInTheDocument();
    });

    it('should have proper button type attribute', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button">Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveAttribute('type', 'button');
    });

    it('should have focus-visible styles', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton data-testid="button">Action</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      const button = screen.getByTestId('button');
      expect(button).toHaveClass('focus-visible:outline-none');
      expect(button).toHaveClass('focus-visible:ring-2');
      expect(button).toHaveClass('focus-visible:ring-ring');
    });
  });

  describe('Integration', () => {
    it('should render complete toolbar with all components', () => {
      render(
        <Toolbar data-testid="toolbar">
          <ToolbarGroup>
            <ToolbarButton variant="default">Draft</ToolbarButton>
            <ToolbarButton variant="text">
              Outputs <ToolbarBadge count={3} />
            </ToolbarButton>
          </ToolbarGroup>
          <ToolbarSeparator />
          <ToolbarGroup>
            <ToolbarButton variant="icon" aria-label="Settings">
              <Icon type="Settings" />
            </ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      expect(screen.getByTestId('toolbar')).toBeInTheDocument();
      expect(screen.getByText('Draft')).toBeInTheDocument();
      expect(screen.getByText('Outputs')).toBeInTheDocument();
      expect(screen.getByText('3')).toBeInTheDocument();
      expect(screen.getByLabelText('Settings')).toBeInTheDocument();
    });

    it('should handle multiple groups with separators', () => {
      render(
        <Toolbar>
          <ToolbarGroup>
            <ToolbarButton>Group 1</ToolbarButton>
          </ToolbarGroup>
          <ToolbarSeparator data-testid="sep1" />
          <ToolbarGroup>
            <ToolbarButton>Group 2</ToolbarButton>
          </ToolbarGroup>
          <ToolbarSeparator data-testid="sep2" />
          <ToolbarGroup>
            <ToolbarButton>Group 3</ToolbarButton>
          </ToolbarGroup>
        </Toolbar>,
      );

      expect(screen.getByText('Group 1')).toBeInTheDocument();
      expect(screen.getByText('Group 2')).toBeInTheDocument();
      expect(screen.getByText('Group 3')).toBeInTheDocument();
      expect(screen.getByTestId('sep1')).toBeInTheDocument();
      expect(screen.getByTestId('sep2')).toBeInTheDocument();
    });
  });
});
