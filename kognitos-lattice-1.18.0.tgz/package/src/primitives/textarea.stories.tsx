import type { Meta, StoryObj } from '@storybook/react-vite';
import { Textarea } from './textarea';
import { Text } from './typography';

const meta: Meta<typeof Textarea> = {
  title: 'Design System/Primitives/Forms/Textarea',
  component: Textarea,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A textarea component that supports multiple lines of text input. The component features automatic content sizing, variants for different visual styles, and built-in invalid state styling.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: ['default', 'ghost', 'inline'],
      description: 'Visual variant of the textarea',
      table: {
        type: { summary: 'default | ghost | inline' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the textarea is disabled',
      table: {
        type: { summary: 'boolean' },
        category: 'State',
      },
    },
    placeholder: {
      control: { type: 'text' },
      description: 'Placeholder text',
      table: {
        type: { summary: 'string' },
        category: 'Content',
      },
    },
    'aria-invalid': {
      control: { type: 'boolean' },
      description: 'Whether the textarea is in an invalid state',
      table: {
        type: { summary: 'boolean' },
        category: 'State',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Textarea>;

// Primary story - Main demo
export const Demo: Story = {
  render: () => (
    <div className="flex w-[350px] flex-col gap-6">
      <div>
        <Text level="small" className="mb-2 block">
          Default
        </Text>
        <Textarea placeholder="Type your message here..." />
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Ghost
        </Text>
        <Textarea variant="ghost" placeholder="Type your message here..." />
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Inline
        </Text>
        <Textarea variant="inline" placeholder="Type your message here..." />
      </div>
    </div>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'The main demo showing all textarea variants. Default includes border, shadow, and focus ring. Ghost is borderless and minimal. Inline is also a minimal borderless design without draggable expansion and no horizontal padding.',
      },
    },
  },
};

// Basic usage
export const Default: Story = {
  args: {
    placeholder: 'Type your message here...',
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Default textarea variant with border, shadow, and focus ring effects.',
      },
    },
  },
};

export const Ghost: Story = {
  args: {
    placeholder: 'Type your message here...',
    variant: 'ghost',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Ghost variant without border or shadow - ideal for inline editing or minimal UI.',
      },
    },
  },
};

export const Inline: Story = {
  render: () => (
    <div className="w-[350px]">
      <Textarea variant="inline" placeholder="Type your message here..." />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Inline variant with minimal borderless design for inline editing. Typically used with an icon (default: Sparkle, see ChatInput component) and supports automatic content sizing.',
      },
    },
  },
};

export const WithValue: Story = {
  args: {
    defaultValue:
      'This textarea has some content already filled in. The content will automatically size the textarea.',
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Textarea with initial content. The component uses field-sizing-content to automatically adjust height based on content.',
      },
    },
  },
};

export const Disabled: Story = {
  args: {
    placeholder: 'This textarea is disabled',
    disabled: true,
    variant: 'default',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Disabled state with reduced opacity and not-allowed cursor. User cannot interact with the textarea.',
      },
    },
  },
};

export const Invalid: Story = {
  render: () => (
    <div className="flex w-[350px] flex-col gap-6">
      <div>
        <Text level="small" className="mb-2 block">
          Invalid Default
        </Text>
        <Textarea
          placeholder="This textarea has an error"
          aria-invalid
          variant="default"
        />
        <Text level="small" color="muted" className="mt-1">
          This field is required
        </Text>
      </div>
      <div>
        <Text level="small" className="mb-2 block">
          Invalid Ghost
        </Text>
        <Textarea
          placeholder="Ghost variant with error"
          aria-invalid
          variant="ghost"
        />
        <Text level="small" color="muted" className="mt-1">
          Ghost variant keeps transparent border even when invalid
        </Text>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Invalid state with destructive border and ring colors. The default variant shows error styling, while ghost variant maintains transparent borders.',
      },
    },
  },
};

export const AutoSizing: Story = {
  render: () => (
    <div className="w-[350px]">
      <Text level="small" className="mb-2 block">
        Auto-sizing Textarea
      </Text>
      <Textarea
        placeholder="Start typing and watch the textarea grow..."
        defaultValue="This textarea uses field-sizing-content to automatically adjust its height based on the content."
      />
      <Text level="small" color="muted" className="mt-2">
        The textarea automatically expands as you type more content, starting
        from a minimum height of 4rem.
      </Text>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Demonstrates automatic content sizing. The textarea grows vertically as content is added, maintaining a minimum height of min-h-16 (4rem).',
      },
    },
  },
};

export const AllVariants: Story = {
  render: () => (
    <div className="flex w-[350px] flex-col gap-6">
      <div>
        <Text level="small" weight="medium" className="mb-2 block">
          Default
        </Text>
        <Textarea
          placeholder="Default textarea with border and focus ring"
          variant="default"
        />
      </div>
      <div>
        <Text level="small" weight="medium" className="mb-2 block">
          Ghost
        </Text>
        <Textarea
          placeholder="Ghost textarea - minimal styling"
          variant="ghost"
        />
      </div>
      <div>
        <Text level="small" weight="medium" className="mb-2 block">
          Inline
        </Text>
        <Textarea variant="inline" placeholder="Inline textarea" />
      </div>
      <div>
        <Text level="small" weight="medium" className="mb-2 block">
          With Content
        </Text>
        <Textarea
          defaultValue="Some content here with visual styling applied"
          variant="default"
        />
      </div>
      <div>
        <Text level="small" weight="medium" className="mb-2 block">
          Disabled
        </Text>
        <Textarea placeholder="Disabled state" disabled variant="default" />
      </div>
      <div>
        <Text level="small" weight="medium" className="mb-2 block">
          Invalid
        </Text>
        <Textarea placeholder="Error state" aria-invalid variant="default" />
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'A comprehensive overview of all textarea variants and states.',
      },
    },
  },
};
