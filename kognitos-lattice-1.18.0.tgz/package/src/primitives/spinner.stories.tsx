import type { Meta, StoryObj } from '@storybook/react';
import { Flex } from '@/design-system';

import { Spinner } from './spinner';

const meta: Meta<typeof Spinner> = {
  title: 'Design System/Primitives/Feedback/Spinner',
  component: Spinner,
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        component:
          'A loading spinner component with various sizes and color variants.',
      },
    },
  },
  tags: ['autodocs'],
  argTypes: {
    size: {
      control: { type: 'select' },
      options: ['sm', 'default', 'lg', 'xl'],
      description: 'The size of the spinner',
    },
    variant: {
      control: { type: 'select' },
      options: ['default', 'secondary', 'muted', 'destructive', 'accent'],
      description: 'The color variant of the spinner',
    },
  },
};

export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {
  args: {},
};

export const Sizes: Story = {
  render: () => (
    <Flex gap={4} align="center">
      <Spinner size="sm" />
      <Spinner size="default" />
      <Spinner size="lg" />
      <Spinner size="xl" />
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'All available spinner sizes from small to extra large.',
      },
    },
  },
};

export const Variants: Story = {
  render: () => (
    <Flex gap={4} align="center">
      <Spinner variant="default" />
      <Spinner variant="secondary" />
      <Spinner variant="muted" />
      <Spinner variant="destructive" />
      <Spinner variant="accent" />
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'All available color variants for the spinner.',
      },
    },
  },
};

export const AllCombinations: Story = {
  render: () => (
    <Flex direction="column" gap={6}>
      <Flex gap={4} align="center">
        <Spinner size="sm" variant="default" />
        <Spinner size="sm" variant="secondary" />
        <Spinner size="sm" variant="muted" />
        <Spinner size="sm" variant="destructive" />
        <Spinner size="sm" variant="accent" />
      </Flex>
      <Flex gap={4} align="center">
        <Spinner size="default" variant="default" />
        <Spinner size="default" variant="secondary" />
        <Spinner size="default" variant="muted" />
        <Spinner size="default" variant="destructive" />
        <Spinner size="default" variant="accent" />
      </Flex>
      <Flex gap={4} align="center">
        <Spinner size="lg" variant="default" />
        <Spinner size="lg" variant="secondary" />
        <Spinner size="lg" variant="muted" />
        <Spinner size="lg" variant="destructive" />
        <Spinner size="lg" variant="accent" />
      </Flex>
      <Flex gap={4} align="center">
        <Spinner size="xl" variant="default" />
        <Spinner size="xl" variant="secondary" />
        <Spinner size="xl" variant="muted" />
        <Spinner size="xl" variant="destructive" />
        <Spinner size="xl" variant="accent" />
      </Flex>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'All combinations of sizes and variants.',
      },
    },
  },
};

export const WithText: Story = {
  render: () => (
    <Flex direction="column" gap={2} align="center">
      <Spinner size="lg" />
      <span className="text-sm text-muted-foreground">Loading...</span>
    </Flex>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Spinner with accompanying text for better user experience.',
      },
    },
  },
};

export const InContainer: Story = {
  render: () => (
    <div className="p-8 border rounded-lg bg-card">
      <Flex direction="column" gap={4} align="center">
        <Spinner size="lg" />
        <span className="text-sm text-muted-foreground">
          Processing your request...
        </span>
      </Flex>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Spinner in a card container with descriptive text.',
      },
    },
  },
};
