import * as React from 'react';
import * as SeparatorPrimitive from '@radix-ui/react-separator';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '../lib/utils';

const separatorVariants = cva('shrink-0', {
  variants: {
    variant: {
      solid: 'bg-border',
      dashed:
        'bg-transparent border-0 border-border border-dashed data-[orientation=horizontal]:border-t data-[orientation=vertical]:border-l',
    },
    orientation: {
      horizontal: 'h-px w-full',
      vertical: 'h-full w-px',
    },
  },
  defaultVariants: {
    variant: 'solid',
    orientation: 'horizontal',
  },
});

interface ISeparatorProps
  extends
    Omit<React.ComponentProps<typeof SeparatorPrimitive.Root>, 'orientation'>,
    VariantProps<typeof separatorVariants> {}

/**
 * A visual separator component for dividing content.
 *
 * @param variant - Visual style: 'solid' (default) or 'dashed'
 * @param orientation - Direction: 'horizontal' (default) or 'vertical'
 * @param decorative - Whether the separator is decorative (default: true)
 */
function Separator({
  className,
  variant,
  orientation = 'horizontal',
  decorative = true,
  ...props
}: ISeparatorProps) {
  const resolvedOrientation = orientation ?? 'horizontal';

  return (
    <SeparatorPrimitive.Root
      data-slot="separator"
      decorative={decorative}
      orientation={resolvedOrientation}
      className={cn(
        separatorVariants({ variant, orientation: resolvedOrientation }),
        className,
      )}
      {...props}
    />
  );
}

export { Separator, separatorVariants, type ISeparatorProps };
