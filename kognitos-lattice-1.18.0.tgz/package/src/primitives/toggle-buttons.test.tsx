import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { ToggleButtons, ToggleButtonItem } from './toggle-buttons';
import { describe, it, expect, vi } from 'vitest';

describe('ToggleButtons', () => {
  describe('Rendering', () => {
    it('should render toggle buttons container', () => {
      render(
        <ToggleButtons data-testid="toggle-buttons" defaultValue="a">
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
        </ToggleButtons>,
      );

      const container = screen.getByTestId('toggle-buttons');
      expect(container).toBeInTheDocument();
    });

    it('should render all toggle button items', () => {
      render(
        <ToggleButtons defaultValue="a">
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
          <ToggleButtonItem value="c">Option C</ToggleButtonItem>
        </ToggleButtons>,
      );

      expect(screen.getByText('Option A')).toBeInTheDocument();
      expect(screen.getByText('Option B')).toBeInTheDocument();
      expect(screen.getByText('Option C')).toBeInTheDocument();
    });
  });

  describe('Click Behavior', () => {
    it('should call onValueChange when item is clicked', async () => {
      const user = userEvent.setup();
      const handleChange = vi.fn();

      render(
        <ToggleButtons defaultValue="a" onValueChange={handleChange}>
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
        </ToggleButtons>,
      );

      await user.click(screen.getByText('Option B'));
      expect(handleChange).toHaveBeenCalledWith('b');
    });

    it('should update selected state when clicked', async () => {
      const user = userEvent.setup();

      render(
        <ToggleButtons defaultValue="a">
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
        </ToggleButtons>,
      );

      const optionA = screen.getByText('Option A');
      const optionB = screen.getByText('Option B');

      expect(optionA).toHaveAttribute('data-state', 'on');
      expect(optionB).toHaveAttribute('data-state', 'off');

      await user.click(optionB);

      expect(optionA).toHaveAttribute('data-state', 'off');
      expect(optionB).toHaveAttribute('data-state', 'on');
    });
  });

  describe('Single Selection', () => {
    it('should only allow one item to be selected at a time', async () => {
      const user = userEvent.setup();

      render(
        <ToggleButtons defaultValue="a">
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
          <ToggleButtonItem value="c">Option C</ToggleButtonItem>
        </ToggleButtons>,
      );

      const optionA = screen.getByText('Option A');
      const optionB = screen.getByText('Option B');
      const optionC = screen.getByText('Option C');

      // Initially A is selected
      expect(optionA).toHaveAttribute('data-state', 'on');
      expect(optionB).toHaveAttribute('data-state', 'off');
      expect(optionC).toHaveAttribute('data-state', 'off');

      // Click B
      await user.click(optionB);
      expect(optionA).toHaveAttribute('data-state', 'off');
      expect(optionB).toHaveAttribute('data-state', 'on');
      expect(optionC).toHaveAttribute('data-state', 'off');
    });

    it('should support controlled value', async () => {
      const user = userEvent.setup();
      const handleChange = vi.fn();

      const { rerender } = render(
        <ToggleButtons value="a" onValueChange={handleChange}>
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
        </ToggleButtons>,
      );

      const optionA = screen.getByText('Option A');
      const optionB = screen.getByText('Option B');

      expect(optionA).toHaveAttribute('data-state', 'on');
      expect(optionB).toHaveAttribute('data-state', 'off');

      await user.click(optionB);
      expect(handleChange).toHaveBeenCalledWith('b');

      // Value doesn't change until parent updates it (controlled)
      expect(optionA).toHaveAttribute('data-state', 'on');

      // Simulate parent updating the value
      rerender(
        <ToggleButtons value="b" onValueChange={handleChange}>
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
        </ToggleButtons>,
      );

      expect(optionA).toHaveAttribute('data-state', 'off');
      expect(optionB).toHaveAttribute('data-state', 'on');
    });
  });

  describe('Disabled State', () => {
    it('should disable all items when container is disabled', () => {
      render(
        <ToggleButtons defaultValue="a" disabled>
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
        </ToggleButtons>,
      );

      const optionA = screen.getByText('Option A');
      const optionB = screen.getByText('Option B');

      expect(optionA).toBeDisabled();
      expect(optionB).toBeDisabled();
    });

    it('should not call onValueChange when disabled', async () => {
      const user = userEvent.setup();
      const handleChange = vi.fn();

      render(
        <ToggleButtons defaultValue="a" disabled onValueChange={handleChange}>
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b">Option B</ToggleButtonItem>
        </ToggleButtons>,
      );

      await user.click(screen.getByText('Option B'));
      expect(handleChange).not.toHaveBeenCalled();
    });

    it('should disable individual items', () => {
      render(
        <ToggleButtons defaultValue="a">
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
          <ToggleButtonItem value="b" disabled>
            Option B
          </ToggleButtonItem>
        </ToggleButtons>,
      );

      const optionA = screen.getByText('Option A');
      const optionB = screen.getByText('Option B');

      expect(optionA).not.toBeDisabled();
      expect(optionB).toBeDisabled();
    });
  });

  describe('Accessibility', () => {
    it('should have role radiogroup on container', () => {
      render(
        <ToggleButtons data-testid="toggle-buttons" defaultValue="a">
          <ToggleButtonItem value="a">Option A</ToggleButtonItem>
        </ToggleButtons>,
      );

      const container = screen.getByTestId('toggle-buttons');
      expect(container).toHaveAttribute('role', 'group');
    });

    it('should support aria-label on items', () => {
      render(
        <ToggleButtons defaultValue="a">
          <ToggleButtonItem
            data-testid="item"
            value="a"
            aria-label="Select option A"
          >
            A
          </ToggleButtonItem>
        </ToggleButtons>,
      );

      const item = screen.getByTestId('item');
      expect(item).toHaveAttribute('aria-label', 'Select option A');
    });
  });
});
