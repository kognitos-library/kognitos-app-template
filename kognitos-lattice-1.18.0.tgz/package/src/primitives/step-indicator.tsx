import { cva, type VariantProps } from 'class-variance-authority';
import { Flex, type IFlexProps } from './flex';
import { cn } from '../lib/utils';

const stepIndicatorVariants = cva(
  'rounded-full transition-colors duration-200',
  {
    variants: {
      size: {
        sm: 'w-2 h-2',
        md: 'w-3 h-3',
        lg: 'w-4 h-4',
      },
      variant: {
        default: '',
        outlined: 'border-2',
      },
    },
    compoundVariants: [
      {
        variant: 'default',
        class: 'bg-muted data-[active=true]:bg-primary',
      },
      {
        variant: 'outlined',
        class:
          'border-muted bg-transparent data-[active=true]:border-primary data-[active=true]:bg-primary',
      },
    ],
    defaultVariants: {
      size: 'md',
      variant: 'default',
    },
  },
);

export interface StepIndicatorProps extends VariantProps<
  typeof stepIndicatorVariants
> {
  /**
   * The current active step (1-based index)
   */
  currentStep: number;
  /**
   * Total number of steps
   */
  totalSteps: number;
  /**
   * Additional CSS class name
   */
  className?: string;
  /**
   * Gap between step indicators
   */
  gap?: IFlexProps['gap'];
  /**
   * Accessible label for the step indicator
   */
  'aria-label'?: string;
}

/**
 * StepIndicator displays progress through a multi-step process
 *
 * @example
 * ```tsx
 * <StepIndicator currentStep={2} totalSteps={4} />
 * <StepIndicator currentStep={1} totalSteps={3} size="lg" variant="outlined" />
 * ```
 */
export function StepIndicator({
  currentStep,
  totalSteps,
  size,
  variant,
  className,
  gap = 2,
  'aria-label': ariaLabel = `Step ${currentStep} of ${totalSteps}`,
  ...props
}: StepIndicatorProps) {
  if (totalSteps <= 0 || currentStep < 1 || currentStep > totalSteps) {
    console.warn('StepIndicator: Invalid step configuration', {
      currentStep,
      totalSteps,
    });
    return null;
  }

  return (
    <Flex
      justify="center"
      align="center"
      gap={gap}
      className={cn('step-indicator', className)}
      role="progressbar"
      aria-label={ariaLabel}
      aria-valuenow={currentStep}
      aria-valuemin={1}
      aria-valuemax={totalSteps}
      {...props}
    >
      {Array.from({ length: totalSteps }, (_, index) => {
        const stepNumber = index + 1;
        const isActive = stepNumber === currentStep;
        const isCompleted = stepNumber < currentStep;

        return (
          <div
            key={stepNumber}
            className={cn(stepIndicatorVariants({ size, variant }))}
            data-active={isActive}
            data-completed={isCompleted}
            data-step={stepNumber}
            aria-hidden="true"
          />
        );
      })}
    </Flex>
  );
}

export { stepIndicatorVariants };
export type { VariantProps as StepIndicatorVariants };
