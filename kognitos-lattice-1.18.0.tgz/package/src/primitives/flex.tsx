import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/design-system/lib/utils';

const flexVariants = cva('flex', {
  variants: {
    direction: {
      row: 'flex-row',
      'row-reverse': 'flex-row-reverse',
      column: 'flex-col',
      'column-reverse': 'flex-col-reverse',
    },
    align: {
      start: 'items-start',
      center: 'items-center',
      end: 'items-end',
      stretch: 'items-stretch',
      baseline: 'items-baseline',
    },
    justify: {
      start: 'justify-start',
      center: 'justify-center',
      end: 'justify-end',
      between: 'justify-between',
      around: 'justify-around',
      evenly: 'justify-evenly',
    },
    wrap: {
      nowrap: 'flex-nowrap',
      wrap: 'flex-wrap',
      'wrap-reverse': 'flex-wrap-reverse',
    },
    gap: {
      0: 'gap-0',
      0.5: 'gap-0.5',
      1: 'gap-1',
      1.5: 'gap-1.5',
      2: 'gap-2',
      2.5: 'gap-2.5',
      3: 'gap-3',
      3.5: 'gap-3.5',
      4: 'gap-4',
      4.5: 'gap-4.5',
      5: 'gap-5',
      6: 'gap-6',
      8: 'gap-8',
      10: 'gap-10',
      11: 'gap-11',
      12: 'gap-12',
      13: 'gap-13',
      14: 'gap-14',
      15: 'gap-15',
      16: 'gap-16',
      18: 'gap-18',
      20: 'gap-20',
      22: 'gap-22',
      24: 'gap-24',
      26: 'gap-26',
      28: 'gap-28',
      30: 'gap-30',
      32: 'gap-32',
      34: 'gap-34',
      36: 'gap-36',
    },
    width: {
      auto: 'w-auto',
      full: 'w-full',
      fit: 'w-fit',
    },
    height: {
      auto: 'h-auto',
      full: 'h-full',
      screen: 'h-screen',
      fit: 'h-fit',
    },
    flex: {
      '1': 'flex-1',
      auto: 'flex-auto',
      initial: 'flex-initial',
      none: 'flex-none',
    },
    position: {
      relative: 'relative',
      absolute: 'absolute',
      fixed: 'fixed',
      sticky: 'sticky',
    },
    overflow: {
      auto: 'overflow-auto',
      hidden: 'overflow-hidden',
      visible: 'overflow-visible',
      scroll: 'overflow-scroll',
    },
    padding: {
      0: 'p-0',
      0.5: 'p-0.5',
      1: 'p-1',
      1.5: 'p-1.5',
      2: 'p-2',
      2.5: 'p-2.5',
      3: 'p-3',
      3.5: 'p-3.5',
      4: 'p-4',
      5: 'p-5',
      6: 'p-6',
      8: 'p-8',
      10: 'p-10',
      12: 'p-12',
    },
    paddingX: {
      0: 'px-0',
      1: 'px-1',
      1.5: 'px-1.5',
      2: 'px-2',
      2.5: 'px-2.5',
      3: 'px-3',
      3.5: 'px-3.5',
      4: 'px-4',
      5: 'px-5',
      6: 'px-6',
      8: 'px-8',
      10: 'px-10',
      12: 'px-12',
    },
    paddingY: {
      0: 'py-0',
      1: 'py-1',
      1.5: 'py-1.5',
      2: 'py-2',
      2.5: 'py-2.5',
      3: 'py-3',
      4: 'py-4',
      5: 'py-5',
      6: 'py-6',
      8: 'py-8',
      10: 'py-10',
      12: 'py-12',
    },
  },
  defaultVariants: {
    direction: 'row',
    align: 'start',
    justify: 'start',
    wrap: 'nowrap',
    gap: 0,
    width: 'auto',
  },
});

interface IFlexProps
  extends
    React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof flexVariants> {
  asChild?: boolean;
}

const Flex = ({
  ref,
  className,
  direction,
  align,
  justify,
  wrap,
  gap,
  width,
  height,
  flex,
  position,
  overflow,
  padding,
  paddingX,
  paddingY,
  ...props
}: IFlexProps & { ref?: React.RefObject<HTMLDivElement | null> }) => {
  return (
    <div
      ref={ref}
      className={cn(
        flexVariants({
          direction,
          align,
          justify,
          wrap,
          gap,
          width,
          height,
          flex,
          position,
          overflow,
          padding,
          paddingX,
          paddingY,
        }),
        className,
      )}
      {...props}
    />
  );
};

Flex.displayName = 'Flex';

export { Flex, flexVariants };
export type { IFlexProps };
