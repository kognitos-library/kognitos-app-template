import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Field,
  FieldContent,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLabel,
  FieldLegend,
  FieldSeparator,
  FieldSet,
  FieldTitle,
} from './field';
import { Input } from './input';
import { Textarea } from './textarea';
import { Button } from './button';
import { Checkbox } from './checkbox';
import { Switch } from './switch';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './select';

const meta: Meta<typeof Field> = {
  title: 'Design System/Primitives/Forms/Field',
  component: Field,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'Combine labels, controls, and help text to compose accessible form fields and grouped inputs. The Field component family provides a flexible system for building forms with proper accessibility, validation states, and responsive layouts.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    orientation: {
      control: { type: 'select' },
      options: ['vertical', 'horizontal', 'responsive'],
      description: 'Layout orientation of the field',
      table: {
        type: { summary: 'vertical | horizontal | responsive' },
        defaultValue: { summary: 'vertical' },
        category: 'Layout',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
};

export default meta;
type Story = StoryObj<typeof Field>;

// Main Demo - Payment Form
export const Demo: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <form>
        <FieldGroup>
          <FieldSet>
            <FieldLegend>Payment Method</FieldLegend>
            <FieldDescription>
              All transactions are secure and encrypted
            </FieldDescription>
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="checkout-7j9-card-name-43j">
                  Name on Card
                </FieldLabel>
                <Input
                  id="checkout-7j9-card-name-43j"
                  placeholder="Evil Rabbit"
                  required
                />
              </Field>
              <Field>
                <FieldLabel htmlFor="checkout-7j9-card-number-uw1">
                  Card Number
                </FieldLabel>
                <Input
                  id="checkout-7j9-card-number-uw1"
                  placeholder="1234 5678 9012 3456"
                  required
                />
                <FieldDescription>
                  Enter your 16-digit card number
                </FieldDescription>
              </Field>
              <div className="grid grid-cols-3 gap-4">
                <Field>
                  <FieldLabel htmlFor="checkout-exp-month-ts6">
                    Month
                  </FieldLabel>
                  <Select defaultValue="">
                    <SelectTrigger id="checkout-exp-month-ts6">
                      <SelectValue placeholder="MM" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="01">01</SelectItem>
                      <SelectItem value="02">02</SelectItem>
                      <SelectItem value="03">03</SelectItem>
                      <SelectItem value="04">04</SelectItem>
                      <SelectItem value="05">05</SelectItem>
                      <SelectItem value="06">06</SelectItem>
                      <SelectItem value="07">07</SelectItem>
                      <SelectItem value="08">08</SelectItem>
                      <SelectItem value="09">09</SelectItem>
                      <SelectItem value="10">10</SelectItem>
                      <SelectItem value="11">11</SelectItem>
                      <SelectItem value="12">12</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel htmlFor="checkout-7j9-exp-year-f59">
                    Year
                  </FieldLabel>
                  <Select defaultValue="">
                    <SelectTrigger id="checkout-7j9-exp-year-f59">
                      <SelectValue placeholder="YYYY" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2025">2025</SelectItem>
                      <SelectItem value="2026">2026</SelectItem>
                      <SelectItem value="2027">2027</SelectItem>
                      <SelectItem value="2028">2028</SelectItem>
                      <SelectItem value="2029">2029</SelectItem>
                    </SelectContent>
                  </Select>
                </Field>
                <Field>
                  <FieldLabel htmlFor="checkout-7j9-cvv">CVV</FieldLabel>
                  <Input id="checkout-7j9-cvv" placeholder="123" required />
                </Field>
              </div>
            </FieldGroup>
          </FieldSet>
          <FieldSeparator />
          <FieldSet>
            <FieldLegend>Billing Address</FieldLegend>
            <FieldDescription>
              The billing address associated with your payment method
            </FieldDescription>
            <FieldGroup>
              <Field orientation="horizontal">
                <Checkbox
                  id="checkout-7j9-same-as-shipping-wgm"
                  defaultChecked
                />
                <FieldLabel
                  htmlFor="checkout-7j9-same-as-shipping-wgm"
                  className="font-normal"
                >
                  Same as shipping address
                </FieldLabel>
              </Field>
            </FieldGroup>
          </FieldSet>
          <FieldSet>
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="checkout-7j9-optional-comments">
                  Comments
                </FieldLabel>
                <Textarea
                  id="checkout-7j9-optional-comments"
                  placeholder="Add any additional comments"
                  className="resize-none"
                />
              </Field>
            </FieldGroup>
          </FieldSet>
          <Field orientation="horizontal">
            <Button type="submit">Submit</Button>
            <Button variant="outline" type="button">
              Cancel
            </Button>
          </Field>
        </FieldGroup>
      </form>
    </div>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'A complete payment form demonstrating all Field components working together with proper grouping, separators, and responsive layouts.',
      },
    },
  },
};

// Input Examples
export const InputExample: Story = {
  render: () => (
    <div className="w-full max-w-md space-y-4">
      <Field>
        <FieldLabel htmlFor="username">Username</FieldLabel>
        <Input id="username" placeholder="Enter your username" />
        <FieldDescription>
          Choose a unique username for your account.
        </FieldDescription>
      </Field>
      <Field>
        <FieldLabel htmlFor="password">Password</FieldLabel>
        <Input
          id="password"
          type="password"
          placeholder="Enter your password"
        />
        <FieldDescription>Must be at least 8 characters long.</FieldDescription>
      </Field>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Basic field usage with input controls. Each field includes a label, input, and optional helper text.',
      },
    },
  },
};

// Textarea Example
export const TextareaExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <Field>
        <FieldLabel htmlFor="bio">Bio</FieldLabel>
        <Textarea
          id="bio"
          placeholder="Tell us about yourself"
          className="min-h-[100px] resize-none"
        />
        <FieldDescription>
          A brief description about yourself (max 200 characters).
        </FieldDescription>
      </Field>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Field component with a textarea control for longer text input.',
      },
    },
  },
};

// Select Example
export const SelectExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <Field>
        <FieldLabel htmlFor="country">Country</FieldLabel>
        <Select defaultValue="">
          <SelectTrigger id="country">
            <SelectValue placeholder="Select your country" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="us">United States</SelectItem>
            <SelectItem value="uk">United Kingdom</SelectItem>
            <SelectItem value="ca">Canada</SelectItem>
            <SelectItem value="au">Australia</SelectItem>
          </SelectContent>
        </Select>
        <FieldDescription>Select your country of residence.</FieldDescription>
      </Field>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Field component with a select dropdown control.',
      },
    },
  },
};

// Slider Example (placeholder as slider component may not be available)
export const SliderExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <Field>
        <FieldLabel htmlFor="volume">Volume</FieldLabel>
        <Input id="volume" type="range" min="0" max="100" defaultValue="50" />
        <FieldDescription>Adjust the volume level.</FieldDescription>
      </Field>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Field component with a range input control (using native HTML range input).',
      },
    },
  },
};

// FieldSet Example
export const FieldSetExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <FieldSet>
        <FieldLegend>Profile</FieldLegend>
        <FieldDescription>
          This appears on invoices and emails.
        </FieldDescription>
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="name">Full name</FieldLabel>
            <Input id="name" autoComplete="off" placeholder="Evil Rabbit" />
            <FieldDescription>
              This appears on invoices and emails.
            </FieldDescription>
          </Field>
          <Field>
            <FieldLabel htmlFor="username-error">Username</FieldLabel>
            <Input
              id="username-error"
              autoComplete="off"
              aria-invalid
              defaultValue="evil"
            />
            <FieldError>Choose another username.</FieldError>
          </Field>
          <Field orientation="horizontal">
            <Switch id="newsletter" />
            <FieldLabel htmlFor="newsletter">
              Subscribe to the newsletter
            </FieldLabel>
          </Field>
        </FieldGroup>
      </FieldSet>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'FieldSet groups related fields with a legend and shared description. Includes validation error example.',
      },
    },
  },
};

// Checkbox Example
export const CheckboxExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <FieldSet>
        <FieldLegend>Notifications</FieldLegend>
        <FieldDescription>
          Choose how you want to receive updates.
        </FieldDescription>
        <FieldGroup data-slot="checkbox-group">
          <Field orientation="horizontal">
            <Checkbox id="email-notif" />
            <FieldLabel htmlFor="email-notif" className="font-normal">
              Email notifications
            </FieldLabel>
          </Field>
          <Field orientation="horizontal">
            <Checkbox id="push-notif" />
            <FieldLabel htmlFor="push-notif" className="font-normal">
              Push notifications
            </FieldLabel>
          </Field>
          <Field orientation="horizontal">
            <Checkbox id="sms-notif" />
            <FieldLabel htmlFor="sms-notif" className="font-normal">
              SMS notifications
            </FieldLabel>
          </Field>
        </FieldGroup>
      </FieldSet>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Checkbox group with horizontal field orientation. The checkbox-group data attribute adjusts spacing.',
      },
    },
  },
};

// Switch Example
export const SwitchExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <FieldSet>
        <FieldLegend>Privacy Settings</FieldLegend>
        <FieldDescription>
          Control your privacy and security settings.
        </FieldDescription>
        <FieldGroup>
          <Field orientation="horizontal">
            <Switch id="profile-visible" defaultChecked />
            <FieldContent>
              <FieldLabel htmlFor="profile-visible">Public Profile</FieldLabel>
              <FieldDescription>
                Make your profile visible to everyone.
              </FieldDescription>
            </FieldContent>
          </Field>
          <Field orientation="horizontal">
            <Switch id="2fa" />
            <FieldContent>
              <FieldLabel htmlFor="2fa">Two-Factor Authentication</FieldLabel>
              <FieldDescription>
                Add an extra layer of security to your account.
              </FieldDescription>
            </FieldContent>
          </Field>
        </FieldGroup>
      </FieldSet>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Switch controls with FieldContent to group label and description when using horizontal orientation.',
      },
    },
  },
};

// Field Group Example
export const FieldGroupExample: Story = {
  render: () => (
    <div className="w-full max-w-2xl">
      <FieldSet>
        <FieldLegend>Shipping Information</FieldLegend>
        <FieldGroup>
          <div className="grid grid-cols-2 gap-4">
            <Field>
              <FieldLabel htmlFor="first-name">First Name</FieldLabel>
              <Input id="first-name" placeholder="First name" />
            </Field>
            <Field>
              <FieldLabel htmlFor="last-name">Last Name</FieldLabel>
              <Input id="last-name" placeholder="Last name" />
            </Field>
          </div>
          <Field>
            <FieldLabel htmlFor="address">Address</FieldLabel>
            <Input id="address" placeholder="Street address" />
          </Field>
          <div className="grid grid-cols-3 gap-4">
            <Field>
              <FieldLabel htmlFor="city">City</FieldLabel>
              <Input id="city" placeholder="City" />
            </Field>
            <Field>
              <FieldLabel htmlFor="state">State</FieldLabel>
              <Input id="state" placeholder="State" />
            </Field>
            <Field>
              <FieldLabel htmlFor="zip">ZIP Code</FieldLabel>
              <Input id="zip" placeholder="ZIP" />
            </Field>
          </div>
        </FieldGroup>
      </FieldSet>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'FieldGroup with custom grid layouts to organize multiple fields in rows and columns.',
      },
    },
  },
};

// Responsive Layout Example
export const ResponsiveLayoutExample: Story = {
  render: () => (
    <div className="w-full max-w-4xl">
      <form>
        <FieldSet>
          <FieldLegend>Profile</FieldLegend>
          <FieldDescription>Fill in your profile information.</FieldDescription>
          <FieldSeparator />
          <FieldGroup>
            <Field orientation="responsive">
              <FieldContent>
                <FieldLabel htmlFor="name-resp">Name</FieldLabel>
                <FieldDescription>
                  Provide your full name for identification
                </FieldDescription>
              </FieldContent>
              <Input id="name-resp" placeholder="Evil Rabbit" required />
            </Field>
            <FieldSeparator />
            <Field orientation="responsive">
              <FieldContent>
                <FieldLabel htmlFor="message-resp">Message</FieldLabel>
                <FieldDescription>
                  You can write your message here. Keep it short, preferably
                  under 100 characters.
                </FieldDescription>
              </FieldContent>
              <Textarea
                id="message-resp"
                placeholder="Hello, world!"
                required
                className="min-h-[100px] resize-none sm:min-w-[300px]"
              />
            </Field>
            <FieldSeparator />
            <Field orientation="responsive">
              <Button type="submit">Submit</Button>
              <Button type="button" variant="outline">
                Cancel
              </Button>
            </Field>
          </FieldGroup>
        </FieldSet>
      </form>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Responsive field orientation that adapts from vertical on mobile to horizontal on larger screens. Uses FieldContent to keep descriptions aligned.',
      },
    },
  },
};

// Validation and Errors Example
export const ValidationExample: Story = {
  render: () => (
    <div className="w-full max-w-md space-y-4">
      <Field data-invalid="true">
        <FieldLabel htmlFor="email-invalid">Email</FieldLabel>
        <Input
          id="email-invalid"
          type="email"
          aria-invalid
          defaultValue="invalid-email"
        />
        <FieldError>Enter a valid email address.</FieldError>
      </Field>
      <Field data-invalid="true">
        <FieldLabel htmlFor="username-invalid">Username</FieldLabel>
        <Input
          id="username-invalid"
          aria-invalid
          defaultValue="taken-username"
        />
        <FieldError
          errors={[
            { message: 'Username is already taken.' },
            { message: 'Username must be at least 3 characters.' },
          ]}
        />
      </Field>
      <Field>
        <FieldLabel htmlFor="phone-valid">Phone Number</FieldLabel>
        <Input id="phone-valid" type="tel" defaultValue="+1 (555) 123-4567" />
        <FieldDescription>Valid phone number format.</FieldDescription>
      </Field>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Field components with validation states. Use data-invalid on Field and aria-invalid on inputs. FieldError can display single or multiple error messages.',
      },
    },
  },
};

// Nested FieldSet Example
export const NestedFieldSetExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <FieldSet>
        <FieldLegend>Account Settings</FieldLegend>
        <FieldGroup>
          <FieldSet>
            <FieldLegend variant="label">Personal Information</FieldLegend>
            <FieldGroup>
              <Field>
                <FieldLabel htmlFor="email-nested">Email</FieldLabel>
                <Input
                  id="email-nested"
                  type="email"
                  placeholder="Email address"
                />
              </Field>
              <Field>
                <FieldLabel htmlFor="phone-nested">Phone</FieldLabel>
                <Input
                  id="phone-nested"
                  type="tel"
                  placeholder="Phone number"
                />
              </Field>
            </FieldGroup>
          </FieldSet>
          <FieldSeparator />
          <FieldSet>
            <FieldLegend variant="label">Preferences</FieldLegend>
            <FieldGroup data-slot="checkbox-group">
              <Field orientation="horizontal">
                <Checkbox id="marketing" />
                <FieldLabel htmlFor="marketing" className="font-normal">
                  Receive marketing emails
                </FieldLabel>
              </Field>
              <Field orientation="horizontal">
                <Checkbox id="updates" />
                <FieldLabel htmlFor="updates" className="font-normal">
                  Receive product updates
                </FieldLabel>
              </Field>
            </FieldGroup>
          </FieldSet>
        </FieldGroup>
      </FieldSet>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Nested FieldSet components with the label variant for sub-sections. Use FieldSeparator between sections.',
      },
    },
  },
};

// Field with FieldTitle
export const FieldTitleExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <FieldSet>
        <FieldLegend>Biometric Settings</FieldLegend>
        <FieldGroup>
          <Field orientation="horizontal">
            <Switch id="touch-id" defaultChecked />
            <FieldContent>
              <FieldTitle>Enable Touch ID</FieldTitle>
              <FieldDescription>
                Unlock your device faster with fingerprint authentication.
              </FieldDescription>
            </FieldContent>
          </Field>
          <Field orientation="horizontal">
            <Switch id="face-id" />
            <FieldContent>
              <FieldTitle>Enable Face ID</FieldTitle>
              <FieldDescription>
                Use facial recognition to unlock your device.
              </FieldDescription>
            </FieldContent>
          </Field>
        </FieldGroup>
      </FieldSet>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Use FieldTitle instead of FieldLabel when you need a title without htmlFor association (e.g., for non-focusable controls).',
      },
    },
  },
};

// Separator with Content
export const SeparatorWithContentExample: Story = {
  render: () => (
    <div className="w-full max-w-md">
      <FieldSet>
        <FieldLegend>Sign In</FieldLegend>
        <FieldGroup>
          <Field>
            <FieldLabel htmlFor="email-sep">Email</FieldLabel>
            <Input id="email-sep" type="email" placeholder="Email address" />
          </Field>
          <Field>
            <FieldLabel htmlFor="password-sep">Password</FieldLabel>
            <Input id="password-sep" type="password" placeholder="Password" />
          </Field>
          <Button type="submit" className="w-full">
            Sign In
          </Button>
          <FieldSeparator>Or continue with</FieldSeparator>
          <Button type="button" variant="outline" className="w-full">
            Sign in with Google
          </Button>
        </FieldGroup>
      </FieldSet>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'FieldSeparator can include inline content to create visual dividers with text.',
      },
    },
  },
};

// Horizontal Orientation
export const HorizontalOrientationExample: Story = {
  render: () => (
    <div className="w-full max-w-md space-y-4">
      <Field orientation="horizontal">
        <FieldLabel htmlFor="remember-me" className="flex-1">
          Remember me
        </FieldLabel>
        <Switch id="remember-me" />
      </Field>
      <Field orientation="horizontal">
        <FieldLabel htmlFor="auto-save" className="flex-1">
          Auto-save drafts
        </FieldLabel>
        <Switch id="auto-save" defaultChecked />
      </Field>
      <Field orientation="horizontal">
        <FieldLabel htmlFor="notifications" className="flex-1">
          Enable notifications
        </FieldLabel>
        <Switch id="notifications" />
      </Field>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Horizontal field orientation aligns label and control side-by-side. Great for switches and checkboxes.',
      },
    },
  },
};

// Complete Form Example
export const CompleteFormExample: Story = {
  render: () => (
    <div className="w-full max-w-2xl">
      <form>
        <FieldGroup>
          <FieldSet>
            <FieldLegend>Create Account</FieldLegend>
            <FieldDescription>
              Fill in the form below to create your account.
            </FieldDescription>
            <FieldSeparator />
            <FieldGroup>
              <div className="grid grid-cols-2 gap-4">
                <Field>
                  <FieldLabel htmlFor="first-name-form">First Name</FieldLabel>
                  <Input
                    id="first-name-form"
                    placeholder="First name"
                    required
                  />
                </Field>
                <Field>
                  <FieldLabel htmlFor="last-name-form">Last Name</FieldLabel>
                  <Input id="last-name-form" placeholder="Last name" required />
                </Field>
              </div>
              <Field>
                <FieldLabel htmlFor="email-form">Email</FieldLabel>
                <Input
                  id="email-form"
                  type="email"
                  placeholder="email@example.com"
                  required
                />
                <FieldDescription>
                  We'll never share your email with anyone.
                </FieldDescription>
              </Field>
              <Field>
                <FieldLabel htmlFor="password-form">Password</FieldLabel>
                <Input
                  id="password-form"
                  type="password"
                  placeholder="Create a password"
                  required
                />
                <FieldDescription>
                  Must be at least 8 characters with a mix of letters and
                  numbers.
                </FieldDescription>
              </Field>
            </FieldGroup>
          </FieldSet>
          <FieldSeparator />
          <FieldSet>
            <FieldLegend variant="label">Preferences</FieldLegend>
            <FieldGroup data-slot="checkbox-group">
              <Field orientation="horizontal">
                <Checkbox id="terms" required />
                <FieldLabel htmlFor="terms" className="font-normal">
                  I agree to the terms and conditions
                </FieldLabel>
              </Field>
              <Field orientation="horizontal">
                <Checkbox id="marketing-emails" />
                <FieldLabel htmlFor="marketing-emails" className="font-normal">
                  Send me marketing emails and special offers
                </FieldLabel>
              </Field>
            </FieldGroup>
          </FieldSet>
          <FieldSeparator />
          <Field orientation="horizontal">
            <Button type="submit">Create Account</Button>
            <Button type="button" variant="outline">
              Cancel
            </Button>
          </Field>
        </FieldGroup>
      </form>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'A complete registration form showcasing all field components working together with proper structure, validation, and layout.',
      },
    },
  },
};

// Accessibility Example
export const AccessibilityExample: Story = {
  render: () => (
    <div className="w-full max-w-md space-y-6">
      <div className="bg-muted p-4 rounded-lg space-y-4">
        <div>
          <h4 className="font-medium text-foreground mb-2 text-sm">
            Proper Label Association
          </h4>
          <Field>
            <FieldLabel htmlFor="accessible-input">Full Name</FieldLabel>
            <Input id="accessible-input" placeholder="Enter your name" />
            <FieldDescription>
              Labels are properly associated with inputs using htmlFor.
            </FieldDescription>
          </Field>
        </div>
        <div>
          <h4 className="font-medium text-foreground mb-2 text-sm">
            Semantic Grouping
          </h4>
          <FieldSet>
            <FieldLegend variant="label">Contact Preferences</FieldLegend>
            <FieldGroup data-slot="checkbox-group">
              <Field orientation="horizontal">
                <Checkbox id="email-pref" />
                <FieldLabel htmlFor="email-pref" className="font-normal">
                  Email
                </FieldLabel>
              </Field>
              <Field orientation="horizontal">
                <Checkbox id="phone-pref" />
                <FieldLabel htmlFor="phone-pref" className="font-normal">
                  Phone
                </FieldLabel>
              </Field>
            </FieldGroup>
          </FieldSet>
        </div>
        <div>
          <h4 className="font-medium text-foreground mb-2 text-sm">
            Error Announcements
          </h4>
          <Field data-invalid="true">
            <FieldLabel htmlFor="error-input">Email Address</FieldLabel>
            <Input
              id="error-input"
              type="email"
              aria-invalid
              defaultValue="invalid"
            />
            <FieldError>
              Please enter a valid email address (role="alert" for screen
              readers).
            </FieldError>
          </Field>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Field components are built with accessibility in mind. Labels are properly associated, errors use role="alert", and semantic HTML is used throughout.',
      },
    },
  },
};
