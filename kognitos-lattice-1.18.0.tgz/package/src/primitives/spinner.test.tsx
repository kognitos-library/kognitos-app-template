import { render, screen } from '@testing-library/react';
import { describe, expect, it } from 'vitest';

import { Spinner } from './spinner';

describe('Spinner', () => {
  it('renders with default props', () => {
    render(<Spinner />);
    const spinner = screen.getByRole('status');
    expect(spinner).toBeInTheDocument();
    expect(spinner).toHaveAttribute('aria-label', 'Loading');
    expect(spinner).toHaveAttribute('data-slot', 'spinner');
  });

  it('renders with custom size', () => {
    render(<Spinner size="lg" />);
    const spinner = screen.getByRole('status');
    expect(spinner).toHaveClass('size-8');
  });

  it('renders with custom variant', () => {
    render(<Spinner variant="destructive" />);
    const spinner = screen.getByRole('status');
    expect(spinner).toHaveClass('text-destructive');
  });

  it('renders with custom className', () => {
    render(<Spinner className="custom-class" />);
    const spinner = screen.getByRole('status');
    expect(spinner).toHaveClass('custom-class');
  });

  it('renders with custom data-testid', () => {
    render(<Spinner data-testid="custom-spinner" />);
    const spinner = screen.getByTestId('custom-spinner');
    expect(spinner).toBeInTheDocument();
  });

  it('renders all size variants', () => {
    const { rerender } = render(<Spinner size="sm" />);
    expect(screen.getByRole('status')).toHaveClass('size-3.5');

    rerender(<Spinner size="default" />);
    expect(screen.getByRole('status')).toHaveClass('size-4');

    rerender(<Spinner size="lg" />);
    expect(screen.getByRole('status')).toHaveClass('size-8');

    rerender(<Spinner size="xl" />);
    expect(screen.getByRole('status')).toHaveClass('size-12');
  });

  it('renders all variant variants', () => {
    const { rerender } = render(<Spinner variant="default" />);
    expect(screen.getByRole('status')).toHaveClass('text-primary');

    rerender(<Spinner variant="secondary" />);
    expect(screen.getByRole('status')).toHaveClass('text-secondary');

    rerender(<Spinner variant="muted" />);
    expect(screen.getByRole('status')).toHaveClass('text-muted-foreground');

    rerender(<Spinner variant="destructive" />);
    expect(screen.getByRole('status')).toHaveClass('text-destructive');

    rerender(<Spinner variant="accent" />);
    expect(screen.getByRole('status')).toHaveClass('text-accent');
  });

  it('has proper accessibility attributes', () => {
    render(<Spinner />);
    const spinner = screen.getByRole('status');
    expect(spinner).toHaveAttribute('aria-label', 'Loading');
  });
});
