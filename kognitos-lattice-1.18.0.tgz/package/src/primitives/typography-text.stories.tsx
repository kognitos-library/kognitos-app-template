import type { Meta, StoryObj } from '@storybook/react-vite';
import {
  Text,
  type TextLevel,
  type TextType,
  type TextColor,
  type TextAlign,
  type TextWeight,
} from '@/design-system';

const meta: Meta<typeof Text> = {
  title: 'Design System/Primitives/General/Typography/Text',
  component: Text,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'Text component for body content with semantic variants. Supports various text levels (small, base, large) and types (paragraph, lead, inlineCode, code, blockquote) with consistent styling that matches the design system.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
  argTypes: {
    level: {
      control: { type: 'select' },
      options: ['small', 'base', 'large'],
      description: 'Text size level',
    },
    type: {
      control: { type: 'select' },
      options: ['paragraph', 'lead', 'inlineCode', 'code', 'blockquote'],
      description: 'Text type/style',
    },
    color: {
      control: { type: 'select' },
      options: [
        'default',
        'muted',
        'primary',
        'secondary',
        'accent',
        'destructive',
        'card',
      ],
      description: 'Text color variant',
    },
    align: {
      control: { type: 'select' },
      options: ['left', 'center', 'right', 'justify'],
      description: 'Text alignment',
    },
    weight: {
      control: { type: 'select' },
      options: ['normal', 'medium', 'semibold', 'bold'],
      description: 'Font weight',
    },
    as: {
      control: { type: 'select' },
      options: ['p', 'span', 'div', 'code', 'blockquote'],
      description: 'HTML element to render as',
    },
    children: {
      control: { type: 'text' },
      description: 'Content to display',
    },
  },
};

export default meta;
type Story = StoryObj<typeof Text>;

// Interactive Text Component with Controls
export const Default: Story = {
  args: {
    level: 'base',
    type: 'paragraph',
    color: 'default',
    align: 'left',
    weight: 'normal',
    children: 'Sample text content',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Interactive Text component with controls. Adjust the props using the controls panel to see real-time changes.',
      },
    },
  },
  render: args => (
    <div className="space-y-4">
      <Text
        level={args.level}
        type={args.type}
        color={args.color}
        align={args.align}
        weight={args.weight}
        as={args.as}
      >
        {args.children}
      </Text>

      <div className="p-3 bg-muted rounded text-xs font-mono">
        <div>Level: {args.level}</div>
        <div>Type: {args.type}</div>
        <div>Color: {args.color}</div>
        <div>Align: {args.align}</div>
        <div>Weight: {args.weight}</div>
        <div>As: {args.as}</div>
      </div>
    </div>
  ),
};

// All Text Levels
export const AllLevels: Story = {
  parameters: {
    docs: {
      description: {
        story: 'All available Text levels displayed in a clean format.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Text Levels</h3>
      <div className="space-y-3">
        {['small', 'base', 'large'].map(level => (
          <div key={level} className="flex items-center gap-4">
            <div className="w-24 text-sm font-mono text-muted-foreground">
              {level}
            </div>
            <Text level={level as TextLevel}>Text level {level} example</Text>
          </div>
        ))}
      </div>
    </div>
  ),
};

// All Text Types
export const AllTypes: Story = {
  parameters: {
    docs: {
      description: {
        story: 'All available Text types displayed in a clean format.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Text Types</h3>
      <div className="space-y-3">
        {['paragraph', 'lead', 'inlineCode', 'code', 'blockquote'].map(type => (
          <div key={type} className="flex items-center gap-4">
            <div className="w-24 text-sm font-mono text-muted-foreground">
              {type}
            </div>
            <Text type={type as TextType}>
              {type === 'code'
                ? 'const greeting = "Hello, World!";'
                : type === 'inlineCode'
                  ? 'inline code example'
                  : type === 'blockquote'
                    ? 'This is a blockquote example with italic styling.'
                    : type === 'lead'
                      ? 'This is a lead paragraph example with larger text and muted color.'
                      : `Text type ${type} example`}
            </Text>
          </div>
        ))}
      </div>
    </div>
  ),
};

// Color Variants
export const ColorVariants: Story = {
  parameters: {
    docs: {
      description: {
        story: 'All available color variants for the Text component.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Color Variants</h3>
      <div className="space-y-3">
        {[
          'default',
          'muted',
          'primary',
          'secondary',
          'accent',
          'destructive',
          'card',
        ].map(color => (
          <div key={color} className="flex items-center gap-4">
            <div className="w-20 text-sm font-mono text-muted-foreground">
              {color}
            </div>
            <Text level="base" color={color as TextColor}>
              {color.charAt(0).toUpperCase() + color.slice(1)} text color
            </Text>
          </div>
        ))}
      </div>
    </div>
  ),
};

// Font Weights
export const FontWeights: Story = {
  parameters: {
    docs: {
      description: {
        story: 'All font weight options for the Text component.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Font Weights</h3>
      <div className="space-y-3">
        {['normal', 'medium', 'semibold', 'bold'].map(weight => (
          <div key={weight} className="flex items-center gap-4">
            <div className="w-20 text-sm font-mono text-muted-foreground">
              {weight}
            </div>
            <Text level="base" weight={weight as TextWeight}>
              {weight.charAt(0).toUpperCase() + weight.slice(1)} weight text
            </Text>
          </div>
        ))}
      </div>
    </div>
  ),
};

// Alignment Options
export const Alignment: Story = {
  parameters: {
    docs: {
      description: {
        story: 'All alignment options for the Text component.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">
        Alignment Options
      </h3>
      <div className="space-y-6">
        {['left', 'center', 'right', 'justify'].map(align => (
          <div key={align} className="space-y-2">
            <div className="text-sm font-mono text-muted-foreground">
              align="{align}"
            </div>
            <Text level="base" align={align as TextAlign}>
              {align.charAt(0).toUpperCase() + align.slice(1)} aligned text.
              This demonstrates how the text alignment affects the layout and
              readability of the content.
            </Text>
          </div>
        ))}
      </div>
    </div>
  ),
};

// Interactive Examples
export const InteractiveExamples: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Interactive text examples with hover states and links.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">
        Interactive Examples
      </h3>
      <div className="space-y-3">
        <a href="#" className="text-primary hover:underline text-base">
          This is a clickable link
        </a>
        <Text
          level="base"
          className="cursor-pointer hover:text-primary transition-colors"
        >
          This text has hover effects
        </Text>
        <Text
          level="small"
          color="muted"
          className="hover:text-foreground transition-colors"
        >
          Hover over this muted text to see it change
        </Text>
      </div>
    </div>
  ),
};

// Code Examples
export const CodeExamples: Story = {
  parameters: {
    docs: {
      description: {
        story: 'Code typography examples using the Text component.',
      },
    },
  },
  render: () => (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground">Code Examples</h3>
      <div className="space-y-3">
        <div className="p-4 border border-border rounded-lg">
          <Text type="inlineCode" level="base">
            const greeting = 'Hello, World!';
          </Text>
        </div>
        <div className="p-4 border border-border rounded-lg">
          <Text type="code" level="base" as="code">
            {`function greet(name) {
  return \`Hello, \${name}!\`;
}`}
          </Text>
        </div>
      </div>
    </div>
  ),
};

// Real-world Examples
export const Examples: Story = {
  parameters: {
    docs: {
      description: {
        story:
          'Real-world examples of Text component usage based on actual codebase patterns.',
      },
    },
  },
  render: () => (
    <div className="space-y-6">
      <h3 className="text-lg font-semibold text-foreground">
        Real-world Examples
      </h3>

      {/* Loading State */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <div className="text-center py-4">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
          <Text level="small" color="muted" className="mt-2">
            Loading system information...
          </Text>
        </div>
      </div>

      {/* Error State */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <div className="bg-destructive/10 border border-destructive/20 rounded-md p-4">
          <Text level="small" color="destructive">
            Error loading system information: Network error
          </Text>
        </div>
      </div>

      {/* Data Display */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <div className="flex items-center justify-between p-3 bg-muted rounded-md">
          <Text level="small" weight="bold" color="muted">
            IP Address:
          </Text>
          <Text level="small">192.168.1.1</Text>
        </div>

        <div className="p-3 bg-muted rounded-md">
          <Text
            level="small"
            weight="bold"
            color="muted"
            className="block mb-2"
          >
            User Agent:
          </Text>
          <Text type="code" level="small" color="muted" className="break-all">
            Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36
          </Text>
        </div>
      </div>

      {/* Article Content */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Text type="lead" color="muted">
          This is an article introduction with lead text, muted color for better
          readability and visual hierarchy.
        </Text>
        <Text level="base">
          This is the main body text of the article. It uses the base level with
          paragraph type to ensure comfortable reading experience for longer
          content.
        </Text>
        <Text level="small" color="muted">
          This is a caption or metadata text with small level and muted color.
        </Text>
      </div>

      {/* Form Description */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Text level="base" color="muted">
          Please provide your contact information below. We'll use this to get
          in touch with you regarding your inquiry.
        </Text>
      </div>

      {/* Card Content */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Text level="large" color="primary" weight="bold">
          Feature Description
        </Text>
        <Text level="base">
          This feature provides enhanced functionality with improved performance
          and better user experience.
        </Text>
      </div>

      {/* Blockquote Example */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Text type="blockquote" color="muted">
          "The best way to predict the future is to invent it." - Alan Kay
        </Text>
      </div>

      {/* Footer Text */}
      <div className="space-y-3 p-4 border border-border rounded-lg">
        <Text level="small" color="muted" align="center">
          © 2025 Kognitos. All rights reserved.
        </Text>
      </div>
    </div>
  ),
};
