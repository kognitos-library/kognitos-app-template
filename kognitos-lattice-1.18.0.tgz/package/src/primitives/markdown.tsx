import ReactMarkdown, { type Components } from 'react-markdown';
import remarkGfm from 'remark-gfm';

import { cn } from '@/design-system';
import { Text, textVariants, Title, type ITextProps } from './typography';
import { buttonVariants } from './button';
import { isValidMarkdownLinkUrl } from '../lib/utils/markdown';

const MARKDOWN_HEADING_SPACING = 'mb-2 last:mb-0';

const DEFAULT_TEXT_PROPS: Pick<ITextProps, 'level' | 'color' | 'weight'> = {
  level: 'base',
  color: 'default',
  weight: 'normal',
};

/**
 * Props for the Markdown component.
 */
interface IMarkdownProps {
  /** The markdown content to render */
  children: string;
  /** Text styling properties to apply to markdown elements */
  textProps?: Pick<ITextProps, 'level' | 'color' | 'weight'>;
  /** Additional className for the wrapper element */
  className?: string;
  /** Additional className applied to every text element (merged via cn, can override variant classes like text color) */
  textClassName?: string;
}

/**
 * Creates React Markdown components configured with design system Text components.
 *
 * The components use the provided text props (level, color, weight) to maintain
 * consistent styling throughout the markdown content.
 *
 * @param textProps - Text styling properties to apply to markdown elements
 * @param textClassName - Additional className applied to every text element (merged via cn, so it can override variant classes)
 * @returns React Markdown components configuration object
 *
 * @example
 * const textProps = { level: 'base', color: 'default', weight: 'normal' };
 * const markdownComponents = createMarkdownComponents(textProps);
 * <ReactMarkdown components={markdownComponents}>{content}</ReactMarkdown>
 */
function createMarkdownComponents(
  textProps: Pick<ITextProps, 'level' | 'color' | 'weight'>,
  textClassName?: string,
): Components {
  return {
    p: ({ children }) => (
      <Text
        level={textProps.level}
        color={textProps.color}
        weight={textProps.weight}
        className={cn('mb-2 last:mb-0', textClassName)}
      >
        {children}
      </Text>
    ),
    h1: ({ children }) => (
      <Title
        level="h1"
        color={textProps.color}
        className={MARKDOWN_HEADING_SPACING}
      >
        {children}
      </Title>
    ),
    h2: ({ children }) => (
      <Title
        level="h2"
        color={textProps.color}
        className={MARKDOWN_HEADING_SPACING}
      >
        {children}
      </Title>
    ),
    h3: ({ children }) => (
      <Title
        level="h3"
        color={textProps.color}
        className={MARKDOWN_HEADING_SPACING}
      >
        {children}
      </Title>
    ),
    h4: ({ children }) => (
      <Title
        level="h4"
        color={textProps.color}
        className={MARKDOWN_HEADING_SPACING}
      >
        {children}
      </Title>
    ),
    strong: ({ children }) => (
      <strong className="font-semibold">{children}</strong>
    ),
    em: ({ children }) => (
      <em
        className={cn(
          textVariants({
            level: textProps.level,
            color: textProps.color,
            weight: textProps.weight,
          }),
          'italic',
          textClassName,
        )}
      >
        {children}
      </em>
    ),
    pre: ({ children }) => (
      <pre
        className={cn(
          textVariants({
            level: textProps.level,
            color: textProps.color,
            weight: textProps.weight,
          }),
          'whitespace-pre-wrap break-anywhere',
          textClassName,
        )}
      >
        {children}
      </pre>
    ),
    code: ({ className, children }) => {
      // Inline code doesn't have a className, block code has 'language-*' class
      const isInline = !className || !className.includes('language-');
      if (isInline) {
        return (
          <Text
            type="inlineCode"
            level={textProps.level}
            color={textProps.color}
            as="code"
            className={textClassName}
          >
            {children}
          </Text>
        );
      }
      return (
        <Text
          type="code"
          level={textProps.level}
          color={textProps.color}
          as="code"
          className={cn('block my-2', textClassName)}
        >
          {children}
        </Text>
      );
    },
    ul: ({ children }) => (
      <ul className="list-disc list-inside mb-2 ml-2 space-y-1">{children}</ul>
    ),
    ol: ({ children }) => (
      <ol className="list-decimal list-inside mb-2 ml-2 space-y-1">
        {children}
      </ol>
    ),
    li: ({ children }) => (
      <li
        className={cn(
          textVariants({
            level: textProps.level,
            color: textProps.color,
            weight: textProps.weight,
          }),
          textClassName,
        )}
      >
        {children}
      </li>
    ),
    blockquote: ({ children }) => (
      <Text
        type="blockquote"
        level={textProps.level}
        color="muted"
        className="my-2"
        as="blockquote"
      >
        {children}
      </Text>
    ),
    a: ({ href, children }) => {
      // Validate URL to prevent XSS attacks via dangerous protocols (javascript:, data:, etc.)
      const isValidUrl = isValidMarkdownLinkUrl(href);

      // If URL is invalid or dangerous, render as plain text instead of a link
      if (!isValidUrl) {
        return <span className="text-link">{children}</span>;
      }

      return (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          className={cn(
            // Use buttonVariants link variant classes for consistent styling
            buttonVariants({ variant: 'link' }),
            // Override button base classes to make it work as an inline markdown link
            '!inline !whitespace-normal !h-auto !px-0 !py-0',
          )}
        >
          {children}
        </a>
      );
    },
    hr: () => <hr className="my-4 border-border" />,
    table: ({ children }) => (
      <div className="w-full overflow-x-auto my-4">
        <table className="border-collapse table-auto w-full border border-border text-xs">
          {children}
        </table>
      </div>
    ),
    thead: ({ children }) => <thead className="bg-muted">{children}</thead>,
    tbody: ({ children }) => <tbody>{children}</tbody>,
    tr: ({ children }) => <tr>{children}</tr>,
    th: ({ children }) => (
      <th className="border border-border p-3 text-left font-semibold">
        {children}
      </th>
    ),
    td: ({ children }) => (
      <td className="border border-border p-3">{children}</td>
    ),
  };
}

/**
 * Markdown component that renders markdown content using design system components.
 *
 * Provides consistent styling for markdown elements (headings, paragraphs, links, code blocks, etc.)
 * using the design system's Text and Title components.
 *
 * @param props - Component props
 * @param props.children - The markdown content to render
 * @param props.textProps - Text styling properties to apply to markdown elements
 * @param props.className - Additional className for the wrapper element
 * @returns Markdown-rendered content
 *
 * @example
 * <Markdown textProps={{ level: 'base', color: 'default' }}>
 *   # Heading
 *   This is **bold** text with a [link](https://example.com)
 * </Markdown>
 */
function Markdown({
  children,
  textProps = DEFAULT_TEXT_PROPS,
  className,
  textClassName,
}: IMarkdownProps) {
  const markdownComponents = createMarkdownComponents(textProps, textClassName);

  return (
    <div className={className}>
      <ReactMarkdown
        components={markdownComponents}
        remarkPlugins={[remarkGfm]}
      >
        {children}
      </ReactMarkdown>
    </div>
  );
}

Markdown.displayName = 'Markdown';

export { Markdown, createMarkdownComponents };
export type { IMarkdownProps };
