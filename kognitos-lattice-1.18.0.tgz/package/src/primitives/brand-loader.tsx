import LogoAnimated from '@/design-system/icons/assets/svg/logo-animated.svg?react';
import { cn } from '@/design-system/lib/utils';

interface BrandLoaderProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  color?: string;
  className?: string;
}

const sizeMap = {
  sm: 'size-12',
  md: 'size-16',
  lg: 'size-20',
  xl: 'size-24',
};

export function BrandLoader({
  size = 'xl',
  color = 'text-primary',
  className,
}: BrandLoaderProps) {
  return (
    <div
      className={cn(sizeMap[size], color, className)}
      role="status"
      aria-label="Loading"
    >
      <LogoAnimated className="w-full h-full" />
    </div>
  );
}
