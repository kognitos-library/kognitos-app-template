import * as React from 'react';
import { cva, type VariantProps } from 'class-variance-authority';

import { cn } from '@/design-system/lib/utils/index';

const textareaVariants = cva(
  'placeholder:text-muted-foreground flex field-sizing-content min-h-16 w-full rounded-md px-3 py-2 text-base transition-[color,box-shadow] outline-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm',
  {
    variants: {
      variant: {
        default:
          'border-input placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-ring/50 aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive dark:bg-input/30 flex field-sizing-content min-h-16 w-full rounded-md border bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none focus-visible:ring-[3px] disabled:cursor-not-allowed disabled:opacity-50 md:text-sm',
        // custom ghost variant
        ghost: 'border-transparent',
        // inline variant - minimal borderless design for inline editing
        inline:
          'flex-1 min-w-0 bg-transparent border-0 resize-none rounded-none px-0 py-2 min-h-[20px]',
      },
    },
    defaultVariants: {
      variant: 'default',
    },
  },
);

interface ITextareaProps
  extends
    React.ComponentProps<'textarea'>,
    VariantProps<typeof textareaVariants> {}

function Textarea({ className, variant, ...props }: ITextareaProps) {
  const isInvalid = props['aria-invalid'] === true;

  return (
    <textarea
      data-slot="textarea"
      className={cn(
        textareaVariants({ variant }),
        {
          'ring-destructive/20 dark:ring-destructive/40 border-destructive focus-within:ring-destructive/20 dark:focus-within:ring-destructive/40 focus-within:border-destructive':
            isInvalid && variant === 'default',
        },
        className,
      )}
      {...props}
    />
  );
}

export { Textarea, textareaVariants, type ITextareaProps };
