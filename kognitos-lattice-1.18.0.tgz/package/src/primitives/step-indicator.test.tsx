import { render, screen } from '@testing-library/react';
import { StepIndicator } from './step-indicator';
import { describe, expect, it, vi } from 'vitest';

describe('StepIndicator', () => {
  it('should render with correct number of steps', () => {
    render(<StepIndicator currentStep={2} totalSteps={4} />);

    const progressbar = screen.getByRole('progressbar');
    expect(progressbar).toBeInTheDocument();
    expect(progressbar).toHaveAttribute('aria-valuenow', '2');
    expect(progressbar).toHaveAttribute('aria-valuemin', '1');
    expect(progressbar).toHaveAttribute('aria-valuemax', '4');

    // Should render 4 step indicators
    const stepElements = progressbar.querySelectorAll('[data-step]');
    expect(stepElements).toHaveLength(4);
  });

  it('should mark the current step as active', () => {
    render(<StepIndicator currentStep={3} totalSteps={5} />);

    const stepElements = screen
      .getByRole('progressbar')
      .querySelectorAll('[data-step]');

    // Step 3 should be active
    expect(stepElements[2]).toHaveAttribute('data-active', 'true');
    expect(stepElements[2]).toHaveAttribute('data-step', '3');

    // Other steps should not be active
    expect(stepElements[0]).toHaveAttribute('data-active', 'false');
    expect(stepElements[1]).toHaveAttribute('data-active', 'false');
    expect(stepElements[3]).toHaveAttribute('data-active', 'false');
    expect(stepElements[4]).toHaveAttribute('data-active', 'false');
  });

  it('should mark completed steps correctly', () => {
    render(<StepIndicator currentStep={3} totalSteps={5} />);

    const stepElements = screen
      .getByRole('progressbar')
      .querySelectorAll('[data-step]');

    // Steps 1 and 2 should be completed
    expect(stepElements[0]).toHaveAttribute('data-completed', 'true');
    expect(stepElements[1]).toHaveAttribute('data-completed', 'true');

    // Current step and future steps should not be completed
    expect(stepElements[2]).toHaveAttribute('data-completed', 'false');
    expect(stepElements[3]).toHaveAttribute('data-completed', 'false');
    expect(stepElements[4]).toHaveAttribute('data-completed', 'false');
  });

  it('should render with custom aria-label', () => {
    const customLabel = 'Custom progress indicator';
    render(
      <StepIndicator currentStep={1} totalSteps={3} aria-label={customLabel} />,
    );

    const progressbar = screen.getByRole('progressbar');
    expect(progressbar).toHaveAttribute('aria-label', customLabel);
  });

  it('should render with default aria-label when not provided', () => {
    render(<StepIndicator currentStep={2} totalSteps={4} />);

    const progressbar = screen.getByRole('progressbar');
    expect(progressbar).toHaveAttribute('aria-label', 'Step 2 of 4');
  });

  it('should apply custom className', () => {
    render(
      <StepIndicator currentStep={1} totalSteps={3} className="custom-class" />,
    );

    const progressbar = screen.getByRole('progressbar');
    expect(progressbar).toHaveClass('custom-class');
  });

  it('should handle edge cases gracefully', () => {
    // Test with invalid currentStep
    const consoleSpy = vi.spyOn(console, 'warn').mockImplementation(() => {});

    const { container: container1 } = render(
      <StepIndicator currentStep={0} totalSteps={3} />,
    );
    expect(container1.firstChild).toBeNull();
    expect(consoleSpy).toHaveBeenCalledWith(
      'StepIndicator: Invalid step configuration',
      { currentStep: 0, totalSteps: 3 },
    );

    // Test with currentStep > totalSteps
    const { container: container2 } = render(
      <StepIndicator currentStep={5} totalSteps={3} />,
    );
    expect(container2.firstChild).toBeNull();
    expect(consoleSpy).toHaveBeenCalledWith(
      'StepIndicator: Invalid step configuration',
      { currentStep: 5, totalSteps: 3 },
    );

    // Test with invalid totalSteps
    const { container: container3 } = render(
      <StepIndicator currentStep={1} totalSteps={0} />,
    );
    expect(container3.firstChild).toBeNull();
    expect(consoleSpy).toHaveBeenCalledWith(
      'StepIndicator: Invalid step configuration',
      { currentStep: 1, totalSteps: 0 },
    );

    consoleSpy.mockRestore();
  });

  it('should render different sizes correctly', () => {
    const { rerender } = render(
      <StepIndicator currentStep={1} totalSteps={3} size="sm" />,
    );

    let progressbar = screen.getByRole('progressbar');
    let stepElements = progressbar.querySelectorAll('[data-step]');
    expect(stepElements[0]).toHaveClass('w-2', 'h-2');

    rerender(<StepIndicator currentStep={1} totalSteps={3} size="md" />);
    progressbar = screen.getByRole('progressbar');
    stepElements = progressbar.querySelectorAll('[data-step]');
    expect(stepElements[0]).toHaveClass('w-3', 'h-3');

    rerender(<StepIndicator currentStep={1} totalSteps={3} size="lg" />);
    progressbar = screen.getByRole('progressbar');
    stepElements = progressbar.querySelectorAll('[data-step]');
    expect(stepElements[0]).toHaveClass('w-4', 'h-4');
  });

  it('should render different variants correctly', () => {
    const { rerender } = render(
      <StepIndicator currentStep={1} totalSteps={3} variant="default" />,
    );

    let progressbar = screen.getByRole('progressbar');
    let stepElements = progressbar.querySelectorAll('[data-step]');
    expect(stepElements[0]).toHaveClass('bg-muted');
    expect(stepElements[0]).not.toHaveClass('border-2');

    rerender(
      <StepIndicator currentStep={1} totalSteps={3} variant="outlined" />,
    );
    progressbar = screen.getByRole('progressbar');
    stepElements = progressbar.querySelectorAll('[data-step]');
    expect(stepElements[0]).toHaveClass('border-2', 'border-muted');
  });

  it('should be accessible with proper ARIA attributes', () => {
    render(<StepIndicator currentStep={2} totalSteps={5} />);

    const progressbar = screen.getByRole('progressbar');
    expect(progressbar).toHaveAttribute('role', 'progressbar');
    expect(progressbar).toHaveAttribute('aria-valuenow', '2');
    expect(progressbar).toHaveAttribute('aria-valuemin', '1');
    expect(progressbar).toHaveAttribute('aria-valuemax', '5');
    expect(progressbar).toHaveAttribute('aria-label', 'Step 2 of 5');

    // Individual step indicators should be hidden from screen readers
    const stepElements = progressbar.querySelectorAll('[data-step]');
    stepElements.forEach(step => {
      expect(step).toHaveAttribute('aria-hidden', 'true');
    });
  });
});
