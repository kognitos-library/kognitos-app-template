import type { Meta, StoryObj } from '@storybook/react-vite';
import { Button } from './button';
import { Icon } from '../icons';

const meta: Meta<typeof Button> = {
  title: 'Design System/Primitives/General/Button',
  component: Button,
  tags: ['autodocs'],
  parameters: {
    docs: {
      description: {
        component:
          'A versatile button component with multiple variants, sizes, and states. Supports icons, loading states, and theme switching.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    variant: {
      control: { type: 'select' },
      options: [
        'default',
        'destructive',
        'outline',
        'secondary',
        'ghost',
        'link',
      ],
      description: 'The visual style variant of the button',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    size: {
      control: { type: 'select' },
      options: ['default', 'sm', 'lg', 'icon', 'icon-xs', 'icon-sm', 'icon-lg'],
      description: 'The size of the button',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'default' },
        category: 'Appearance',
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the button is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'State',
      },
    },
    asChild: {
      control: { type: 'boolean' },
      description: 'Render as a child component using Radix Slot',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'Behavior',
      },
    },
    isLoading: {
      control: { type: 'boolean' },
      description: 'Show loading spinner and disable the button',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
        category: 'State',
      },
    },
    children: {
      control: { type: 'text' },
      description: 'The content to display inside the button',
      table: {
        type: { summary: 'ReactNode' },
        category: 'Content',
      },
    },
    className: {
      control: { type: 'text' },
      description: 'Additional CSS classes to apply',
      table: {
        type: { summary: 'string' },
        category: 'Styling',
      },
    },
  },
  args: {
    children: 'Button',
    variant: 'default',
    size: 'default',
    disabled: false,
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

// Primary story - This will be the main showcase in autodocs
export const Primary: Story = {
  args: {
    children: 'Button',
    variant: 'default',
    size: 'default',
    disabled: false,
  },
  parameters: {
    layout: 'centered',
    docs: {
      description: {
        story:
          'The primary button variant. Use the controls below to experiment with different variants, sizes, and states.',
      },
    },
  },
};

// Basic Button Story
export const Default: Story = {
  args: {
    children: 'Button',
    variant: 'default',
    size: 'default',
    disabled: false,
  },
  parameters: {
    docs: {
      description: {
        story: 'The default button variant with standard styling and behavior.',
      },
    },
  },
};

// All Variants Story
export const Variants: Story = {
  render: () => (
    <div className="space-y-3">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Button Variants
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="default">Default</Button>
          <Button variant="destructive">Destructive</Button>
          <Button variant="outline">Outline</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="link">Link</Button>
        </div>
      </div>
    </div>
  ),
};

// All Sizes Story
export const Sizes: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Text Button Sizes
        </h3>
        <div className="flex flex-wrap items-center gap-3">
          <Button size="sm">Small</Button>
          <Button size="default">Default</Button>
          <Button size="lg">Large</Button>
        </div>
      </div>
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Icon Button Sizes
        </h3>
        <div className="flex flex-wrap items-center gap-3">
          <Button size="icon-xs">
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon-sm">
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon">
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon-lg">
            <Icon type={'Settings'} />
          </Button>
        </div>
      </div>
    </div>
  ),
};

// With Icons Story
export const WithIcons: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Buttons with Icons
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button>
            <Icon type={'Download'} />
            Download
          </Button>
          <Button variant="outline">
            <Icon type={'User'} />
            Profile
          </Button>
          <Button variant="secondary">
            <Icon type={'Settings'} />
            Settings
          </Button>
          <Button variant="ghost">
            <Icon type={'Heart'} />
            Favorite
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Icon Only Buttons
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button size="icon" variant="default">
            <Icon type={'Download'} />
          </Button>
          <Button size="icon" variant="outline">
            <Icon type={'User'} />
          </Button>
          <Button size="icon" variant="secondary">
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon" variant="ghost">
            <Icon type={'Heart'} />
          </Button>
          <Button size="icon" variant="destructive">
            <Icon type={'Download'} />
          </Button>
        </div>
      </div>
    </div>
  ),
};

// States Story
export const States: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Button States
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button>Normal</Button>
          <Button disabled>Disabled</Button>
          <Button variant="outline">Normal</Button>
          <Button variant="outline" disabled>
            Disabled
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          All Variants - Disabled State
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="default" disabled>
            Default
          </Button>
          <Button variant="destructive" disabled>
            Destructive
          </Button>
          <Button variant="outline" disabled>
            Outline
          </Button>
          <Button variant="secondary" disabled>
            Secondary
          </Button>
          <Button variant="ghost" disabled>
            Ghost
          </Button>
          <Button variant="link" disabled>
            Link
          </Button>
        </div>
      </div>
    </div>
  ),
};

// Loading States Story
export const LoadingStates: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Loading Buttons - All Variants
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="default" isLoading>
            Default
          </Button>
          <Button variant="destructive" isLoading>
            Destructive
          </Button>
          <Button variant="outline" isLoading>
            Outline
          </Button>
          <Button variant="secondary" isLoading>
            Secondary
          </Button>
          <Button variant="ghost" isLoading>
            Ghost
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Loading Buttons - All Sizes
        </h3>
        <div className="flex flex-wrap items-center gap-3">
          <Button size="sm" isLoading>
            Small
          </Button>
          <Button size="default" isLoading>
            Default
          </Button>
          <Button size="lg" isLoading>
            Large
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Loading Icon Buttons
        </h3>
        <div className="flex flex-wrap items-center gap-3">
          <Button size="icon-sm" isLoading>
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon" isLoading>
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon-lg" isLoading>
            <Icon type={'Settings'} />
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Loading Buttons with Icons
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button isLoading>
            <Icon type={'Download'} />
            Downloading
          </Button>
          <Button variant="outline" isLoading>
            <Icon type={'Upload'} />
            Uploading
          </Button>
          <Button variant="secondary" isLoading>
            <Icon type={'Save'} />
            Saving
          </Button>
        </div>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Buttons automatically show a loading spinner when the `isLoading` prop is true. For icon-only buttons, the loading spinner replaces the icon. For regular buttons, the spinner appears before the text.',
      },
    },
  },
};

// Interactive Examples Story
export const InteractiveExamples: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Form Actions
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="default">
            <Icon type={'Download'} />
            Save Changes
          </Button>
          <Button variant="outline">Cancel</Button>
          <Button variant="destructive">Delete</Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Navigation
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="ghost">
            <Icon type={'User'} />
            Profile
          </Button>
          <Button variant="ghost">
            <Icon type={'Settings'} />
            Settings
          </Button>
          <Button variant="link">View All</Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Social Actions
        </h3>
        <div className="flex flex-wrap gap-3">
          <Button variant="outline">
            <Icon type={'Heart'} />
            Like
          </Button>
          <Button variant="secondary">Share</Button>
          <Button variant="ghost">Comment</Button>
        </div>
      </div>
    </div>
  ),
};

// Theme Showcase Story
export const ThemeShowcase: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Primary Actions
        </h3>
        <p className="text-xs text-muted-foreground mb-2">
          Use default variant for primary actions and calls-to-action.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button variant="default">Primary Action</Button>
          <Button variant="default" size="lg">
            Large Primary
          </Button>
          <Button variant="default" size="sm">
            Small Primary
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Secondary Actions
        </h3>
        <p className="text-xs text-muted-foreground mb-2">
          Use secondary, outline, or ghost variants for secondary actions.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button variant="secondary">Secondary</Button>
          <Button variant="outline">Outline</Button>
          <Button variant="ghost">Ghost</Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Destructive Actions
        </h3>
        <p className="text-xs text-muted-foreground mb-2">
          Use destructive variant for dangerous actions like delete or remove.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button variant="destructive">Delete</Button>
          <Button variant="destructive" size="sm">
            Remove
          </Button>
        </div>
      </div>

      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">Links</h3>
        <p className="text-xs text-muted-foreground mb-2">
          Use link variant for navigation or external links.
        </p>
        <div className="flex flex-wrap gap-3">
          <Button variant="link">Learn More</Button>
          <Button variant="link">View Documentation</Button>
        </div>
      </div>
    </div>
  ),
};

// Accessibility Story
export const Accessibility: Story = {
  render: () => (
    <div className="space-y-4">
      <div>
        <h3 className="text-sm font-semibold text-foreground mb-2">
          Accessibility Features
        </h3>
        <div className="space-y-3">
          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Keyboard Navigation
            </h4>
            <p className="text-xs text-muted-foreground">
              All buttons are keyboard accessible. Use Tab to navigate and
              Enter/Space to activate.
            </p>
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Focus Indicators
            </h4>
            <p className="text-xs text-muted-foreground">
              Buttons have visible focus indicators that work with the current
              theme.
            </p>
            <div className="mt-2">
              <Button
                variant="outline"
                className="focus:ring-2 focus:ring-ring"
              >
                Focus me (Tab to this button)
              </Button>
            </div>
          </div>

          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Screen Reader Support
            </h4>
            <p className="text-xs text-muted-foreground">
              Buttons include proper ARIA attributes and semantic HTML.
            </p>
            <div className="mt-2">
              <Button aria-label="Download file">
                <Icon type={'Download'} />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  ),
};

// All Buttons Story - Simplified version
export const AllButtons: Story = {
  render: () => (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          All Button Variants
        </h2>
        <div className="flex flex-wrap gap-3">
          <Button variant="default">Default</Button>
          <Button variant="destructive">Destructive</Button>
          <Button variant="outline">Outline</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="ghost">Ghost</Button>
          <Button variant="link">Link</Button>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          All Button Sizes
        </h2>
        <div className="flex flex-wrap items-center gap-3">
          <Button size="sm">Small</Button>
          <Button size="default">Default</Button>
          <Button size="lg">Large</Button>
        </div>
        <div className="flex flex-wrap items-center gap-3 mt-3">
          <Button size="icon-xs">
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon-sm">
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon">
            <Icon type={'Settings'} />
          </Button>
          <Button size="icon-lg">
            <Icon type={'Settings'} />
          </Button>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Loading Buttons
        </h2>
        <div className="flex flex-wrap items-center gap-3">
          <Button size="sm" isLoading>
            Small
          </Button>
          <Button size="default" isLoading>
            Default
          </Button>
          <Button size="lg" isLoading>
            Large
          </Button>
          <Button size="icon" isLoading>
            <Icon type={'Settings'} />
          </Button>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Buttons with Icons
        </h2>
        <div className="flex flex-wrap gap-3">
          <Button>
            <Icon type={'Download'} />
            Download
          </Button>
          <Button variant="outline">
            <Icon type={'User'} />
            Profile
          </Button>
          <Button variant="secondary">
            <Icon type={'Settings'} />
            Settings
          </Button>
          <Button variant="ghost">
            <Icon type={'Heart'} />
            Favorite
          </Button>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Button States
        </h2>
        <div className="flex flex-wrap gap-3">
          <Button>Normal</Button>
          <Button disabled>Disabled</Button>
          <Button variant="outline">Normal</Button>
          <Button variant="outline" disabled>
            Disabled
          </Button>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Interactive Examples
        </h2>
        <div className="flex flex-wrap gap-3">
          <Button variant="default">
            <Icon type={'Download'} />
            Save Changes
          </Button>
          <Button variant="outline">Cancel</Button>
          <Button variant="destructive">Delete</Button>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Theme Showcase
        </h2>
        <div className="flex flex-wrap gap-3">
          <Button variant="default">Primary Action</Button>
          <Button variant="secondary">Secondary</Button>
          <Button variant="destructive">Delete</Button>
          <Button variant="link">Learn More</Button>
        </div>
      </div>

      <div>
        <h2 className="text-lg font-bold text-foreground mb-3">
          Accessibility
        </h2>
        <div className="space-y-3">
          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Focus Indicators
            </h4>
            <Button variant="outline" className="focus:ring-2 focus:ring-ring">
              Focus me (Tab to this button)
            </Button>
          </div>
          <div className="bg-muted p-3 rounded-lg">
            <h4 className="font-medium text-foreground mb-1 text-sm">
              Screen Reader Support
            </h4>
            <Button aria-label="Download file">
              <Icon type={'Download'} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  ),
};
