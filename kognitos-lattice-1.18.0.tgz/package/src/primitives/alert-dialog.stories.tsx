import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from './alert-dialog';
import { Button } from './button';

const meta: Meta<typeof AlertDialog> = {
  title: 'Design System/Primitives/Feedback/AlertDialog',
  component: AlertDialog,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A modal dialog that interrupts the user workflow to request confirmation or display critical information. Uses Radix UI primitives for accessibility.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
    controls: {
      expanded: true,
      sort: 'requiredFirst',
    },
  },
  argTypes: {
    open: {
      control: { type: 'boolean' },
      description: 'Whether the dialog is open',
      table: {
        type: { summary: 'boolean' },
        category: 'State',
      },
    },
    onOpenChange: {
      description: 'Callback when the open state changes',
      table: {
        type: { summary: 'function' },
        category: 'Events',
      },
    },
  },
  args: {
    open: false,
  },
};

export default meta;
type Story = StoryObj<typeof AlertDialog>;

// Basic Alert Dialog
export const Basic: Story = {
  render: () => {
    const BasicDialog = () => {
      const [open, setOpen] = useState(false);
      return (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger asChild>
            <Button variant="outline">Delete Account</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription>
                This action cannot be undone. This will permanently delete your
                account and remove your data from our servers.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction>Continue</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      );
    };
    return <BasicDialog />;
  },
};

// Destructive Action
export const DestructiveAction: Story = {
  render: () => {
    const DestructiveDialog = () => {
      const [open, setOpen] = useState(false);
      return (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger asChild>
            <Button variant="destructive">Delete Project</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Delete Project</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to delete this project? This action cannot
                be undone and will permanently remove all project data,
                including files, settings, and history.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction variant="destructive">
                Delete Project
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      );
    };
    return <DestructiveDialog />;
  },
};

// Confirmation Dialog
export const Confirmation: Story = {
  render: () => {
    const ConfirmationDialog = () => {
      const [open, setOpen] = useState(false);
      return (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger asChild>
            <Button>Save Changes</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Save Changes</AlertDialogTitle>
              <AlertDialogDescription>
                You have unsaved changes. Do you want to save them before
                leaving?
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Don't Save</AlertDialogCancel>
              <AlertDialogAction>Save Changes</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      );
    };
    return <ConfirmationDialog />;
  },
};

// Information Dialog
export const Information: Story = {
  render: () => {
    const InformationDialog = () => {
      const [open, setOpen] = useState(false);
      return (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger asChild>
            <Button variant="outline">View Details</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>System Maintenance</AlertDialogTitle>
              <AlertDialogDescription>
                Scheduled maintenance will begin in 30 minutes. During this
                time, some features may be temporarily unavailable. We apologize
                for any inconvenience.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogAction>Got it</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      );
    };
    return <InformationDialog />;
  },
};

// Custom Styled Dialog
export const CustomStyled: Story = {
  render: () => {
    const CustomStyledDialog = () => {
      const [open, setOpen] = useState(false);
      return (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger asChild>
            <Button variant="outline">Custom Dialog</Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="max-w-md">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-center">
                Welcome!
              </AlertDialogTitle>
              <AlertDialogDescription className="text-center">
                Thank you for trying our new feature. We hope you enjoy it!
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="flex-col gap-2 sm:flex-row">
              <AlertDialogCancel className="w-full sm:w-auto">
                Maybe Later
              </AlertDialogCancel>
              <AlertDialogAction className="w-full sm:w-auto">
                Get Started
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      );
    };
    return <CustomStyledDialog />;
  },
};

// Multiple Actions
export const MultipleActions: Story = {
  render: () => {
    const MultipleActionsDialog = () => {
      const [open, setOpen] = useState(false);
      return (
        <AlertDialog open={open} onOpenChange={setOpen}>
          <AlertDialogTrigger asChild>
            <Button variant="outline">Export Data</Button>
          </AlertDialogTrigger>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Export Options</AlertDialogTitle>
              <AlertDialogDescription>
                Choose how you would like to export your data. You can export as
                CSV, JSON, or PDF.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter className="flex-col gap-2 sm:flex-row">
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction variant="outline">
                Export as CSV
              </AlertDialogAction>
              <AlertDialogAction>Export as PDF</AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      );
    };
    return <MultipleActionsDialog />;
  },
};
