import * as React from 'react';
import { CheckIcon, ChevronsUpDownIcon } from 'lucide-react';

import { cn, useI18n } from '@/design-system/lib/utils';
import { Button } from '@/design-system/primitives/button';
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from '@/design-system/primitives/avatar';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/design-system/primitives/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/design-system/primitives/popover';
import { Flex } from './flex';

export interface IComboboxOption {
  value: string;
  label: string;
  disabled?: boolean;
  icon?: React.ReactNode;
  description?: string;
  group?: string;
  avatar?: {
    src?: string;
    alt?: string;
    fallback?: string;
    color?: string;
  };
}

export interface IComboboxProps {
  options: IComboboxOption[];
  value?: string;
  onValueChange?: (value: string) => void;
  placeholder?: string;
  searchPlaceholder?: string;
  emptyMessage?: string;
  disabled?: boolean;
  className?: string;
  buttonClassName?: string;
  popoverClassName?: string;
  commandClassName?: string;
  trigger?: React.ReactNode;
  showGroups?: boolean;
  showIcons?: boolean;
  showDescriptions?: boolean;
  createOption?: {
    label: string;
    onSelect: (value: string) => void;
  };
  /**
   * These keywords are used for filtering when the user types in the search input.
   * By default, searches by value.
   * @example
   * // Search by custom fields
   * getSearchKeywords={(option) => [option.label, option.email, option.department]}
   */
  getSearchKeywords?: (option: IComboboxOption) => string[];
  align?: 'start' | 'center' | 'end';
  side?: 'top' | 'right' | 'bottom' | 'left';
  sideOffset?: number;
  alignOffset?: number;
  avoidCollisions?: boolean;
  collisionBoundary?: Element | null | Array<Element | null>;
  collisionPadding?: number;
  arrowPadding?: number;
  sticky?: 'partial' | 'always';
  hideWhenDetached?: boolean;
  updatePositionStrategy?: 'optimized' | 'always';
  modal?: boolean;
  open?: boolean;
  defaultOpen?: boolean;
  onOpenChange?: (open: boolean) => void;
}

// Helper function to render avatar or icon
const renderAvatarOrIcon = (option: IComboboxOption) => {
  if (option.avatar) {
    return (
      <Avatar className="h-6 w-6">
        <AvatarImage src={option.avatar.src} alt={option.avatar.alt} />
        <AvatarFallback
          className="text-xs"
          style={{ backgroundColor: option.avatar.color }}
        >
          {option.avatar.fallback || option.label.charAt(0).toUpperCase()}
        </AvatarFallback>
      </Avatar>
    );
  }

  if (option.icon) {
    return option.icon;
  }

  return null;
};

export function Combobox({
  options,
  value,
  onValueChange,
  placeholder,
  searchPlaceholder,
  emptyMessage,
  disabled = false,
  className,
  buttonClassName,
  popoverClassName,
  commandClassName,
  trigger,
  showGroups = false,
  showIcons = false,
  showDescriptions = false,
  createOption,
  getSearchKeywords = () => [] as string[],
  align = 'start',
  side = 'bottom',
  sideOffset = 4,
  alignOffset = 0,
  avoidCollisions = true,
  collisionBoundary,
  collisionPadding = 0,
  arrowPadding = 0,
  sticky = 'partial',
  hideWhenDetached = false,
  updatePositionStrategy = 'optimized',
  modal = false,
  open,
  defaultOpen = false,
  onOpenChange,
  ...props
}: IComboboxProps) {
  const { t } = useI18n();
  const resolvedPlaceholder = placeholder ?? t('combobox.placeholder');
  const resolvedSearchPlaceholder =
    searchPlaceholder ?? t('combobox.searchPlaceholder');
  const resolvedEmptyMessage = emptyMessage ?? t('combobox.emptyMessage');

  const [openState, setOpenState] = React.useState(defaultOpen);
  const controlledOpen = open !== undefined ? open : openState;
  const setControlledOpen = onOpenChange || setOpenState;

  const selectedOption = options.find(option => option.value === value);

  const handleSelect = (currentValue: string) => {
    const newValue = currentValue === value ? '' : currentValue;
    onValueChange?.(newValue);
    setControlledOpen(false);
  };

  const triggerContent = trigger || (
    <Button
      variant="outline"
      role="combobox"
      aria-expanded={controlledOpen}
      disabled={disabled}
      className={cn('w-full justify-between px-3', buttonClassName)}
    >
      <Flex className="w-full" justify="between" gap={1} align="center">
        {selectedOption &&
          (selectedOption.avatar || selectedOption.icon) &&
          renderAvatarOrIcon(selectedOption)}
        <span
          className={cn('truncate', {
            'text-muted-foreground': !selectedOption,
          })}
        >
          {selectedOption ? selectedOption.label : resolvedPlaceholder}
        </span>
        <ChevronsUpDownIcon className="h-4 w-4 shrink-0 opacity-50 ml-auto" />
      </Flex>
    </Button>
  );

  return (
    <Popover
      open={controlledOpen}
      onOpenChange={setControlledOpen}
      modal={modal}
      {...props}
    >
      <PopoverTrigger asChild className={className}>
        {triggerContent}
      </PopoverTrigger>
      <PopoverContent
        className={cn('w-full p-0', popoverClassName)}
        align={align}
        side={side}
        sideOffset={sideOffset}
        alignOffset={alignOffset}
        avoidCollisions={avoidCollisions}
        collisionBoundary={collisionBoundary}
        collisionPadding={collisionPadding}
        arrowPadding={arrowPadding}
        sticky={sticky}
        hideWhenDetached={hideWhenDetached}
        updatePositionStrategy={updatePositionStrategy}
      >
        <Command className={commandClassName}>
          <CommandInput placeholder={resolvedSearchPlaceholder} />
          <CommandList>
            <CommandEmpty>{resolvedEmptyMessage}</CommandEmpty>
            {showGroups ? (
              // Group options by their group property
              Object.entries(
                options.reduce(
                  (groups, option) => {
                    const group = option.group || 'default';
                    if (!groups[group]) groups[group] = [];
                    groups[group].push(option);
                    return groups;
                  },
                  {} as Record<string, IComboboxOption[]>,
                ),
              ).map(([groupName, groupOptions]) => (
                <CommandGroup
                  key={groupName}
                  heading={groupName !== 'default' ? groupName : undefined}
                >
                  {groupOptions.map(option => (
                    <CommandItem
                      key={option.value}
                      value={option.value}
                      keywords={getSearchKeywords(option)}
                      disabled={option.disabled}
                      onSelect={handleSelect}
                    >
                      {(showIcons || option.avatar) &&
                        renderAvatarOrIcon(option)}
                      <div className="flex flex-col flex-1">
                        <span>{option.label}</span>
                        {showDescriptions && option.description && (
                          <span className="text-xs text-muted-foreground">
                            {option.description}
                          </span>
                        )}
                      </div>
                      <CheckIcon
                        className={cn(
                          'ml-2 h-4 w-4',
                          value === option.value ? 'opacity-100' : 'opacity-0',
                        )}
                      />
                    </CommandItem>
                  ))}
                </CommandGroup>
              ))
            ) : (
              <CommandGroup>
                {options.map(option => (
                  <CommandItem
                    key={option.value}
                    value={option.value}
                    keywords={getSearchKeywords(option)}
                    disabled={option.disabled}
                    onSelect={handleSelect}
                  >
                    {(showIcons || option.avatar) && renderAvatarOrIcon(option)}
                    <div className="flex flex-col flex-1">
                      <span>{option.label}</span>
                      {showDescriptions && option.description && (
                        <span className="text-xs text-muted-foreground">
                          {option.description}
                        </span>
                      )}
                    </div>
                    <CheckIcon
                      className={cn(
                        'ml-2 h-4 w-4',
                        value === option.value ? 'opacity-100' : 'opacity-0',
                      )}
                    />
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {createOption && (
              <CommandGroup>
                <CommandItem
                  value="create"
                  onSelect={() => {
                    createOption.onSelect('create');
                    setControlledOpen(false);
                  }}
                >
                  <span className="mr-2">+</span>
                  {createOption.label}
                </CommandItem>
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

// Multi-select Combobox
export interface IMultiComboboxProps extends Omit<
  IComboboxProps,
  'value' | 'onValueChange'
> {
  value?: string[];
  onValueChange?: (value: string[]) => void;
  placeholder?: string;
  emptyMessage?: string;
}

const DEFAULT_MULTI_VALUE: string[] = [];

export function MultiCombobox({
  options,
  value = DEFAULT_MULTI_VALUE,
  onValueChange,
  placeholder,
  emptyMessage,
  showGroups = false,
  showIcons = false,
  showDescriptions = false,
  createOption,
  getSearchKeywords = () => [] as string[],
  ...props
}: IMultiComboboxProps) {
  const { t } = useI18n();
  const resolvedPlaceholder = placeholder ?? t('combobox.placeholderMulti');
  const resolvedEmptyMessage = emptyMessage ?? t('combobox.emptyMessageMulti');

  const [openState, setOpenState] = React.useState(false);
  const controlledOpen = props.open !== undefined ? props.open : openState;
  const setControlledOpen = props.onOpenChange || setOpenState;

  const selectedOptions = options.filter(option =>
    value.includes(option.value),
  );

  const handleSelect = (currentValue: string) => {
    const newValue = value.includes(currentValue)
      ? value.filter(v => v !== currentValue)
      : [...value, currentValue];
    onValueChange?.(newValue);
  };

  const displayText =
    selectedOptions.length > 0
      ? selectedOptions.length > 2
        ? `${selectedOptions[0].label}, ${selectedOptions[1].label} +${selectedOptions.length - 2}`
        : selectedOptions.map(option => option.label).join(', ')
      : resolvedPlaceholder;

  return (
    <Popover
      open={controlledOpen}
      onOpenChange={setControlledOpen}
      modal={props.modal}
    >
      <PopoverTrigger asChild className={props.className}>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={controlledOpen}
          disabled={props.disabled}
          className={cn('w-full justify-between', props.buttonClassName)}
        >
          <div className="flex items-center gap-2">
            <span className="truncate">{displayText}</span>
          </div>
          <ChevronsUpDownIcon className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent
        className={cn('w-full p-0', props.popoverClassName)}
        align={props.align}
        side={props.side}
        sideOffset={props.sideOffset}
        alignOffset={props.alignOffset}
        avoidCollisions={props.avoidCollisions}
        collisionBoundary={props.collisionBoundary}
        collisionPadding={props.collisionPadding}
        arrowPadding={props.arrowPadding}
        sticky={props.sticky}
        hideWhenDetached={props.hideWhenDetached}
        updatePositionStrategy={props.updatePositionStrategy}
      >
        <Command className={props.commandClassName}>
          <CommandInput
            placeholder={
              props.searchPlaceholder ?? t('combobox.searchPlaceholder')
            }
          />
          <CommandList>
            <CommandEmpty>{resolvedEmptyMessage}</CommandEmpty>
            {showGroups ? (
              // Group options by their group property
              Object.entries(
                options.reduce(
                  (groups, option) => {
                    const group = option.group || 'default';
                    if (!groups[group]) groups[group] = [];
                    groups[group].push(option);
                    return groups;
                  },
                  {} as Record<string, IComboboxOption[]>,
                ),
              ).map(([groupName, groupOptions]) => (
                <CommandGroup
                  key={groupName}
                  heading={groupName !== 'default' ? groupName : undefined}
                >
                  {groupOptions.map(option => (
                    <CommandItem
                      key={option.value}
                      value={option.value}
                      keywords={getSearchKeywords(option)}
                      disabled={option.disabled}
                      onSelect={handleSelect}
                    >
                      {(showIcons || option.avatar) &&
                        renderAvatarOrIcon(option)}
                      <div className="flex flex-col flex-1">
                        <span>{option.label}</span>
                        {showDescriptions && option.description && (
                          <span className="text-xs text-muted-foreground">
                            {option.description}
                          </span>
                        )}
                      </div>
                      <CheckIcon
                        className={cn(
                          'ml-2 h-4 w-4',
                          value.includes(option.value)
                            ? 'opacity-100'
                            : 'opacity-0',
                        )}
                      />
                    </CommandItem>
                  ))}
                </CommandGroup>
              ))
            ) : (
              <CommandGroup>
                {options.map(option => (
                  <CommandItem
                    key={option.value}
                    value={option.value}
                    keywords={getSearchKeywords(option)}
                    disabled={option.disabled}
                    onSelect={handleSelect}
                  >
                    {(showIcons || option.avatar) && renderAvatarOrIcon(option)}
                    <div className="flex flex-col flex-1">
                      <span>{option.label}</span>
                      {showDescriptions && option.description && (
                        <span className="text-xs text-muted-foreground">
                          {option.description}
                        </span>
                      )}
                    </div>
                    <CheckIcon
                      className={cn(
                        'ml-2 h-4 w-4',
                        value.includes(option.value)
                          ? 'opacity-100'
                          : 'opacity-0',
                      )}
                    />
                  </CommandItem>
                ))}
              </CommandGroup>
            )}
            {createOption && (
              <CommandGroup>
                <CommandItem
                  value="create"
                  onSelect={() => {
                    createOption.onSelect('create');
                    setControlledOpen(false);
                  }}
                >
                  <span className="mr-2">+</span>
                  {createOption.label}
                </CommandItem>
              </CommandGroup>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
