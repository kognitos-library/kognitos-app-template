import { useState } from 'react';
import {
  StepperCardItem,
  type TStepperCardState,
  StepperCardIcon,
  StepperCardContent,
  StepperCardTitle,
  StepperCardDescription,
} from './stepper-card-items';
import { Flex } from './flex';
import { type IconType } from '@/design-system/icons';
import {
  cn,
  gridColsClasses,
  type IResponsiveColumns,
} from '@/design-system/lib/utils';

// ============================================================================
// TYPES & ENUMS
// ============================================================================

/**
 * Direction of the stepper card layout
 */
export enum EStepperCardDirection {
  COLUMN = 'column',
  ROW = 'row',
}

// Creates a union type of string literals from EStepperCardDirection enum values
// e.g., "column" | "row"
export type TStepperCardDirection = `${EStepperCardDirection}`;

/**
 * Props for each step item in the StepperCardItem
 */
export interface IStepperCardItemData {
  key: string;
  title: string;
  description?: string;
  state?: TStepperCardState;
  icon?: IconType;
}

// ============================================================================
// STEPPER CARD
// ============================================================================

export interface IStepperCardProps
  extends
    Omit<React.HTMLAttributes<HTMLDivElement>, 'children'>,
    IResponsiveColumns {
  /**
   * Layout direction for simple row/column layouts.
   * Ignored when responsive breakpoints (xs, sm, md, lg) are provided.
   */
  direction?: TStepperCardDirection;
  steps: IStepperCardItemData[];
  /** Controlled: Current selected step key (parent manages state) */
  current?: string;
  /** Uncontrolled: Initial selected step key (internal state management) */
  defaultCurrent?: string;
  /** Callback when a step is clicked. Required for controlled mode. */
  onStepClick?: (stepKey: string) => void;
}

/**
 * StepperCard component for multi-step processes.
 *
 * Supports both controlled and uncontrolled modes:
 * - **Controlled**: Pass `current` and `onStepClick` - parent manages selection state
 * - **Uncontrolled**: Pass `defaultCurrent` - component manages its own state
 *
 * Supports two layout modes:
 * - **Simple**: Use `direction` prop for basic row/column layouts
 * - **Responsive Grid**: Use breakpoint props (xs, sm, md, lg) for responsive column layouts
 *
 * Disabled steps cannot be selected.
 *
 * @example Uncontrolled (internal state)
 * ```tsx
 * <StepperCard
 *   steps={steps}
 *   defaultCurrent="1"
 * />
 * ```
 *
 * @example Controlled (parent manages state)
 * ```tsx
 * const [currentStep, setCurrentStep] = useState('1');
 *
 * <StepperCard
 *   steps={steps}
 *   current={currentStep}
 *   onStepClick={setCurrentStep}
 * />
 * ```
 *
 * @example Responsive grid layout
 * ```tsx
 * <StepperCard
 *   steps={steps}
 *   xs={1}
 *   sm={2}
 *   md={4}
 * />
 * ```
 */
export function StepperCard({
  direction = 'row',
  steps,
  current,
  defaultCurrent,
  onStepClick,
  className,
  xs,
  sm,
  md,
  lg,
  ...props
}: IStepperCardProps) {
  // Internal state for uncontrolled mode
  const [internalCurrent, setInternalCurrent] = useState(
    defaultCurrent ?? steps[0]?.key,
  );

  // Use controlled value if provided, otherwise use internal state
  const isControlled = current !== undefined;
  const activeStep = isControlled ? current : internalCurrent;

  const handleStepClick = (stepKey: string) => {
    // Update internal state only in uncontrolled mode
    if (!isControlled) {
      setInternalCurrent(stepKey);
    }

    onStepClick?.(stepKey);
  };

  const isResponsive =
    xs !== undefined ||
    sm !== undefined ||
    md !== undefined ||
    lg !== undefined;

  // Render stepper card items
  const stepperCardItems = steps.map((step, index) => {
    // Only one item can be active at a time (the one matching `activeStep`)
    const isActive = activeStep === step.key;

    // Sets state as step data if provided, otherwise defaults to 'default'
    const state = step.state ?? 'default';

    // Sets variant as 'selected' if the step is active, otherwise defaults to 'default'
    const finalVariant = isActive ? 'selected' : 'default';

    return (
      <StepperCardItem
        key={step.key}
        state={state}
        variant={finalVariant}
        onClick={() => handleStepClick(step.key)}
      >
        <StepperCardIcon
          state={state}
          variant={finalVariant}
          stepNumber={index + 1}
          icon={step.icon}
        />
        <StepperCardContent>
          <StepperCardTitle>{step.title}</StepperCardTitle>
          {step.description && (
            <StepperCardDescription>{step.description}</StepperCardDescription>
          )}
        </StepperCardContent>
      </StepperCardItem>
    );
  });

  // Responsive grid layout
  if (isResponsive) {
    return (
      <div
        data-slot="stepper-card"
        className={cn(
          'grid gap-3 w-full',
          gridColsClasses.xs[xs ?? 1],
          sm !== undefined && gridColsClasses.sm[sm],
          md !== undefined && gridColsClasses.md[md],
          lg !== undefined && gridColsClasses.lg[lg],
          className,
        )}
        {...props}
      >
        {stepperCardItems}
      </div>
    );
  }

  // Simple flex layout (row/column)
  return (
    <Flex
      direction={direction === 'row' ? 'row' : 'column'}
      gap={3}
      data-slot="stepper-card"
      className={className}
      width="full"
      {...props}
    >
      {stepperCardItems}
    </Flex>
  );
}
