import type { Meta, StoryObj } from '@storybook/react-vite';
import { useState } from 'react';
import { DatePicker, DateRangePicker, DatePickerInput } from './date-picker';
import { Label } from './label';
import { Button } from './button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from './card';
import { Calendar as CalendarIcon } from 'lucide-react';

const meta: Meta<typeof DatePicker> = {
  title: 'Design System/Primitives/Data Entry/DatePicker',
  component: DatePicker,
  tags: ['autodocs'],
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'A versatile date picker component built using Popover and Calendar components. Supports single date selection, date ranges, and various customization options.',
      },
      toc: {
        title: 'On this page',
        disable: false,
      },
    },
  },
  argTypes: {
    date: {
      control: { type: 'date' },
      description: 'The selected date',
      table: {
        type: { summary: 'Date' },
      },
    },
    onDateChange: {
      description: 'Callback when date changes',
      table: {
        type: { summary: '(date: Date | undefined) => void' },
      },
    },
    placeholder: {
      control: { type: 'text' },
      description: 'Placeholder text when no date is selected',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'Pick a date' },
      },
    },
    disabled: {
      control: { type: 'boolean' },
      description: 'Whether the date picker is disabled',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    showIcon: {
      control: { type: 'boolean' },
      description: 'Whether to show the calendar icon',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'true' },
      },
    },
    showChevron: {
      control: { type: 'boolean' },
      description: 'Whether to show the chevron icon',
      table: {
        type: { summary: 'boolean' },
        defaultValue: { summary: 'false' },
      },
    },
    format: {
      control: { type: 'text' },
      description: 'Date format string (using date-fns format)',
      table: {
        type: { summary: 'string' },
        defaultValue: { summary: 'PPP' },
      },
    },
    align: {
      control: { type: 'select' },
      options: ['start', 'center', 'end'],
      description: 'Alignment of the popover relative to the trigger',
      table: {
        type: { summary: 'start | center | end' },
        defaultValue: { summary: 'start' },
      },
    },
    side: {
      control: { type: 'select' },
      options: ['top', 'right', 'bottom', 'left'],
      description: 'Side of the trigger where the popover appears',
      table: {
        type: { summary: 'top | right | bottom | left' },
        defaultValue: { summary: 'bottom' },
      },
    },
  },
  args: {
    placeholder: 'Pick a date',
    disabled: false,
    showIcon: true,
    showChevron: false,
    format: 'PPP',
    align: 'start',
    side: 'bottom',
  },
};

export default meta;
type Story = StoryObj<typeof DatePicker>;

// Basic DatePicker Story
export const Default: Story = {
  render: args => {
    const DefaultComponent = () => {
      const [date, setDate] = useState<Date>();
      return <DatePicker {...args} date={date} onDateChange={setDate} />;
    };
    return <DefaultComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'The default date picker with basic functionality for selecting a single date.',
      },
    },
  },
};

// DatePicker with Preselected Date
export const WithPreselectedDate: Story = {
  render: args => {
    const WithPreselectedDateComponent = () => {
      const [date, setDate] = useState<Date>(new Date());
      return (
        <DatePicker
          {...args}
          date={date}
          onDateChange={newDate => setDate(newDate || new Date())}
        />
      );
    };
    return <WithPreselectedDateComponent />;
  },
  parameters: {
    docs: {
      description: {
        story: 'Date picker with a preselected date.',
      },
    },
  },
};

// DatePicker Variants
export const Variants: Story = {
  render: () => {
    const VariantsComponent = () => {
      const [date1, setDate1] = useState<Date>();
      const [date2, setDate2] = useState<Date>();
      const [date3, setDate3] = useState<Date>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Default Date Picker
            </h3>
            <DatePicker date={date1} onDateChange={setDate1} />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              With Chevron Icon
            </h3>
            <DatePicker
              date={date2}
              onDateChange={setDate2}
              showChevron
              placeholder="Select a date"
            />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Without Calendar Icon
            </h3>
            <DatePicker
              date={date3}
              onDateChange={setDate3}
              showIcon={false}
              placeholder="Choose date"
            />
          </div>
        </div>
      );
    };
    return <VariantsComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Different variants of the date picker with various icon configurations.',
      },
    },
  },
};

// DatePicker States
export const States: Story = {
  render: () => {
    const StatesComponent = () => {
      const [date, setDate] = useState<Date>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Normal State
            </h3>
            <DatePicker date={date} onDateChange={setDate} />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Disabled State
            </h3>
            <DatePicker date={date} onDateChange={setDate} disabled />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              With Selected Date
            </h3>
            <DatePicker
              date={new Date()}
              onDateChange={setDate}
              placeholder="Date selected"
            />
          </div>
        </div>
      );
    };
    return <StatesComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Different states of the date picker including normal, disabled, and with selected date.',
      },
    },
  },
};

// DatePicker with Different Formats
export const DateFormats: Story = {
  render: () => {
    const DateFormatsComponent = () => {
      const [date1, setDate1] = useState<Date>();
      const [date2, setDate2] = useState<Date>();
      const [date3, setDate3] = useState<Date>();
      const [date4, setDate4] = useState<Date>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Default Format (PPP)
            </h3>
            <DatePicker date={date1} onDateChange={setDate1} format="PPP" />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Short Format (MMM dd, yyyy)
            </h3>
            <DatePicker
              date={date2}
              onDateChange={setDate2}
              format="MMM dd, yyyy"
            />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Numeric Format (MM/dd/yyyy)
            </h3>
            <DatePicker
              date={date3}
              onDateChange={setDate3}
              format="MM/dd/yyyy"
            />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              ISO Format (yyyy-MM-dd)
            </h3>
            <DatePicker
              date={date4}
              onDateChange={setDate4}
              format="yyyy-MM-dd"
            />
          </div>
        </div>
      );
    };
    return <DateFormatsComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Date picker with different date format options using date-fns format strings.',
      },
    },
  },
};

// DatePicker Positioning
export const Positioning: Story = {
  render: () => {
    const PositioningComponent = () => {
      const [date1, setDate1] = useState<Date>();
      const [date2, setDate2] = useState<Date>();
      const [date3, setDate3] = useState<Date>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Bottom Alignment (Default)
            </h3>
            <DatePicker date={date1} onDateChange={setDate1} side="bottom" />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Top Alignment
            </h3>
            <DatePicker date={date2} onDateChange={setDate2} side="top" />
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Center Alignment
            </h3>
            <DatePicker date={date3} onDateChange={setDate3} align="center" />
          </div>
        </div>
      );
    };
    return <PositioningComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Date picker with different positioning options for the popover.',
      },
    },
  },
};

// DateRangePicker Story
export const DateRange: Story = {
  render: () => {
    const DateRangeComponent = () => {
      const [dateRange, setDateRange] = useState<{
        from: Date | undefined;
        to?: Date | undefined;
      }>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Date Range Picker
            </h3>
            <DateRangePicker
              dateRange={dateRange}
              onDateRangeChange={setDateRange}
              placeholder="Pick a date range"
            />
          </div>

          {dateRange?.from && (
            <div className="text-sm text-muted-foreground">
              Selected range: {dateRange.from.toLocaleDateString()}
              {dateRange.to && ` - ${dateRange.to.toLocaleDateString()}`}
            </div>
          )}
        </div>
      );
    };
    return <DateRangeComponent />;
  },
  parameters: {
    docs: {
      description: {
        story: 'Date range picker for selecting a range of dates.',
      },
    },
  },
};

// DatePickerInput Story
export const DatePickerWithInput: Story = {
  render: () => {
    const DatePickerWithInputComponent = () => {
      const [date, setDate] = useState<Date>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Date Picker with Input Style
            </h3>
            <DatePickerInput
              date={date}
              onDateChange={setDate}
              placeholder="Select date"
            />
          </div>

          {date && (
            <div className="text-sm text-muted-foreground">
              Selected date: {date.toLocaleDateString()}
            </div>
          )}
        </div>
      );
    };
    return <DatePickerWithInputComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Date picker with an input-style trigger button and dropdown month/year selection.',
      },
    },
  },
};

// Form Integration Story
export const FormIntegration: Story = {
  render: () => {
    const FormIntegrationComponent = () => {
      const [date, setDate] = useState<Date>();

      return (
        <Card className="w-[400px]">
          <CardHeader>
            <CardTitle>Date of Birth</CardTitle>
            <CardDescription>
              Please select your date of birth for age verification.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="dob">Date of Birth</Label>
              <DatePicker
                date={date}
                onDateChange={setDate}
                placeholder="Select your date of birth"
              />
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setDate(undefined)}>
                Clear
              </Button>
              <Button disabled={!date}>Submit</Button>
            </div>

            {date && (
              <div className="text-sm text-muted-foreground">
                Age:{' '}
                {Math.floor(
                  (Date.now() - date.getTime()) /
                    (365.25 * 24 * 60 * 60 * 1000),
                )}{' '}
                years old
              </div>
            )}
          </CardContent>
        </Card>
      );
    };
    return <FormIntegrationComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Date picker integrated into a form with validation and age calculation.',
      },
    },
  },
};

// Custom Trigger Story
export const CustomTrigger: Story = {
  render: () => {
    const CustomTriggerComponent = () => {
      const [date, setDate] = useState<Date>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Custom Trigger Button
            </h3>
            <DatePicker
              date={date}
              onDateChange={setDate}
              placeholder="Custom trigger"
            >
              <Button variant="secondary" className="w-[200px]">
                {date
                  ? `Selected: ${date.toLocaleDateString()}`
                  : 'Click to select date'}
              </Button>
            </DatePicker>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Icon Only Trigger
            </h3>
            <DatePicker
              date={date}
              onDateChange={setDate}
              placeholder="Icon trigger"
            >
              <Button size="icon" variant="outline">
                <CalendarIcon className="h-4 w-4" />
              </Button>
            </DatePicker>
          </div>
        </div>
      );
    };
    return <CustomTriggerComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Date picker with custom trigger components instead of the default button.',
      },
    },
  },
};

// All Components Showcase
export const AllComponents: Story = {
  render: () => {
    const AllComponentsComponent = () => {
      const [date, setDate] = useState<Date>();
      const [dateRange, setDateRange] = useState<{
        from: Date | undefined;
        to?: Date | undefined;
      }>();
      const [dateInput, setDateInput] = useState<Date>();

      return (
        <div className="space-y-6">
          <div>
            <h2 className="text-lg font-bold text-foreground mb-3">
              All Date Picker Components
            </h2>

            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">
                  Single Date Picker
                </h3>
                <DatePicker
                  date={date}
                  onDateChange={setDate}
                  placeholder="Pick a date"
                />
              </div>

              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">
                  Date Range Picker
                </h3>
                <DateRangePicker
                  dateRange={dateRange}
                  onDateRangeChange={setDateRange}
                  placeholder="Pick a date range"
                />
              </div>

              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">
                  Date Picker with Input
                </h3>
                <DatePickerInput
                  date={dateInput}
                  onDateChange={setDateInput}
                  placeholder="Select date"
                />
              </div>
            </div>
          </div>

          <div>
            <h2 className="text-lg font-bold text-foreground mb-3">
              Selected Values
            </h2>
            <div className="space-y-2 text-sm text-muted-foreground">
              <div>
                Single Date:{' '}
                {date ? date.toLocaleDateString() : 'None selected'}
              </div>
              <div>
                Date Range:{' '}
                {dateRange?.from ? dateRange.from.toLocaleDateString() : 'None'}
                {dateRange?.to && ` - ${dateRange.to.toLocaleDateString()}`}
              </div>
              <div>
                Input Date:{' '}
                {dateInput ? dateInput.toLocaleDateString() : 'None selected'}
              </div>
            </div>
          </div>
        </div>
      );
    };
    return <AllComponentsComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Showcase of all date picker components with their selected values displayed.',
      },
    },
  },
};

// Accessibility Story
export const Accessibility: Story = {
  render: () => {
    const AccessibilityComponent = () => {
      const [date, setDate] = useState<Date>();

      return (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Accessibility Features
            </h3>
            <div className="space-y-3">
              <div className="bg-muted p-3 rounded-lg">
                <h4 className="font-medium text-foreground mb-1 text-sm">
                  Keyboard Navigation
                </h4>
                <p className="text-xs text-muted-foreground">
                  Use Tab to navigate to the date picker, Enter/Space to open,
                  and arrow keys to navigate dates.
                </p>
              </div>

              <div className="bg-muted p-3 rounded-lg">
                <h4 className="font-medium text-foreground mb-1 text-sm">
                  Screen Reader Support
                </h4>
                <p className="text-xs text-muted-foreground">
                  Proper ARIA labels and semantic HTML for screen reader
                  compatibility.
                </p>
              </div>

              <div className="bg-muted p-3 rounded-lg">
                <h4 className="font-medium text-foreground mb-1 text-sm">
                  Focus Management
                </h4>
                <p className="text-xs text-muted-foreground">
                  Automatic focus management when opening/closing the calendar.
                </p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-foreground mb-2">
              Accessible Date Picker
            </h3>
            <DatePicker
              date={date}
              onDateChange={setDate}
              placeholder="Select a date (accessible)"
              aria-label="Choose a date"
            />
          </div>
        </div>
      );
    };
    return <AccessibilityComponent />;
  },
  parameters: {
    docs: {
      description: {
        story:
          'Date picker with accessibility features and keyboard navigation support.',
      },
    },
  },
};
