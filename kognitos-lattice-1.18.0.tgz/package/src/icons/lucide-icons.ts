/**
 * Lucide Icons
 *
 * Individual exports of Lucide icons for tree-shaking support.
 * Only import the icons you need to keep bundle size minimal.
 * Add new icons from lucide-react/icons directly to this file.
 *
 * Icons are organized by Lucide categories and ordered alphabetically within each category.
 */

/**
 * Accessibility
 */
export { Eye } from 'lucide-react';
export { EyeOff } from 'lucide-react';
export { HelpCircle } from 'lucide-react';
export { ScanEye } from 'lucide-react';

/**
 * Accounts & access
 */
export { BadgeCheck } from 'lucide-react';
export { Key } from 'lucide-react';
export { KeyRound } from 'lucide-react';
export { Lock } from 'lucide-react';
export { LogOut } from 'lucide-react';
export { Shield } from 'lucide-react';
export { ShieldAlert } from 'lucide-react';
export { ShieldCheck } from 'lucide-react';
export { ToggleRight } from 'lucide-react';
export { Unlock } from 'lucide-react';
export { User } from 'lucide-react';
export { UserCog } from 'lucide-react';
export { UserPlus } from 'lucide-react';
export { UserRound } from 'lucide-react';
export { Users } from 'lucide-react';

/**
 * Arrows
 */
export { ArrowLeft } from 'lucide-react';
export { ArrowRight } from 'lucide-react';
export { ArrowUp } from 'lucide-react';
export { ArrowUpRight } from 'lucide-react';
export { ChevronDown } from 'lucide-react';
export { ChevronLeft } from 'lucide-react';
export { ChevronRight } from 'lucide-react';
export { ChevronUp } from 'lucide-react';
export { ChevronsUp } from 'lucide-react';
export { ChevronsUpDown } from 'lucide-react';
export { ChevronsRight } from 'lucide-react';

/**
 * Buildings
 */
export { Building } from 'lucide-react';
export { GraduationCap } from 'lucide-react';

/**
 * Brands
 */
export { Github } from 'lucide-react';
export { Facebook } from 'lucide-react';
export { Twitter } from 'lucide-react';
export { Instagram } from 'lucide-react';

/**
 * Charts
 */
export { Activity } from 'lucide-react';
export { BarChart } from 'lucide-react';
export { BarChart3 } from 'lucide-react';
export { BarChartBig } from 'lucide-react';
export { ChartBar } from 'lucide-react';
export { LineChart } from 'lucide-react';
export { PieChart } from 'lucide-react';
export { Target } from 'lucide-react';
export { TrendingDown } from 'lucide-react';
export { TrendingUp } from 'lucide-react';

/**
 * Chat
 */
export { MessagesSquare } from 'lucide-react';

/**
 * Communication
 */
export { AtSign } from 'lucide-react';
export { CircleHelp } from 'lucide-react';
export { Hash } from 'lucide-react';
export { Languages } from 'lucide-react';
export { Loader } from 'lucide-react';
export { Loader2 } from 'lucide-react';
export { LoaderCircle } from 'lucide-react';
export { Mail } from 'lucide-react';
export { MessageCircle } from 'lucide-react';
export { MessageCircleWarning } from 'lucide-react';
export { MessageSquare } from 'lucide-react';
export { Phone } from 'lucide-react';
export { Quote } from 'lucide-react';
export { SendHorizontal } from 'lucide-react';
export { SendToBack } from 'lucide-react';
export { Webhook } from 'lucide-react';
export { Archive } from 'lucide-react';
export { ArchiveX } from 'lucide-react';

/**
 * Connectivity
 */
export { Link } from 'lucide-react';
export { Network } from 'lucide-react';
export { Wifi } from 'lucide-react';
export { WifiOff } from 'lucide-react';

/**
 * Cursors
 */
export { Crosshair } from 'lucide-react';
export { MousePointer } from 'lucide-react';
export { MousePointerClick } from 'lucide-react';
export { Sparkles } from 'lucide-react';

/**
 * Design
 */
export { AlignCenter } from 'lucide-react';
export { AlignJustify } from 'lucide-react';
export { AlignLeft } from 'lucide-react';
export { AlignRight } from 'lucide-react';
export { Bold } from 'lucide-react';
export { Brush } from 'lucide-react';
export { Circle } from 'lucide-react';
export { CircleDashed } from 'lucide-react';
export { CircleSlash2 } from 'lucide-react';
export { CircleAlert } from 'lucide-react';
export { Code } from 'lucide-react';
export { Disc } from 'lucide-react';
export { GalleryVerticalEnd } from 'lucide-react';
export { Hexagon } from 'lucide-react';
export { Italic } from 'lucide-react';
export { List } from 'lucide-react';
export { ListOrdered } from 'lucide-react';
export { Octagon } from 'lucide-react';
export { Palette } from 'lucide-react';
export { Pen } from 'lucide-react';
export { PencilLine } from 'lucide-react';
export { PenLine } from 'lucide-react';
export { PenTool } from 'lucide-react';
export { Square } from 'lucide-react';
export { SquareMousePointer } from 'lucide-react';
export { Strikethrough } from 'lucide-react';
export { Triangle } from 'lucide-react';
export { Type } from 'lucide-react';
export { Underline } from 'lucide-react';
export { SquareAsterisk } from 'lucide-react';

/**
 * Coding & development
 */
export { Cpu } from 'lucide-react';
export { Database } from 'lucide-react';
export { DatabaseZap } from 'lucide-react';
export { HardDrive } from 'lucide-react';
export { MemoryStick } from 'lucide-react';
export { Server } from 'lucide-react';
export { Unplug } from 'lucide-react';
export { BetweenHorizonalStart } from 'lucide-react';

/**
 * Development
 */
export { BookOpen } from 'lucide-react';
export { Blocks } from 'lucide-react';
export { Layers3 } from 'lucide-react';

/**
 * Devices
 */
export { Battery } from 'lucide-react';
export { BatteryCharging } from 'lucide-react';
export { Camera } from 'lucide-react';
export { Headphones } from 'lucide-react';
export { Laptop } from 'lucide-react';
export { LaptopMinimal } from 'lucide-react';
export { Lightbulb } from 'lucide-react';
export { Mic } from 'lucide-react';
export { MicOff } from 'lucide-react';
export { Monitor } from 'lucide-react';
export { Power } from 'lucide-react';
export { Printer } from 'lucide-react';
export { Smartphone } from 'lucide-react';
export { Tablet } from 'lucide-react';
export { TvMinimalPlay } from 'lucide-react';
export { Video } from 'lucide-react';
export { VideoOff } from 'lucide-react';
export { SwitchCamera } from 'lucide-react';

/**
 * Emoji
 */
export { Angry } from 'lucide-react';
export { Frown } from 'lucide-react';
export { Ghost } from 'lucide-react';
export { Laugh } from 'lucide-react';
export { Meh } from 'lucide-react';
export { PartyPopper } from 'lucide-react';
export { Skull } from 'lucide-react';
export { Smile } from 'lucide-react';
export { ThumbsDown } from 'lucide-react';
export { ThumbsUp } from 'lucide-react';

/**
 * Files
 */
export { File } from 'lucide-react';
export { FileCheck } from 'lucide-react';
export { FileCode } from 'lucide-react';
export { FileCog } from 'lucide-react';
export { FileJson } from 'lucide-react';
export { FileScan } from 'lucide-react';
export { FileSpreadsheet } from 'lucide-react';
export { FileText } from 'lucide-react';
export { FileType } from 'lucide-react';
export { FileX } from 'lucide-react';
export { Folder } from 'lucide-react';
export { FolderCode } from 'lucide-react';
export { FolderOpen } from 'lucide-react';
export { Image } from 'lucide-react';
export { Music } from 'lucide-react';
export { ListVideo } from 'lucide-react';
export { Paperclip } from 'lucide-react';
export { GalleryHorizontalEnd } from 'lucide-react';

/**
 * Finance
 */
export { Bitcoin } from 'lucide-react';
export { CreditCard } from 'lucide-react';
export { DollarSign } from 'lucide-react';
export { Euro } from 'lucide-react';
export { PoundSterling } from 'lucide-react';
export { ShoppingCart } from 'lucide-react';

/**
 * Food & beverage
 */
export { Beer } from 'lucide-react';
export { Cake } from 'lucide-react';
export { Candy } from 'lucide-react';
export { Coffee } from 'lucide-react';
export { Fish } from 'lucide-react';
export { IceCream } from 'lucide-react';
export { Milk } from 'lucide-react';
export { Pizza } from 'lucide-react';
export { Salad } from 'lucide-react';
export { Shrimp } from 'lucide-react';
export { Wine } from 'lucide-react';

/**
 * Home
 */
export { Home } from 'lucide-react';

/**
 * Layout
 */
export { EllipsisVertical } from 'lucide-react';
export { Ellipsis } from 'lucide-react';
export { ExternalLink } from 'lucide-react';
export { Grip } from 'lucide-react';
export { Maximize } from 'lucide-react';
export { Maximize2 } from 'lucide-react';
export { Menu } from 'lucide-react';
export { Minimize } from 'lucide-react';
export { MoreHorizontal } from 'lucide-react';
export { MoreVertical } from 'lucide-react';
export { PanelLeft } from 'lucide-react';
export { RotateCcw } from 'lucide-react';
export { RotateCw } from 'lucide-react';
export { RotateCwSquare } from 'lucide-react';
export { Table } from 'lucide-react';
export { Table2 } from 'lucide-react';
export { ZoomIn } from 'lucide-react';
export { ZoomOut } from 'lucide-react';

/**
 * Mathematics
 */
export { Infinity } from 'lucide-react';
export { Percent } from 'lucide-react';
export { Pi } from 'lucide-react';

/**
 * Multimedia
 */
export { Bookmark } from 'lucide-react';
export { Copy } from 'lucide-react';
export { Download } from 'lucide-react';
export { Edit } from 'lucide-react';
export { Filter } from 'lucide-react';
export { Heart } from 'lucide-react';
export { ListFilter } from 'lucide-react';
export { Pause } from 'lucide-react';
export { Play } from 'lucide-react';
export { FastForward } from 'lucide-react';
export { Package } from 'lucide-react';
export { Plus } from 'lucide-react';
export { RefreshCw } from 'lucide-react';
export { Rocket } from 'lucide-react';
export { Search } from 'lucide-react';
export { Share } from 'lucide-react';
export { SkipBack } from 'lucide-react';
export { SkipForward } from 'lucide-react';
export { SortAsc } from 'lucide-react';
export { SortDesc } from 'lucide-react';
export { SquarePlay } from 'lucide-react';
export { Star } from 'lucide-react';
export { Tag } from 'lucide-react';
export { Trash } from 'lucide-react';
export { Upload } from 'lucide-react';
export { Volume } from 'lucide-react';
export { Volume1 } from 'lucide-react';
export { Volume2 } from 'lucide-react';
export { VolumeX } from 'lucide-react';
export { X } from 'lucide-react';
export { Save } from 'lucide-react';

/**
 * Navigation
 */
export { Compass } from 'lucide-react';
export { Flag } from 'lucide-react';
export { Globe } from 'lucide-react';
export { LocateFixed } from 'lucide-react';
export { Map } from 'lucide-react';
export { MapPin } from 'lucide-react';
export { Pin } from 'lucide-react';
export { Navigation } from 'lucide-react';
export { GlobeLock } from 'lucide-react';

/**
 * Notification
 */
export { AlertCircle } from 'lucide-react';
export { AlertOctagon } from 'lucide-react';
export { AlertTriangle } from 'lucide-react';
export { Bell } from 'lucide-react';
export { Check } from 'lucide-react';
export { CircleCheck } from 'lucide-react';
export { CircleCheckBig } from 'lucide-react';
export { CircleStop } from 'lucide-react';
export { CircleX } from 'lucide-react';
export { Info } from 'lucide-react';
export { Minus } from 'lucide-react';
export { TriangleAlert } from 'lucide-react';

/**
 * People
 */
export { Briefcase } from 'lucide-react';
export { BriefcaseBusiness } from 'lucide-react';
export { Crown } from 'lucide-react';
export { Glasses } from 'lucide-react';
export { Handshake } from 'lucide-react';
export { Shirt } from 'lucide-react';

/**
 * Science
 */
export { FlaskConical } from 'lucide-react';

/**
 * Shapes
 */
export { Sparkle } from 'lucide-react';

/**
 * Social
 */
export { Award } from 'lucide-react';
export { Gift } from 'lucide-react';
export { Trophy } from 'lucide-react';

/**
 * Text
 */
export { Text } from 'lucide-react';
export { TextCursor } from 'lucide-react';
export { TextCursorInput } from 'lucide-react';

/**
 * Time & calendar
 */
export { Calendar } from 'lucide-react';
export { Clock } from 'lucide-react';
export { Clock4 } from 'lucide-react';
export { History } from 'lucide-react';

/**
 * Tools
 */
export { Hammer } from 'lucide-react';
export { Scissors } from 'lucide-react';
export { Settings } from 'lucide-react';
export { Settings2 } from 'lucide-react';
export { Wrench } from 'lucide-react';
export { Diamond } from 'lucide-react';

/**
 * Transportation
 */
export { Car } from 'lucide-react';

/**
 * Weather
 */
export { Cloud } from 'lucide-react';
export { CloudRain } from 'lucide-react';
export { CloudSnow } from 'lucide-react';
export { Droplets } from 'lucide-react';
export { Moon } from 'lucide-react';
export { Sun } from 'lucide-react';
export { SunDim } from 'lucide-react';
export { Thermometer } from 'lucide-react';
export { Umbrella } from 'lucide-react';
export { Wind } from 'lucide-react';
export { Zap } from 'lucide-react';

/**
 * Animals
 */
export { Turtle } from 'lucide-react';
