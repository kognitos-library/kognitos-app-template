/**
 * Custom Icon Assets
 *
 * This file exports all custom React component icons.
 * SVG icons are automatically imported and available through the Icon component.
 *
 * Tree-shaking friendly: Only imported icons will be included in the bundle.
 */

/**
 * Weather
 */
export { default as Stars } from './svg/stars.svg?react';

/**
 * Bars
 */
export { default as BarHigh } from './svg/bar-high.svg?react';
export { default as BarLow } from './svg/bar-low.svg?react';
export { default as BarMedium } from './svg/bar-medium.svg?react';
