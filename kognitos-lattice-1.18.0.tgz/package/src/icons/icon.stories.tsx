import React from 'react';
import type { Meta, StoryObj } from '@storybook/react-vite';
import { Icon, type IconType } from '@/design-system/icons';

// Import all available icons dynamically
import * as LucideIcons from '@/design-system/icons/lucide-icons';
import * as CustomIconAssets from '@/design-system/icons/assets';
import { Input } from '../primitives/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../primitives/select';

// Generate available icon types dynamically
const availableLucideIcons = Object.keys(LucideIcons) as Array<
  keyof typeof LucideIcons
>;
const availableCustomIcons = Object.keys(CustomIconAssets) as Array<
  keyof typeof CustomIconAssets
>;
const allAvailableIcons = [...availableLucideIcons, ...availableCustomIcons];

const meta: Meta<typeof Icon> = {
  title: 'Design System/Primitives/General/Icons',
  component: Icon,
  parameters: {
    docs: {
      description: {
        component: `
A flexible icon component that supports both Lucide icons and custom SVG icons.
Supports tree-shaking for optimal bundle size.

## Features
- **Tree-shaking friendly**: Only imported icons are included in the bundle
- **Flexible sizing**: Predefined sizes (XS, S, M, L, XL, 2XL, 3XL) or custom numbers
- **Custom icons**: Support for custom SVG icons
- **Consistent styling**: Inherits text color and supports custom classes
- **TypeScript support**: Full type safety for icon names

## Usage
\`\`\`tsx
// Using Lucide icons
<Icon type="ChevronDown" size="lg" />
<Icon type="Search" size={24} />

// Using custom icons
<Icon type="ExampleCustom" size="xl" />
\`\`\`
        `,
      },
    },
  },
  argTypes: {
    type: {
      control: 'select',
      options: allAvailableIcons,
      description: 'The type of icon to render',
    },
    size: {
      control: 'select',
      options: ['xs', 'sm', 'md', 'lg', 'xl', '2xl', '3xl'],
      description: 'The size of the icon',
    },
    inheritColor: {
      control: 'boolean',
      description: 'Whether the icon should inherit the current text color',
    },
    className: {
      control: 'text',
      description: 'Additional CSS classes',
    },
    rotate: {
      control: { type: 'range', min: 0, max: 360, step: 15 },
      description: 'Rotation angle in degrees',
    },
  },
  tags: ['autodocs'],
};

export default meta;
type Story = StoryObj<typeof meta>;

// Base story
export const Default: Story = {
  args: {
    type: 'ChevronDown',
    size: 'md',
  },
  parameters: {
    layout: 'centered',
  },
};

// Rotation examples
export const Rotation: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="lg" rotate={0} />
        <span className="text-xs">0°</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="lg" rotate={90} />
        <span className="text-xs">90°</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="lg" rotate={180} />
        <span className="text-xs">180°</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="lg" rotate={270} />
        <span className="text-xs">270°</span>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Icons can be rotated using the rotate prop (0-360 degrees).',
      },
    },
  },
};

// Size variations
export const Sizes: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="xs" />
        <span className="text-xs">xs (12px)</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="sm" />
        <span className="text-xs">sm (16px)</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="md" />
        <span className="text-xs">md (20px)</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="lg" />
        <span className="text-xs">lg (24px)</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="xl" />
        <span className="text-xs">xl (32px)</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="2xl" />
        <span className="text-xs">2xl (40px)</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size="3xl" />
        <span className="text-xs">3xl (48px)</span>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'All available predefined sizes for icons.',
      },
    },
  },
};

// Custom sizes
export const CustomSizes: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size={8} />
        <span className="text-xs">8px</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size={14} />
        <span className="text-xs">14px</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size={28} />
        <span className="text-xs">28px</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size={36} />
        <span className="text-xs">36px</span>
      </div>
      <div className="flex flex-col items-center gap-2">
        <Icon type="ChevronDown" size={64} />
        <span className="text-xs">64px</span>
      </div>
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Custom numeric sizes for precise control.',
      },
    },
  },
};

// Custom icons showcase
export const CustomIcons: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      {availableCustomIcons.length > 0 ? (
        availableCustomIcons.map(iconName => (
          <div key={iconName} className="flex flex-col items-center gap-2">
            <Icon type={iconName} size="lg" />
            <span className="text-xs">{iconName}</span>
          </div>
        ))
      ) : (
        <div className="text-center py-8 text-gray-500">
          <p>No custom icons available</p>
        </div>
      )}
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story: 'Custom SVG icons can be added to the system.',
      },
    },
  },
};

// Color variations
export const Colors: Story = {
  render: () => (
    <div className="flex items-center gap-4">
      <Icon type="Heart" size="lg" className="text-destructive" />
      <Icon type="Star" size="lg" className="text-yellow-500" />
      <Icon type="Check" size="lg" className="text-green-500" />
      <Icon type="AlertCircle" size="lg" className="text-blue-500" />
      <Icon type="Settings" size="lg" className="text-purple-500" />
      <Icon type="User" size="lg" className="text-gray-500" />
    </div>
  ),
  parameters: {
    docs: {
      description: {
        story:
          'Icons inherit text color by default and can be styled with custom classes.',
      },
    },
  },
};

// Interactive example
export const Interactive: Story = {
  render: () => (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-4">
        <Icon
          type="ChevronDown"
          size="lg"
          className="cursor-pointer hover:text-blue-500 transition-colors"
        />
        <span>Hover me!</span>
      </div>
      <div className="flex items-center gap-4">
        <Icon
          type="Heart"
          size="lg"
          className="cursor-pointer hover:scale-110 transition-transform"
        />
        <span>Click me!</span>
      </div>
      <div className="flex items-center gap-4">
        <Icon
          type="RefreshCw"
          size="lg"
          className="cursor-pointer hover:rotate-180 transition-transform duration-500"
        />
        <span>Hover to rotate!</span>
      </div>
    </div>
  ),
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        story:
          'Icons can be made interactive with hover effects and transitions, including rotation.',
      },
    },
  },
};

// Available icons showcase
const AvailableIconsComponent = () => {
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedSize, setSelectedSize] = React.useState<'sm' | 'md' | 'lg'>(
    'lg',
  );

  // Filter icons based on search term
  const filteredIcons = allAvailableIcons.filter(iconName =>
    iconName.toLowerCase().includes(searchTerm.toLowerCase()),
  );

  return (
    <div className="space-y-6 w-full">
      {/* Controls */}
      <div className="space-y-4 w-full">
        {/* Search */}
        <div>
          <label
            htmlFor="icon-search"
            className="block text-sm font-medium mb-2"
          >
            Search Icons
          </label>
          <Input
            id="icon-search"
            type="text"
            placeholder="Search by icon name..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
          />
        </div>

        {/* Size selector */}
        <div>
          <label htmlFor="icon-size" className="block text-sm font-medium mb-2">
            Size
          </label>
          <Select
            value={selectedSize}
            onValueChange={value =>
              setSelectedSize(value as 'sm' | 'md' | 'lg')
            }
          >
            <SelectTrigger>
              <SelectValue placeholder="Select size" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="sm">Small (16px)</SelectItem>
              <SelectItem value="md">Medium (20px)</SelectItem>
              <SelectItem value="lg">Large (24px)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Results count */}
        <div className="text-sm text-gray-600">
          Showing {filteredIcons.length} of {allAvailableIcons.length} icons
        </div>
      </div>
      {/* Icons grid */}
      {filteredIcons.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filteredIcons.map(iconName => (
            <div
              key={iconName}
              className="flex flex-col items-center gap-2 p-3 rounded-lg border border-gray-200 hover:border-gray-300 hover:bg-accent transition-colors cursor-pointer"
              onClick={() => {
                // Copy icon name to clipboard
                navigator.clipboard.writeText(
                  `<Icon type="${iconName}" size="${selectedSize}" />`,
                );
              }}
              title={`Click to copy: <Icon type="${iconName}" size="${selectedSize}" />`}
            >
              <Icon type={iconName as IconType} size={selectedSize} />
              <span
                className="text-xs text-center text-gray-600 leading-tight truncate w-full"
                title={iconName}
              >
                {iconName}
              </span>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500">
          <Icon
            type="Search"
            size="xl"
            className="mx-auto mb-4 text-gray-300"
          />
          <p>No icons found matching "{searchTerm}"</p>
        </div>
      )}
    </div>
  );
};

export const AvailableIcons: Story = {
  render: () => <AvailableIconsComponent />,
  parameters: {
    docs: {
      description: {
        story:
          'Browse all available icons with search functionality. Click any icon to copy its usage code to clipboard.',
      },
    },
  },
};
