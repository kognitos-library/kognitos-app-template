import React from 'react';
import { cn } from '@/design-system/lib/utils';

// Import all Lucide icons for dynamic access
import * as LucideIcons from './lucide-icons';

// Import custom icons (including SVG components)
import * as CustomIcons from './assets';

// Type definitions
export type IconSize =
  | 'xs'
  | 'sm'
  | 'md'
  | 'lg'
  | 'xl'
  | '2xl'
  | '3xl'
  | number;

export type LucideIconType = keyof typeof LucideIcons;
export type CustomIconType = keyof typeof CustomIcons;

// All icon types are now unified under CustomIconType
export type IconType = LucideIconType | CustomIconType;

// Size mapping for predefined sizes
const sizeMap: Record<Exclude<IconSize, number>, number> = {
  xs: 12,
  sm: 16,
  md: 20,
  lg: 24,
  xl: 32,
  '2xl': 40,
  '3xl': 48,
};

// Icon component interface
export interface IIconProps extends React.SVGProps<SVGSVGElement> {
  /** The type of icon to render (Lucide icon name or custom icon name) */
  type: IconType;
  /** The size of the icon - can be predefined size or custom number */
  size?: IconSize;
  /** Additional CSS classes */
  className?: string;
  /** Whether the icon should inherit the current text color */
  inheritColor?: boolean;
  /** Rotation angle in degrees (0-360) */
  rotate?: number;
}

/**
 * Icon Component
 *
 * A flexible icon component that supports both Lucide icons and custom SVG icons.
 * Supports tree-shaking for optimal bundle size.
 *
 * @example
 * ```tsx
 * // Using Lucide icons
 * <Icon type="ChevronDown" size="lg" />
 * <Icon type="Search" size={24} />
 *
 * // Using custom icons
 * <Icon type="CustomLogo" size="xl" />
 * <Icon type="Brand" size={32} />
 * ```
 */
export function Icon({
  type,
  size = 'md',
  className,
  inheritColor = true,
  rotate,
  ...props
}: IIconProps) {
  // Calculate the actual size
  const actualSize = typeof size === 'number' ? size : sizeMap[size];

  // Try to get the icon component
  const LucideIcon = LucideIcons[type as LucideIconType];
  const CustomIcon = CustomIcons[type as CustomIconType];

  const IconComponent = LucideIcon || CustomIcon;

  if (!IconComponent) {
    console.warn(`Icon type "${type}" not found. Available types:`, {
      lucide: Object.keys(LucideIcons),
      custom: Object.keys(CustomIcons),
    });
    return null;
  }

  // Base classes for consistent styling
  const baseClasses = cn(
    'inline-block',
    inheritColor && 'text-current',
    className,
  );

  // Apply rotation if specified
  const style =
    rotate !== undefined ? { transform: `rotate(${rotate}deg)` } : undefined;

  // Handle different icon types
  if (type in LucideIcons) {
    // Lucide icons accept a size prop
    return (
      <IconComponent
        size={actualSize}
        className={baseClasses}
        style={style}
        {...props}
      />
    );
  } else {
    // Custom SVG icons need width and height props
    return (
      <IconComponent
        width={actualSize}
        height={actualSize}
        className={baseClasses}
        style={style}
        {...props}
      />
    );
  }
}

// Export the component and types
export default Icon;
