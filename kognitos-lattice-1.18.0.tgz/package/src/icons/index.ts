/**
 * Design System Icons
 *
 * A comprehensive icon system that supports both Lucide icons and custom SVG icons.
 * Built with tree-shaking support for optimal bundle size.
 *
 * @example
 * ```tsx
 * import { Icon } from '@/design-system/icons';
 *
 * // Using Lucide icons
 * <Icon type="ChevronDown" size="lg" />
 * <Icon type="Search" size={24} />
 *
 * // Using custom icons
 * <Icon type="ExampleCustom" size="xl" />
 * ```
 */

// Main Icon component
export { Icon, type IIconProps, type IconSize, type IconType } from './icon';

// Re-export Lucide icons for direct access (tree-shaking friendly)
export * from './lucide-icons';

// Re-export custom icons
export * from './assets';

// Default export
export { Icon as default } from './icon';
