# Design System Icons

A comprehensive icon system that supports both Lucide icons and custom SVG icons with tree-shaking support for optimal bundle size.

## Features

- **Tree-shaking friendly**: Only imported icons are included in the bundle
- **Flexible sizing**: Predefined sizes (XS, S, M, L, XL, 2XL, 3XL) or custom numbers
- **Custom icons**: Support for custom SVG icons
- **Consistent styling**: Inherits text color and supports custom classes
- **TypeScript support**: Full type safety for icon names
- **Scalable**: Easy to switch icon libraries or add new custom icons

## Quick Start

```tsx
import { Icon } from '@/design-system/icons';

// Using Lucide icons
<Icon type="ChevronDown" size="md" />
<Icon type="Search" size={24} />

// Using custom SVG icons
<Icon type="ExampleCustom" size="lg" />
```

## Usage

### Basic Usage

```tsx
import { Icon } from '@/design-system/icons';

function MyComponent() {
  return (
    <div>
      <Icon type="ChevronDown" size="lg" />
      <Icon type="Search" size={24} />
      <Icon type="ExampleCustom" size="xl" />
    </div>
  );
}
```

### Size Options

The `size` prop accepts predefined sizes or custom numbers:

```tsx
// Predefined sizes
<Icon type="ChevronDown" size="xs" />   // 12px
<Icon type="ChevronDown" size="sm" />   // 16px
<Icon type="ChevronDown" size="md" />   // 20px
<Icon type="ChevronDown" size="lg" />   // 24px
<Icon type="ChevronDown" size="xl" />   // 32px
<Icon type="ChevronDown" size="2xl" />  // 40px
<Icon type="ChevronDown" size="3xl" />  // 48px

// Custom sizes
<Icon type="ChevronDown" size={18} />
<Icon type="ChevronDown" size={36} />
```

### Styling and Rotation

Icons inherit the current text color by default and can be styled with custom classes and rotation:

```tsx
// Inherit text color
<Icon type="Heart" size="lg" />

// Custom colors
<Icon type="Heart" size="lg" className="text-red-500" />
<Icon type="Star" size="lg" className="text-yellow-500" />

// Rotation
<Icon type="ChevronDown" size="lg" rotate={90} />
<Icon type="ArrowRight" size="lg" rotate={180} />

// Interactive styling
<Icon
  type="ChevronDown"
  size="lg"
  className="cursor-pointer hover:text-blue-500 transition-colors"
/>

// Interactive rotation
<Icon
  type="RefreshCw"
  size="lg"
  className="cursor-pointer hover:rotate-180 transition-transform duration-500"
/>
```

### Available Lucide Icons

The system includes a comprehensive set of [Lucide icons](https://lucide.dev/icons/).
For a complete list, see the `lucide-icons.ts` file.

## Adding Custom SVG Icons

### Requirements for Custom SVG Icons

All custom SVG icons must follow these requirements:

1. **24x24 viewBox**: All icons should use `viewBox="0 0 24 24"`
2. **currentColor**: Use `currentColor` for all stroke and fill attributes
3. **Consistent styling**: Follow the same design patterns as Lucide icons

### Method 1: Direct SVG Import (Recommended)

1. Place your SVG file in `/design-system/icons/assets/svg/`:

```svg
<!-- /design-system/icons/assets/svg/my-custom-icon.svg -->
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path d="M12 2L2 7L12 12L22 7L12 2Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
  <path d="M2 17L12 22L22 17" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
```

2. Export it in `/design-system/icons/assets/index.ts`:

```tsx
export { default as MyCustomIcon } from './svg/my-custom-icon.svg?react';
```

3. Use it in your components:

```tsx
<Icon type="MyCustomIcon" size="lg" />
```

**That's it!** Just add the export line and the icon is available. No manual type definitions or mapping updates needed.

### Method 2: Manual React Component

For complex icons that need custom logic, create a React component:

1. Create a new component in `/design-system/icons/assets/`:

```tsx
// /design-system/icons/assets/complex-icon.tsx
import React from 'react';
import { cn } from '@/design-system/lib/utils';

export interface ComplexIconProps extends React.SVGProps<SVGSVGElement> {
  size?: number;
  className?: string;
}

export function ComplexIcon({
  size = 24,
  className,
  ...props
}: ComplexIconProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={cn('inline-block', className)}
      {...props}
    >
      {/* Your SVG content here */}
      <path
        d="M12 2L2 7L12 12L22 7L12 2Z"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default ComplexIcon;
```

2. Export it in `/design-system/icons/assets/index.ts`:

```tsx
export { default as ComplexIcon } from './svg/complex-icon.svg?react';
```

3. Use it in your components:

```tsx
<Icon type="ComplexIcon" size="lg" />
```

### SVG Best Practices

- **Use currentColor**: This allows the icon to inherit text color
- **24x24 viewBox**: Maintains consistency with Lucide icons
- **Clean paths**: Optimize SVG paths for better performance
- **Semantic naming**: Use descriptive names for your icons
- **Stroke-based**: Prefer stroke-based icons for consistency

## Tree-Shaking

The icon system is designed for optimal tree-shaking:

- **Lucide icons**: Only imported icons are included in the bundle
- **Custom icons**: Only exported custom icons are included
- **Dynamic imports**: Icons are resolved at runtime, allowing for conditional loading

### Best Practices

1. **Import only what you need**: Don't import the entire icon library
2. **Use the Icon component**: Instead of importing individual icons directly
3. **Export custom icons selectively**: Only export custom icons that are actually used
4. **Monitor bundle size**: Use tools like webpack-bundle-analyzer to verify tree-shaking

## Switching Icon Libraries

The system is designed to be easily extensible. To switch from Lucide to another icon library:

1. Create a new icon mapping file (e.g., `heroicons.ts`)
2. Update the `Icon` component to support the new library
3. Update the type definitions
4. Migrate existing icon usage

Example for Heroicons:

```tsx
// /design-system/icons/heroicons.ts
export { ChevronDownIcon } from '@heroicons/react/24/outline';
export { SearchIcon } from '@heroicons/react/24/outline';
// ... more icons

// Update icon.tsx to support Heroicons
const HeroiconComponent = Heroicons[type as HeroiconType];
```

## API Reference

### Icon Component Props

| Prop           | Type       | Default | Description                   |
| -------------- | ---------- | ------- | ----------------------------- |
| `type`         | `IconType` | -       | The type of icon to render    |
| `size`         | `IconSize` | `'md'`  | The size of the icon          |
| `className`    | `string`   | -       | Additional CSS classes        |
| `inheritColor` | `boolean`  | `true`  | Whether to inherit text color |
| `rotate`       | `number`   | -       | Rotation angle in degrees     |
| `...props`     | `SVGProps` | -       | All standard SVG props        |

### Types

```tsx
type IconSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | number;
type IconType = LucideIconType | CustomIconType;
```

### Size Mapping

| Size | Pixels |
| ---- | ------ |
| xs   | 12px   |
| sm   | 16px   |
| md   | 20px   |
| lg   | 24px   |
| xl   | 32px   |
| 2xl  | 40px   |
| 3xl  | 48px   |

## Examples

### Button with Icon

```tsx
import { Icon } from '@/design-system/icons';
import { Button } from '@/design-system/primitives/button';

function SearchButton() {
  return (
    <Button>
      <Icon type="Search" size="sm" className="mr-2" />
      Search
    </Button>
  );
}
```

### Loading State

```tsx
import { Icon } from '@/design-system/icons';

function LoadingSpinner() {
  return (
    <Icon type="RefreshCw" size="lg" className="animate-spin text-blue-500" />
  );
}

function RotatedIcon() {
  return (
    <Icon type="ChevronDown" size="lg" rotate={90} className="text-blue-500" />
  );
}
```

### Interactive Icon

```tsx
import { Icon } from '@/design-system/icons';
import { useState } from 'react';

function LikeButton() {
  const [isLiked, setIsLiked] = useState(false);

  return (
    <button
      onClick={() => setIsLiked(!isLiked)}
      className="p-2 rounded-full hover:bg-gray-100 transition-colors"
    >
      <Icon
        type="Heart"
        size="lg"
        className={isLiked ? 'text-red-500 fill-current' : 'text-gray-400'}
      />
    </button>
  );
}
```

## Troubleshooting

### Icon Not Found

If you see a warning about an icon not being found:

1. Check that the icon name is spelled correctly
2. Verify the icon is exported from the appropriate file
3. For Lucide icons, check the `lucide-icons.ts` file
4. For custom icons, check the `assets/index.ts` file

### TypeScript Errors

If you get TypeScript errors:

1. Make sure the icon type is included in the `IconType` union
2. Check that custom icons are properly exported
3. Verify the component follows the correct interface

### Bundle Size Issues

If your bundle size is larger than expected:

1. Check that you're not importing unused icons
2. Verify tree-shaking is working in your build
3. Use the Icon component instead of direct imports
4. Consider using dynamic imports for rarely used icons

## Contributing

When adding new icons:

1. Follow the existing naming conventions
2. Add proper TypeScript types
3. Include JSDoc comments
4. Update the documentation
5. Add Storybook stories for new icon types
