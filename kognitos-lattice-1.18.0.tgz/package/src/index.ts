/**
 * Design System Main Export
 *
 * A comprehensive design system that provides design tokens, theming, and pre-built components
 * that work seamlessly with Tailwind CSS. Built with TypeScript and optimized for React applications.
 *
 * @example
 * ```tsx
 * import { ds } from '@/design-system';
 *
 * // For semantic color references
 * const primaryColor = ds.color('primary'); // Returns "var(--primary)"
 *
 * // For theme management
 * ds.applyTheme('dark');
 * ```
 *
 * @see {@link README.md} Full documentation
 * @see {@link API.md} Complete API reference
 * @see {@link QUICKSTART.md} Quick start guide
 */

// ============================================================================
// CORE DESIGN SYSTEM
// ============================================================================

// Main design system instance and types
export { designSystem, ds } from './config';

export type { TDesignSystem, TDS } from './config';

// Default export - Main design system instance
import { designSystem } from './config';
export default designSystem;

// ============================================================================
// DESIGN TOKENS
// ============================================================================

// All design tokens (colors, spacing, typography, etc.)
export * from './tokens';
export type {
  TColorToken,
  TBaseColorKey,
  TThemeColorKey,
} from './tokens/colors';

// ============================================================================
// THEME MANAGEMENT
// ============================================================================

// Theme utilities
export { applyTheme, getTokenValue } from './lib/utils/theme';
export type { TTheme } from './theme/theme-context';

// Theme provider and hook
export { ThemeProvider } from './theme/theme-provider';
export { useTheme } from './theme/use-theme';
export { ModeToggle } from './theme/mode-toggle';

// ============================================================================
// UTILITIES
// ============================================================================

// Utility functions
export { cn, toISO8601, formatDate } from './lib/utils';

// ============================================================================
// HOOKS
// ============================================================================

// Custom hooks
export { useIsMobile } from './hooks/use-mobile';

// ============================================================================
// UI COMPONENTS
// ============================================================================

// Icon System
export {
  Chat,
  ChatMessage,
  ChatMessageAttachment,
  ChatStatus,
  ChatMessageWidget,
  ChatActionCardWidget,
  ChatButtonGroupWidget,
  ChatThinkingMessage,
  chatVariants,
  messageContainerVariants,
  messageBubbleVariants,
  ChatInput,
  ChatToast,
  useChat,
  EMessageDirection,
  EMessageVariant,
  EMessageStatus,
  EAttachmentType,
  EMessageUpdateState,
  EWidgetType,
  EMessageType,
  getAttachmentIcon,
  getAttachmentColorClass,
} from './components/chat';
export type {
  IChatMessage,
  IChatAttachment,
  IChatMessageWidget,
  IChatMessageButton,
  IChatMessageActionCard,
  TMessageDirection,
  TMessageVariant,
  TMessageStatus,
  TAttachmentType,
  TMessageType,
  IChatProps,
  IChatMessageProps,
  IChatMessageAttachmentProps,
  IChatStatusProps,
  IChatThinkingMessageProps,
  IChatThinkingTexts,
  TMessageUpdateState,
  TWidgetType,
  IChatInputProps,
  IChatToastProps,
  IUseChatReturn,
} from './components/chat';

export { Icon, type IIconProps, type IconSize, type IconType } from './icons';
export * from './icons';

export { EmptyState, type IEmptyStateProps } from './components/empty-state';
export {
  InsightsCard,
  InsightsCardTrend,
  insightsCardVariants,
  type IInsightsCardProps,
  type IInsightsCardTrendProps,
} from './components/insights-card';
export {
  StepCard,
  EStepState,
  type IStepCardProps,
} from './components/step-card';

// ============================================================================
// PRIMITIVE COMPONENTS
// ============================================================================

// General Components
export { Button, buttonVariants, type IButtonProps } from './primitives/button';
export {
  ButtonGroup,
  ButtonGroupSeparator,
  ButtonGroupText,
  buttonGroupVariants,
  type IButtonGroupProps,
} from './primitives/button-group';
export {
  Toolbar,
  ToolbarGroup,
  ToolbarButton,
  ToolbarBadge,
  ToolbarSeparator,
  type IToolbarProps,
  type IToolbarGroupProps,
  type IToolbarButtonProps,
  type IToolbarBadgeProps,
} from './primitives/toolbar';
export { Kbd, KbdGroup } from './primitives/kbd';

// Page Layout Components
export {
  PageLayout,
  PageHeader,
  PageContent,
  CenteredContent,
  PillBadge,
} from './components/page-layout';

// Layout Components
export { AspectRatio } from './primitives/aspect-ratio';
export {
  Card,
  CardHeader,
  CardFooter,
  CardTitle,
  CardAction,
  CardDescription,
  CardContent,
} from './primitives/card';
export { Flex, flexVariants } from './primitives/flex';
export type { IFlexProps } from './primitives/flex';
export { Grid, gridVariants } from './primitives/grid';
export type { IGridProps } from './primitives/grid';
export {
  Separator,
  separatorVariants,
  type ISeparatorProps,
} from './primitives/separator';
export { Skeleton } from './primitives/skeleton';
export {
  ShimmeringText,
  type TShimmeringTextProps,
} from './primitives/shimmering-text';

// Typography Components
export {
  Title,
  Text,
  titleVariants,
  textVariants,
} from './primitives/typography';
export type {
  ITitleProps,
  ITextProps,
  TextLevel,
  TextType,
  TextColor,
  TextAlign,
  TextWeight,
  TitleLevel,
  TitleColor,
  TitleAlign,
} from './primitives/typography';

// Markdown Component
export { Markdown, createMarkdownComponents } from './primitives/markdown';
export type { IMarkdownProps } from './primitives/markdown';

// Navigation Components
export {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from './primitives/breadcrumb';
export {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
  NavigationMenuViewport,
} from './primitives/navigation-menu';
export {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from './primitives/pagination';
export {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupAction,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInput,
  SidebarInset,
  SidebarMenu,
  SidebarMenuAction,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSkeleton,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
  SidebarProvider,
  SidebarRail,
  SidebarSeparator,
  SidebarTrigger,
  useSidebar,
} from './primitives/sidebar';
export { Tabs, TabsContent, TabsList, TabsTrigger } from './primitives/tabs';

// Data Entry Components
export { Checkbox } from './primitives/checkbox';
export {
  Field,
  FieldLabel,
  FieldDescription,
  FieldError,
  FieldGroup,
  FieldLegend,
  FieldSeparator,
  FieldSet,
  FieldContent,
  FieldTitle,
  fieldVariants,
} from './primitives/field';
export {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  useFormField,
} from './primitives/form';
export { Input } from './primitives/input';
export {
  InputGroup,
  InputGroupAddon,
  InputGroupButton,
  InputGroupText,
  InputGroupInput,
  InputGroupTextarea,
} from './primitives/input-group';
export { InputOTP, InputOTPGroup, InputOTPSlot } from './primitives/input-otp';
export { Label } from './primitives/label';
export { RadioGroup, RadioGroupItem } from './primitives/radio-group';
export {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectSeparator,
  SelectTrigger,
  SelectValue,
  type ISelectProps,
  type ISelectTriggerProps,
} from './primitives/select';
export { Slider } from './primitives/slider';
export { Switch } from './primitives/switch';
export {
  Textarea,
  textareaVariants,
  type ITextareaProps,
} from './primitives/textarea';
export { Toggle, toggleVariants } from './primitives/toggle';
export {
  ToggleButtons,
  ToggleButtonItem,
  type IToggleButtonsProps,
  type IToggleButtonItemProps,
} from './primitives/toggle-buttons';
export { ToggleGroup, ToggleGroupItem } from './primitives/toggle-group';

// Data Display Components
export {
  Asset,
  AssetType,
  EAssetTypeVariant,
  type TAssetTypeVariant,
  type IAssetProps,
  type IAssetTypeProps,
} from './primitives/asset';
export { Avatar, AvatarFallback, AvatarImage } from './primitives/avatar';
export { Badge, badgeVariants, type IBadgeProps } from './primitives/badge';
export { Calendar } from './primitives/calendar';
export {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  ChartLegend,
  ChartLegendContent,
  ChartStyle,
  type TChartConfig,
} from './primitives/chart';
export {
  DatePicker,
  DateRangePicker,
  DatePickerInput,
} from './primitives/date-picker';
export {
  DataTable,
  type IDataTableProps,
  type IDataTableColDef,
  type IDataTableCellRendererParams,
  type IDataTableValueFormatterParams,
  type IDataTableGridOptions,
  type IDataTableTextFilterParams,
  type IDataTableRowClickedEvent,
} from './primitives/data-table';
export {
  Item,
  ItemMedia,
  ItemContent,
  ItemActions,
  ItemGroup,
  ItemSeparator,
  ItemTitle,
  ItemDescription,
  ItemHeader,
  ItemFooter,
  itemVariants,
  itemMediaVariants,
} from './primitives/item';
export { Progress, type IProgressProps } from './primitives/progress';
export {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from './primitives/table';

// Feedback Components
export { Alert, AlertDescription, AlertTitle } from './primitives/alert';
export {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from './primitives/alert-dialog';
export { BrandLoader } from './primitives/brand-loader';
export {
  Empty,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyDescription,
  EmptyContent,
} from './primitives/empty';
export { Spinner } from './primitives/spinner';
export { Toaster, toast } from './primitives/sonner';

// Overlay Components
export {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from './primitives/collapsible';
export {
  Command,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
  CommandShortcut,
} from './primitives/command';
export {
  ContextMenu,
  ContextMenuCheckboxItem,
  ContextMenuContent,
  ContextMenuGroup,
  ContextMenuItem,
  ContextMenuLabel,
  ContextMenuRadioGroup,
  ContextMenuRadioItem,
  ContextMenuSeparator,
  ContextMenuShortcut,
  ContextMenuSub,
  ContextMenuSubContent,
  ContextMenuSubTrigger,
  ContextMenuTrigger,
} from './primitives/context-menu';
export {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './primitives/dialog';
export {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerDescription,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from './primitives/drawer';
export {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  ShortcutDisplay,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
  type IDropdownMenuItemProps,
} from './primitives/dropdown-menu';
export {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from './primitives/hover-card';
export {
  Menubar,
  MenubarCheckboxItem,
  MenubarContent,
  MenubarGroup,
  MenubarItem,
  MenubarLabel,
  MenubarMenu,
  MenubarRadioGroup,
  MenubarRadioItem,
  MenubarSeparator,
  MenubarShortcut,
  MenubarSub,
  MenubarSubContent,
  MenubarSubTrigger,
  MenubarTrigger,
} from './primitives/menubar';
export { Popover, PopoverContent, PopoverTrigger } from './primitives/popover';
export {
  Combobox,
  MultiCombobox,
  type IComboboxOption,
  type IComboboxProps,
  type IMultiComboboxProps,
} from './primitives/combobox';
export {
  ResizablePanelGroup,
  ResizablePanel,
  ResizableHandle,
} from './primitives/resizable';
export { ScrollArea, ScrollBar } from './primitives/scroll-area';
export {
  Sheet,
  SheetClose,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from './primitives/sheet';
export {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from './primitives/tooltip';

// Interactive Components
export {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './primitives/accordion';
export {
  Carousel,
  type TCarouselApi,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from './primitives/carousel';
export {
  StepIndicator,
  stepIndicatorVariants,
  type StepIndicatorProps,
  type StepIndicatorVariants,
} from './primitives/step-indicator';
export {
  EStepperCardState,
  EStepperCardVariant,
  StepperCardContent,
  StepperCardItem,
  StepperCardIcon,
  StepperCardTitle,
  StepperCardDescription,
} from './primitives/stepper-card-items';
export {
  StepperCard,
  EStepperCardDirection,
  type IStepperCardProps,
  type IStepperCardItemData,
} from './primitives/stepper-card';

// Flow Chart Components
export {
  default as FlowChart,
  type IFlowChartProps,
} from './primitives/flow-chart';
export {
  transformFlowGraphToFlowChart,
  FlowNodeType,
  type TFlowNodeType,
  type IFlowNode,
  type IFlowEdge,
  type IFlowGraph,
} from './primitives/flow-chart.utils';
