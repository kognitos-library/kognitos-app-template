// Design System Configuration
// Central configuration that integrates all design tokens and provides a unified API
// Maintains compatibility with both ShadCN and Figma design tokens

import { themeColors, getColorToken, type TColorToken } from './tokens/colors';
import { applyTheme } from './lib/utils/theme';
import type { TTheme } from './theme/theme-context';

// Design System Configuration Interface
export interface IDesignSystemConfig {
  themeConfig: typeof themeColors;
  tokens: {
    colors: {
      get: (token: TColorToken) => string;
    };
  };
  theme: {
    apply: (mode: TTheme) => void;
  };
}

// Design System Configuration
export const designSystem: IDesignSystemConfig = {
  themeConfig: themeColors,
  tokens: {
    colors: {
      get: (token: TColorToken) => getColorToken(token),
    },
  },
  theme: {
    apply: (mode: TTheme) => applyTheme(mode),
  },
};

// Utility functions for common design system operations
export const ds = {
  // Color utilities
  color: (token: TColorToken) => designSystem.tokens.colors.get(token),

  // Theme utilities
  applyTheme: (mode: TTheme) => designSystem.theme.apply(mode),
};

// Export the design system as default
export default designSystem;

// Type exports
export type TDesignSystem = typeof designSystem;
export type TDS = typeof ds;
