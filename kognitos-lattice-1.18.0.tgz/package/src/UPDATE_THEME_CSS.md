# Updating theme.css with Figma Shadcn Plugin

This guide explains how to update the `theme.css` file using the Figma Shadcn plugin to keep design tokens synchronized between Figma and code.

## 📋 Prerequisites

1. **Figma Desktop App** - The plugin works best with the desktop app
2. **Shadcn/ui Figma Plugin** - Install from [shadcn/ui Figma plugin](https://ui.shadcn.com/figma), you'll need Gemini a supported AI model token to use the plugin.
3. **Access to Design File** - Ensure you have access to the design system Figma file
4. **Git Access** - To review changes before committing

> **⚠️ License Restriction**: Our Shadcn/ui Figma plugin license allows **only 3 team members** to have access to the plugin (not the Figma file itself). If you need access to the plugin to update design tokens, please coordinate with the design team or team lead to ensure you're one of the authorized users. If all 3 plugin slots are currently in use, you may need to request changes from an existing authorized user.

## 🎯 Overview

The `theme.css` file contains all design tokens as CSS custom properties using the **OKLCH color system**. This file is the single source of truth for colors in the codebase and must be kept in sync with Figma designs.

### File Structure

The `theme.css` file has the following structure:

1. **Custom Variants** - Dark mode variant definition
2. **@theme inline** - Tailwind theme variable mappings
3. **:root** - Light theme OKLCH color values
4. **.dark** - Dark theme OKLCH color values
5. **@layer utilities** - Custom utility classes
6. **@layer base** - Base styles and typography

## 🔄 Update Process

### Step 1: Prepare Figma File

1. Open the design system file in Figma Desktop
2. Ensure all design tokens are properly set up in Figma variables
3. **No frame or component selection needed** - The plugin works on the entire design system library and automatically detects all design tokens and differences

### Step 2: Generate CSS Variables with Plugin

1. **Open the Shadcn/ui Plugin**:
   - In Figma, go to `Plugins` → `shadcn/ui` → `Generate CSS Variables`
   - Or use the keyboard shortcut if configured

2. **Configure Plugin Settings**:
   - ✅ **Color Format**: Select **OKLCH** from the plugin's color format dropdown (not RGB, HSL, or HEX)
   - ✅ **Output Format**: Select **CSS Variables**
   - ✅ **Variable Prefix**: Should be `--` (default)

   **Note**: The OKLCH format selection is made **within the plugin interface**, not in Figma settings.

3. **Generate Variables**:
   - Click "Export Theme Settings"
   - Then choose either "Copy CSS" or Copy CLI command"
   - The plugin will generate CSS variables in OKLCH format
   - After replacing the src/theme.css file, make sure to revert any unnecessary changes to the file before pushing to the repository (e.g. classname groups generated due to custom token in figma variables etc.).

### Step 3: Review Generated Output

Before updating the file, verify the generated CSS:

**✅ Check for OKLCH Format**:

```css
/* ✅ CORRECT - OKLCH format */
--brand: oklch(0.963 0.166 113.862);
--background: oklch(1 0 0);
--border: oklch(1 0 0 / 10%);

/* ✅ CORRECT - CSS variable references (used for theme variations) */
--primary: var(--brand-15);
--chart-1: var(--brand-15);

/* ❌ INCORRECT - Other color formats */
--brand: rgb(255, 0, 0);
--background: #ffffff;
--brand: hsl(0, 100%, 50%);
```

**✅ Check Variable Names**:

- Variables should match existing names exactly
- Standard shadcn/ui tokens: `--background`, `--foreground`, `--primary`, `--secondary`, `--muted`, `--accent`, `--destructive`, `--border`, `--input`, `--ring`, `--card`, `--popover`, etc.
- Sidebar tokens: `--sidebar`, `--sidebar-foreground`, `--sidebar-primary`, `--sidebar-accent`, `--sidebar-border`, `--sidebar-ring`, `--sidebar-muted`
- Chart tokens: `--chart-1` through `--chart-10`
- Semantic colors: `--warning`, `--warning-foreground`, `--link`, `--success`, `--success-foreground`, `--informative`, `--informative-foreground`
- Alternate colors: `--alternate-1` through `--alternate-9`
- Brand colors: `--brand`, `--brand-10` through `--brand-60` (internal use, not exposed as Tailwind tokens)
- Custom tokens: `--button-primary`, `--transparent`

**✅ Check Structure**:

- Light theme variables in `:root` block
- Dark theme variables in `.dark` block
- Both blocks should have the same variable names

### Step 4: Update theme.css File

**⚠️ IMPORTANT**: Only update the color variable sections. Do NOT modify:

- Custom variants
- @theme inline mappings (unless new tokens are added)
- @layer utilities
- @layer base styles
- Typography definitions
- Comments

#### What to Update

1. **:root block**:
   - Update OKLCH color values for light theme
   - Keep variable names unchanged
   - Maintain structure and formatting
   - Note: Some variables use `var()` references (e.g., `--primary: var(--brand-15)`, chart colors referencing brand variants)

2. **.dark block**:
   - Update OKLCH color values for dark theme
   - Keep variable names unchanged
   - Maintain structure and formatting
   - Note: Dark theme may have different variable references than light theme (e.g., `--primary: var(--brand)` vs `var(--brand-15)`)

3. **@theme inline block**:
   - Only update if new tokens are added
   - Keep existing mappings unchanged
   - Note: Brand variants (`--brand-10` through `--brand-60`) are intentionally NOT exposed as Tailwind tokens

#### What NOT to Update

- ❌ Custom variant definitions
- ❌ @layer utilities
- ❌ @layer base styles
- ❌ Typography classes (`.heading-xl`, `.heading-lg`, etc.)
- ❌ Comments and documentation

### Step 5: Verify Changes

Before committing, perform these checks:

#### 1. Format Verification

```bash
# Check that all colors use OKLCH format
grep -n "oklch(" src/theme.css

# Check CSS variable references (these are valid)
grep -n "var(--" src/theme.css

# Verify no RGB/HEX/HSL values were introduced
grep -nE "(rgb|rgba|#[0-9a-fA-F]{3,6}|hsl|hsla)" src/theme.css
# Should return no results (or only in comments)
```

**Note**: CSS variable references like `var(--brand-15)` are valid and commonly used for theme variations (e.g., chart colors, primary colors that reference brand variants).

#### 2. Structure Verification

- ✅ `:root` block contains light theme variables
- ✅ `.dark` block contains dark theme variables
- ✅ Both blocks have matching variable names
- ✅ Variable names match @theme inline mappings
- ✅ No syntax errors (missing semicolons, brackets, etc.)

#### 3. Visual Verification

1. **Start Development Server**:

   ```bash
   yarn storybook
   ```

2. **Check Light Theme**:
   - Open the Storybook application
   - Verify colors match Figma design
   - Check all components render correctly

3. **Check Dark Theme**:
   - Toggle dark mode (or add `.dark` class to root)
   - Verify colors match Figma dark theme
   - Check all components render correctly

4. **Test Key Components**:
   - Buttons (primary, secondary, destructive)
   - Cards and surfaces
   - Text colors (foreground, muted)
   - Borders and inputs
   - Custom brand colors

#### 4. Git Diff Review

```bash
# Review changes before committing
git diff src/theme.css

# Verify only color values changed, not structure
# Look for:
# ✅ Only OKLCH values changed
# ✅ No new variables added (unless intentional)
# ✅ No variables removed (unless intentional)
# ✅ No structural changes (layers, etc.)
```

### Step 6: Commit Changes

Once verified:

```bash
# Stage the file
git add src/theme.css

# Commit with descriptive message
git commit -m "chore(design-system): update color tokens from Figma

- Updated OKLCH color values for light and dark themes
- Synced with latest Figma design tokens
- Verified no structural changes"
```

## 🔍 Common Issues & Solutions

### Issue: Plugin Generated RGB/HEX Instead of OKLCH

**Solution**:

1. Check plugin settings - ensure "OKLCH" is selected as color format in the plugin interface
2. Regenerate CSS variables with OKLCH format selected
3. Verify the generated output uses `oklch()` format before copying

### Issue: Missing Variables After Update

**Solution**:

1. Check if new variables were added in Figma
2. Verify plugin generated all variables
3. Manually add missing variables to both `:root` and `.dark` blocks
4. Add corresponding mappings to `@theme inline` block if needed

### Issue: Dark Theme Colors Look Wrong

**Solution**:

1. Verify `.dark` block has all variables from `:root` block
2. Check that dark theme values are actually darker/lighter as appropriate
3. Ensure `.dark` class is properly applied to root element
4. Verify CSS specificity (`.dark` should override `:root`)

### Issue: Colors Don't Match Figma

**Solution**:

1. Verify plugin is using the correct Figma file/frame
2. Check that Figma variables match what's in the design
3. Ensure OKLCH values are correctly copied
4. Clear browser cache and rebuild CSS

### Issue: Build Errors After Update

**Solution**:

1. Check for syntax errors (missing semicolons, brackets)
2. Verify all OKLCH values are valid format: `oklch(L C H)` or `oklch(L C H / alpha)`
3. Check for typos in variable names
4. Ensure no structural changes were made

## 📝 Best Practices

### ✅ DO

- ✅ Always use OKLCH format for colors
- ✅ Update both `:root` and `.dark` blocks together
- ✅ Verify changes visually before committing
- ✅ Review git diff to ensure only intended changes
- ✅ Test both light and dark themes
- ✅ Keep variable names consistent with shadcn/ui conventions
- ✅ Document any new custom variables added

### ❌ DON'T

- ❌ Don't mix color formats (OKLCH with RGB/HEX)
- ❌ Don't modify structure unless adding new tokens
- ❌ Don't remove existing variables without checking usage
- ❌ Don't skip visual verification
- ❌ Don't commit without reviewing git diff
- ❌ Don't modify layers or typography during color updates

## 🎨 OKLCH Color Format Reference

OKLCH format: `oklch(lightness chroma hue)` or `oklch(lightness chroma hue / alpha)`

**Examples**:

```css
/* Full opacity */
--brand: oklch(0.963 0.166 113.862);

/* With alpha transparency (decimal or percentage) */
--border: oklch(1 0 0 / 10%);
--transparent: oklch(1 0 0 / 0);

/* Grayscale (chroma = 0) */
--background: oklch(1 0 0);

/* Using CSS variable references */
--primary: var(--brand-15);
--chart-1: var(--brand-15);
```

**Components**:

- **Lightness**: 0-1 (0 = black, 1 = white)
- **Chroma**: 0-0.4 (0 = grayscale, higher = more saturated)
- **Hue**: 0-360 (degrees on color wheel)
- **Alpha**: 0-1 (optional, 0 = transparent, 1 = opaque)

## 🔗 Resources

- [Shadcn/ui Figma Plugin](https://ui.shadcn.com/figma)
- [OKLCH Color Space Guide](https://oklch.com/)
- [CSS Custom Properties MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/--*)
- [Design System README](../README.md)

## Support

If you encounter issues:

1. Check this guide for common solutions
2. Review the [Design System README](../README.md)
3. Consult with the design team for Figma or token inconsistency related issues
4. Check plugin documentation for generation issues

---

**Remember**: The goal is to keep design and code perfectly synchronized. Always verify changes visually and structurally before committing.
