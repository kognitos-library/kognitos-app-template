import { render, screen } from '@testing-library/react';
import { describe, it, expect, vi } from 'vitest';
import { ThemeProvider } from './theme-provider';
import { useTheme } from './use-theme';

// Mock useTernaryDarkMode
vi.mock('usehooks-ts', () => ({
  useTernaryDarkMode: vi.fn(() => ({
    isDarkMode: false,
    ternaryDarkMode: 'light',
    setTernaryDarkMode: vi.fn(),
    toggleTernaryDarkMode: vi.fn(),
  })),
}));

// Test component
function TestComponent() {
  const { theme, setTheme } = useTheme();

  return (
    <div>
      <div data-testid="theme-value">{theme}</div>
      <button onClick={() => setTheme('dark')} data-testid="set-dark">
        Set Dark
      </button>
    </div>
  );
}

describe('ThemeProvider with useTernaryDarkMode', () => {
  it('renders with theme context', () => {
    render(
      <ThemeProvider>
        <TestComponent />
      </ThemeProvider>,
    );

    expect(screen.getByTestId('theme-value')).toHaveTextContent('light');
    expect(screen.getByTestId('set-dark')).toBeInTheDocument();
  });
});
