import { useEffect, useMemo } from 'react';
import { useTernaryDarkMode } from 'usehooks-ts';
import { type TTheme, ThemeProviderContext } from './theme-context';

type TThemeProviderProps = {
  children: React.ReactNode;
  defaultTheme?: TTheme;
  storageKey?: string;
};

export function ThemeProvider({
  children,
  defaultTheme = 'system',
  storageKey = 'ui-theme',
  ...props
}: TThemeProviderProps) {
  const {
    isDarkMode,
    ternaryDarkMode: theme,
    setTernaryDarkMode: setTernaryTheme,
  } = useTernaryDarkMode({
    defaultValue: defaultTheme,
    localStorageKey: storageKey,
    initializeWithValue: true,
  });

  useEffect(() => {
    const root = window.document.documentElement;

    root.classList.remove('light', 'dark');

    if (isDarkMode) {
      root.classList.add('dark');
    } else {
      root.classList.add('light');
    }
  }, [isDarkMode]);

  const value = useMemo(
    () => ({
      theme,
      setTheme: (theme: TTheme) => {
        setTernaryTheme(theme);
      },
    }),
    [theme, setTernaryTheme],
  );

  return (
    <ThemeProviderContext {...props} value={value}>
      {children}
    </ThemeProviderContext>
  );
}
