import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import userEvent from '@testing-library/user-event';
import { ModeToggle } from './mode-toggle';
import { ThemeProvider } from './theme-provider';

// Mock useTernaryDarkMode
vi.mock('usehooks-ts', () => ({
  useTernaryDarkMode: vi.fn(() => ({
    isDarkMode: false,
    ternaryDarkMode: 'light',
    setTernaryDarkMode: vi.fn(),
    toggleTernaryDarkMode: vi.fn(),
  })),
}));

// Mock the Icon component to avoid complex icon rendering in tests
vi.mock('../icons', () => ({
  Icon: ({
    type,
    className,
    ...props
  }: {
    type: string;
    className?: string;
    [key: string]: unknown;
  }) => (
    <div
      data-testid={`icon-${type.toLowerCase()}`}
      className={className}
      {...props}
    >
      {type}
    </div>
  ),
}));

describe('ModeToggle', () => {
  const renderModeToggle = () => {
    return render(
      <ThemeProvider>
        <ModeToggle />
      </ThemeProvider>,
    );
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Rendering', () => {
    it('renders the mode toggle button', () => {
      renderModeToggle();

      const button = screen.getByRole('button');
      expect(button).toBeInTheDocument();
    });

    it('renders sun and moon icons', () => {
      renderModeToggle();

      expect(screen.getByTestId('icon-sun')).toBeInTheDocument();
      expect(screen.getByTestId('icon-moon')).toBeInTheDocument();
    });

    it('has proper accessibility label', () => {
      renderModeToggle();

      const srOnlyText = screen.getByText('Toggle theme');
      expect(srOnlyText).toHaveClass('sr-only');
    });

    it('renders with correct button styling', () => {
      renderModeToggle();

      const button = screen.getByRole('button');
      // The button should have the variant="outline" styling applied
      expect(button).toHaveClass('border');
    });
  });

  describe('Dropdown Menu', () => {
    it('opens dropdown menu when button is clicked', async () => {
      const user = userEvent.setup();
      renderModeToggle();

      const button = screen.getByRole('button');
      await user.click(button);

      await waitFor(() => {
        expect(screen.getByText('Light')).toBeInTheDocument();
        expect(screen.getByText('Dark')).toBeInTheDocument();
        expect(screen.getByText('System')).toBeInTheDocument();
      });
    });

    it('closes dropdown menu when pressing Escape key', async () => {
      const user = userEvent.setup();
      renderModeToggle();

      const button = screen.getByRole('button');
      await user.click(button);

      // Verify menu is open
      await waitFor(() => {
        expect(screen.getByText('Light')).toBeInTheDocument();
      });

      // Press Escape to close
      fireEvent.keyDown(document, { key: 'Escape' });

      await waitFor(() => {
        expect(screen.queryByText('Light')).not.toBeInTheDocument();
      });
    });
  });

  describe('Theme Selection', () => {
    it('shows theme options when menu is opened', async () => {
      const user = userEvent.setup();
      renderModeToggle();

      const button = screen.getByRole('button');
      await user.click(button);

      await waitFor(() => {
        expect(screen.getByText('Light')).toBeInTheDocument();
        expect(screen.getByText('Dark')).toBeInTheDocument();
        expect(screen.getByText('System')).toBeInTheDocument();
      });
    });

    it('can interact with theme options', async () => {
      const user = userEvent.setup();
      renderModeToggle();

      const button = screen.getByRole('button');
      await user.click(button);

      // Verify all options are present and clickable
      const lightOption = screen.getByText('Light');
      const darkOption = screen.getByText('Dark');
      const systemOption = screen.getByText('System');

      expect(lightOption).toBeInTheDocument();
      expect(darkOption).toBeInTheDocument();
      expect(systemOption).toBeInTheDocument();

      // Test that options are clickable by checking their role
      expect(lightOption).toHaveAttribute('role', 'menuitem');
      expect(darkOption).toHaveAttribute('role', 'menuitem');
      expect(systemOption).toHaveAttribute('role', 'menuitem');
    });
  });

  describe('Keyboard Navigation', () => {
    it('opens dropdown menu when Enter key is pressed', async () => {
      const user = userEvent.setup();
      renderModeToggle();

      const button = screen.getByRole('button');
      button.focus();
      await user.keyboard('{Enter}');

      await waitFor(() => {
        expect(screen.getByText('Light')).toBeInTheDocument();
      });
    });

    it('opens dropdown menu when Space key is pressed', async () => {
      const user = userEvent.setup();
      renderModeToggle();

      const button = screen.getByRole('button');
      button.focus();
      await user.keyboard(' ');

      await waitFor(() => {
        expect(screen.getByText('Light')).toBeInTheDocument();
      });
    });

    it('navigates through menu items with arrow keys', async () => {
      const user = userEvent.setup();
      renderModeToggle();

      const button = screen.getByRole('button');
      await user.click(button);

      // Wait for menu to be visible
      await waitFor(() => {
        expect(screen.getByText('Light')).toBeInTheDocument();
      });

      // Test arrow key navigation
      await user.keyboard('{ArrowDown}');
      await user.keyboard('{ArrowDown}');
      await user.keyboard('{ArrowUp}');

      // Menu should still be visible
      expect(screen.getByText('Light')).toBeInTheDocument();
    });
  });

  describe('Accessibility', () => {
    it('has proper ARIA attributes', () => {
      renderModeToggle();

      const button = screen.getByRole('button');
      expect(button).toHaveAttribute('aria-haspopup', 'menu');
    });

    it('supports screen reader navigation', () => {
      renderModeToggle();

      const button = screen.getByRole('button');
      const srOnlyText = screen.getByText('Toggle theme');

      expect(button).toBeInTheDocument();
      expect(srOnlyText).toBeInTheDocument();
      expect(srOnlyText).toHaveClass('sr-only');
    });
  });

  describe('Icon Styling', () => {
    it('applies correct CSS classes to sun icon', () => {
      renderModeToggle();

      const sunIcon = screen.getByTestId('icon-sun');
      expect(sunIcon).toHaveClass(
        'scale-100',
        'rotate-0',
        'transition-all',
        'dark:scale-0',
        'dark:-rotate-90',
      );
    });

    it('applies correct CSS classes to moon icon', () => {
      renderModeToggle();

      const moonIcon = screen.getByTestId('icon-moon');
      expect(moonIcon).toHaveClass(
        'absolute',
        'scale-0',
        'rotate-90',
        'transition-all',
        'dark:scale-100',
        'dark:rotate-0',
      );
    });

    it('renders icons with correct size', () => {
      renderModeToggle();

      const sunIcon = screen.getByTestId('icon-sun');
      const moonIcon = screen.getByTestId('icon-moon');

      expect(sunIcon).toHaveAttribute('size', '20');
      expect(moonIcon).toHaveAttribute('size', '20');
    });
  });

  describe('Integration with ThemeProvider', () => {
    it('renders without crashing when wrapped in ThemeProvider', () => {
      expect(() => renderModeToggle()).not.toThrow();
    });

    it('maintains proper component hierarchy', () => {
      renderModeToggle();

      const button = screen.getByRole('button');
      const sunIcon = screen.getByTestId('icon-sun');
      const moonIcon = screen.getByTestId('icon-moon');

      expect(button).toContainElement(sunIcon);
      expect(button).toContainElement(moonIcon);
    });
  });
});
