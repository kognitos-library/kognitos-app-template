import { createContext } from 'react';

export type TTheme = 'dark' | 'light' | 'system';

export type IThemeProviderState = {
  theme: TTheme;
  setTheme: (theme: TTheme) => void;
};

const initialState: IThemeProviderState = {
  theme: 'system',
  setTheme: () => null,
};

export const ThemeProviderContext =
  createContext<IThemeProviderState>(initialState);
