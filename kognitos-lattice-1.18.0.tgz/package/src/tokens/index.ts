// Design System Tokens
// This file serves as the central export for all design tokens
// Organized to match the Figma token structure while maintaining ShadCN compatibility

export * from './colors';
