// Color Tokens
// This file provides TypeScript access to the CSS variables defined in index.css
// Benefits of this approach:
// 1. Single source of truth: index.css is the authoritative source for color values
// 2. shadcn plugin compatibility: The plugin can modify index.css and changes are reflected here
// 3. Type safety: TypeScript provides autocomplete and type checking for color names
// 4. Runtime flexibility: CSS variables can be dynamically changed via CSS custom properties

// Base Colors (minimal set)
export const baseColors = {
  black: '#000000',
  white: '#ffffff',
  transparent: 'rgba(255, 255, 255, 0)',
} as const;

// Theme Colors - Reference CSS variables defined in index.css
// CSS variables automatically switch between light/dark values based on the .dark class
// This creates a single source of truth where index.css is the authoritative source
export const themeColors = {
  accent: 'var(--accent)',
  'accent-foreground': 'var(--accent-foreground)',
  background: 'var(--background)',
  border: 'var(--border)',
  card: 'var(--card)',
  'card-foreground': 'var(--card-foreground)',
  destructive: 'var(--destructive)',
  foreground: 'var(--foreground)',
  input: 'var(--input)',
  muted: 'var(--muted)',
  'muted-foreground': 'var(--muted-foreground)',
  popover: 'var(--popover)',
  'popover-foreground': 'var(--popover-foreground)',
  primary: 'var(--primary)',
  'primary-foreground': 'var(--primary-foreground)',
  ring: 'var(--ring)',
  secondary: 'var(--secondary)',
  'secondary-foreground': 'var(--secondary-foreground)',
  // Chart colors
  'chart-1': 'var(--chart-1)',
  'chart-2': 'var(--chart-2)',
  'chart-3': 'var(--chart-3)',
  'chart-4': 'var(--chart-4)',
  'chart-5': 'var(--chart-5)',
  'chart-6': 'var(--chart-6)',
  'chart-7': 'var(--chart-7)',
  'chart-8': 'var(--chart-8)',
  'chart-9': 'var(--chart-9)',
  'chart-10': 'var(--chart-10)',
  // Sidebar colors
  sidebar: 'var(--sidebar)',
  'sidebar-foreground': 'var(--sidebar-foreground)',
  'sidebar-primary': 'var(--sidebar-primary)',
  'sidebar-primary-foreground': 'var(--sidebar-primary-foreground)',
  'sidebar-accent': 'var(--sidebar-accent)',
  'sidebar-accent-foreground': 'var(--sidebar-accent-foreground)',
  'sidebar-border': 'var(--sidebar-border)',
  'sidebar-ring': 'var(--sidebar-ring)',
  'sidebar-muted': 'var(--sidebar-muted)',
  // Button colors
  'button-primary': 'var(--button-primary)',
  // Custom theme colors
  brand: 'var(--brand)',
  warning: 'var(--warning)',
  'warning-foreground': 'var(--warning-foreground)',
  link: 'var(--link)',
  success: 'var(--success)',
  'success-foreground': 'var(--success-foreground)',
  informative: 'var(--informative)',
  'informative-foreground': 'var(--informative-foreground)',
  'alternate-1': 'var(--alternate-1)',
  'alternate-2': 'var(--alternate-2)',
  'alternate-3': 'var(--alternate-3)',
  'alternate-4': 'var(--alternate-4)',
  'alternate-5': 'var(--alternate-5)',
  'alternate-6': 'var(--alternate-6)',
  'alternate-7': 'var(--alternate-7)',
  'alternate-8': 'var(--alternate-8)',
  'alternate-9': 'var(--alternate-9)',
  transparent: 'var(--transparent)',
} as const;

// Helper function to get the current theme mode from the DOM
export const getCurrentThemeMode = (): 'light' | 'dark' => {
  if (typeof document === 'undefined') {
    return 'light'; // Default for SSR
  }

  const root = document.documentElement;
  if (root.classList.contains('dark')) {
    return 'dark';
  }
  if (root.classList.contains('light')) {
    return 'light';
  }

  // Check system preference if no explicit theme is set
  if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
    return 'dark';
  }

  return 'light';
};

// Create a union type of only theme and base colors
export type TColorToken = keyof typeof baseColors | keyof typeof themeColors;

// Color utility functions
export const getColorToken = (color: TColorToken) => {
  // Check theme colors (our semantic colors that reference CSS variables)
  if (color in themeColors) {
    const themeColor = themeColors[color as keyof typeof themeColors];
    return themeColor; // Return CSS variable reference instead of resolving
  }

  // Check base colors
  if (color in baseColors) {
    return baseColors[color as keyof typeof baseColors];
  }

  // This should never happen due to TypeScript's type checking,
  // but we'll throw an error for runtime safety
  throw new Error(
    `Invalid color: "${color}". Only theme colors and base colors are supported.`,
  );
};

// Type exports
export type TBaseColors = typeof baseColors;
export type TThemeColors = typeof themeColors;
export type TBaseColorKey = keyof typeof baseColors;
export type TThemeColorKey = keyof typeof themeColors;
